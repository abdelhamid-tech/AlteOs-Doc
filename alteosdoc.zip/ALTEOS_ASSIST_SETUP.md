# AlteOS Assist — configuration serveur

AlteOS Assist utilise une passerelle serveur. Les clés OpenAI ne sont jamais envoyées au navigateur.

## 1. Variables d'environnement

Copiez `.env.example` vers `.env` et définissez :

- `DATABASE_URL`
- `ADMIN_PASSWORD` — mot de passe du Control Center
- `ADMIN_SESSION_SECRET` — secret long (32+ caractères)
- `ALTEOS_KEY_ENCRYPTION_SECRET` — autre secret long (32+ caractères)
- `ALTEOS_AI_MODEL` — modèle OpenAI à utiliser

Ne committez jamais `.env`.

## 2. Base de données

Après installation :

```bash
npx prisma generate
npx prisma db push
```

## 3. Dashboard privé

Ouvrez :

`/admin/assist`

Connectez-vous avec `ADMIN_PASSWORD`.

Le dashboard permet de :

- ajouter plusieurs clés OpenAI ;
- les activer/désactiver ;
- les supprimer ;
- suivre les succès/erreurs ;
- consulter les statistiques sur 30 jours.

Les clés sont chiffrées en AES-256-GCM avec `ALTEOS_KEY_ENCRYPTION_SECRET`.

## 4. Fallback

AlteOS Assist essaie les clés OpenAI actives dans leur ordre de priorité. Pour les erreurs récupérables (clé invalide, quota/rate limit, erreurs temporaires du fournisseur), le serveur passe à la clé suivante.

Le client n'a accès qu'à `/api/assist` et ne reçoit jamais une clé API.
