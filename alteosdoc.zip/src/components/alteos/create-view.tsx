"use client";

/**
 * Vue Créer — Document, PDF, Design, Formulaire + Importer.
 * La zone de dépôt traite tout localement : aucun fichier n'est envoyé ailleurs.
 */

import { useRef, useState } from "react";
import { ClipboardList, FileText, LayoutTemplate, Loader2, PenLine, Upload } from "lucide-react";
import { toast } from "sonner";

import { useAppStore } from "@/store/app-store";
import type { DocKind } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const CREATE_OPTIONS: { kind: DocKind; title: string; desc: string; icon: typeof FileText }[] = [
  { kind: "document", title: "Document", desc: "Page blanche, titres, listes, tableaux, images.", icon: FileText },
  { kind: "pdf", title: "PDF", desc: "Ouvrir un PDF existant pour l'annoter et le modifier.", icon: PenLine },
  { kind: "design", title: "Design", desc: "Mise en page libre : déplacer et redimensionner chaque élément.", icon: LayoutTemplate },
  { kind: "form", title: "Formulaire", desc: "Document avec des champs remplissables et exportables.", icon: ClipboardList },
];

export default function CreateView() {
  const createDoc = useAppStore((s) => s.createDoc);
  const importFile = useAppStore((s) => s.importFile);
  const fileRef = useRef<HTMLInputElement>(null);
  const pdfRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  async function runImport(file: File) {
    setBusy(true);
    try {
      const res = await importFile(file);
      if (!res.ok) {
        toast.error(res.message ?? "Impossible d'ouvrir ce fichier", {
          description: "Le fichier semble endommagé ou son format n'est pas encore pris en charge.",
          action: { label: "Choisir un autre fichier", onClick: () => fileRef.current?.click() },
        });
      } else {
        toast.success("Document ouvert", { description: "Traité localement sur cet appareil." });
      }
    } finally {
      setBusy(false);
    }
  }

  async function handleCreate(kind: DocKind) {
    if (kind === "pdf") {
      pdfRef.current?.click();
      return;
    }
    await createDoc(kind);
  }

  return (
    <div className="aos-appear max-w-3xl mx-auto space-y-8">
      <header>
        <h1 className="text-2xl font-display font-semibold tracking-tight">Créer</h1>
        <p className="text-muted-foreground mt-1">Commencez à partir de zéro ou avec un fichier existant.</p>
      </header>

      <section aria-label="Nouveau document" className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {CREATE_OPTIONS.map((o) => {
          const Icon = o.icon;
          return (
            <button
              key={o.kind}
              onClick={() => handleCreate(o.kind)}
              className="group rounded-xl border bg-card p-5 flex items-start gap-4 text-left transition-all hover:border-primary/45 hover:shadow-sm focus-visible:outline-2 focus-visible:outline-ring"
            >
              <span className="grid place-items-center size-10 rounded-lg bg-secondary text-secondary-foreground/80 group-hover:bg-accent group-hover:text-accent-foreground transition-colors shrink-0">
                <Icon className="size-5" aria-hidden />
              </span>
              <span>
                <span className="block font-medium">{o.title}</span>
                <span className="block text-sm text-muted-foreground mt-1 leading-relaxed">{o.desc}</span>
              </span>
            </button>
          );
        })}
      </section>

      {/* Importer */}
      <section aria-labelledby="import-title">
        <h2 id="import-title" className="text-lg font-semibold tracking-tight mb-3">
          Importer
        </h2>
        <div
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") fileRef.current?.click();
          }}
          onClick={() => fileRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) runImport(f);
          }}
          className={cn(
            "rounded-xl border-2 border-dashed p-10 flex flex-col items-center gap-3 text-center cursor-pointer transition-colors focus-visible:outline-2 focus-visible:outline-ring",
            dragOver ? "border-primary bg-accent/50" : "border-border hover:border-primary/50 hover:bg-accent/25"
          )}
          aria-describedby="import-formats"
        >
          {busy ? (
            <Loader2 className="size-8 text-primary animate-spin" aria-hidden />
          ) : (
            <Upload className="size-8 text-muted-foreground/60" aria-hidden />
          )}
          <div>
            <p className="font-medium">{busy ? "Ouverture du document…" : "Déposer un fichier ici"}</p>
            <p id="import-formats" className="text-sm text-muted-foreground mt-1">
              PDF, images (PNG, JPEG, WebP) ou texte (TXT, MD)
            </p>
          </div>
          <Button variant="secondary" size="sm" className="h-9" disabled={busy}>
            Importer depuis l&apos;appareil
          </Button>
          <p className="text-xs text-muted-foreground/70 max-w-sm leading-relaxed">
            Le fichier est traité sur cet appareil et n&apos;est envoyé à aucun service externe.
          </p>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="application/pdf,image/png,image/jpeg,image/webp,.txt,.md,.pdf"
          className="sr-only"
          aria-label="Importer depuis l'appareil"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) runImport(f);
            e.currentTarget.value = "";
          }}
        />
        <input
          ref={pdfRef}
          type="file"
          accept="application/pdf,.pdf"
          className="sr-only"
          aria-label="Ouvrir un PDF"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) runImport(f);
            e.currentTarget.value = "";
          }}
        />
        <p className="mt-3 text-center">
          <button
            className="text-sm text-primary underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-ring rounded"
            onClick={async () => {
              try {
                const res = await fetch("/exemple.pdf");
                const blob = await res.blob();
                const file = new File([blob], "Exemple AlteOS.pdf", { type: "application/pdf" });
                await runImport(file);
              } catch {
                toast.error("Impossible de charger l'exemple");
              }
            }}
          >
            Essayer avec un PDF d&apos;exemple
          </button>
        </p>
      </section>
    </div>
  );
}
