"use client";

/**
 * Coquille AlteOS Docs — navigation principale et répartition des vues.
 * Ordinateur : rail latéral « studio ». Mobile : en-tête + navigation basse.
 * Le rail et l'en-tête appliquent l'accent signature choisi (data-accent).
 */

import { useEffect, useLayoutEffect } from "react";
import dynamic from "next/dynamic";
import { ThemeProvider, useTheme } from "next-themes";
import {
  BookOpen,
  FilePlus2,
  Home,
  LayoutTemplate,
  Moon,
  Search,
  Settings,
  Sparkles,
  Sun,
} from "lucide-react";

import { AlteosLogo } from "@/components/alteos/logo";
import { FontLoader } from "@/components/alteos/font-loader";
import { CommandPalette } from "@/components/alteos/command-palette";
import { CustomizeEditorDialog } from "@/components/alteos/customize/customize-editor";
import { useAppStore, type View } from "@/store/app-store";
import { useUiPrefs } from "@/store/ui-prefs";
import { formatBytes } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const HomeView = dynamic(() => import("@/components/alteos/home-view"), {
  loading: () => <ViewSkeleton />,
  ssr: false,
});
const CreateView = dynamic(() => import("@/components/alteos/create-view"), {
  loading: () => <ViewSkeleton />,
  ssr: false,
});
const DocumentsView = dynamic(() => import("@/components/alteos/documents-view"), {
  loading: () => <ViewSkeleton />,
  ssr: false,
});
const TemplatesView = dynamic(() => import("@/components/alteos/templates-view"), {
  loading: () => <ViewSkeleton />,
  ssr: false,
});
const AssistView = dynamic(() => import("@/components/alteos/assist-view"), {
  loading: () => <ViewSkeleton />,
  ssr: false,
});
const SettingsView = dynamic(() => import("@/components/alteos/settings-view"), {
  loading: () => <ViewSkeleton />,
  ssr: false,
});
const EditorRoot = dynamic(() => import("@/components/alteos/editor/editor-root"), {
  loading: () => <ViewSkeleton />,
  ssr: false,
});

function ViewSkeleton() {
  return (
    <div className="flex-1 grid place-items-center p-10" aria-busy="true" aria-label="Chargement">
      <div className="flex flex-col items-center gap-3 text-muted-foreground">
        <div className="h-8 w-8 rounded-full border-2 border-muted border-t-primary animate-spin" />
        <p className="text-sm">Chargement…</p>
      </div>
    </div>
  );
}

const NAV_ITEMS: { view: View; label: string; icon: typeof Home }[] = [
  { view: "home", label: "Accueil", icon: Home },
  { view: "create", label: "Créer", icon: FilePlus2 },
  { view: "documents", label: "Documents", icon: BookOpen },
  { view: "templates", label: "Modèles", icon: LayoutTemplate },
  { view: "assist", label: "AlteOS Assist", icon: Sparkles },
  { view: "settings", label: "Paramètres", icon: Settings },
];

/** Applique l'accent et la densité sur <html> (miroir localStorage : avant le premier rendu). */
function UiPrefsApplier() {
  const accent = useUiPrefs((s) => s.accent);
  const density = useUiPrefs((s) => s.density);

  useLayoutEffect(() => {
    try {
      const raw = localStorage.getItem("alteos.ui");
      if (raw) {
        const p = JSON.parse(raw) as { accent?: string; density?: string };
        if (p.accent) document.documentElement.dataset.accent = p.accent;
        if (p.density) document.documentElement.dataset.density = p.density;
      }
    } catch {
      /* rien : l'accent par défaut reste appliqué */
    }
  }, []);

  useEffect(() => {
    document.documentElement.dataset.accent = accent;
    document.documentElement.dataset.density = density;
  }, [accent, density]);

  return null;
}

function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";
  return (
    <Button
      variant="ghost"
      size="icon"
      className="size-8 text-muted-foreground"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      aria-label={isDark ? "Passer en thème clair" : "Passer en thème sombre"}
    >
      {isDark ? <Sun className="size-4" aria-hidden /> : <Moon className="size-4" aria-hidden />}
    </Button>
  );
}

export function AppShell() {
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const refreshDocs = useAppStore((s) => s.refreshDocs);
  const refreshStorage = useAppStore((s) => s.refreshStorage);
  const loading = useAppStore((s) => s.loading);
  const storageUsage = useAppStore((s) => s.storageUsage);
  const docsCount = useAppStore((s) => s.docs.filter((d) => !d.deletedAt).length);
  const hydrateUiPrefs = useUiPrefs((s) => s.hydrate);
  const editorCustomOpen = useUiPrefs((s) => s.editorCustomOpen);
  const setEditorCustomOpen = useUiPrefs((s) => s.setEditorCustomOpen);

  useEffect(() => {
    (async () => {
      // Les préférences de personnalisation précèdent l'affichage des vues.
      await hydrateUiPrefs();
      await refreshDocs();
      await refreshStorage();
      useAppStore.setState({ loading: false });
    })();
  }, [refreshDocs, refreshStorage, hydrateUiPrefs]);

  const isEditor = view === "editor";

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <FontLoader />
      <UiPrefsApplier />
      <CommandPalette />
      <CustomizeEditorDialog open={editorCustomOpen} onOpenChange={setEditorCustomOpen} />
      <div className="min-h-screen flex bg-background">
        {isEditor ? (
          <EditorRoot />
        ) : (
          <>
            {/* Rail latéral — ordinateur */}
            <aside className="aos-rail hidden md:flex flex-col w-[228px] shrink-0 sticky top-0 h-screen" aria-label="Navigation principale">
              <div className="h-16 flex items-center px-5" style={{ boxShadow: "inset 0 -1px 0 var(--sidebar-border)" }}>
                <button className="rounded-md focus-visible:outline-2 focus-visible:outline-ring" onClick={() => setView("home")} aria-label="AlteOS Docs — Accueil">
                  <AlteosLogo />
                </button>
              </div>

              <div className="px-4 pt-4 pb-3">
                <Button size="sm" className="w-full h-9" onClick={() => setView("create")}>
                  <FilePlus2 className="size-4 mr-1.5" aria-hidden />
                  Nouveau
                </Button>
                <button
                  onClick={() => window.dispatchEvent(new CustomEvent("alteos:open-command"))}
                  className="mt-2 w-full flex items-center gap-2 rounded-lg border bg-background/70 px-3 h-8 text-xs text-muted-foreground hover:border-primary/40 hover:text-foreground transition-colors"
                  aria-label="Rechercher une action (Ctrl+K)"
                >
                  <Search className="size-3.5 shrink-0" aria-hidden />
                  <span className="truncate">Rechercher…</span>
                  <kbd className="aos-kbd ml-auto shrink-0">Ctrl K</kbd>
                </button>
              </div>

              <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto editor-scroll" aria-label="Sections">
                {NAV_ITEMS.map((item) => (
                  <button
                    key={item.view}
                    className="aos-rail-item focus-visible:outline-2 focus-visible:outline-ring"
                    data-active={view === item.view}
                    onClick={() => setView(item.view)}
                    aria-current={view === item.view ? "page" : undefined}
                  >
                    <span className="aos-rail-dot" aria-hidden />
                    <item.icon className="size-4 shrink-0" aria-hidden />
                    {item.label === "AlteOS Assist" ? "AlteOS Assist" : item.label}
                  </button>
                ))}
              </nav>

              <div className="p-4 space-y-3" style={{ boxShadow: "inset 0 1px 0 var(--sidebar-border)" }}>
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[11px] text-muted-foreground leading-tight">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="inline-block size-1.5 rounded-full bg-primary shrink-0" aria-hidden />
                      {docsCount} document{docsCount > 1 ? "s" : ""}
                      {storageUsage != null && ` · ${formatBytes(storageUsage)}`}
                    </span>
                  </p>
                  <ThemeToggle />
                </div>
                <p className="text-[10.5px] leading-snug text-muted-foreground/75">
                  Tout est stocké et traité sur cet appareil.
                </p>
              </div>
            </aside>

            {/* Colonne principale */}
            <div className="flex-1 flex flex-col min-w-0">
              {/* En-tête mobile */}
              <header className="aos-topbar md:hidden sticky top-0 z-30" aria-label="En-tête">
                <div className="px-4 h-14 flex items-center justify-between">
                  <button
                    className="rounded-md focus-visible:outline-2 focus-visible:outline-ring px-1"
                    onClick={() => setView("home")}
                    aria-label="AlteOS Docs — Accueil"
                  >
                    <AlteosLogo compact />
                  </button>
                  <div className="flex items-center gap-1">
                    <ThemeToggle />
                    <Button size="sm" className="h-8" onClick={() => setView("create")}>
                      <FilePlus2 className="size-4 mr-1.5" aria-hidden />
                      Nouveau
                    </Button>
                  </div>
                </div>
              </header>

              {/* Contenu */}
              <main className="flex-1 w-full px-4 sm:px-6 lg:px-10 pb-24 md:pb-10 pt-6" id="contenu-principal">
                {loading ? (
                  <ViewSkeleton />
                ) : (
                  <>
                    {view === "home" && <HomeView />}
                    {view === "create" && <CreateView />}
                    {view === "documents" && <DocumentsView />}
                    {view === "templates" && <TemplatesView />}
                    {view === "assist" && <AssistView />}
                    {view === "settings" && <SettingsView />}
                  </>
                )}
              </main>

              {/* Pied de page */}
              <footer className="mt-auto border-t">
                <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-10 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
                  <p>AlteOS Docs — Créer sans limites. Modifier sans complexité. Garder le contrôle.</p>
                  <p className="inline-flex items-center gap-1.5">
                    <span className="inline-block size-1.5 rounded-full bg-primary" aria-hidden />
                    Vos documents restent sur cet appareil
                  </p>
                </div>
              </footer>

              {/* Navigation mobile */}
              <nav
                className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t bg-background/95 backdrop-blur"
                aria-label="Navigation mobile"
              >
                <div className="grid grid-cols-5 h-16">
                  {NAV_ITEMS.slice(0, 5).map((item) => (
                    <button
                      key={item.view}
                      className={cn(
                        "flex flex-col items-center justify-center gap-1 text-[10.5px] font-medium transition-colors",
                        view === item.view ? "text-primary" : "text-muted-foreground"
                      )}
                      onClick={() => setView(item.view)}
                      aria-current={view === item.view ? "page" : undefined}
                    >
                      <item.icon className="size-5" aria-hidden />
                      {item.label === "AlteOS Assist" ? "Assist" : item.label}
                    </button>
                  ))}
                </div>
              </nav>
            </div>
          </>
        )}
      </div>
    </ThemeProvider>
  );
}
