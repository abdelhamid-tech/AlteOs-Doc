"use client";

/**
 * Rail d'outils vertical de l'AlteOS Editor.
 * PDF : tous les outils. Design : sous-ensemble sans couche de texte.
 */

import {
  Circle,
  Highlighter,
  ImagePlus,
  Minus,
  MousePointer2,
  Move,
  PenTool,
  QrCode,
  Shapes,
  Slash,
  Square,
  StickyNote,
  Type,
  ArrowUpRight,
  Underline,
  Hand,
} from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import { useUiPrefs } from "@/store/ui-prefs";
import type { Tool } from "@/lib/types";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface ToolDef {
  tool: Tool;
  label: string;
  shortcut: string;
  icon: typeof MousePointer2;
  pdfOnly?: boolean;
}

const TOOLS: ToolDef[] = [
  { tool: "select", label: "Sélectionner", shortcut: "V", icon: MousePointer2 },
  { tool: "pan", label: "Déplacer la vue", shortcut: "H", icon: Hand },
  { tool: "highlight", label: "Surligner", shortcut: "S", icon: Highlighter, pdfOnly: true },
  { tool: "underline", label: "Souligner", shortcut: "U", icon: Underline, pdfOnly: true },
  { tool: "strike", label: "Barrer", shortcut: "B", icon: Slash, pdfOnly: true },
  { tool: "text", label: "Ajouter du texte", shortcut: "T", icon: Type },
  { tool: "note", label: "Commentaire", shortcut: "C", icon: StickyNote },
  { tool: "draw", label: "Dessiner", shortcut: "D", icon: PenTool },
  { tool: "arrow", label: "Flèche", shortcut: "A", icon: ArrowUpRight },
  { tool: "line", label: "Ligne", shortcut: "L", icon: Minus },
  { tool: "rect", label: "Rectangle", shortcut: "R", icon: Square },
  { tool: "ellipse", label: "Cercle", shortcut: "E", icon: Circle },
  { tool: "image", label: "Ajouter une image", shortcut: "I", icon: ImagePlus },
  { tool: "signature", label: "Signature", shortcut: "G", icon: PenTool },
  { tool: "qr", label: "Code QR", shortcut: "Q", icon: QrCode },
  { tool: "icon", label: "Icône", shortcut: "N", icon: Shapes },
];

export function ToolRail({ mode }: { mode: "pdf" | "design" }) {
  const tool = useEditorStore((s) => s.tool);
  const setTool = useEditorStore((s) => s.setTool);
  const toolbarDensity = useUiPrefs((s) => s.editor.toolbar);
  const visible = TOOLS.filter((t) => mode === "pdf" || !t.pdfOnly);
  const compact = toolbarDensity === "compacte";

  return (
    <TooltipProvider delayDuration={280}>
      <div
        className={cn(
          "flex flex-col items-center border-r bg-card/70 w-12 shrink-0 overflow-y-auto editor-scroll",
          compact ? "py-1.5 px-1 gap-0.5" : "py-2 px-1 gap-0.5"
        )}
        role="toolbar"
        aria-label="Outils d'édition"
      >
        {visible.map((t, i) => (
          <div key={t.tool} className={cn(i > 0 && i % 5 === 0 && "mt-1.5 pt-1.5 border-t w-full")}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => setTool(t.tool)}
                  aria-pressed={tool === t.tool}
                  aria-label={`${t.label} (${t.shortcut})`}
                  className={cn(
                    "grid place-items-center rounded-lg transition-colors focus-visible:outline-2 focus-visible:outline-ring",
                    compact ? "size-8" : "size-9",
                    tool === t.tool ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  <t.icon className={compact ? "size-4" : "size-[17px]"} aria-hidden />
                </button>
              </TooltipTrigger>
              <TooltipContent side="right" className="text-xs">
                {t.label} · {t.shortcut}
              </TooltipContent>
            </Tooltip>
          </div>
        ))}
      </div>
    </TooltipProvider>
  );
}

export function MoveIcon() {
  return <Move className="size-4" aria-hidden />;
}
