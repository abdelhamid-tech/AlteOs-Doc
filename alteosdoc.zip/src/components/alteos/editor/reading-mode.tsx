"use client";

/**
 * Mode Lecture / Présentation — affiche les pages en plein cadre,
 * une à une, avec navigation clavier. Rendu réel (pdf.js pour les PDF,
 * page Design pour les designs) : ce qui s'affiche est ce qui existe.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Contrast, Maximize, Minimize, Palette, X } from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import { renderPageToCanvas } from "@/lib/pdf/engine";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const READING_FILTERS = [
  { id: "normal", label: "Normal", css: "" },
  { id: "sepia", label: "Sépia", css: "sepia(0.45) saturate(0.9) brightness(1.02)" },
  { id: "sombre", label: "Sombre", css: "invert(0.9) hue-rotate(180deg) contrast(0.95)" },
  { id: "contraste", label: "Contraste", css: "contrast(1.25) saturate(1.1)" },
] as const;

export function ReadingMode({ open, onClose }: { open: boolean; onClose: () => void }) {
  const doc = useEditorStore((s) => s.doc);
  const pdfDoc = useEditorStore((s) => s.pdfDoc);
  const currentPageIndex = useEditorStore((s) => s.currentPageIndex);
  const setCurrentPageIndex = useEditorStore((s) => s.setCurrentPageIndex);
  const [index, setIndex] = useState(currentPageIndex);
  const [fullscreen, setFullscreen] = useState(false);
  const [filter, setFilter] = useState<(typeof READING_FILTERS)[number]["id"]>("normal");
  const canvasHostRef = useRef<HTMLDivElement>(null);
  const [rendered, setRendered] = useState<string | null>(null);

  const pageCount = doc ? (doc.kind === "pdf" ? doc.pages.length : doc.kind === "design" ? doc.designPages.length : 0) : 0;

  // À l'ouverture, démarre sur la page courante de l'éditeur (signet, vignette…).
  useEffect(() => {
    if (open) setIndex(Math.max(0, Math.min(pageCount - 1, currentPageIndex)));
  }, [open, pageCount, currentPageIndex]);

  const go = useCallback(
    (delta: number) => {
      setIndex((i) => Math.max(0, Math.min(pageCount - 1, i + delta)));
    },
    [pageCount]
  );

  // Navigation clavier + plein écran
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "PageDown" || e.key === " ") {
        e.preventDefault();
        go(1);
      }
      if (e.key === "ArrowLeft" || e.key === "PageUp") {
        e.preventDefault();
        go(-1);
      }
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, go, onClose]);

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  // Rendu de la page courante (PDF réel via pdf.js ; Design = aperçu édité)
  useEffect(() => {
    if (!open || !doc) return;
    const host = canvasHostRef.current;
    if (!host) return;
    let cancelled = false;

    (async () => {
      try {
        if (doc.kind === "pdf" && pdfDoc) {
          const ref = doc.pages[index];
          if (!ref) return;
          setRendered(null);
          const canvas = document.createElement("canvas");
          await renderPageToCanvas(pdfDoc, ref.src, canvas, 1.6, ref.rotation);
          if (cancelled) return;
          host.replaceChildren(canvas);
          setRendered(ref.id);
        } else if (doc.kind === "design") {
          const page = doc.designPages[index];
          if (!page) return;
          setRendered(null);
          // Aperçu SVG réel des éléments de la page (même moteur de rendu que l'éditeur).
          const { renderDesignPageSvg } = await import("@/lib/pdf/engine");
          const svg = await renderDesignPageSvg(doc, page.id, 1.6);
          if (cancelled) return;
          host.replaceChildren(svg);
          setRendered(page.id);
        }
      } catch {
        /* page illisible : reste sur la dernière rendue */
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [open, doc, pdfDoc, index]);

  if (!open || !doc || (doc.kind !== "pdf" && doc.kind !== "design")) return null;

  const activeFilter = READING_FILTERS.find((f) => f.id === filter) ?? READING_FILTERS[0];

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await canvasHostRef.current?.requestFullscreen();
    } catch {
      /* plein écran refusé par le navigateur : le mode lecture reste utilisable */
    }
  }

  return (
    <div className="fixed inset-0 z-50 aos-reading-canvas flex flex-col" role="dialog" aria-modal="true" aria-label="Mode lecture">
      <div className="flex items-center justify-between px-4 py-2 text-white/80">
        <span className="text-xs truncate max-w-[50%]" data-reading-title>
          {doc.name} — lecture
        </span>
        <div className="flex items-center gap-1">
          <div className="flex items-center gap-0.5 rounded-full bg-white/10 px-1 py-0.5" role="radiogroup" aria-label="Confort de lecture" data-reading-filters>
            {READING_FILTERS.map((f) => (
              <button
                key={f.id}
                role="radio"
                aria-checked={filter === f.id}
                onClick={() => setFilter(f.id)}
                title={`Confort : ${f.label}`}
                aria-label={`Confort de lecture : ${f.label}`}
                className={cn(
                  "grid place-items-center size-7 rounded-full transition-colors",
                  filter === f.id ? "bg-white text-black" : "text-white/70 hover:text-white hover:bg-white/10"
                )}
              >
                {f.id === "normal" ? <Palette className="size-3.5" aria-hidden /> : <Contrast className="size-3.5" aria-hidden />}
              </button>
            ))}
            <span className="text-[10px] px-1.5 text-white/70" aria-hidden>{activeFilter.label}</span>
          </div>
          <Button variant="ghost" size="icon" className="size-8 text-white/80 hover:text-white hover:bg-white/10" onClick={toggleFullscreen} aria-label={fullscreen ? "Quitter le plein écran" : "Plein écran"}>
            {fullscreen ? <Minimize className="size-4" aria-hidden /> : <Maximize className="size-4" aria-hidden />}
          </Button>
          <Button variant="ghost" size="icon" className="size-8 text-white/80 hover:text-white hover:bg-white/10" onClick={onClose} aria-label="Quitter le mode lecture">
            <X className="size-4" aria-hidden />
          </Button>
        </div>
      </div>
      <div className="flex-1 grid place-items-center overflow-hidden px-4 pb-4" data-reading-stage>
        <div
          ref={canvasHostRef}
          className={cn("grid place-items-center transition-opacity duration-150", rendered ? "opacity-100" : "opacity-40")}
          style={activeFilter.css ? { filter: activeFilter.css } : undefined}
          aria-live="polite"
        />
        {!rendered && <p className="absolute text-white/50 text-sm">Rendu de la page…</p>}
      </div>
      <div className="flex items-center justify-center gap-3 py-3">
        <Button variant="secondary" size="icon" className="size-9 rounded-full" onClick={() => go(-1)} disabled={index === 0} aria-label="Page précédente">
          <ChevronLeft className="size-4" aria-hidden />
        </Button>
        <span className="text-xs text-white/70 tabular-nums" data-reading-position>
          {index + 1} / {pageCount}
        </span>
        <Button variant="secondary" size="icon" className="size-9 rounded-full" onClick={() => go(1)} disabled={index >= pageCount - 1} aria-label="Page suivante">
          <ChevronRight className="size-4" aria-hidden />
        </Button>
      </div>
    </div>
  );
}
