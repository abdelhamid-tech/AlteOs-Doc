"use client";

/** Zoom de l'éditeur : −, pourcentage (presets), +, largeur, page.
 *  Deux présentations : pilule flottante, ou intégrée à la barre d'état. */

import { Maximize2, Minus, Plus, Scan } from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

const PRESETS = [0.5, 0.75, 1, 1.25, 1.5, 2] as const;

export function ZoomControls({ fitPageWidth, inline = false }: { fitPageWidth?: () => void; inline?: boolean }) {
  const zoom = useEditorStore((s) => s.zoom);
  const setZoom = useEditorStore((s) => s.setZoom);

  function fitWidth() {
    const host = document.querySelector("[data-page-slot]");
    if (!host) return;
    const scroller = host.closest(".editor-scroll") ?? host.closest("main")?.parentElement;
    const available = (scroller as HTMLElement | null)?.clientWidth ?? window.innerWidth;
    const pageW = host.getBoundingClientRect().width / (zoom || 1);
    if (pageW > 10) setZoom((available - 80) / pageW);
  }

  function fitPage() {
    const host = document.querySelector("[data-page-slot]");
    if (!host) return;
    const scroller = (host.closest(".editor-scroll") as HTMLElement) ?? document.querySelector("main");
    const availableH = (scroller?.clientHeight ?? window.innerHeight) - 80;
    const availableW = (scroller?.clientWidth ?? window.innerWidth) - 80;
    const rect = host.getBoundingClientRect();
    const w = rect.width / (zoom || 1);
    const h = rect.height / (zoom || 1);
    if (w > 10 && h > 10) setZoom(Math.min(availableW / w, availableH / h));
  }

  const nearestPreset = PRESETS.find((p) => Math.abs(p - zoom) < 0.02)?.toString() ?? "custom";

  return (
    <TooltipProvider delayDuration={250}>
      <div
        className={cn(
          "flex items-center gap-0.5",
          inline ? "text-muted-foreground" : "absolute bottom-4 right-4 z-20 rounded-full border bg-background/92 backdrop-blur px-1.5 py-1 shadow-md"
        )}
        role="toolbar"
        aria-label="Zoom"
      >
        <Button
          variant="ghost"
          size="icon"
          className={cn(inline ? "size-6 rounded-md" : "size-7 rounded-full")}
          onClick={() => setZoom(zoom - 0.15)}
          aria-label="Réduire le zoom"
          disabled={zoom <= 0.25}
        >
          <Minus className="size-3.5" aria-hidden />
        </Button>
        <Select value={nearestPreset} onValueChange={(v) => v !== "custom" && setZoom(Number(v))}>
          <SelectTrigger
            className={cn(
              "border-0 bg-transparent px-1 shadow-none focus:ring-0",
              inline ? "h-6 w-[58px] text-[11px]" : "h-7 w-[72px] text-xs"
            )}
            aria-label="Niveau de zoom"
          >
            <SelectValue>
              <span className="tabular-nums">{Math.round(zoom * 100)} %</span>
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            {PRESETS.map((p) => (
              <SelectItem key={p} value={String(p)} className="text-xs tabular-nums">
                {Math.round(p * 100)} %
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          variant="ghost"
          size="icon"
          className={cn(inline ? "size-6 rounded-md" : "size-7 rounded-full")}
          onClick={() => setZoom(zoom + 0.15)}
          aria-label="Agrandir le zoom"
          disabled={zoom >= 4}
        >
          <Plus className="size-3.5" aria-hidden />
        </Button>
        <div className="w-px h-3.5 bg-border mx-0.5" />
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className={cn(inline ? "size-6 rounded-md" : "size-7 rounded-full")}
              onClick={fitPageWidth ?? fitWidth}
              aria-label="Ajuster à la largeur"
            >
              <Maximize2 className="size-3.5" aria-hidden />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Largeur</TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className={cn(inline ? "size-6 rounded-md" : "size-7 rounded-full")}
              onClick={fitPage}
              aria-label="Ajuster à la page"
            >
              <Scan className="size-3.5" aria-hidden />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Page entière</TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
