"use client";

/**
 * Panneau Calques — liste des éléments de la page courante :
 * sélection, visibilité, verrou et ordre d'empilement.
 */

import { Eye, EyeOff, Lock, LockOpen, ArrowDown, ArrowUp, BringToFront, SendToBack, Layers2 } from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import type { Item } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const TYPE_LABEL: Record<Item["type"], string> = {
  highlight: "Surlignage",
  underline: "Soulignement",
  strike: "Texte barré",
  rect: "Rectangle",
  ellipse: "Ellipse",
  line: "Ligne",
  arrow: "Flèche",
  draw: "Tracé",
  text: "Texte",
  note: "Commentaire",
  image: "Image",
  signature: "Signature",
  qr: "Code QR",
  icon: "Icône",
};

function itemLabel(it: Item): string {
  const base = TYPE_LABEL[it.type];
  if (it.type === "text" && it.text.trim()) return `« ${it.text.trim().slice(0, 24)}${it.text.trim().length > 24 ? "…" : ""} »`;
  if (it.type === "note" && it.text.trim()) return `« ${it.text.trim().slice(0, 24)}${it.text.trim().length > 24 ? "…" : ""} »`;
  if (it.type === "qr" && it.data.trim()) return `QR · ${it.data.trim().slice(0, 20)}${it.data.trim().length > 20 ? "…" : ""}`;
  if (it.type === "icon") return `Icône · ${it.iconId}`;
  return base;
}

export function LayersPanel({ pageId, className }: { pageId: string; className?: string }) {
  const items = useEditorStore((s) => s.doc?.items ?? []);
  const selectedIds = useEditorStore((s) => s.selectedIds);
  const setSelectedIds = useEditorStore((s) => s.setSelectedIds);
  const toggleSelectedId = useEditorStore((s) => s.toggleSelectedId);
  const setItemHidden = useEditorStore((s) => s.setItemHidden);
  const setItemLocked = useEditorStore((s) => s.setItemLocked);
  const moveUp = useEditorStore((s) => s.moveUp);
  const moveDown = useEditorStore((s) => s.moveDown);
  const bringToFront = useEditorStore((s) => s.bringToFront);
  const sendToBack = useEditorStore((s) => s.sendToBack);

  // Ordre d'affichage : du plus haut (fin du tableau) au plus bas.
  const pageItems = items.filter((it) => it.pageId === pageId);
  const ordered = [...pageItems].reverse();

  return (
    <aside className={cn("flex flex-col border-l bg-card/70 w-[212px] shrink-0", className)} aria-label="Calques de la page">
      <div className="px-2.5 py-2 border-b flex items-center gap-1.5">
        <Layers2 className="size-3.5 text-muted-foreground" aria-hidden />
        <span className="text-xs font-medium text-muted-foreground">Calques</span>
        <span className="ml-auto text-[10px] text-muted-foreground tabular-nums" data-layers-count>
          {ordered.length}
        </span>
      </div>

      {ordered.length === 0 ? (
        <div className="px-3 py-6 text-[11px] text-muted-foreground/80 leading-relaxed">
          Aucun élément sur cette page. Ajoutez du texte, une forme ou une annotation pour le voir apparaître ici.
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto editor-scroll p-1.5 space-y-0.5">
          {ordered.map((it) => {
            const selected = selectedIds.includes(it.id);
            return (
              <div
                key={it.id}
                className="aos-layer-row group/l"
                data-selected={selected}
                data-layer-id={it.id}
                data-layer-hidden={it.hidden ? "true" : "false"}
                onClick={(e) => {
                  if (e.ctrlKey || e.metaKey || e.shiftKey) toggleSelectedId(it.id);
                  else setSelectedIds([it.id]);
                }}
                role="button"
                tabIndex={0}
                aria-label={`Calque : ${itemLabel(it)}`}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setSelectedIds([it.id]);
                  }
                }}
              >
                <span
                  className="size-2.5 rounded-[3px] border border-black/15 shrink-0"
                  style={{ background: "color" in it ? it.color : "#888" }}
                  aria-hidden
                />
                <span className={cn("flex-1 truncate min-w-0", it.hidden && "opacity-40 line-through")}>{itemLabel(it)}</span>
                <span className="flex items-center gap-0.5 shrink-0">
                  <button
                    className="p-0.5 rounded text-muted-foreground/60 hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring"
                    onClick={(e) => {
                      e.stopPropagation();
                      setItemHidden(it.id, !it.hidden);
                    }}
                    title={it.hidden ? "Afficher" : "Masquer"}
                    aria-label={it.hidden ? `Afficher ${itemLabel(it)}` : `Masquer ${itemLabel(it)}`}
                  >
                    {it.hidden ? <EyeOff className="size-3" aria-hidden /> : <Eye className="size-3" aria-hidden />}
                  </button>
                  <button
                    className={cn("p-0.5 rounded text-muted-foreground/60 hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring", it.locked && "text-primary")}
                    onClick={(e) => {
                      e.stopPropagation();
                      setItemLocked(it.id, !it.locked);
                    }}
                    title={it.locked ? "Déverrouiller" : "Verrouiller"}
                    aria-label={it.locked ? `Déverrouiller ${itemLabel(it)}` : `Verrouiller ${itemLabel(it)}`}
                  >
                    {it.locked ? <Lock className="size-3" aria-hidden /> : <LockOpen className="size-3" aria-hidden />}
                  </button>
                </span>
              </div>
            );
          })}
        </div>
      )}

      {pageItems.length > 0 && (
        <TooltipProvider delayDuration={200}>
          <div className="px-1.5 py-1.5 border-t grid grid-cols-4 gap-1" data-layers-actions>
            <LayersActionButton label="Monter" ariaLabel="Monter les calques sélectionnés" onClick={() => moveUp(selectedIds)} disabled={selectedIds.length === 0}>
              <ArrowUp className="size-3.5" aria-hidden />
            </LayersActionButton>
            <LayersActionButton label="Descendre" ariaLabel="Descendre les calques sélectionnés" onClick={() => moveDown(selectedIds)} disabled={selectedIds.length === 0}>
              <ArrowDown className="size-3.5" aria-hidden />
            </LayersActionButton>
            <LayersActionButton label="Premier plan" ariaLabel="Premier plan" onClick={() => bringToFront(selectedIds)} disabled={selectedIds.length === 0}>
              <BringToFront className="size-3.5" aria-hidden />
            </LayersActionButton>
            <LayersActionButton label="Arrière-plan" ariaLabel="Arrière-plan" onClick={() => sendToBack(selectedIds)} disabled={selectedIds.length === 0}>
              <SendToBack className="size-3.5" aria-hidden />
            </LayersActionButton>
          </div>
        </TooltipProvider>
      )}

      {pageItems.length > 0 && (
        <div className="px-2 py-1.5 border-t text-[10px] text-muted-foreground/70 leading-relaxed">
          L&apos;ordre va du premier plan (haut) à l&apos;arrière-plan (bas).
        </div>
      )}
    </aside>
  );
}

function LayersActionButton({
  label,
  ariaLabel,
  onClick,
  disabled,
  children,
}: {
  label: string;
  ariaLabel: string;
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button variant="ghost" size="icon" className="size-7" onClick={onClick} disabled={disabled} aria-label={ariaLabel} title={label}>
          {children}
        </Button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}
