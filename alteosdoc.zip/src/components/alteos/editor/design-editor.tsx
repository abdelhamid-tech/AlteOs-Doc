"use client";

/**
 * AlteOS Editor — mode Design : mise en page libre.
 * Même système d'éléments que le mode PDF, sur des pages vierges
 * dont le format et le fond sont configurables (A4, diapositive, story…).
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { CopyPlus, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import { editorBackdropClass, useUiPrefs } from "@/store/ui-prefs";
import { PageSurface } from "./page-surface";
import { ToolRail } from "./tool-rail";
import { ContextBar } from "./context-bar";
import { ZoomControls } from "./zoom-controls";
import { EditorStatusBar } from "./status-bar";
import { LayersPanel } from "./layers-panel";
import { putAsset } from "@/lib/idb";
import { PAGE_PRESETS, PAGE_BG_COLORS, uid, type ImageItem } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

const DEFAULT_PAGE = { id: "pg-design", w: 595.28, h: 841.89, background: "#FFFFFF" };

export function DesignEditor({
  onOpenSignature,
  onCropImage,
}: {
  onOpenSignature: () => void;
  onCropImage: (item: ImageItem) => void;
}) {
  const doc = useEditorStore((s) => s.doc);
  const tool = useEditorStore((s) => s.tool);
  const setTool = useEditorStore((s) => s.setTool);
  const zoom = useEditorStore((s) => s.zoom);
  const setZoom = useEditorStore((s) => s.setZoom);
  const currentPageIndex = useEditorStore((s) => s.currentPageIndex);
  const setCurrentPageIndex = useEditorStore((s) => s.setCurrentPageIndex);
  const layersOpen = useEditorStore((s) => s.layersOpen);
  const editorPrefs = useUiPrefs((s) => s.editor);
  const addDesignPage = useEditorStore((s) => s.addDesignPage);
  const duplicateDesignPage = useEditorStore((s) => s.duplicateDesignPage);
  const deleteDesignPage = useEditorStore((s) => s.deleteDesignPage);
  const updateDesignPage = useEditorStore((s) => s.updateDesignPage);
  const applyDesignPreset = useEditorStore((s) => s.applyDesignPreset);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (tool === "signature") {
      onOpenSignature();
      setTool("select");
    }
  }, [tool, onOpenSignature, setTool]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const first = doc?.designPages[0] ?? DEFAULT_PAGE;
    const fit = (el.clientWidth - 90) / first.w;
    setZoom(Math.min(1.5, Math.max(0.25, fit)));
  }, []); // zoom initial uniquement

  const onAddImage = useCallback(async (file: File) => {
    const state = useEditorStore.getState();
    const currentDoc = state.doc;
    if (!currentDoc) return;
    const idx = Math.min(state.currentPageIndex, currentDoc.designPages.length - 1);
    const page = currentDoc.designPages[idx] ?? DEFAULT_PAGE;
    const assetId = uid();
    await putAsset({ id: assetId, blob: file, mime: file.type, createdAt: Date.now() });
    const dims = await new Promise<{ w: number; h: number }>((resolve) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        resolve({ w: img.naturalWidth, h: img.naturalHeight });
        URL.revokeObjectURL(url);
      };
      img.onerror = () => {
        resolve({ w: 400, h: 300 });
        URL.revokeObjectURL(url);
      };
      img.src = url;
    });
    const wPt = Math.min(dims.w * 0.75, page.w * 0.8);
    const hPt = wPt * (dims.h / dims.w);
    state.addItems([
      {
        id: uid(),
        pageId: page.id,
        createdAt: Date.now(),
        type: "image",
        x: (page.w - wPt) / 2,
        y: Math.max(40, (page.h - hPt) / 4),
        w: wPt,
        h: hPt,
        assetId,
        rotation: 0,
        opacity: 1,
      },
    ]);
    state.setTool("select");
  }, []);

  if (!doc) {
    return (
      <div className="flex-1 grid place-items-center" role="status">
        <p className="text-sm text-muted-foreground">Ouverture du design…</p>
      </div>
    );
  }

  const pages = doc.designPages.length ? doc.designPages : [DEFAULT_PAGE];
  const currentIdx = Math.min(currentPageIndex, pages.length - 1);
  const current = pages[currentIdx];
  const currentPresetId = PAGE_PRESETS.find((p) => Math.abs(p.w - current.w) < 0.6 && Math.abs(p.h - current.h) < 0.6)?.id ?? "";

  return (
    <div className="flex flex-1 min-h-0">
      <ToolRail mode="design" />
      <div className="flex-1 flex flex-col min-w-0">
        <ContextBar onRequestCrop={onCropImage} />

        {/* Barre Pages : ajout, format, fond, duplication, suppression */}
        <div className="flex items-center gap-2 px-3 py-1.5 border-b bg-background/60 overflow-x-auto editor-scroll" data-design-pages-bar>
          <Button variant="outline" size="sm" className="h-7 text-xs gap-1 shrink-0" onClick={addDesignPage} aria-label="Ajouter une page">
            <Plus className="size-3.5" aria-hidden />
            Page
          </Button>
          <span className="text-xs text-muted-foreground shrink-0">
            Page {currentIdx + 1} / {pages.length}
          </span>
          <Select value={currentPresetId || "custom"} onValueChange={(v) => v !== "custom" && applyDesignPreset(current.id, v)}>
            <SelectTrigger className="h-7 w-[150px] text-xs shrink-0" aria-label="Format de la page">
              <SelectValue placeholder="Format" />
            </SelectTrigger>
            <SelectContent>
              {PAGE_PRESETS.map((p) => (
                <SelectItem key={p.id} value={p.id} className="text-xs">
                  {p.label}
                </SelectItem>
              ))}
              <SelectItem value="custom" disabled className="text-xs">
                Personnalisé
              </SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center gap-1 shrink-0" role="radiogroup" aria-label="Couleur de fond de la page">
            {PAGE_BG_COLORS.map((c) => (
              <button
                key={c}
                role="radio"
                aria-checked={current.background === c}
                aria-label={`Fond ${c}`}
                onClick={() => updateDesignPage(current.id, { background: c })}
                className={cn(
                  "size-5 rounded-md border shadow-inner transition-transform",
                  current.background === c ? "ring-2 ring-ring ring-offset-1 scale-110" : "hover:scale-105"
                )}
                style={{ background: c, borderColor: "rgba(0,0,0,0.18)" }}
              />
            ))}
            <input
              type="color"
              value={current.background}
              onChange={(e) => updateDesignPage(current.id, { background: e.target.value })}
              className="size-5 rounded-md border cursor-pointer bg-transparent p-0"
              aria-label="Couleur de fond personnalisée"
              title="Couleur personnalisée"
            />
          </div>
          <span className="flex-1" />
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs gap-1 shrink-0"
            onClick={() => duplicateDesignPage(current.id)}
            aria-label="Dupliquer la page courante"
          >
            <CopyPlus className="size-3.5" aria-hidden />
            Dupliquer
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs gap-1 shrink-0 text-destructive hover:text-destructive"
            onClick={() => {
              toast(`Supprimer la page ${currentIdx + 1} ?`, {
                description: "Les éléments de cette page seront supprimés aussi.",
                action: {
                  label: "Supprimer",
                  onClick: () => {
                    deleteDesignPage(current.id);
                    toast.success("Page supprimée");
                  },
                },
              });
            }}
            disabled={pages.length <= 1}
            aria-label="Supprimer la page courante"
          >
            <Trash2 className="size-3.5" aria-hidden />
            Supprimer
          </Button>
        </div>

        <div
          ref={scrollRef}
          className={cn(
            "relative flex-1 overflow-auto editor-scroll",
            editorBackdropClass(editorPrefs.backdrop)
          )}
        >
          <div
            className={cn(
              "flex flex-col items-center px-6 w-fit min-w-full",
              editorPrefs.pageGap === "aeree" ? "gap-10 py-14" : "gap-8 py-8"
            )}
          >
            {pages.map((p, i) => (
              <DesignPageSlot key={p.id} pageId={p.id} index={i} w={p.w} h={p.h} background={p.background} zoom={zoom} onVisible={setCurrentPageIndex} />
            ))}
          </div>
        </div>
        {editorPrefs.statusBar ? (
          <EditorStatusBar pageLabel={`Page ${currentIdx + 1} / ${pages.length}`} />
        ) : (
          <ZoomControls />
        )}
      </div>
      {layersOpen && <LayersPanel pageId={current.id} className="hidden md:flex" />}
      <ImageToolBridge onAddImage={onAddImage} />
    </div>
  );
}

/** Page Design + suivi de visibilité (page courante pour calques, collage, lecture). */
function DesignPageSlot({
  pageId,
  index,
  w,
  h,
  background,
  zoom,
  onVisible,
}: {
  pageId: string;
  index: number;
  w: number;
  h: number;
  background: string;
  zoom: number;
  onVisible: (i: number) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const en of entries) {
          if (en.isIntersecting && en.intersectionRatio > 0.35) onVisible(index);
        }
      },
      { rootMargin: "0px 0px", threshold: [0.35, 0.6] }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [index, onVisible]);

  return (
    <div ref={ref} data-page-slot={index} className="relative flex flex-col items-center">
      <div style={{ width: w * zoom, height: h * zoom }} className="relative">
        <PageSurface pageId={pageId} uw={w} uh={h} rotation={0} scale={zoom} background={background} grid={zoom > 0.5}>
          <span />
        </PageSurface>
      </div>
      <span className="text-[10px] text-muted-foreground/60 mt-2 tabular-nums">Page {index + 1}</span>
    </div>
  );
}

function ImageToolBridge({ onAddImage }: { onAddImage: (f: File) => void }) {
  const tool = useEditorStore((s) => s.tool);
  const setTool = useEditorStore((s) => s.setTool);
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (tool === "image") ref.current?.click();
  }, [tool]);
  return (
    <input
      ref={ref}
      type="file"
      accept="image/png,image/jpeg,image/webp"
      className="sr-only"
      aria-label="Ajouter une image"
      onChange={(e) => {
        const f = e.target.files?.[0];
        e.currentTarget.value = "";
        if (f) onAddImage(f);
        setTool("select");
      }}
    />
  );
}
