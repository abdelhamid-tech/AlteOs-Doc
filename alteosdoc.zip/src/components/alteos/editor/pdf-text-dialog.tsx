"use client";

/**
 * Texte du PDF — extraction réelle via pdf.js, page par page,
 * avec copie (page ou document entier). Aucun service externe.
 */

import { useEffect, useState } from "react";
import { Copy, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import { extractPageText } from "@/lib/pdf/engine";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

export function PdfTextDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const doc = useEditorStore((s) => s.doc);
  const pdfDoc = useEditorStore((s) => s.pdfDoc);
  const [result, setResult] = useState<{ key: string; pages: string[] } | null>(null);
  const [active, setActive] = useState(0);
  const key = open && doc && pdfDoc ? doc.id : "";
  const pagesText = result && result.key === key ? result.pages : null;

  useEffect(() => {
    if (!open || !pdfDoc || !doc || doc.kind !== "pdf") return;
    let cancelled = false;
    (async () => {
      const out: string[] = [];
      for (const ref of doc.pages) {
        if (cancelled) return;
        try {
          out.push(await extractPageText(pdfDoc, ref.src));
        } catch {
          out.push("");
        }
      }
      if (!cancelled) setResult({ key: doc.id, pages: out });
    })();
    return () => {
      cancelled = true;
    };
  }, [open, pdfDoc, doc]);

  if (!doc || doc.kind !== "pdf") return null;

  const totalChars = pagesText?.reduce((a, t) => a + t.length, 0) ?? 0;
  const current = pagesText?.[active] ?? "";

  async function copy(text: string, label: string) {
    if (!text.trim()) {
      toast.info("Aucun texte à copier", { description: "Cette page ne contient pas de couche texte." });
      return;
    }
    const ok = await navigator.clipboard.writeText(text).then(() => true).catch(() => false);
    if (ok) toast.success(`${label} copiée`, { description: `${text.length} caractères dans le presse-papiers.` });
    else toast.error("Copie refusée par le navigateur", { description: "Sélectionnez le texte manuellement." });
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Texte du PDF</DialogTitle>
          <DialogDescription>
            Extraction locale du texte de chaque page. Les pages sans couche texte (images scannées) apparaissent vides.
          </DialogDescription>
        </DialogHeader>

        {pagesText === null ? (
          <div className="flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground" role="status">
            <Loader2 className="size-4 animate-spin" aria-hidden />
            Extraction du texte…
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              {pagesText.length > 1 ? (
                <Tabs value={String(active)} onValueChange={(v) => setActive(Number(v))}>
                  <TabsList className="h-8 max-w-full overflow-x-auto editor-scroll flex-wrap justify-start">
                    {pagesText.map((_, i) => (
                      <TabsTrigger key={i} value={String(i)} className="text-xs px-2.5 h-6">
                        {i + 1}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              ) : (
                <span className="text-xs text-muted-foreground">Page unique</span>
              )}
            </div>
            <ScrollArea className="h-64 rounded-lg border bg-secondary/30">
              <pre className="whitespace-pre-wrap text-xs leading-relaxed p-3 font-mono" data-pdf-text-content>
                {current || "(Aucun texte extrait sur cette page)"}
              </pre>
            </ScrollArea>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground tabular-nums">
                {totalChars.toLocaleString("fr-FR")} caractères au total
              </span>
              <div className="flex items-center gap-2">
                <Button variant="secondary" size="sm" onClick={() => copy(current, "Page")}>
                  <Copy className="size-3.5 mr-1.5" aria-hidden />
                  Copier la page
                </Button>
                <Button size="sm" onClick={() => copy(pagesText.join("\n\n———\n\n"), "Texte intégral")}>
                  <Copy className="size-3.5 mr-1.5" aria-hidden />
                  Copier tout le texte
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
