"use client";

/** Chargement d'asset en objectURL avec cache mémoire (images, signatures). */

import { useEffect, useState } from "react";

import { getAsset } from "@/lib/idb";

const urlCache = new Map<string, { url: string; ref: number }>();

export function useAssetUrl(assetId: string | null | undefined): string | null {
  const [url, setUrl] = useState<string | null>(() => (assetId ? (urlCache.get(assetId)?.url ?? null) : null));

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!assetId) {
        setUrl(null);
        return;
      }
      const hit = urlCache.get(assetId);
      if (hit) {
        hit.ref++;
        setUrl(hit.url);
        return;
      }
      const asset = await getAsset(assetId);
      if (!asset || cancelled) return;
      const u = URL.createObjectURL(asset.blob);
      urlCache.set(assetId, { url: u, ref: 1 });
      setUrl(u);
    })();
    return () => {
      cancelled = true;
    };
  }, [assetId]);

  return url;
}
