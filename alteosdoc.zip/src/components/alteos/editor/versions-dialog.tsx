"use client";

/**
 * Historique de versions — instantanés locaux (IndexedDB) créés à la demande,
 * restauration complète du contenu éditorial. Les assets restent partagés.
 */

import { useCallback, useEffect, useState } from "react";
import { History, Loader2, RotateCcw, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import { deleteVersion, listVersions, putVersion } from "@/lib/idb";
import { uid, type DocVersion } from "@/lib/types";
import { relativeDateFR } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export function VersionsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const doc = useEditorStore((s) => s.doc);
  const applyVersionSnapshot = useEditorStore((s) => s.applyVersionSnapshot);
  const pushHistory = useEditorStore((s) => s.pushHistory);
  const [versions, setVersions] = useState<DocVersion[]>([]);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    if (!doc) return;
    const list = await listVersions(doc.id);
    setVersions(list);
  }, [doc]);

  useEffect(() => {
    if (open) void refresh();
  }, [open, refresh]);

  if (!open || !doc) return null;

  async function createVersion() {
    if (!doc) return;
    setBusy(true);
    try {
      const version: DocVersion = {
        id: uid(),
        docId: doc.id,
        createdAt: Date.now(),
        label: "",
        snapshot: {
          name: doc.name,
          blocks: JSON.parse(JSON.stringify(doc.blocks)),
          items: JSON.parse(JSON.stringify(doc.items)),
          pages: JSON.parse(JSON.stringify(doc.pages)),
          designPages: JSON.parse(JSON.stringify(doc.designPages)),
          formValues: { ...doc.formValues },
          settings: { ...doc.settings },
        },
      };
      await putVersion(version);
      await refresh();
      toast.success("Version créée", { description: `${versions.length + 1} version${versions.length ? "s" : ""} conservée(s) sur cet appareil (20 max).` });
    } catch {
      toast.error("La création de la version a échoué");
    } finally {
      setBusy(false);
    }
  }

  async function restore(v: DocVersion) {
    if (!doc) return;
    const ok = window.confirm(`Restaurer l'état du ${relativeDateFR(v.createdAt)} ?\n\nLe contenu actuel pourra être annulé (Ctrl+Z) ou retrouvé en créant d'abord une version.`);
    if (!ok) return;
    pushHistory();
    applyVersionSnapshot(v.snapshot);
    toast.success("Version restaurée", { description: "Le contenu est revenu à l'instantané choisi. Ctrl+Z revient à l'état précédent." });
    onClose();
  }

  async function remove(id: string) {
    await deleteVersion(id);
    await refresh();
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md" data-versions-dialog>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="size-4 text-primary" aria-hidden />
            Historique de versions
          </DialogTitle>
          <DialogDescription>
            Instantanés enregistrés sur cet appareil. Restauration du contenu complet (blocs, éléments, pages, réglages).
          </DialogDescription>
        </DialogHeader>

        <div className="max-h-72 overflow-y-auto editor-scroll rounded-lg border divide-y" data-versions-list>
          {versions.length === 0 ? (
            <div className="px-4 py-8 text-center text-sm text-muted-foreground">
              Aucune version pour l&apos;instant.
              <br />
              Créez-en une avant une grosse modification — vous pourrez revenir en arrière d&apos;un clic.
            </div>
          ) : (
            versions.map((v) => (
              <div key={v.id} className="flex items-center gap-2 px-3 py-2.5">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{v.snapshot.name}</p>
                  <p className="text-[11px] text-muted-foreground tabular-nums">
                    {relativeDateFR(v.createdAt)} · {v.snapshot.blocks.length} bloc{v.snapshot.blocks.length > 1 ? "s" : ""} · {v.snapshot.items.length} élément{v.snapshot.items.length > 1 ? "s" : ""}
                  </p>
                </div>
                <Button variant="secondary" size="sm" className="h-7 text-xs gap-1" onClick={() => restore(v)} data-version-restore>
                  <RotateCcw className="size-3" aria-hidden />
                  Restaurer
                </Button>
                <Button variant="ghost" size="icon" className="size-7 text-muted-foreground hover:text-destructive" onClick={() => remove(v.id)} aria-label="Supprimer cette version">
                  <Trash2 className="size-3.5" aria-hidden />
                </Button>
              </div>
            ))
          )}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Fermer</Button>
          <Button onClick={createVersion} disabled={busy} data-version-create>
            {busy ? <Loader2 className="size-4 mr-1.5 animate-spin" aria-hidden /> : <Save className="size-4 mr-1.5" aria-hidden />}
            Créer une version maintenant
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
