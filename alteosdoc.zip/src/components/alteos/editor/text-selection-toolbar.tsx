"use client";

/**
 * Barre flottante de sélection de texte réel du PDF :
 * surligner, souligner, barrer, copier.
 */

import { Copy, Highlighter, Strikethrough, Underline } from "lucide-react";

import { cn } from "@/lib/utils";

export function TextSelectionToolbar({
  x,
  y,
  onHighlight,
  onUnderline,
  onStrike,
  onCopy,
}: {
  x: number;
  y: number;
  onHighlight: () => void;
  onUnderline: () => void;
  onStrike: () => void;
  onCopy: () => void;
}) {
  return (
    <div
      data-selection-toolbar
      className="absolute z-30 -translate-x-1/2 -translate-y-full flex items-center gap-0.5 rounded-lg border bg-background shadow-lg px-1 py-1"
      style={{ left: x, top: Math.max(-4, y) }}
      onMouseDown={(e) => e.preventDefault()} // conserve la sélection
      role="toolbar"
      aria-label="Actions sur le texte sélectionné"
    >
      <ToolBtn label="Surligner" onClick={onHighlight}>
        <Highlighter className="size-3.5" aria-hidden />
      </ToolBtn>
      <ToolBtn label="Souligner" onClick={onUnderline}>
        <Underline className="size-3.5" aria-hidden />
      </ToolBtn>
      <ToolBtn label="Barrer" onClick={onStrike}>
        <Strikethrough className="size-3.5" aria-hidden />
      </ToolBtn>
      <div className="w-px h-4 bg-border mx-0.5" />
      <ToolBtn label="Copier" onClick={onCopy}>
        <Copy className="size-3.5" aria-hidden />
      </ToolBtn>
    </div>
  );
}

function ToolBtn({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      title={label}
      aria-label={label}
      className={cn(
        "grid place-items-center size-7 rounded-md text-muted-foreground transition-colors",
        "hover:bg-accent hover:text-accent-foreground focus-visible:outline-2 focus-visible:outline-ring"
      )}
    >
      {children}
    </button>
  );
}
