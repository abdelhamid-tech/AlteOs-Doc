"use client";

/**
 * AlteOS Editor — point d'entrée de l'éditeur.
 * Charge le document, gère la sauvegarde locale automatique,
 * la barre supérieure, les raccourcis et les dialogues.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  BarChart3,
  BookOpenText,
  Check,
  CloudOff,
  Copy,
  FileDown,
  History,
  Keyboard,
  Layers2,
  Loader2,
  Maximize,
  Minimize,
  PanelRight,
  PenLine,
  Presentation,
  Redo2,
  SlidersHorizontal,
  Sparkles,
  Undo2,
  Volume2,
} from "lucide-react";
import { toast } from "sonner";

import { AlteosMark } from "@/components/alteos/logo";
import { useAppStore } from "@/store/app-store";
import { useEditorStore } from "@/store/editor-store";
import { useUiPrefs } from "@/store/ui-prefs";
import { getDoc, getPref, putAsset, putDoc } from "@/lib/idb";
import { loadPdfDocument, renderThumb } from "@/lib/pdf/engine";
import { exportPdfPageAsPng } from "@/lib/pdf/export";
import { rasterizeSvg } from "@/lib/svg-raster";
import { blocksToSegments, type SpeakSegment } from "@/lib/tts";
import { uid, KIND_LABEL, type ImageItem } from "@/lib/types";
import { PdfEditor } from "./pdf-editor";
import { DesignEditor } from "./design-editor";
import { BlocksEditor } from "./blocks-editor";
import { ExportDialog } from "./export-dialog";
import { SignatureModal } from "./signature-modal";
import { CropDialog } from "./crop-dialog";
import { ReadingMode } from "./reading-mode";
import { ShortcutsDialog } from "./shortcuts-dialog";
import { FindReplaceDialog } from "./find-replace";
import { PdfTextDialog } from "./pdf-text-dialog";
import { StatsDialog } from "./stats-dialog";
import { VersionsDialog } from "./versions-dialog";
import { SpeakDialog } from "./speak-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ASSIST_ACTIONS, AssistUnavailableError, runAssistAction } from "@/lib/assist/gateway";
import { cn } from "@/lib/utils";

export default function EditorRoot() {
  const editingDocId = useAppStore((s) => s.editingDocId);
  const closeEditor = useAppStore((s) => s.closeEditor);
  const refreshDocs = useAppStore((s) => s.refreshDocs);

  const doc = useEditorStore((s) => s.doc);
  const dirty = useEditorStore((s) => s.dirty);
  const saving = useEditorStore((s) => s.saving);
  const savedAt = useEditorStore((s) => s.savedAt);
  const load = useEditorStore((s) => s.load);
  const reset = useEditorStore((s) => s.reset);
  const save = useEditorStore((s) => s.save);
  const setName = useEditorStore((s) => s.setName);
  const undo = useEditorStore((s) => s.undo);
  const redo = useEditorStore((s) => s.redo);
  const addItems = useEditorStore((s) => s.addItems);
  const past = useEditorStore((s) => s.past);
  const future = useEditorStore((s) => s.future);

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [signatureOpen, setSignatureOpen] = useState(false);
  const [cropItem, setCropItem] = useState<ImageItem | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [fillMode, setFillMode] = useState(false);
  const [readingOpen, setReadingOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [findOpen, setFindOpen] = useState(false);
  const [textDialogOpen, setTextDialogOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [versionsOpen, setVersionsOpen] = useState(false);
  const [speakOpen, setSpeakOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** Début d'une rafale de nudge clavier (un seul point d'annulation par rafale). */
  const nudgeBurst = useRef(0);

  const layersOpen = useEditorStore((s) => s.layersOpen);
  const setLayersOpen = useEditorStore((s) => s.setLayersOpen);
  const setEditorCustomOpen = useUiPrefs((s) => s.setEditorCustomOpen);

  // --- Chargement du document ---
  useEffect(() => {
    if (!editingDocId) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      setLoadError(null);
      try {
        const full = await getDoc(editingDocId);
        if (!full) throw new Error("introuvable");
        if (full.kind === "pdf") {
          if (!full.pdfBytes) throw new Error("PDF manquant");
          const loaded = await loadPdfDocument(full.pdfBytes);
          if (cancelled) return;
          load(full, loaded.doc);
        } else {
          if (cancelled) return;
          load(full, null);
        }
        // Police par défaut des nouveaux textes (préférence locale)
        const prefFont = await getPref<string>("defaultFont");
        if (!cancelled && prefFont) useEditorStore.getState().setTextFont(prefFont);
        // Panneau Calques : ouvert selon la personnalisation de l'éditeur
        if (!cancelled) useEditorStore.getState().setLayersOpen(useUiPrefs.getState().editor.layers);
      } catch {
        if (!cancelled) {
          setLoadError("Impossible d'ouvrir ce document. Il semble endommagé ou son format n'est pas pris en charge.");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [editingDocId, load]);

  // --- Sauvegarde locale automatique (débounce) ---
  useEffect(() => {
    if (!dirty || !doc) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      save().catch(() => {
        toast.error("L'enregistrement local a échoué", { description: "Vérifiez l'espace disponible sur cet appareil." });
      });
    }, 900);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, [dirty, doc, save]);

  // --- Sauvegarde en quittant l'éditeur / fermant l'onglet ---
  useEffect(() => {
    const state = useEditorStore.getState();
    const flush = () => {
      if (useEditorStore.getState().dirty) {
        void useEditorStore.getState().save();
      }
    };
    window.addEventListener("beforeunload", flush);
    return () => {
      window.removeEventListener("beforeunload", flush);
      flush();
      void state;
    };
  }, []);

  // --- Raccourcis clavier ---
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const typing =
        target.isContentEditable ||
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.tagName === "SELECT";
      const mod = e.ctrlKey || e.metaKey;

      if (mod && e.key.toLowerCase() === "z") {
        if (typing) return;
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
        return;
      }
      if (mod && e.key.toLowerCase() === "y") {
        if (typing) return;
        e.preventDefault();
        redo();
        return;
      }
      // Dupliquer / copier / coller les éléments sélectionnés (PDF & Design)
      if (mod && ["d", "c", "v"].includes(e.key.toLowerCase()) && !typing) {
        const s = useEditorStore.getState();
        if (s.doc && (s.doc.kind === "pdf" || s.doc.kind === "design")) {
          if (e.key.toLowerCase() === "d" && s.selectedIds.length > 0) {
            e.preventDefault();
            s.duplicateItems();
            return;
          }
          if (e.key.toLowerCase() === "c" && s.selectedIds.length > 0) {
            e.preventDefault();
            s.copySelection();
            toast.info("Copié", { description: "Ctrl+V pour coller sur la page courante." });
            return;
          }
          if (e.key.toLowerCase() === "v" && s.clipboard.length > 0) {
            e.preventDefault();
            s.pasteClipboard();
            return;
          }
        }
      }
      // Rechercher / remplacer (modes Document et Formulaire)
      if (mod && (e.key.toLowerCase() === "f" || e.key.toLowerCase() === "h")) {
        if (useEditorStore.getState().doc?.kind === "document" || useEditorStore.getState().doc?.kind === "form") {
          e.preventDefault();
          setFindOpen(true);
          return;
        }
      }
      // Exporter / Imprimer
      if (mod && e.key.toLowerCase() === "e") {
        e.preventDefault();
        setExportOpen(true);
        return;
      }
      if (mod && e.key.toLowerCase() === "p") {
        e.preventDefault();
        setExportOpen(true);
        return;
      }
      // Déplacement au clavier de la sélection (flèches ; Maj = pas de 10 pt)
      if (e.key.startsWith("Arrow")) {
        if (typing) return;
        const s = useEditorStore.getState();
        if (s.doc && (s.doc.kind === "pdf" || s.doc.kind === "design") && s.selectedIds.length > 0) {
          e.preventDefault();
          const step = e.shiftKey ? 10 : 1;
          const now = Date.now();
          if (now - nudgeBurst.current > 700) s.pushHistory();
          nudgeBurst.current = now;
          if (e.key === "ArrowLeft") s.nudgeSelection(-step, 0);
          if (e.key === "ArrowRight") s.nudgeSelection(step, 0);
          if (e.key === "ArrowUp") s.nudgeSelection(0, -step);
          if (e.key === "ArrowDown") s.nudgeSelection(0, step);
          return;
        }
      }
      if (e.key === "Delete" || e.key === "Backspace") {
        if (typing) return;
        const s = useEditorStore.getState();
        if (s.selectedIds.length > 1) {
          e.preventDefault();
          s.deleteItems(s.selectedIds);
          return;
        }
        const id = s.selectedItemId;
        if (id) {
          e.preventDefault();
          s.deleteItem(id);
        }
        return;
      }
      if (typing || mod) return;

      const map: Record<string, string> = {
        v: "select",
        h: "pan",
        s: "highlight",
        u: "underline",
        b: "strike",
        t: "text",
        c: "note",
        d: "draw",
        a: "arrow",
        l: "line",
        r: "rect",
        e: "ellipse",
        i: "image",
        g: "signature",
        q: "qr",
        n: "icon",
      };
      const tool = map[e.key.toLowerCase()];
      if (tool) {
        useEditorStore.getState().setTool(tool as never);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]);

  // --- Plein écran de l'éditeur ---
  useEffect(() => {
    const onFs = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  // --- Coller une image depuis le presse-papiers système (Ctrl+V) ---
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const state = useEditorStore.getState();
      const d = state.doc;
      if (!d || (d.kind !== "pdf" && d.kind !== "design")) return;
      // Ne pas intercepter la saisie de texte.
      const target = e.target as HTMLElement | null;
      if (target && (target.isContentEditable || target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      const files = Array.from(e.clipboardData?.files ?? []);
      const image = files.find((f) => f.type.startsWith("image/"));
      if (!image) return;
      e.preventDefault();
      (async () => {
        try {
          const assetId = uid();
          await putAsset({ id: assetId, blob: image, mime: image.type, createdAt: Date.now() });
          const dims = await new Promise<{ w: number; h: number }>((resolve) => {
            const url = URL.createObjectURL(image);
            const img = new Image();
            img.onload = () => {
              resolve({ w: img.naturalWidth, h: img.naturalHeight });
              URL.revokeObjectURL(url);
            };
            img.onerror = () => {
              resolve({ w: 400, h: 300 });
              URL.revokeObjectURL(url);
            };
            img.src = url;
          });
          let pageId: string;
          let pageW: number;
          let pageH: number;
          const idx = Math.min(state.currentPageIndex, d.kind === "pdf" ? d.pages.length - 1 : d.designPages.length - 1);
          if (d.kind === "pdf") {
            const ref = d.pages[idx];
            if (!ref) return;
            pageId = ref.id;
            const size = d.srcPageSizes[ref.src] ?? { w: 595.28, h: 841.89 };
            pageW = size.w;
            pageH = size.h;
          } else {
            const page = d.designPages[idx];
            if (!page) return;
            pageId = page.id;
            pageW = page.w;
            pageH = page.h;
          }
          const wPt = Math.min(dims.w * 0.75, pageW * 0.6);
          const hPt = wPt * (dims.h / dims.w);
          state.addItems([
            {
              id: uid(),
              pageId,
              createdAt: Date.now(),
              type: "image",
              x: (pageW - wPt) / 2,
              y: (pageH - hPt) / 2,
              w: wPt,
              h: hPt,
              assetId,
              rotation: 0,
              opacity: 1,
            },
          ]);
          toast.success("Image collée sur la page", { description: "Capture d'écran ou copie d'image — tout reste sur cet appareil." });
        } catch {
          toast.error("Le collage de l'image a échoué");
        }
      })();
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, []);

  // --- Copier la page courante en image (presse-papiers) ---
  const copyCurrentPageAsImage = useCallback(async () => {
    const state = useEditorStore.getState();
    const d = state.doc;
    if (!d) return;
    if (!navigator.clipboard || typeof ClipboardItem === "undefined") {
      toast.info("Copie non disponible", { description: "Ce navigateur ne permet pas d'écrire des images dans le presse-papiers." });
      return;
    }
    try {
      let blob: Blob;
      if (d.kind === "pdf" && state.pdfDoc) {
        const ref = d.pages[Math.min(state.currentPageIndex, d.pages.length - 1)];
        if (!ref) return;
        blob = await exportPdfPageAsPng(state.pdfDoc, ref.src, ref.rotation, 2);
      } else if (d.kind === "design") {
        const { renderDesignPageSvg } = await import("@/lib/pdf/engine");
        const page = d.designPages[Math.min(state.currentPageIndex, d.designPages.length - 1)];
        if (!page) return;
        const svg = await renderDesignPageSvg(d, page.id, 2);
        const markup = new XMLSerializer().serializeToString(svg);
        blob = await rasterizeSvg(markup, page.w * 2);
      } else {
        toast.info("Copie d'image disponible dans les modes PDF et Design.");
        return;
      }
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      toast.success("Page copiée en image", { description: "Collez-la (Ctrl+V) dans un message, un e-mail ou un autre document." });
    } catch {
      toast.error("La copie de la page a échoué", { description: "Le navigateur a refusé l'accès au presse-papiers." });
    }
  }, []);

  // --- Segments de lecture à voix haute selon le type de document ---
  const [speakSegments, setSpeakSegments] = useState<SpeakSegment[]>([]);
  const openSpeak = useCallback(async () => {
    const state = useEditorStore.getState();
    const d = state.doc;
    if (!d) return;
    if (d.kind === "document" || d.kind === "form") {
      setSpeakSegments(blocksToSegments(d.blocks));
      setSpeakOpen(true);
      return;
    }
    if (d.kind === "pdf" && state.pdfDoc) {
      try {
        const { extractPageText } = await import("@/lib/pdf/engine");
        const ref = d.pages[Math.min(state.currentPageIndex, d.pages.length - 1)];
        if (!ref) return;
        const text = await extractPageText(state.pdfDoc, ref.src);
        const trimmed = text.replace(/\s+/g, " ").trim();
        if (!trimmed) {
          toast.info("Cette page ne contient pas de texte lisible", { description: "Le PDF est probablement composé d'images — aucune lecture n'est simulée." });
          return;
        }
        setSpeakSegments([{ text: trimmed, label: `Page ${state.currentPageIndex + 1}` }]);
        setSpeakOpen(true);
      } catch {
        toast.error("L'extraction du texte de la page a échoué");
      }
      return;
    }
    toast.info("La lecture à voix haute est disponible pour les documents et les pages PDF.");
  }, []);

  const toggleEditorFullscreen = useCallback(async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      toast.info("Le plein écran a été refusé par le navigateur");
    }
  }, []);

  // --- Placement de signature ---
  const handlePlaceSignature = useCallback(
    async (result: { blob: Blob }) => {
      const state = useEditorStore.getState();
      const currentDoc = state.doc;
      if (!currentDoc) return;
      const dims = await new Promise<{ w: number; h: number }>((resolve) => {
        const url = URL.createObjectURL(result.blob);
        const img = new Image();
        img.onload = () => {
          resolve({ w: img.naturalWidth, h: img.naturalHeight });
          URL.revokeObjectURL(url);
        };
        img.onerror = () => {
          resolve({ w: 300, h: 80 });
          URL.revokeObjectURL(url);
        };
        img.src = url;
      });
      const assetId = uid();
      await putAsset({ id: assetId, blob: result.blob, mime: "image/png", createdAt: Date.now() });

      let pageId: string;
      let pageW = 595.28;
      let pageH = 841.89;
      if (currentDoc.kind === "pdf") {
        const ref = currentDoc.pages[Math.min(state.currentPageIndex, currentDoc.pages.length - 1)];
        if (!ref) return;
        pageId = ref.id;
        const size = currentDoc.srcPageSizes[ref.src] ?? { w: 595.28, h: 841.89 };
        pageW = size.w;
        pageH = size.h;
      } else {
        const page = currentDoc.designPages[Math.min(state.currentPageIndex, currentDoc.designPages.length - 1)];
        if (!page) return;
        pageId = page.id;
        pageW = page.w;
        pageH = page.h;
      }
      const wPt = Math.min(150, pageW * 0.3);
      const hPt = wPt * (dims.h / dims.w);
      addItems([
        {
          id: uid(),
          pageId,
          createdAt: Date.now(),
          type: "signature",
          x: pageW * 0.55,
          y: pageH * 0.78,
          w: wPt,
          h: hPt,
          assetId,
          rotation: 0,
          opacity: 1,
        },
      ]);
      toast.success("Signature placée", { description: "Déplacez-la et redimensionnez-la, puis exportez le document." });
    },
    [addItems]
  );

  // --- Assistance IA (état honnête : jamais de simulation) ---
  const handleAssist = useCallback(async (actionId: string) => {
    const state = useEditorStore.getState();
    const currentDoc = state.doc;
    const text = currentDoc?.blocks
      .map((b) => ("text" in b ? b.text : "html" in b ? b.html.replace(/<[^>]+>/g, " ") : ""))
      .join("\n")
      .trim();
    if (!text) {
      toast.info("Aucun texte à traiter", { description: "Écrivez d'abord du contenu dans ce document." });
      return;
    }
    try {
      const out = await runAssistAction({ action: actionId as never, text });
      toast.success("AlteOS Assist a répondu", { description: out.slice(0, 160) });
    } catch (err) {
      if (err instanceof AssistUnavailableError) {
        toast.info("AlteOS Assist n'est pas encore configuré", {
          description: "Aucun fournisseur d'IA n'est connecté — aucune réponse n'est simulée. Consultez la page AlteOS Assist.",
        });
      } else {
        toast.error("AlteOS Assist a échoué", { description: err instanceof Error ? err.message : undefined });
      }
    }
  }, []);

  const handleClose = async () => {
    if (useEditorStore.getState().dirty) {
      await useEditorStore.getState().save().catch(() => undefined);
    }
    await refreshDocs();
    reset();
    closeEditor();
  };

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center" role="status" aria-live="polite">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Loader2 className="size-7 animate-spin text-primary" aria-hidden />
          <p className="text-sm">Ouverture du document…</p>
        </div>
      </div>
    );
  }

  if (loadError || !doc) {
    return (
      <div className="min-h-screen grid place-items-center p-6">
        <div className="text-center max-w-md space-y-4">
          <p className="text-lg font-semibold">Impossible d&apos;ouvrir ce document</p>
          <p className="text-sm text-muted-foreground">{loadError ?? "Document introuvable."}</p>
          <Button onClick={() => { reset(); closeEditor(); }}>Retour aux documents</Button>
        </div>
      </div>
    );
  }

  const isForm = doc.kind === "form";

  return (
    <div className="flex flex-col h-screen bg-background overflow-hidden">
      {/* Barre supérieure — chrome Studio Ink */}
      <header className="aos-topbar flex items-center gap-1.5 px-2 sm:px-3 shrink-0 h-12" data-editor-header>
        <Button variant="ghost" size="icon" className="size-8 shrink-0" onClick={handleClose} aria-label="Fermer l'éditeur et revenir aux documents">
          <ArrowLeft className="size-4" aria-hidden />
        </Button>
        <span className="hidden lg:grid place-items-center text-primary shrink-0" aria-hidden>
          <AlteosMark size={20} />
        </span>
        <Badge variant="outline" className="hidden sm:inline-flex text-[10px] px-1.5 h-auto py-0.5 font-medium shrink-0">
          {KIND_LABEL[doc.kind]}
        </Badge>
        <input
          value={doc.name}
          onChange={(e) => setName(e.target.value)}
          className="bg-transparent border-none outline-none focus:underline decoration-primary/50 underline-offset-4 text-sm font-medium min-w-0 flex-1 truncate rounded px-1 h-8 focus-visible:outline-2 focus-visible:outline-ring"
          aria-label="Nom du document"
          spellCheck={false}
        />
        <SaveState saving={saving} dirty={dirty} savedAt={savedAt} />

        <div className="flex items-center gap-1 shrink-0">
          <TooltipProvider delayDuration={200}>
            {/* Historique */}
            <div className="flex items-center gap-0.5" role="group" aria-label="Historique">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={undo} disabled={past.length === 0} aria-label="Annuler">
                    <Undo2 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Annuler (Ctrl+Z)</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={redo} disabled={future.length === 0} aria-label="Rétablir">
                    <Redo2 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Rétablir (Ctrl+Maj+Z)</TooltipContent>
              </Tooltip>
            </div>

            <span className="w-px h-5 bg-border mx-1 hidden sm:block" aria-hidden />

            {/* Affichage du document */}
            <div className="flex items-center gap-0.5" role="group" aria-label="Affichage du document">
              {(doc.kind === "pdf" || doc.kind === "design") && (
                <>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant={layersOpen ? "secondary" : "ghost"} size="icon" className="size-8" onClick={() => setLayersOpen(!layersOpen)} aria-label="Calques" aria-pressed={layersOpen}>
                        <Layers2 className="size-4" aria-hidden />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Calques</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="size-8" onClick={() => setReadingOpen(true)} aria-label="Mode lecture">
                        <Presentation className="size-4" aria-hidden />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Mode lecture</TooltipContent>
                  </Tooltip>
                </>
              )}
              {doc.kind === "pdf" && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => setTextDialogOpen(true)} aria-label="Texte du PDF">
                      <BookOpenText className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Texte du PDF</TooltipContent>
                </Tooltip>
              )}
              {(doc.kind === "document" || isForm) && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => setFindOpen(true)} aria-label="Rechercher et remplacer">
                      <BookOpenText className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Rechercher (Ctrl+F)</TooltipContent>
                </Tooltip>
              )}
              {(doc.kind === "pdf" || doc.kind === "design") && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8 hidden md:inline-flex" onClick={copyCurrentPageAsImage} aria-label="Copier la page en image">
                      <Copy className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Copier la page en image</TooltipContent>
                </Tooltip>
              )}
            </div>

            <span className="w-px h-5 bg-border mx-1 hidden md:block" aria-hidden />

            {/* Outils du document */}
            <div className="hidden md:flex items-center gap-0.5" role="group" aria-label="Outils du document">
              {isForm && (
                <Button
                  variant={fillMode ? "default" : "secondary"}
                  size="sm"
                  className="h-8 text-xs"
                  onClick={() => setFillMode((f) => !f)}
                  aria-pressed={fillMode}
                >
                  <PenLine className="size-3.5 mr-1.5" aria-hidden />
                  {fillMode ? "Remplir" : "Modifier"}
                </Button>
              )}
              {(doc.kind === "document" || isForm) && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => setSettingsOpen(true)} aria-label="Réglages du document (en-tête, pied de page)">
                      <PanelRight className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Réglages du document</TooltipContent>
                </Tooltip>
              )}
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => handleAssist("improve")} aria-label="AlteOS Assist">
                    <Sparkles className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>AlteOS Assist</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => setStatsOpen(true)} aria-label="Statistiques du document">
                    <BarChart3 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Statistiques</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => setVersionsOpen(true)} aria-label="Historique de versions">
                    <History className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Versions</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={openSpeak} aria-label="Lecture à voix haute">
                    <Volume2 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Lecture à voix haute</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => setShortcutsOpen(true)} aria-label="Raccourcis clavier">
                    <Keyboard className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Raccourcis clavier</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={toggleEditorFullscreen} aria-label="Plein écran">
                    {isFullscreen ? <Minimize className="size-4" aria-hidden /> : <Maximize className="size-4" aria-hidden />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{isFullscreen ? "Quitter le plein écran" : "Plein écran"}</TooltipContent>
              </Tooltip>
            </div>

            <span className="w-px h-5 bg-border mx-1 hidden md:block" aria-hidden />

            {/* Personnaliser + Exporter */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8"
                  onClick={() => setEditorCustomOpen(true)}
                  aria-label="Personnaliser l'éditeur"
                  data-personalize-editor
                >
                  <SlidersHorizontal className="size-4" aria-hidden />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Personnaliser l&apos;éditeur</TooltipContent>
            </Tooltip>
            <Button size="sm" className="h-8" onClick={() => setExportOpen(true)}>
              <FileDown className="size-4 mr-1.5" aria-hidden />
              Exporter
            </Button>
          </TooltipProvider>
        </div>
      </header>

      {/* Corps selon le type */}
      {doc.kind === "pdf" && (
        <PdfEditor onExport={() => setExportOpen(true)} onOpenSignature={() => setSignatureOpen(true)} onCropImage={(it) => setCropItem(it)} />
      )}
      {doc.kind === "design" && <DesignEditor onOpenSignature={() => setSignatureOpen(true)} onCropImage={(it) => setCropItem(it)} />}
      {(doc.kind === "document" || isForm) && <BlocksEditor fillMode={isForm && fillMode} />}

      {/* Dialogues */}
      <ExportDialog open={exportOpen} onClose={() => setExportOpen(false)} />
      <SignatureModal open={signatureOpen} onClose={() => setSignatureOpen(false)} onPlace={handlePlaceSignature} />
      <CropDialog item={cropItem} onClose={() => setCropItem(null)} />
      <DocSettingsSheet open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <ReadingMode open={readingOpen} onClose={() => setReadingOpen(false)} />
      <ShortcutsDialog open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} />
      {(doc.kind === "document" || isForm) && findOpen && <FindReplaceDialog open onClose={() => setFindOpen(false)} />}
      {doc.kind === "pdf" && <PdfTextDialog open={textDialogOpen} onClose={() => setTextDialogOpen(false)} />}
      <StatsDialog open={statsOpen} onClose={() => setStatsOpen(false)} />
      <VersionsDialog open={versionsOpen} onClose={() => setVersionsOpen(false)} />
      {speakOpen && <SpeakDialog open onClose={() => setSpeakOpen(false)} segments={speakSegments} title={doc.name} />}
    </div>
  );
}

function SaveState({ saving, dirty, savedAt }: { saving: boolean; dirty: boolean; savedAt: number | null }) {
  const label = saving
    ? "Enregistrement…"
    : dirty
      ? "Modifications en attente"
      : savedAt
        ? "Enregistré sur cet appareil"
        : "Stocké sur cet appareil";
  return (
    <span
      className={cn(
        "hidden md:inline-flex items-center gap-1.5 text-[11px] text-muted-foreground px-2 py-1 rounded-md bg-secondary/60 shrink-0",
        saving && "text-primary"
      )}
      role="status"
      aria-live="polite"
    >
      {saving ? (
        <Loader2 className="size-3 animate-spin" aria-hidden />
      ) : (
        <CloudOff className="size-3" aria-label="Stockage local, sans cloud" />
      )}
      {label}
    </span>
  );
}

function DocSettingsSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const doc = useEditorStore((s) => s.doc);
  const updateSettings = useEditorStore((s) => s.updateSettings);
  if (!doc) return null;
  const s = doc.settings;

  return (
    <Sheet open={open} onOpenChange={(v) => !v && onClose()}>
      <SheetContent className="w-[360px] sm:max-w-[360px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Réglages du document</SheetTitle>
          <SheetDescription>En-tête, pied de page et numéros de page — appliqués lors de l&apos;export PDF.</SheetDescription>
        </SheetHeader>
        <div className="space-y-5 px-4 pb-8">
          <div className="space-y-1.5">
            <Label htmlFor="set-header">Texte d&apos;en-tête</Label>
            <Input id="set-header" value={s.header} onChange={(e) => updateSettings({ header: e.target.value })} placeholder="Ex. Rapport trimestriel" />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <Label htmlFor="set-hfirst" className="font-normal text-sm">
              En-tête sur la première page
            </Label>
            <Switch id="set-hfirst" checked={s.showHeaderOnFirstPage} onCheckedChange={(v) => updateSettings({ showHeaderOnFirstPage: v })} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="set-footer">Texte de pied de page</Label>
            <Input id="set-footer" value={s.footer} onChange={(e) => updateSettings({ footer: e.target.value })} placeholder="Ex. Confidentiel" />
          </div>
          <div className="space-y-1.5">
            <Label>Numéros de page</Label>
            <Select value={s.pageNumbers} onValueChange={(v) => updateSettings({ pageNumbers: v as typeof s.pageNumbers })}>
              <SelectTrigger className="w-full" aria-label="Position des numéros de page">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Aucun</SelectItem>
                <SelectItem value="bottom-center">Bas, centré</SelectItem>
                <SelectItem value="bottom-right">Bas, à droite</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="set-margin">Marge des pages</Label>
            <div className="flex items-center gap-3">
              <input
                id="set-margin"
                type="range"
                min={40}
                max={100}
                step={2}
                value={s.margin}
                onChange={(e) => updateSettings({ margin: Number(e.target.value) })}
                className="flex-1 accent-primary"
              />
              <span className="text-sm tabular-nums text-muted-foreground w-16">{s.margin} pt</span>
            </div>
            <p className="text-xs text-muted-foreground/70">La marge s&apos;applique à l&apos;export et à la mise en page de l&apos;éditeur.</p>
          </div>
          <div className="rounded-lg bg-secondary/50 p-3 text-xs text-muted-foreground leading-relaxed">
            Ces réglages sont appliqués réellement lors de l&apos;export PDF : chaque page générée reçoit son en-tête, son pied de page et son numéro.
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
