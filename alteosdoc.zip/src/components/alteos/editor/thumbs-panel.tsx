"use client";

/**
 * Panneau des pages — miniatures, sélection multiple, réorganisation,
 * rotation, duplication, suppression, extraction et fusion.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { Bookmark, CopyPlus, FileOutput, Layers, RotateCw, Trash2, Undo2 } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import { renderThumb } from "@/lib/pdf/engine";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function ThumbsPanel({
  onExtract,
  onMerge,
  className,
}: {
  onExtract?: (pageIds: string[]) => void;
  onMerge?: () => void;
  className?: string;
}) {
  const doc = useEditorStore((s) => s.doc);
  const pdfDoc = useEditorStore((s) => s.pdfDoc);
  const selectedPageIds = useEditorStore((s) => s.selectedPageIds);
  const toggleSelectedPage = useEditorStore((s) => s.toggleSelectedPage);
  const setSelectedPageIds = useEditorStore((s) => s.setSelectedPageIds);
  const duplicatePage = useEditorStore((s) => s.duplicatePage);
  const deletePages = useEditorStore((s) => s.deletePages);
  const rotatePages = useEditorStore((s) => s.rotatePages);
  const movePage = useEditorStore((s) => s.movePage);
  const currentPageIndex = useEditorStore((s) => s.currentPageIndex);
  const setCurrentPageIndex = useEditorStore((s) => s.setCurrentPageIndex);
  const togglePageBookmark = useEditorStore((s) => s.togglePageBookmark);

  const dragIndex = useRef<number | null>(null);
  const [dropIndex, setDropIndex] = useState<number | null>(null);

  const pages = doc?.pages ?? [];
  const hasSelection = selectedPageIds.length > 0;
  const bookmarks = pages.filter((p) => p.bookmarked);

  const scrollToPage = (idx: number) => {
    const el = document.querySelector<HTMLElement>(`[data-page-slot="${idx}"]`);
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
    setCurrentPageIndex(idx);
  };

  return (
    <aside className={cn("flex flex-col border-r bg-card/70 w-[168px] shrink-0", className)} aria-label="Pages du document">
      <div className="px-2 py-2 border-b flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground px-1">Pages</span>
        <span className="text-[10px] text-muted-foreground tabular-nums">
          {hasSelection ? `${selectedPageIds.length} sél.` : `${pages.length}`}
        </span>
      </div>

      {/* Actions sur la sélection */}
      <div className="px-2 py-1.5 border-b grid grid-cols-3 gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="size-7"
          title="Dupliquer"
          aria-label="Dupliquer les pages sélectionnées"
          disabled={!hasSelection}
          onClick={() => {
            for (const id of selectedPageIds) duplicatePage(id);
            toast.success(`${selectedPageIds.length} page(s) dupliquée(s)`);
            setSelectedPageIds([]);
          }}
        >
          <CopyPlus className="size-3.5" aria-hidden />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-7"
          title="Pivoter de 90°"
          aria-label="Pivoter les pages sélectionnées"
          disabled={!hasSelection}
          onClick={() => rotatePages(selectedPageIds, 90)}
        >
          <RotateCw className="size-3.5" aria-hidden />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-7 text-destructive hover:text-destructive"
          title="Supprimer"
          aria-label="Supprimer les pages sélectionnées"
          disabled={!hasSelection || pages.length <= selectedPageIds.length}
          onClick={() => {
            toast(`Supprimer ${selectedPageIds.length} page(s) ?`, {
              description: "Les annotations de ces pages seront supprimées aussi.",
              action: {
                label: "Supprimer",
                onClick: () => {
                  deletePages(selectedPageIds);
                  toast.success("Pages supprimées");
                },
              },
            });
          }}
        >
          <Trash2 className="size-3.5" aria-hidden />
        </Button>
      </div>
      <div className="px-2 pb-1.5 border-b grid grid-cols-2 gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="size-7"
          title="Extraire vers un nouveau PDF"
          aria-label="Extraire les pages sélectionnées"
          disabled={!hasSelection || !onExtract}
          onClick={() => onExtract?.(selectedPageIds)}
        >
          <FileOutput className="size-3.5" aria-hidden />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-7"
          title="Fusionner un PDF à la suite"
          aria-label="Fusionner un PDF"
          disabled={!onMerge}
          onClick={() => onMerge?.()}
        >
          <Layers className="size-3.5" aria-hidden />
        </Button>
      </div>

      {/* Signets — saut rapide aux pages marquées */}
      {bookmarks.length > 0 && (
        <div className="px-2 py-1.5 border-b" data-bookmarks-list>
          <p className="text-[9px] text-muted-foreground mb-1 px-1">Signets ({bookmarks.length})</p>
          <div className="flex flex-wrap gap-1">
            {bookmarks.map((p) => {
              const idx = pages.findIndex((x) => x.id === p.id);
              return (
                <button
                  key={p.id}
                  className="inline-flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-[10px] tabular-nums text-muted-foreground hover:border-primary/60 hover:text-foreground transition-colors"
                  onClick={() => scrollToPage(idx)}
                  aria-label={`Aller à la page ${idx + 1} (signet)`}
                >
                  <Bookmark className="size-2.5 text-primary" aria-hidden />
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Liste des miniatures */}
      <div className="flex-1 overflow-y-auto editor-scroll p-2 space-y-2">
        {pages.map((p, i) => (
          <div
            key={p.id}
            data-thumb-index={i}
            draggable
            onDragStart={() => (dragIndex.current = i)}
            onDragOver={(e) => {
              e.preventDefault();
              setDropIndex(i);
            }}
            onDragEnd={() => {
              setDropIndex(null);
              dragIndex.current = null;
            }}
            onDrop={(e) => {
              e.preventDefault();
              const from = dragIndex.current;
              setDropIndex(null);
              dragIndex.current = null;
              if (from !== null && from !== i) {
                movePage(from, i);
              }
            }}
            className={cn(
              "group relative rounded-md border transition-all",
              selectedPageIds.includes(p.id) ? "border-primary ring-1 ring-primary/60" : "border-transparent hover:border-border",
              dropIndex === i && "border-dashed border-primary",
              currentPageIndex === i && !selectedPageIds.includes(p.id) && "border-primary/50"
            )}
          >
            <button
              className="block w-full rounded-[inherit] overflow-hidden bg-white shadow-sm"
              onClick={(e) => {
                if (e.ctrlKey || e.metaKey || e.shiftKey) toggleSelectedPage(p.id);
                else scrollToPage(i);
              }}
              aria-label={`Page ${i + 1}${selectedPageIds.includes(p.id) ? " (sélectionnée)" : ""}`}
            >
              <PageThumb pdfDoc={pdfDoc} src={p.src} rotation={p.rotation} />
            </button>
            <div className="flex items-center justify-between px-1 py-0.5">
              <span className="text-[10px] text-muted-foreground tabular-nums">{i + 1}</span>
              <span className="flex items-center gap-0.5">
                <button
                  className={cn(
                    "grid place-items-center size-5 rounded text-[10px] transition-colors focus-visible:outline-2 focus-visible:outline-ring",
                    p.bookmarked ? "text-primary" : "text-muted-foreground/0 group-hover:text-muted-foreground/80 hover:!text-foreground"
                  )}
                  onClick={() => togglePageBookmark(p.id)}
                  aria-pressed={!!p.bookmarked}
                  aria-label={p.bookmarked ? `Retirer le signet de la page ${i + 1}` : `Marquer la page ${i + 1} d'un signet`}
                  title={p.bookmarked ? "Retirer le signet" : "Ajouter un signet"}
                >
                  <Bookmark className="size-3" aria-hidden />
                </button>
                <button
                  className="text-muted-foreground/0 group-hover:text-muted-foreground/90 hover:text-foreground text-[10px] px-1 rounded focus-visible:outline-2 focus-visible:outline-ring"
                  onClick={() => toggleSelectedPage(p.id)}
                  aria-label={`Sélectionner la page ${i + 1}`}
                >
                  <span className={cn("inline-block size-2.5 rounded-[2px] border", selectedPageIds.includes(p.id) ? "bg-primary border-primary" : "border-muted-foreground/50")} />
                </button>
              </span>
            </div>
            {p.rotation % 360 !== 0 && (
              <span className="absolute top-1 right-1 bg-background/85 text-[9px] rounded px-1 py-0.5 tabular-nums text-muted-foreground">
                {((p.rotation % 360) + 360) % 360}°
              </span>
            )}
          </div>
        ))}
      </div>

      {pages.length > 0 && (
        <div className="px-2 py-1.5 border-t text-[10px] text-muted-foreground/70 leading-relaxed">
          Glissez une miniature pour réordonner. Ctrl+clic : sélection multiple.
        </div>
      )}
    </aside>
  );
}

function PageThumb({ pdfDoc, src, rotation }: { pdfDoc: import("pdfjs-dist").PDFDocumentProxy | null; src: number; rotation: number }) {
  const [url, setUrl] = useState<string | null>(null);
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const sizes = useEditorStore((s) => s.doc?.srcPageSizes ?? []);
  const size = sizes[src] ?? { w: 595.28, h: 841.89 };
  const swap = ((rotation % 180) + 360) % 360 !== 0;
  const aspect = (swap ? size.h / size.w : size.w / size.h) || 0.707;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const en of entries) {
          if (en.isIntersecting) {
            setVisible(true);
            io.disconnect();
          }
        }
      },
      { rootMargin: "300px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!visible || !pdfDoc) return;
    let cancelled = false;
    (async () => {
      try {
        const { blob } = await renderThumb(pdfDoc, src, 132, rotation);
        if (!cancelled && blob) setUrl((old) => {
          if (old) URL.revokeObjectURL(old);
          return URL.createObjectURL(blob);
        });
      } catch {
        /* page illisible : squelette conservé */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, pdfDoc, src, rotation]);

  useEffect(() => {
    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [url]);

  return (
    <div ref={ref} className="w-full grid place-items-center bg-secondary/40" style={{ aspectRatio: String(aspect) }}>
      {url ? (
         
        <img src={url} alt="" className="w-full h-full object-contain" draggable={false} />
      ) : (
        <div className="w-full h-full animate-pulse bg-secondary/60" />
      )}
    </div>
  );
}

export function ThumbsPanelHintIcon() {
  return <Undo2 className="size-3.5" aria-hidden />;
}
