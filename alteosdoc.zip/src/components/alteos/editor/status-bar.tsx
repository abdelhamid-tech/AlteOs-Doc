"use client";

/**
 * Barre d'état de l'éditeur — page courante, pages sélectionnées,
 * outil actif, bascule du panneau des pages et zoom intégré.
 * Affichée selon la personnalisation de l'éditeur (préférence locale).
 */

import type { ReactNode } from "react";
import { PanelLeftClose, PanelLeftOpen } from "lucide-react";

import { ZoomControls } from "./zoom-controls";
import { Button } from "@/components/ui/button";

export function EditorStatusBar({
  pageLabel,
  extra,
  onToggleThumbs,
  thumbsOpen,
}: {
  pageLabel?: string;
  extra?: ReactNode;
  onToggleThumbs?: () => void;
  thumbsOpen?: boolean;
}) {
  return (
    <div
      className="flex items-center gap-2 px-2 sm:px-3 h-9 border-t bg-card/70 text-[11px] text-muted-foreground shrink-0"
      data-editor-statusbar
      role="status"
      aria-live="polite"
    >
      {onToggleThumbs && (
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-1.5 text-[11px] gap-1 text-muted-foreground"
          onClick={onToggleThumbs}
          aria-pressed={thumbsOpen}
          aria-label={thumbsOpen ? "Masquer le panneau des pages" : "Afficher le panneau des pages"}
          data-toggle-thumbs
        >
          {thumbsOpen ? <PanelLeftClose className="size-3.5" aria-hidden /> : <PanelLeftOpen className="size-3.5" aria-hidden />}
          Pages
        </Button>
      )}
      {pageLabel && <span className="tabular-nums">{pageLabel}</span>}
      {extra}
      <span className="flex-1" />
      <ZoomControls inline />
    </div>
  );
}

/** Contenu additionnel compact (compteur de sélection, outil actif…). */
export function StatusItem({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 rounded px-1.5 h-5 bg-secondary/70 whitespace-nowrap">
      {children}
    </span>
  );
}
