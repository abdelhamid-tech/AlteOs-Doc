"use client";

/**
 * Export — PDF (pages, qualité, compression, filigrane, numéros, métadonnées),
 * PNG, et formats texte (Markdown / HTML / TXT) pour les documents.
 * Génération intégralement locale via pdf-lib / pdf.js.
 */

import { useState } from "react";
import { ChevronDown, Droplets, FileCode2, FileDown, FileText, FileType2, Image as ImageIcon, Loader2, Printer, Settings2 } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import { DEFAULT_PAGE_DECOR, exportBlocksPdf, exportDesignPdf, exportPdfDoc, exportPdfPageAsPng, type PageDecor, type PdfMetadata } from "@/lib/pdf/export";
import { blocksToHtml, blocksToMarkdown, blocksToPlainText } from "@/lib/export-text";
import { downloadBlob, sanitizeFilename } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

type TextFormat = "markdown" | "html" | "txt";

export function ExportDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const doc = useEditorStore((s) => s.doc);
  const pdfDoc = useEditorStore((s) => s.pdfDoc);
  const selectedPageIds = useEditorStore((s) => s.selectedPageIds);
  const currentPageIndex = useEditorStore((s) => s.currentPageIndex);
  const [format, setFormat] = useState<"pdf" | "png" | "text">("pdf");
  const [textFormat, setTextFormat] = useState<TextFormat>("markdown");
  const [scope, setScope] = useState<"all" | "selection" | "current">("all");
  const [quality, setQuality] = useState<"standard" | "haute">("standard");
  const [compact, setCompact] = useState(true);
  const [fillable, setFillable] = useState(true);
  const [busy, setBusy] = useState(false);
  const [pngScale, setPngScale] = useState(2);
  const [advanced, setAdvanced] = useState(false);
  const [decor, setDecor] = useState<PageDecor>({ ...DEFAULT_PAGE_DECOR });
  const [meta, setMeta] = useState<PdfMetadata>({});
  const [useCustomMeta, setUseCustomMeta] = useState(false);

  if (!doc) return null;
  const d = doc;
  const isPdf = d.kind === "pdf";
  const isDesign = d.kind === "design";
  const isBlocks = d.kind === "document" || d.kind === "form";
  const hasSelection = selectedPageIds.length > 0;
  const pageCount = isPdf ? d.pages.length : isDesign ? d.designPages.length : 1;
  const filenameBase = sanitizeFilename(d.name);
  const decorActive = decor.watermarkText.trim() !== "" || decor.header.trim() !== "" || decor.footer.trim() !== "" || decor.pageNumbers !== "none";

  async function run() {
    setBusy(true);
    try {
      await new Promise((r) => setTimeout(r, 30)); // laisse respirer le rendu du bouton
      if (isPdf && format === "png") {
        if (!pdfDoc) throw new Error("PDF non chargé.");
        const indices =
          scope === "all"
            ? d.pages.map((_, i) => i)
            : scope === "selection"
              ? d.pages.map((p, i) => ({ p, i })).filter(({ p }) => selectedPageIds.includes(p.id)).map(({ i }) => i)
              : [Math.min(currentPageIndex, d.pages.length - 1)];
        if (indices.length === 1) {
          toast.promise(
            (async () => {
              const ref = d.pages[indices[0]];
              const blob = await exportPdfPageAsPng(pdfDoc, ref.src, ref.rotation, pngScale);
              downloadBlob(blob, `${filenameBase}-page-${indices[0] + 1}.png`);
            })(),
            { loading: "Préparation de l'export…", success: "Image PNG enregistrée", error: "L'export a échoué" }
          );
        } else {
          for (const i of indices) {
            const ref = d.pages[i];
            const blob = await exportPdfPageAsPng(pdfDoc, ref.src, ref.rotation, pngScale);
            downloadBlob(blob, `${filenameBase}-page-${i + 1}.png`);
            await new Promise((r) => setTimeout(r, 220));
          }
          toast.success(`${indices.length} images exportées`);
        }
        onClose();
        return;
      }

      if (isBlocks && format === "text") {
        const textPromise = (async () => {
          let content: string;
          let ext: string;
          let mime: string;
          if (textFormat === "markdown") {
            content = await blocksToMarkdown(d);
            ext = "md";
            mime = "text/markdown;charset=utf-8";
          } else if (textFormat === "html") {
            content = await blocksToHtml(d);
            ext = "html";
            mime = "text/html;charset=utf-8";
          } else {
            content = blocksToPlainText(d);
            ext = "txt";
            mime = "text/plain;charset=utf-8";
          }
          downloadBlob(new Blob([content], { type: mime }), `${filenameBase}.${ext}`);
        })();
        toast.promise(textPromise, {
          loading: "Génération du fichier…",
          success: "Fichier texte enregistré — images incorporées en base64",
          error: "L'export a échoué",
        });
        onClose();
        return;
      }

      const qualityVal = quality === "haute" ? "original" : "standard";
      const metadata = useCustomMeta ? meta : undefined;
      const exportPromise = (async () => {
        let blob: Blob;
        if (isPdf) {
          const pageIds =
            scope === "all" ? undefined : scope === "selection" ? selectedPageIds : [d.pages[Math.min(currentPageIndex, d.pages.length - 1)]?.id];
          blob = await exportPdfDoc(d, {
            pageIds: pageIds && pageIds.length ? pageIds : undefined,
            quality: qualityVal,
            compact,
            decor: decorActive ? decor : undefined,
            metadata,
          });
        } else if (isDesign) {
          blob = await exportDesignPdf(d, { quality: qualityVal, compact, decor: decorActive ? decor : undefined, metadata });
        } else {
          blob = await exportBlocksPdf(d, { quality: qualityVal, compact, fillableForm: d.kind === "form" && fillable, metadata });
        }
        downloadBlob(blob, `${filenameBase}.pdf`);
      })();
      exportPromise.catch((err) => console.error("[AlteOS Export]", err));
      toast.promise(exportPromise, {
        loading: "Préparation de l'export…",
        success: "Export terminé — enregistré dans vos téléchargements",
        error: "L'export a échoué",
      });
      onClose();
    } catch (err) {
      toast.error("Impossible d'exporter", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setBusy(false);
    }
  }

  /** Génère le PDF localement puis ouvre la boîte d'impression du navigateur. */
  async function print() {
    setBusy(true);
    try {
      const qualityVal = quality === "haute" ? "original" : "standard";
      const metadata = useCustomMeta ? meta : undefined;
      const blob = isPdf
        ? await exportPdfDoc(d, { quality: qualityVal, compact, decor: decorActive ? decor : undefined, metadata })
        : isDesign
          ? await exportDesignPdf(d, { quality: qualityVal, compact, decor: decorActive ? decor : undefined, metadata })
          : await exportBlocksPdf(d, { quality: qualityVal, compact, fillableForm: d.kind === "form" && fillable, metadata });
      const url = URL.createObjectURL(blob);
      const iframe = document.createElement("iframe");
      iframe.style.position = "fixed";
      iframe.style.right = "0";
      iframe.style.bottom = "0";
      iframe.style.width = "1px";
      iframe.style.height = "1px";
      iframe.style.opacity = "0";
      iframe.src = url;
      iframe.setAttribute("aria-hidden", "true");
      iframe.title = "Impression AlteOS Docs";
      document.body.appendChild(iframe);
      const cleanup = () => {
        URL.revokeObjectURL(url);
        iframe.remove();
      };
      iframe.onload = () => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
          setTimeout(cleanup, 60_000);
        } catch {
          cleanup();
          window.open(url, "_blank");
        }
      };
      toast.info("Boîte d'impression ouverte", { description: "Le document est généré sur cet appareil puis transmis au système d'impression." });
      onClose();
    } catch (err) {
      toast.error("Impression impossible", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setBusy(false);
    }
  }

  const radioCard =
    "flex items-center gap-2 rounded-lg border p-3 cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40";

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileDown className="size-4 text-primary" aria-hidden />
            Exporter
          </DialogTitle>
          <DialogDescription>
            Le fichier est généré sur cet appareil, puis enregistré dans vos téléchargements.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-1">
          {/* Format */}
          <div>
            <Label className="text-xs text-muted-foreground">Format</Label>
            <RadioGroup value={format} onValueChange={(v) => setFormat(v as typeof format)} className="grid grid-cols-3 gap-2 mt-1.5">
              <Label className={radioCard}>
                <RadioGroupItem value="pdf" id="fmt-pdf" />
                <span className="text-sm font-medium flex items-center gap-1.5">
                  <FileDown className="size-3.5" aria-hidden /> PDF
                </span>
              </Label>
              <Label className={cn(radioCard, !isPdf && "opacity-60")}>
                <RadioGroupItem value="png" id="fmt-png" disabled={!isPdf} />
                <span className="text-sm font-medium flex items-center gap-1.5">
                  <ImageIcon className="size-3.5" aria-hidden /> PNG
                </span>
              </Label>
              <Label className={cn(radioCard, !isBlocks && "opacity-60")}>
                <RadioGroupItem value="text" id="fmt-text" disabled={!isBlocks} />
                <span className="text-sm font-medium flex items-center gap-1.5">
                  <FileText className="size-3.5" aria-hidden /> Texte
                </span>
              </Label>
            </RadioGroup>
          </div>

          {/* Sous-format texte */}
          {isBlocks && format === "text" && (
            <div>
              <Label className="text-xs text-muted-foreground">Type de fichier</Label>
              <RadioGroup value={textFormat} onValueChange={(v) => setTextFormat(v as TextFormat)} className="grid grid-cols-3 gap-2 mt-1.5">
                <Label className="flex flex-col items-start rounded-lg border p-2.5 cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40">
                  <RadioGroupItem value="markdown" id="tf-md" className="sr-only" />
                  <span className="text-xs font-medium flex items-center gap-1">
                    <FileType2 className="size-3.5" aria-hidden /> Markdown
                  </span>
                  <span className="text-[10px] text-muted-foreground">.md — portable</span>
                </Label>
                <Label className="flex flex-col items-start rounded-lg border p-2.5 cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40">
                  <RadioGroupItem value="html" id="tf-html" className="sr-only" />
                  <span className="text-xs font-medium flex items-center gap-1">
                    <FileCode2 className="size-3.5" aria-hidden /> HTML
                  </span>
                  <span className="text-[10px] text-muted-foreground">.html — mis en page</span>
                </Label>
                <Label className="flex flex-col items-start rounded-lg border p-2.5 cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40">
                  <RadioGroupItem value="txt" id="tf-txt" className="sr-only" />
                  <span className="text-xs font-medium flex items-center gap-1">
                    <FileText className="size-3.5" aria-hidden /> Texte brut
                  </span>
                  <span className="text-[10px] text-muted-foreground">.txt — universel</span>
                </Label>
              </RadioGroup>
              <p className="text-xs text-muted-foreground mt-1.5">
                Les images sont incorporées dans le fichier (base64) : il reste lisible partout, sans dépendance.
              </p>
            </div>
          )}

          {/* Pages (PDF) */}
          {isPdf && (
            <div>
              <Label className="text-xs text-muted-foreground">Pages</Label>
              <RadioGroup value={scope} onValueChange={(v) => setScope(v as typeof scope)} className="grid grid-cols-3 gap-2 mt-1.5">
                <Label className="flex items-center rounded-lg border p-2.5 cursor-pointer text-sm has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40">
                  <RadioGroupItem value="all" id="sc-all" className="sr-only" />
                  Toutes ({pageCount})
                </Label>
                <Label className="flex items-center rounded-lg border p-2.5 cursor-pointer text-sm has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40">
                  <RadioGroupItem value="current" id="sc-current" className="sr-only" />
                  Page {currentPageIndex + 1}
                </Label>
                <Label className={cn("flex items-center rounded-lg border p-2.5 text-sm", hasSelection ? "cursor-pointer has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40" : "opacity-50")}>
                  <RadioGroupItem value="selection" id="sc-sel" className="sr-only" disabled={!hasSelection} />
                  Sélection ({selectedPageIds.length})
                </Label>
              </RadioGroup>
            </div>
          )}

          {/* PNG : résolution */}
          {isPdf && format === "png" && (
            <div className="flex items-center gap-3">
              <Label className="text-xs text-muted-foreground w-24 shrink-0">Résolution</Label>
              <Slider value={[pngScale]} min={1} max={3} step={0.5} onValueChange={(v) => setPngScale(v[0])} className="flex-1" aria-label="Échelle de l'image" />
              <span className="text-xs tabular-nums text-muted-foreground w-14">{pngScale.toFixed(1)}×</span>
            </div>
          )}

          {/* Qualité images */}
          {format === "pdf" && (
            <div>
              <Label className="text-xs text-muted-foreground">Qualité des images</Label>
              <RadioGroup value={quality} onValueChange={(v) => setQuality(v as typeof quality)} className="grid grid-cols-2 gap-2 mt-1.5">
                <Label className="flex items-center rounded-lg border p-2.5 cursor-pointer text-sm has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40">
                  <RadioGroupItem value="standard" id="q-std" className="sr-only" />
                  Standard — fichier léger
                </Label>
                <Label className="flex items-center rounded-lg border p-2.5 cursor-pointer text-sm has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-accent/40">
                  <RadioGroupItem value="q-hi" id="q-hi" className="sr-only" />
                  Haute — images d&apos;origine
                </Label>
              </RadioGroup>
            </div>
          )}

          {/* Compression */}
          {format === "pdf" && (
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm">Compression du fichier</Label>
                <p className="text-xs text-muted-foreground">Optimise la taille du PDF (structures internes).</p>
              </div>
              <Switch checked={compact} onCheckedChange={setCompact} aria-label="Compression du fichier" />
            </div>
          )}

          {/* Formulaires */}
          {d.kind === "form" && format === "pdf" && (
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm">Champs remplissables</Label>
                <p className="text-xs text-muted-foreground">Le PDF exporté reste modifiable dans tout lecteur.</p>
              </div>
              <Switch checked={fillable} onCheckedChange={setFillable} aria-label="Champs remplissables" />
            </div>
          )}

          {/* Options avancées (PDF & Design) */}
          {format === "pdf" && (isPdf || isDesign) && (
            <div className="rounded-lg border overflow-hidden" data-export-advanced>
              <button
                className="w-full flex items-center justify-between px-3 py-2.5 text-sm hover:bg-accent/40 transition-colors"
                onClick={() => setAdvanced((a) => !a)}
                aria-expanded={advanced}
              >
                <span className="flex items-center gap-2 font-medium">
                  <Settings2 className="size-4 text-muted-foreground" aria-hidden />
                  Options avancées
                  {decorActive && (
                    <span className="text-[10px] font-normal text-primary bg-primary/10 rounded-full px-2 py-0.5">actives</span>
                  )}
                </span>
                <ChevronDown className={cn("size-4 text-muted-foreground transition-transform", advanced && "rotate-180")} aria-hidden />
              </button>
              {advanced && (
                <div className="px-3 pb-3.5 pt-1 space-y-4 border-t">
                  {/* Filigrane */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                      <Droplets className="size-3.5" aria-hidden />
                      Filigrane (appliqué à chaque page)
                    </div>
                    <Input
                      value={decor.watermarkText}
                      onChange={(e) => setDecor({ ...decor, watermarkText: e.target.value })}
                      placeholder="Ex. CONFIDENTIEL — ne pas diffuser"
                      aria-label="Texte du filigrane"
                      data-watermark-input
                    />
                    {decor.watermarkText.trim() && (
                      <div className="grid grid-cols-2 gap-3">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-muted-foreground w-16">Opacité</span>
                          <Slider
                            value={[Math.round(decor.watermarkOpacity * 100)]}
                            min={3}
                            max={60}
                            step={1}
                            onValueChange={(v) => setDecor({ ...decor, watermarkOpacity: v[0] / 100 })}
                            aria-label="Opacité du filigrane"
                            className="flex-1"
                          />
                          <span className="text-[11px] tabular-nums text-muted-foreground w-9">{Math.round(decor.watermarkOpacity * 100)} %</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-muted-foreground w-16">Angle</span>
                          <Slider
                            value={[decor.watermarkAngle]}
                            min={0}
                            max={90}
                            step={5}
                            onValueChange={(v) => setDecor({ ...decor, watermarkAngle: v[0] })}
                            aria-label="Angle du filigrane"
                            className="flex-1"
                          />
                          <span className="text-[11px] tabular-nums text-muted-foreground w-9">{decor.watermarkAngle}°</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-muted-foreground w-16">Taille</span>
                          <Slider
                            value={[decor.watermarkSize]}
                            min={14}
                            max={96}
                            step={2}
                            onValueChange={(v) => setDecor({ ...decor, watermarkSize: v[0] })}
                            aria-label="Taille du filigrane"
                            className="flex-1"
                          />
                          <span className="text-[11px] tabular-nums text-muted-foreground w-9">{decor.watermarkSize} pt</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-muted-foreground w-16">Couleur</span>
                          <input
                            type="color"
                            value={decor.watermarkColor}
                            onChange={(e) => setDecor({ ...decor, watermarkColor: e.target.value })}
                            className="h-7 w-10 cursor-pointer rounded border bg-transparent p-0.5"
                            aria-label="Couleur du filigrane"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Numéros de page */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Numéros de page</Label>
                      <Select value={decor.pageNumbers} onValueChange={(v) => setDecor({ ...decor, pageNumbers: v as PageDecor["pageNumbers"] })}>
                        <SelectTrigger className="h-8 text-xs" aria-label="Position des numéros de page">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Aucun</SelectItem>
                          <SelectItem value="bottom-center">Bas, centré</SelectItem>
                          <SelectItem value="bottom-right">Bas, à droite</SelectItem>
                          <SelectItem value="bottom-left">Bas, à gauche</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Format du numéro</Label>
                      <Select value={decor.numberFormat} onValueChange={(v) => setDecor({ ...decor, numberFormat: v as "n" | "n/total" })}>
                        <SelectTrigger className="h-8 text-xs" aria-label="Format du numéro de page">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="n">1, 2, 3…</SelectItem>
                          <SelectItem value="n/total">1 / 12, 2 / 12…</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* En-tête / pied */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground" htmlFor="exp-header">En-tête</Label>
                      <Input
                        id="exp-header"
                        value={decor.header}
                        onChange={(e) => setDecor({ ...decor, header: e.target.value })}
                        placeholder="Titre du document"
                        className="h-8 text-xs"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground" htmlFor="exp-footer">Pied de page</Label>
                      <Input
                        id="exp-footer"
                        value={decor.footer}
                        onChange={(e) => setDecor({ ...decor, footer: e.target.value })}
                        placeholder="© 2026 — Tous droits réservés"
                        className="h-8 text-xs"
                      />
                    </div>
                  </div>
                  <p className="text-[11px] text-muted-foreground/80 leading-relaxed">
                    Ces éléments sont dessinés réellement dans le PDF exporté (pdf-lib), sur chaque page sélectionnée.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Métadonnées */}
          {format === "pdf" && (
            <div className="rounded-lg border p-3 space-y-2.5" data-export-meta>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm">Métadonnées du fichier</Label>
                  <p className="text-xs text-muted-foreground">Auteur, sujet, mots-clés — inscrits dans le PDF.</p>
                </div>
                <Switch checked={useCustomMeta} onCheckedChange={setUseCustomMeta} aria-label="Personnaliser les métadonnées" />
              </div>
              {useCustomMeta && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground" htmlFor="meta-author">Auteur</Label>
                    <Input
                      id="meta-author"
                      value={meta.author ?? ""}
                      onChange={(e) => setMeta({ ...meta, author: e.target.value })}
                      placeholder="Votre nom"
                      className="h-8 text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground" htmlFor="meta-title">Titre</Label>
                    <Input
                      id="meta-title"
                      value={meta.title ?? ""}
                      onChange={(e) => setMeta({ ...meta, title: e.target.value })}
                      placeholder={d.name}
                      className="h-8 text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground" htmlFor="meta-subject">Sujet</Label>
                    <Input
                      id="meta-subject"
                      value={meta.subject ?? ""}
                      onChange={(e) => setMeta({ ...meta, subject: e.target.value })}
                      placeholder="Objet du document"
                      className="h-8 text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground" htmlFor="meta-keywords">Mots-clés</Label>
                    <Input
                      id="meta-keywords"
                      value={meta.keywords ?? ""}
                      onChange={(e) => setMeta({ ...meta, keywords: e.target.value })}
                      placeholder="rapport, 2026, finance"
                      className="h-8 text-xs"
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          {format !== "text" && (
            <Button variant="secondary" onClick={print} disabled={busy}>
              <Printer className="size-4 mr-1.5" aria-hidden />
              Imprimer
            </Button>
          )}
          <Button onClick={run} disabled={busy}>
            {busy ? <Loader2 className="size-4 mr-1.5 animate-spin" aria-hidden /> : <FileDown className="size-4 mr-1.5" aria-hidden />}
            {busy ? "Préparation…" : "Exporter"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
