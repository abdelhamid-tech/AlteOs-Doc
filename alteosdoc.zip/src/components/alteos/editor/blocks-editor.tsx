"use client";

/**
 * AlteOS Editor — modes Document et Formulaire.
 * Éditeur par blocs : titres, paragraphes riches, listes, citations,
 * tableaux, images, séparateurs et champs remplissables.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  Bold,
  GripVertical,
  Heading1,
  Heading2,
  Heading3,
  ImagePlus,
  Italic,
  Lightbulb,
  Link2,
  List,
  ListChecks,
  ListOrdered,
  ListTree,
  Minus,
  Omega,
  Plus,
  Quote,
  Redo2,
  SquareCode,
  Table as TableIcon,
  Trash2,
  TriangleAlert,
  Underline as UnderlineIcon,
  Undo2,
  Type,
  ClipboardList,
  CheckSquare,
  CalendarDays,
  AlignJustify,
  X,
} from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import { editorBackdropClass, useUiPrefs } from "@/store/ui-prefs";
import { putAsset, getAsset } from "@/lib/idb";
import { fontStack } from "@/lib/fonts";
import { toast } from "sonner";
import { uid, type Block } from "@/lib/types";
import { useAssetUrl } from "./asset-image";
import { FontPicker } from "@/components/alteos/font-picker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const PT = 96 / 72; // point → pixel
const PAGE_W = 595.28; // A4 en points

const BLOCK_LABEL: Record<Block["type"], string> = {
  title: "Titre",
  subtitle: "Sous-titre",
  h1: "Titre 1",
  h2: "Titre 2",
  h3: "Titre 3",
  paragraph: "Paragraphe",
  list: "Liste",
  checklist: "Tâches",
  quote: "Citation",
  code: "Code",
  callout: "Encadré",
  divider: "Séparateur",
  spacer: "Espace",
  image: "Image",
  table: "Tableau",
  field: "Champ",
};

const MONO_STACK = "'JetBrains Mono', 'Fira Code', 'Courier New', monospace";

const CALLOUT_STYLES: Record<"info" | "warning" | "success", { bg: string; border: string; icon: typeof Lightbulb; label: string }> = {
  info: { bg: "#EAF3EF", border: "#0E7C66", icon: Lightbulb, label: "Information" },
  warning: { bg: "#FBF3E4", border: "#B7791F", icon: TriangleAlert, label: "Attention" },
  success: { bg: "#EDF3E6", border: "#4C7A34", icon: CheckSquare, label: "À retenir" },
};

/** Statistiques du document (mots, caractères, temps de lecture). */
function documentStats(blocks: Block[]): { words: number; chars: number; readingMin: number } {
  let text = "";
  for (const b of blocks) {
    if ("text" in b) text += " " + b.text;
    else if ("html" in b) {
      const div = document.createElement("div");
      div.innerHTML = b.html;
      text += " " + (div.textContent ?? "");
    } else if (b.type === "table") text += " " + b.rows.flat().join(" ");
    else if (b.type === "checklist") text += " " + b.entries.map((e) => e.text).join(" ");
  }
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.replace(/\s+/g, " ").trim().length;
  return { words, chars, readingMin: Math.max(1, Math.round(words / 220)) };
}

export function BlocksEditor({ fillMode = false }: { fillMode?: boolean }) {
  const doc = useEditorStore((s) => s.doc);
  const insertBlock = useEditorStore((s) => s.insertBlock);
  const removeBlock = useEditorStore((s) => s.removeBlock);
  const moveBlock = useEditorStore((s) => s.moveBlock);
  const updateSettings = useEditorStore((s) => s.updateSettings);
  const editorPrefs = useUiPrefs((s) => s.editor);
  const [adding, setAdding] = useState<number | null>(null);
  const dragFrom = useRef<number | null>(null);
  const stats = useMemo(() => documentStats(doc?.blocks ?? []), [doc?.blocks]);

  if (!doc) {
    return (
      <div className="flex-1 grid place-items-center" role="status">
        <p className="text-sm text-muted-foreground">Ouverture du document…</p>
      </div>
    );
  }

  const margin = doc.settings.margin;
  const baseFont = doc.settings.baseFont ?? "Helvetica";

  return (
    <TooltipProvider delayDuration={220}>
      {!fillMode && (
        <div className="flex items-center gap-2 px-3 h-12 border-b bg-card/80 backdrop-blur shrink-0 overflow-x-auto editor-scroll">
          <span className="text-xs text-muted-foreground shrink-0">Police du document</span>
          <FontPicker
            value={baseFont}
            onChange={(id) => updateSettings({ baseFont: id })}
            ariaLabel="Police du document"
            className="w-[170px] shrink-0"
          />
          <span className="text-xs text-muted-foreground/70 hidden lg:inline">
            Titres, paragraphes, listes et tableaux suivent cette police — elle est incorporée à l'export PDF.
          </span>
        </div>
      )}
      <div className={cn("flex-1 overflow-auto editor-scroll", editorBackdropClass(editorPrefs.backdrop))}>
        <div className={cn("flex justify-center px-4", editorPrefs.pageGap === "aeree" ? "py-14" : "py-8")}>
          <div
            className="aos-page bg-white text-[#1C1B1A] w-full max-w-[820px] shadow-xl"
            style={{ padding: `${margin * PT}px ${margin * PT}px`, fontFamily: fontStack(baseFont) }}
            role="document"
            aria-label="Document en cours d'édition"
          >
            {doc.blocks.length === 0 && (
              <EmptyHint onAdd={() => insertBlock(0, { id: uid(), type: "paragraph", html: "" })} />
            )}

            {doc.blocks.map((block, i) => (
              <div
                key={block.id}
                data-block-id={block.id}
                className="group/block relative"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const from = dragFrom.current;
                  dragFrom.current = null;
                  if (from !== null && from !== i) moveBlock(from, i);
                }}
              >
                {/* Poignée + actions au survol */}
                {!fillMode && (
                  <div className="absolute -left-11 top-1 flex flex-col items-center gap-0.5 opacity-0 group-hover/block:opacity-100 transition-opacity print:hidden">
                    <button
                      draggable
                      onDragStart={() => (dragFrom.current = i)}
                      className="cursor-grab text-muted-foreground/60 hover:text-foreground p-1 rounded focus-visible:outline-2 focus-visible:outline-ring"
                      aria-label="Déplacer ce bloc"
                    >
                      <GripVertical className="size-3.5" aria-hidden />
                    </button>
                    <button
                      className="text-muted-foreground/60 hover:text-destructive p-1 rounded focus-visible:outline-2 focus-visible:outline-ring"
                      onClick={() => removeBlock(block.id)}
                      aria-label={`Supprimer : ${BLOCK_LABEL[block.type]}`}
                    >
                      <Trash2 className="size-3.5" aria-hidden />
                    </button>
                  </div>
                )}

                <BlockView block={block} fillMode={fillMode} />

                {/* Insérer un bloc entre les lignes */}
                {!fillMode && (
                  <div className="relative h-0">
                    <div
                      className="absolute inset-x-0 -top-3 h-6 flex items-center justify-center opacity-0 group-hover/block:opacity-100 focus-within:opacity-100 transition-opacity"
                      onDragOver={(e) => e.preventDefault()}
                    >
                      <button
                        className="rounded-full border bg-background shadow-sm px-2 py-0.5 text-[10px] text-muted-foreground hover:text-foreground hover:border-primary/50 focus-visible:outline-2 focus-visible:outline-ring"
                        onClick={() => setAdding(i + 1)}
                        aria-label="Insérer un bloc ici"
                      >
                        <Plus className="size-2.5 inline" aria-hidden /> Insérer
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Palette d'ajout */}
        {adding !== null && (
          <div className="fixed inset-0 z-50 grid place-items-center bg-black/25" onClick={() => setAdding(null)} role="dialog" aria-modal="true" aria-label="Ajouter un bloc">
            <div className="rounded-xl border bg-background shadow-xl p-4 w-96" onClick={(e) => e.stopPropagation()}>
              <p className="text-sm font-medium mb-3">Ajouter un bloc</p>
              <div className="grid grid-cols-2 gap-2">
                <AddBtn icon={Type} label="Paragraphe" onClick={() => addBlock(adding, "paragraph")} />
                <AddBtn icon={Heading1} label="Titre 1" onClick={() => addBlock(adding, "h1")} />
                <AddBtn icon={Heading2} label="Titre 2" onClick={() => addBlock(adding, "h2")} />
                <AddBtn icon={Heading3} label="Titre 3" onClick={() => addBlock(adding, "h3")} />
                <AddBtn icon={List} label="Liste à puces" onClick={() => addBlock(adding, "list")} />
                <AddBtn icon={ListOrdered} label="Liste numérotée" onClick={() => addBlock(adding, "list", true)} />
                <AddBtn icon={ListChecks} label="Liste de tâches" onClick={() => addBlock(adding, "checklist")} />
                <AddBtn icon={Quote} label="Citation" onClick={() => addBlock(adding, "quote")} />
                <AddBtn icon={SquareCode} label="Bloc de code" onClick={() => addBlock(adding, "code")} />
                <AddBtn icon={Lightbulb} label="Encadré (information)" onClick={() => addCallout(adding, "info")} />
                <AddBtn icon={TriangleAlert} label="Encadré (attention)" onClick={() => addCallout(adding, "warning")} />
                <AddBtn icon={TableIcon} label="Tableau" onClick={() => addBlock(adding, "table")} />
                <AddBtn icon={ImagePlus} label="Image" onClick={() => addBlock(adding, "image")} />
                <AddBtn icon={Minus} label="Séparateur" onClick={() => addBlock(adding, "divider")} />
                <AddBtn icon={ListTree} label="Sommaire automatique" onClick={() => insertToc(adding)} />
                {doc.kind === "form" && <AddBtn icon={ClipboardList} label="Champ texte" onClick={() => addField(adding, "text")} />}
                {doc.kind === "form" && <AddBtn icon={CheckSquare} label="Case à cocher" onClick={() => addField(adding, "checkbox")} />}
                {doc.kind === "form" && <AddBtn icon={CalendarDays} label="Champ date" onClick={() => addField(adding, "date")} />}
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Barre de statistiques du document (temps réel) */}
      {editorPrefs.statusBar && (
        <div className="flex items-center justify-between gap-3 px-4 py-1.5 border-t bg-card/70 text-[11px] text-muted-foreground shrink-0" data-doc-stats aria-live="polite">
        <span className="tabular-nums">
          <b className="text-foreground font-medium">{stats.words.toLocaleString("fr-FR")}</b> mots ·{" "}
          <b className="text-foreground font-medium">{stats.chars.toLocaleString("fr-FR")}</b> caractères
        </span>
        <span className="tabular-nums hidden sm:inline">
          Lecture ≈ {stats.readingMin} min · {doc.blocks.length} bloc{doc.blocks.length > 1 ? "s" : ""} · Stocké sur cet appareil
        </span>
        </div>
      )}
    </TooltipProvider>
  );

  function addBlock(at: number, type: Block["type"], ordered?: boolean) {
    let block: Block;
    switch (type) {
      case "paragraph":
        block = { id: uid(), type: "paragraph", html: "" };
        break;
      case "h1":
        block = { id: uid(), type: "h1", text: "" };
        break;
      case "h2":
        block = { id: uid(), type: "h2", text: "" };
        break;
      case "h3":
        block = { id: uid(), type: "h3", text: "" };
        break;
      case "list":
        block = { id: uid(), type: "list", ordered: !!ordered, html: "" };
        break;
      case "checklist":
        block = { id: uid(), type: "checklist", entries: [] };
        break;
      case "quote":
        block = { id: uid(), type: "quote", html: "" };
        break;
      case "code":
        block = { id: uid(), type: "code", html: "" };
        break;
      case "callout":
        block = { id: uid(), type: "callout", html: "", variant: "info" };
        break;
      case "table":
        block = { id: uid(), type: "table", header: true, rows: [["Colonne 1", "Colonne 2", "Colonne 3"], ["", "", ""], ["", "", ""]] };
        break;
      case "divider":
        block = { id: uid(), type: "divider" };
        break;
      case "image":
        block = { id: uid(), type: "image", assetId: "", widthPct: 70, align: "center" };
        break;
      default:
        block = { id: uid(), type: "paragraph", html: "" };
    }
    insertBlock(at, block);
    setAdding(null);
  }

  function addCallout(at: number, variant: "info" | "warning" | "success") {
    insertBlock(at, { id: uid(), type: "callout", html: "", variant });
    setAdding(null);
  }

  /** Sommaire généré depuis les titres réels du document (recalculable à volonté). */
  function insertToc(at: number) {
    if (!doc) return;
    const headings = doc.blocks.filter((b) => b.type === "h1" || b.type === "h2" || b.type === "h3");
    if (headings.length === 0) {
      toast.info("Aucun titre à indexer", { description: "Ajoutez des blocs « Titre 1 / 2 / 3 » : le sommaire les listera ici." });
      setAdding(null);
      return;
    }
    const blocks: Block[] = [{ id: uid(), type: "h2", text: "Sommaire" }];
    let n = 0;
    for (const h of headings) {
      const label = h.text.trim();
      if (!label) continue;
      if (h.type === "h1") {
        n += 1;
        blocks.push({ id: uid(), type: "paragraph", html: `<p><b>${n}. ${escapeHtml(label)}</b></p>` });
      } else if (h.type === "h2") {
        blocks.push({ id: uid(), type: "paragraph", html: `<p>&nbsp;&nbsp;— ${escapeHtml(label)}</p>` });
      } else {
        blocks.push({ id: uid(), type: "paragraph", html: `<p>&nbsp;&nbsp;&nbsp;&nbsp;· ${escapeHtml(label)}</p>` });
      }
    }
    for (let i = blocks.length - 1; i >= 0; i--) insertBlock(at, blocks[i]);
    toast.success("Sommaire inséré", { description: "Il liste les titres actuels — régénérez-le après vos changements." });
    setAdding(null);
  }

  function escapeHtml(s: string): string {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function addField(at: number, fieldType: "text" | "checkbox" | "date") {
    insertBlock(at, { id: uid(), type: "field", fieldType, label: "Nouveau champ", required: false });
    setAdding(null);
  }
}

function EmptyHint({ onAdd }: { onAdd: () => void }) {
  return (
    <button
      onClick={onAdd}
      className="w-full rounded-lg border border-dashed p-10 text-center text-sm text-muted-foreground hover:border-primary/50 hover:text-foreground transition-colors"
    >
      Page blanche — cliquez pour ajouter du texte
    </button>
  );
}

function AddBtn({ icon: Icon, label, onClick }: { icon: typeof Type; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 rounded-lg border p-2.5 text-sm hover:border-primary/50 hover:bg-accent/40 transition-colors focus-visible:outline-2 focus-visible:outline-ring"
    >
      <Icon className="size-4 text-muted-foreground" aria-hidden />
      {label}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Rendu d'un bloc
// ---------------------------------------------------------------------------

function BlockView({ block, fillMode }: { block: Block; fillMode: boolean }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);

  switch (block.type) {
    case "title":
      return (
        <Heading block={block} level="title" style={{ fontSize: 24 * PT, fontWeight: 700, letterSpacing: "-0.01em" }} placeholder="Titre du document" />
      );
    case "subtitle":
      return <Heading block={block} level="subtitle" style={{ fontSize: 13 * PT, fontStyle: "italic", color: "#57544E" }} placeholder="Sous-titre" />;
    case "h1":
      return <Heading block={block} level="h1" style={{ fontSize: 17 * PT, fontWeight: 700, marginTop: 18 }} placeholder="Titre de section" />;
    case "h2":
      return <Heading block={block} level="h2" style={{ fontSize: 14 * PT, fontWeight: 700, marginTop: 14 }} placeholder="Sous-section" />;
    case "h3":
      return <Heading block={block} level="h3" style={{ fontSize: 12 * PT, fontWeight: 600, marginTop: 10, color: "#3C3A36" }} placeholder="Petit titre" />;
    case "paragraph":
    case "list":
    case "quote":
      return <RichBlock block={block} fillMode={fillMode} />;
    case "checklist":
      return <ChecklistBlock block={block} fillMode={fillMode} />;
    case "code":
      return <CodeBlock block={block} fillMode={fillMode} />;
    case "callout":
      return <CalloutBlock block={block} fillMode={fillMode} />;
    case "divider":
      return <hr className="my-4 border-t border-[#DDDAD4]" />;
    case "spacer":
      return <div style={{ height: block.h * PT }} />;
    case "image":
      return <ImageBlock block={block} />;
    case "table":
      return <TableBlock block={block} />;
    case "field":
      return <FieldBlock block={block} fillMode={fillMode} />;
    default:
      return null;
  }
}

function Heading({ block, level, style, placeholder }: { block: Extract<Block, { type: "title" | "subtitle" | "h1" | "h2" | "h3" }>; level: string; style: React.CSSProperties; placeholder: string }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);
  return (
    <h2 // sémantique neutre, le style porte la hiérarchie
      className={cn("aos-block-editable outline-none focus:bg-[#FFFDF3]/40 transition-colors rounded-sm", level === "title" && "mb-2", level === "subtitle" && "mb-6")}
      style={style}
      contentEditable
      suppressContentEditableWarning
      data-placeholder={placeholder}
      onBlur={(e) => {
        const text = e.currentTarget.innerText;
        if (text !== block.text) updateBlock(block.id, { text });
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          (e.currentTarget as HTMLElement).blur();
        }
      }}
      aria-label={placeholder}
    >
      {block.text}
    </h2>
  );
}

function RichBlock({ block, fillMode }: { block: Extract<Block, { type: "paragraph" | "list" | "quote" }>; fillMode: boolean }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);
  const insertBlock = useEditorStore((s) => s.insertBlock);
  const removeBlock = useEditorStore((s) => s.removeBlock);
  const ref = useRef<HTMLDivElement>(null);
  const [focused, setFocused] = useState(false);
  const doc = useEditorStore((s) => s.doc);
  const index = useMemo(() => doc?.blocks.findIndex((b) => b.id === block.id) ?? -1, [doc, block.id]);

  const style: React.CSSProperties =
    block.type === "quote"
      ? { paddingLeft: 16, borderLeft: "3px solid #0E7C66", fontStyle: "italic", color: "#4A4844", margin: "10px 0" }
      : block.type === "list"
        ? { paddingLeft: 8 }
        : {};

  function exec(cmd: string, value?: string) {
    document.execCommand(cmd, false, value);
    if (ref.current) updateBlock(block.id, { html: cleanHtml(ref.current.innerHTML) });
  }

  return (
    <div className="relative group/rich" style={style}>
      <div
        ref={ref}
        className={cn(
          "aos-block-editable outline-none leading-relaxed",
          block.type === "paragraph" && "text-[14px] min-h-[1.6em] mb-2",
          block.type === "list" && "text-[14px] min-h-[1.6em]",
          block.type === "quote" && "text-[14px] min-h-[1.6em]"
        )}
        style={
          block.type === "list"
            ? { listStyle: block.ordered ? "decimal" : "disc", paddingLeft: 24, minHeight: "1.6em" }
            : undefined
        }
        contentEditable={!fillMode}
        suppressContentEditableWarning
        data-placeholder={
          block.type === "list" ? "Un élément par ligne (Entrée pour ajouter)" : block.type === "quote" ? "Citation…" : "Écrivez ici…"
        }
        onFocus={() => setFocused(true)}
        onBlur={(e) => {
          setFocused(false);
          const html = cleanHtml(e.currentTarget.innerHTML);
          if (html !== block.html) updateBlock(block.id, { html });
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey && block.type !== "list") {
            e.preventDefault();
            const after = index + 1;
            insertBlock(after, { id: uid(), type: "paragraph", html: "" });
            setTimeout(() => {
              const next = document.querySelectorAll<HTMLDivElement>("[data-block-rich]");
              (next[after] as HTMLDivElement | undefined)?.focus();
            }, 30);
          }
        }}
        data-block-rich={block.id}
        dangerouslySetInnerHTML={{ __html: block.html || "" }}
        aria-label={BLOCK_LABEL[block.type]}
      />
      {/* Liste : marqueurs gérés par CSS pour l'affichage, export : un <p> par ligne */}
      {block.type === "list" && <span className="sr-only">{block.ordered ? "Liste numérotée" : "Liste à puces"}</span>}

      {!fillMode && focused && (
        <div className="sticky top-2 z-10 mt-1 mb-2 flex items-center gap-0.5 rounded-lg border bg-background/95 backdrop-blur shadow-sm p-1 w-fit" role="toolbar" aria-label="Mise en forme du texte">
          <FmtBtn label="Gras" onClick={() => exec("bold")} shortcut="Ctrl+G">
            <Bold className="size-3.5" aria-hidden />
          </FmtBtn>
          <FmtBtn label="Italique" onClick={() => exec("italic")}>
            <Italic className="size-3.5" aria-hidden />
          </FmtBtn>
          <FmtBtn label="Souligné" onClick={() => exec("underline")}>
            <UnderlineIcon className="size-3.5" aria-hidden />
          </FmtBtn>
          <FmtBtn label="Lien" onClick={() => {
            const url = window.prompt("Adresse du lien (https://…)");
            if (url) exec("createLink", url);
          }}>
            <Link2 className="size-3.5" aria-hidden />
          </FmtBtn>
          <div className="w-px h-4 bg-border mx-0.5" />
          <FmtBtn label="Aligner à gauche" onClick={() => exec("justifyLeft")}>
            <AlignLeft className="size-3.5" aria-hidden />
          </FmtBtn>
          <FmtBtn label="Centrer" onClick={() => exec("justifyCenter")}>
            <AlignCenter className="size-3.5" aria-hidden />
          </FmtBtn>
          <FmtBtn label="Aligner à droite" onClick={() => exec("justifyRight")}>
            <AlignRight className="size-3.5" aria-hidden />
          </FmtBtn>
          <div className="w-px h-4 bg-border mx-0.5" />
          <input
            type="color"
            className="size-6 rounded cursor-pointer border-none bg-transparent p-0"
            aria-label="Couleur du texte"
            onChange={(e) => exec("foreColor", e.target.value)}
            defaultValue="#1C1B1A"
          />
          <SpecialCharsMenu
            onInsert={(ch) => {
              document.execCommand("insertText", false, ch);
              if (ref.current) updateBlock(block.id, { html: cleanHtml(ref.current.innerHTML) });
            }}
          />
          {block.type === "list" && (
            <>
              <div className="w-px h-4 bg-border mx-0.5" />
              <FmtBtn label={block.ordered ? "Passer en puces" : "Passer en numérotée"} onClick={() => updateBlock(block.id, { ordered: !block.ordered })}>
                {block.ordered ? <List className="size-3.5" aria-hidden /> : <ListOrdered className="size-3.5" aria-hidden />}
              </FmtBtn>
            </>
          )}
          <div className="w-px h-4 bg-border mx-0.5" />
          <FmtBtn label="Supprimer le bloc" onClick={() => removeBlock(block.id)}>
            <Trash2 className="size-3.5 text-destructive" aria-hidden />
          </FmtBtn>
        </div>
      )}
    </div>
  );
}

function FmtBtn({ label, onClick, children, shortcut }: { label: string; onClick: () => void; children: React.ReactNode; shortcut?: string }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()} // conserve la sélection
          onClick={onClick}
          className="grid place-items-center size-7 rounded-md text-muted-foreground hover:bg-accent hover:text-accent-foreground focus-visible:outline-2 focus-visible:outline-ring"
          aria-label={label}
        >
          {children}
        </button>
      </TooltipTrigger>
      <TooltipContent>{label}{shortcut ? ` · ${shortcut}` : ""}</TooltipContent>
    </Tooltip>
  );
}

/** Caractères spéciaux français & typographie — insertion au curseur. */
const SPECIAL_CHARS = [
  "œ", "Œ", "æ", "Æ",
  "«", "»", "‹", "›",
  "—", "–", "…",
  "€", "©", "®", "™", "°",
  "±", "×", "÷", "≈", "≠", "≤", "≥",
  "•", "·",
] as const;

function SpecialCharsMenu({ onInsert }: { onInsert: (ch: string) => void }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()}
          className="grid place-items-center size-7 rounded-md text-muted-foreground hover:bg-accent hover:text-accent-foreground focus-visible:outline-2 focus-visible:outline-ring"
          aria-label="Caractères spéciaux"
          title="Caractères spéciaux"
          data-special-chars
        >
          <Omega className="size-3.5" aria-hidden />
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-64 p-2" onOpenAutoFocus={(e) => e.preventDefault()} onCloseAutoFocus={(e) => e.preventDefault()}>
        <p className="text-[11px] text-muted-foreground mb-1.5">Typographie française — clic pour insérer au curseur</p>
        <div className="grid grid-cols-8 gap-0.5">
          {SPECIAL_CHARS.map((ch) => (
            <button
              key={ch}
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => onInsert(ch)}
              className="grid place-items-center h-7 rounded text-sm hover:bg-accent hover:text-accent-foreground focus-visible:outline-2 focus-visible:outline-ring"
              aria-label={`Insérer ${ch}`}
            >
              {ch}
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}

// ---------------------------------------------------------------------------
// Bloc Checklist — tâches interactives (case cochée, réordonnancement)
// ---------------------------------------------------------------------------

function ChecklistBlock({ block, fillMode }: { block: Extract<Block, { type: "checklist" }>; fillMode: boolean }) {
  const addChecklistEntry = useEditorStore((s) => s.addChecklistEntry);
  const updateChecklistEntry = useEditorStore((s) => s.updateChecklistEntry);
  const removeChecklistEntry = useEditorStore((s) => s.removeChecklistEntry);
  const moveChecklistEntry = useEditorStore((s) => s.moveChecklistEntry);
  const [draft, setDraft] = useState("");
  const done = block.entries.filter((e) => e.done).length;
  const total = block.entries.length;

  function add() {
    const text = draft.trim();
    if (!text) return;
    addChecklistEntry(block.id, text);
    setDraft("");
  }

  return (
    <div className="my-2 rounded-lg border p-3 bg-[#FBFAF7]" data-checklist-block data-checklist-total={total} data-checklist-done={done}>
      <div className="flex items-center gap-2 mb-2">
        <ListChecks className="size-3.5 text-primary" aria-hidden />
        <span className="text-[11px] font-medium text-muted-foreground">
          Liste de tâches
          {total > 0 && (
            <>
              {" · "}
              <span className="tabular-nums">
                {done}/{total} {done === total && total > 0 ? "✓" : ""}
              </span>
            </>
          )}
        </span>
        {total > 0 && (
          <span className="flex-1 h-1 rounded-full bg-border overflow-hidden" role="progressbar" aria-valuenow={total ? Math.round((done / total) * 100) : 0} aria-valuemin={0} aria-valuemax={100} aria-label="Progression des tâches">
            <span className="block h-full bg-primary transition-all" style={{ width: `${total ? (done / total) * 100 : 0}%` }} />
          </span>
        )}
      </div>

      <ul className="space-y-0.5" role="list">
        {block.entries.map((entry, i) => (
          <li key={entry.id} className="group/entry flex items-center gap-2 rounded px-1 py-0.5 hover:bg-black/[0.03]" data-checklist-entry={entry.done ? "done" : "todo"}>
            <Checkbox
              checked={entry.done}
              onCheckedChange={(v) => updateChecklistEntry(block.id, entry.id, { done: v === true })}
              aria-label={entry.done ? `Marquer « ${entry.text} » comme à faire` : `Marquer « ${entry.text} » comme fait`}
            />
            <input
              value={entry.text}
              onChange={(e) => updateChecklistEntry(block.id, entry.id, { text: e.target.value })}
              className={cn(
                "flex-1 bg-transparent border-none outline-none text-[14px] rounded px-1 py-0.5 focus-visible:bg-white focus-visible:outline-1 focus-visible:outline-primary/40",
                entry.done && "line-through text-muted-foreground"
              )}
              aria-label={`Texte de la tâche ${i + 1}`}
              readOnly={fillMode}
            />
            {!fillMode && (
              <span className="flex items-center gap-0.5 opacity-0 group-hover/entry:opacity-100 transition-opacity">
                <button
                  className="grid place-items-center size-6 rounded text-muted-foreground/70 hover:text-foreground disabled:opacity-30"
                  disabled={i === 0}
                  onClick={() => moveChecklistEntry(block.id, i, i - 1)}
                  aria-label="Monter cette tâche"
                >
                  <AlignJustify className="size-3 rotate-180" aria-hidden />
                </button>
                <button
                  className="grid place-items-center size-6 rounded text-muted-foreground/70 hover:text-foreground disabled:opacity-30"
                  disabled={i === block.entries.length - 1}
                  onClick={() => moveChecklistEntry(block.id, i, i + 1)}
                  aria-label="Descendre cette tâche"
                >
                  <AlignJustify className="size-3" aria-hidden />
                </button>
                <button
                  className="grid place-items-center size-6 rounded text-muted-foreground/70 hover:text-destructive"
                  onClick={() => removeChecklistEntry(block.id, entry.id)}
                  aria-label="Supprimer cette tâche"
                >
                  <X className="size-3" aria-hidden />
                </button>
              </span>
            )}
          </li>
        ))}
      </ul>

      {!fillMode && (
        <div className="flex items-center gap-1.5 mt-1.5">
          <Plus className="size-3.5 text-muted-foreground shrink-0" aria-hidden />
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                add();
              }
            }}
            placeholder="Nouvelle tâche — Entrée pour ajouter"
            className="flex-1 bg-transparent border-none outline-none text-[13px] rounded px-1 py-0.5 focus-visible:outline-1 focus-visible:outline-primary/40"
            aria-label="Nouvelle tâche"
            data-checklist-input
          />
        </div>
      )}
    </div>
  );
}

/** Bloc de code : police à chasse fixe, fond grisé, export PDF équivalent. */
function CodeBlock({ block, fillMode }: { block: Extract<Block, { type: "code" }>; fillMode: boolean }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);
  const ref = useRef<HTMLDivElement>(null);
  const [focused, setFocused] = useState(false);

  return (
    <div className="relative group/code my-2">
      <div
        ref={ref}
        className="aos-block-editable rounded-lg border bg-[#F4F2ED] px-3.5 py-2.5 text-[12.5px] leading-relaxed outline-none min-h-[2.2em] whitespace-pre-wrap"
        style={{ fontFamily: MONO_STACK, color: "#33302B" }}
        contentEditable={!fillMode}
        suppressContentEditableWarning
        data-placeholder="const exemple = « du code » ;"
        data-block-rich={block.id}
        onFocus={() => setFocused(true)}
        onBlur={(e) => {
          setFocused(false);
          const html = cleanHtml(e.currentTarget.innerHTML);
          if (html !== block.html) updateBlock(block.id, { html });
        }}
        onKeyDown={(e) => e.stopPropagation()}
        dangerouslySetInnerHTML={{ __html: block.html || "" }}
        aria-label="Bloc de code"
      />
      {focused && (
        <span className="absolute -top-2 right-2 rounded bg-[#F4F2ED] border px-1.5 text-[9px] text-muted-foreground">
          Code — police à chasse fixe
        </span>
      )}
    </div>
  );
}

/** Encadré mis en évidence (information / attention / à retenir) — export PDF équivalent. */
function CalloutBlock({ block, fillMode }: { block: Extract<Block, { type: "callout" }>; fillMode: boolean }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);
  const ref = useRef<HTMLDivElement>(null);
  const style = CALLOUT_STYLES[block.variant] ?? CALLOUT_STYLES.info;
  const Icon = style.icon;

  return (
    <div className="relative group/callout my-2">
      <div
        className="rounded-lg pl-3.5 pr-3 py-2.5 flex gap-2.5 items-start"
        style={{ background: style.bg, borderLeft: `3px solid ${style.border}` }}
      >
        <Icon className="size-4 mt-0.5 shrink-0" style={{ color: style.border }} aria-hidden />
        <div
          ref={ref}
          className="aos-block-editable flex-1 text-[13.5px] leading-relaxed outline-none min-h-[1.6em]"
          contentEditable={!fillMode}
          suppressContentEditableWarning
          data-placeholder={`${style.label}…`}
          data-block-rich={block.id}
          onBlur={(e) => {
            const html = cleanHtml(e.currentTarget.innerHTML);
            if (html !== block.html) updateBlock(block.id, { html });
          }}
          onKeyDown={(e) => e.stopPropagation()}
          dangerouslySetInnerHTML={{ __html: block.html || "" }}
          aria-label={`Encadré ${style.label}`}
        />
        <Select value={block.variant} onValueChange={(v) => updateBlock(block.id, { variant: v as "info" | "warning" | "success" })}>
          <SelectTrigger
            className="h-6 w-24 text-[10px] opacity-0 group-hover/callout:opacity-100 focus-visible:opacity-100 transition-opacity shrink-0"
            aria-label="Type d'encadré"
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="info">Information</SelectItem>
            <SelectItem value="warning">Attention</SelectItem>
            <SelectItem value="success">À retenir</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}

function cleanHtml(html: string): string {
  // Autorise uniquement les balises de mise en forme ; nettoie les collages sauvages.
  const div = document.createElement("div");
  div.innerHTML = html;
  const allowed = new Set(["P", "B", "STRONG", "I", "EM", "U", "A", "SPAN", "BR"]);
  const walk = (node: Node) => {
    for (const child of Array.from(node.childNodes)) {
      if (child.nodeType === Node.ELEMENT_NODE) {
        const el = child as HTMLElement;
        if (!allowed.has(el.tagName)) {
          const frag = document.createDocumentFragment();
          while (el.firstChild) frag.appendChild(el.firstChild);
          el.replaceWith(frag);
          walk(node);
          return;
        }
        if (el.tagName === "SPAN") {
          const c = el.style?.color;
          if (!c) {
            const frag = document.createDocumentFragment();
            while (el.firstChild) frag.appendChild(el.firstChild);
            el.replaceWith(frag);
            walk(node);
            return;
          }
        }
        if (el.tagName === "A") {
          const href = el.getAttribute("href") ?? "";
          if (!/^https?:\/\//i.test(href)) {
            const frag = document.createDocumentFragment();
            while (el.firstChild) frag.appendChild(el.firstChild);
            el.replaceWith(frag);
            walk(node);
            return;
          }
        }
        walk(el);
      }
    }
  };
  walk(div);
  return div.innerHTML;
}

function ImageBlock({ block }: { block: Extract<Block, { type: "image" }> }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);
  const removeBlock = useEditorStore((s) => s.removeBlock);
  const url = useAssetUrl(block.assetId || null);
  const fileRef = useRef<HTMLInputElement>(null);

  if (!block.assetId || !url) {
    return (
      <div className="my-3">
        <button
          onClick={() => fileRef.current?.click()}
          className="w-full rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground hover:border-primary/50 hover:text-foreground transition-colors focus-visible:outline-2 focus-visible:outline-ring"
        >
          <ImagePlus className="size-5 mx-auto mb-1.5" aria-hidden />
          Ajouter une image
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          className="sr-only"
          aria-label="Choisir une image"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.currentTarget.value = "";
            if (!f) return;
            const assetId = uid();
            await putAsset({ id: assetId, blob: f, mime: f.type, createdAt: Date.now() });
            updateBlock(block.id, { assetId });
          }}
        />
      </div>
    );
  }

  return (
    <figure className="my-3 group/figure">
      <div className={cn("flex", block.align === "center" && "justify-center", block.align === "right" && "justify-end")}>
        { }
        <img
          src={url}
          alt="Image du document"
          className="rounded-md border shadow-sm max-w-full"
          style={{ width: `${block.widthPct}%` }}
          draggable={false}
        />
      </div>
      <div className="flex items-center gap-2 mt-1.5 opacity-0 group-hover/figure:opacity-100 transition-opacity">
        <label className="text-[10px] text-muted-foreground flex items-center gap-1.5">
          Largeur
          <input
            type="range"
            min={20}
            max={100}
            value={block.widthPct}
            onChange={(e) => updateBlock(block.id, { widthPct: Number(e.target.value) })}
            className="w-24 h-1 accent-[#0E7C66]"
            aria-label="Largeur de l'image (pour cent)"
          />
          <span className="tabular-nums w-8">{block.widthPct} %</span>
        </label>
        <Select value={block.align} onValueChange={(v) => updateBlock(block.id, { align: v as "left" | "center" | "right" })}>
          <SelectTrigger className="h-6 w-24 text-[10px]" aria-label="Alignement de l'image">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="left">Gauche</SelectItem>
            <SelectItem value="center">Centre</SelectItem>
            <SelectItem value="right">Droite</SelectItem>
          </SelectContent>
        </Select>
        <button
          className="text-[10px] text-muted-foreground hover:text-destructive inline-flex items-center gap-1 focus-visible:outline-2 focus-visible:outline-ring rounded"
          onClick={() => fileRef.current?.click()}
        >
          Remplacer
        </button>
        <button
          className="text-[10px] text-muted-foreground hover:text-destructive inline-flex items-center gap-1 focus-visible:outline-2 focus-visible:outline-ring rounded"
          onClick={() => removeBlock(block.id)}
        >
          <Trash2 className="size-3" aria-hidden />
          Supprimer
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          className="sr-only"
          aria-label="Remplacer l'image"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.currentTarget.value = "";
            if (!f) return;
            const assetId = uid();
            await putAsset({ id: assetId, blob: f, mime: f.type, createdAt: Date.now() });
            updateBlock(block.id, { assetId });
          }}
        />
      </div>
    </figure>
  );
}

function TableBlock({ block }: { block: Extract<Block, { type: "table" }> }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);
  const removeBlock = useEditorStore((s) => s.removeBlock);

  const setCell = (r: number, c: number, value: string) => {
    const rows = block.rows.map((row, ri) => (ri === r ? row.map((cell, ci) => (ci === c ? value : cell)) : row));
    updateBlock(block.id, { rows });
  };
  const addRow = (after: number) => {
    const rows = [...block.rows];
    const cols = rows[0]?.length ?? 3;
    rows.splice(after + 1, 0, new Array(cols).fill(""));
    updateBlock(block.id, { rows });
  };
  const removeRow = (r: number) => {
    if (block.rows.length <= 1) return;
    updateBlock(block.id, { rows: block.rows.filter((_, ri) => ri !== r) });
  };
  const addCol = () => {
    updateBlock(block.id, { rows: block.rows.map((row) => [...row, ""]) });
  };
  const removeCol = () => {
    if ((block.rows[0]?.length ?? 0) <= 1) return;
    updateBlock(block.id, { rows: block.rows.map((row) => row.slice(0, -1)) });
  };

  return (
    <div className="my-3 group/table">
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-[13px]">
          <tbody>
            {block.rows.map((row, r) => (
              <tr key={r} className="group/row">
                {row.map((cell, c) => (
                  <td
                    key={c}
                    className={cn(
                      "border border-[#DDDAD4] p-1.5 min-w-[90px] align-top",
                      block.header && r === 0 && "bg-[#EEF2F1] font-semibold"
                    )}
                  >
                    <div
                      className="aos-block-editable outline-none min-h-[1.4em]"
                      contentEditable
                      suppressContentEditableWarning
                      data-placeholder="…"
                      onBlur={(e) => setCell(r, c, e.currentTarget.innerText)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          (e.currentTarget as HTMLElement).blur();
                        }
                      }}
                      aria-label={`Cellule ${r + 1}-${c + 1}`}
                    >
                      {cell}
                    </div>
                  </td>
                ))}
                <td className="w-6 p-0 text-center">
                  <button
                    className="size-5 rounded text-muted-foreground/0 group-hover/row:text-muted-foreground/80 hover:text-destructive transition-colors focus-visible:text-destructive focus-visible:outline-2 focus-visible:outline-ring"
                    onClick={() => removeRow(r)}
                    aria-label={`Supprimer la ligne ${r + 1}`}
                  >
                    <Trash2 className="size-3 mx-auto" aria-hidden />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center gap-2 mt-1 opacity-0 group-hover/table:opacity-100 transition-opacity text-[10px]">
        <button className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1 rounded focus-visible:outline-2 focus-visible:outline-ring" onClick={() => addRow(block.rows.length - 1)}>
          <Plus className="size-3" aria-hidden /> Ligne
        </button>
        <button className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1 rounded focus-visible:outline-2 focus-visible:outline-ring" onClick={addCol}>
          <Plus className="size-3" aria-hidden /> Colonne
        </button>
        <button className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1 rounded focus-visible:outline-2 focus-visible:outline-ring" onClick={removeCol}>
          <Minus className="size-3" aria-hidden /> Colonne
        </button>
        <label className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1 rounded cursor-pointer focus-within:outline-2 focus-within:outline-ring">
          <input type="checkbox" checked={block.header} onChange={(e) => updateBlock(block.id, { header: e.target.checked })} className="size-3 accent-[#0E7C66]" />
          Ligne d&apos;en-tête
        </label>
        <button className="text-muted-foreground hover:text-destructive inline-flex items-center gap-1 rounded focus-visible:outline-2 focus-visible:outline-ring" onClick={() => removeBlock(block.id)}>
          <Trash2 className="size-3" aria-hidden /> Tableau
        </button>
      </div>
    </div>
  );
}

function FieldBlock({ block, fillMode }: { block: Extract<Block, { type: "field" }>; fillMode: boolean }) {
  const updateBlock = useEditorStore((s) => s.updateBlock);
  const removeBlock = useEditorStore((s) => s.removeBlock);
  const setFormValue = useEditorStore((s) => s.setFormValue);
  const doc = useEditorStore((s) => s.doc);
  const value = doc?.formValues[block.id];

  return (
    <div className="my-3 group/field">
      <div className="flex items-center gap-2">
        <label className="text-[13px] font-medium">
          {block.label}
          {block.required && <span className="text-destructive ml-0.5" aria-label="champ obligatoire">*</span>}
        </label>
        {!fillMode && (
          <span className="opacity-0 group-hover/field:opacity-100 transition-opacity flex items-center gap-1 text-[10px]">
            <button className="text-muted-foreground hover:text-destructive rounded focus-visible:outline-2 focus-visible:outline-ring" onClick={() => removeBlock(block.id)} aria-label="Supprimer le champ">
              <Trash2 className="size-3" aria-hidden />
            </button>
          </span>
        )}
      </div>

      {fillMode ? (
        <div className="mt-1">
          {block.fieldType === "checkbox" ? (
            <label className="flex items-center gap-2 text-[13px] cursor-pointer">
              <Checkbox checked={value === true} onCheckedChange={(v) => setFormValue(block.id, v === true)} aria-label={block.label} />
              <span className="text-muted-foreground">Cocher si applicable</span>
            </label>
          ) : block.fieldType === "multiline" ? (
            <Textarea
              value={String(value ?? "")}
              onChange={(e) => setFormValue(block.id, e.target.value)}
              className="mt-1 bg-white"
              aria-label={block.label}
              rows={3}
            />
          ) : (
            <Input
              type={block.fieldType === "date" ? "date" : "text"}
              value={String(value ?? "")}
              onChange={(e) => setFormValue(block.id, e.target.value)}
              className="mt-1 bg-white"
              aria-label={block.label}
            />
          )}
        </div>
      ) : (
        <div className="mt-1">
          {block.fieldType === "checkbox" ? (
            <div className="h-[18px] w-[18px] rounded-[3px] border border-[#8A8781] bg-white/60" aria-hidden />
          ) : block.fieldType === "multiline" ? (
            <div className="h-16 rounded-[4px] border border-[#8A8781] bg-white/60" aria-hidden />
          ) : (
            <div className="h-7 rounded-[4px] border border-[#8A8781] bg-white/60" aria-hidden />
          )}
          <div className="opacity-0 group-hover/field:opacity-100 transition-opacity mt-1 flex items-center gap-2 text-[10px]">
            <input
              type="text"
              value={block.label}
              onChange={(e) => updateBlock(block.id, { label: e.target.value })}
              className="h-6 w-44 rounded border bg-background px-2 focus-visible:outline-2 focus-visible:outline-ring"
              aria-label="Libellé du champ"
            />
            <label className="text-muted-foreground inline-flex items-center gap-1 cursor-pointer">
              <input type="checkbox" checked={block.required} onChange={(e) => updateBlock(block.id, { required: e.target.checked })} className="size-3 accent-[#0E7C66]" />
              Obligatoire
            </label>
          </div>
        </div>
      )}
    </div>
  );
}
