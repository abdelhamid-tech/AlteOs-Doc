"use client";

/**
 * Lecture à voix haute — SpeechSynthesis du navigateur (local, gratuit).
 * Contrôles : lecture, pause, reprise, arrêt, voix, vitesse, segment courant.
 */

import { useEffect, useMemo, useState } from "react";
import { Pause, Play, Square, Volume2 } from "lucide-react";

import { speak, type SpeakSegment, type SpeakState } from "@/lib/tts";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

export function SpeakDialog({
  open,
  onClose,
  segments,
  title,
}: {
  open: boolean;
  onClose: () => void;
  segments: SpeakSegment[];
  title: string;
}) {
  const [state, setState] = useState<SpeakState>({ supported: true, playing: false, paused: false, segmentIndex: 0, total: 0 });
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceURI, setVoiceURI] = useState<string>("");
  const [rate, setRate] = useState(1);

  useEffect(() => {
    const off = speak.setListener(setState);
    return off;
  }, []);

  useEffect(() => {
    if (!open) return;
    const load = () => {
      const fr = speak.frenchVoices();
      setVoices(fr);
      const preferred = fr.find((v) => v.lang.toLowerCase().startsWith("fr"));
      if (preferred) setVoiceURI(preferred.voiceURI);
    };
    load();
    // Les voix arrivent de façon asynchrone dans certains navigateurs.
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.onvoiceschanged = load;
    }
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, [open]);

  useEffect(() => {
    speak.setVoice(voices.find((v) => v.voiceURI === voiceURI) ?? null);
  }, [voiceURI, voices]);

  useEffect(() => {
    speak.setRate(rate);
  }, [rate]);

  useEffect(() => {
    if (!open) speak.stop();
  }, [open]);

  const current = useMemo(() => segments[state.segmentIndex] ?? null, [segments, state.segmentIndex]);

  if (!open) return null;

  if (!state.supported) {
    return (
      <Dialog open onOpenChange={(v) => !v && onClose()}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Volume2 className="size-4 text-primary" aria-hidden />
              Lecture à voix haute
            </DialogTitle>
            <DialogDescription>
              Votre navigateur ne fournit pas de synthèse vocale. Aucune lecture n&apos;est simulée — essayez un navigateur récent (Chrome, Edge, Firefox).
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md" data-speak-dialog>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Volume2 className="size-4 text-primary" aria-hidden />
            Lecture à voix haute
          </DialogTitle>
          <DialogDescription>
            {segments.length > 0
              ? `${segments.length} passage${segments.length > 1 ? "s" : ""} de « ${title} » — voix synthétisée localement par votre navigateur.`
              : "Ce document ne contient pas encore de texte lisible."}
          </DialogDescription>
        </DialogHeader>

        {segments.length > 0 && (
          <>
            <div className="rounded-lg border bg-secondary/40 p-3 min-h-[72px]" aria-live="polite">
              {current ? (
                <>
                  <p className="text-[11px] text-muted-foreground mb-1 tabular-nums" data-speak-position>
                    Passage {state.segmentIndex + 1} / {segments.length}
                  </p>
                  <p className="text-sm leading-relaxed line-clamp-2">{current.label}</p>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">{state.playing ? "…" : "Prêt à lire — appuyez sur Lecture."}</p>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button onClick={() => speak.start(segments, state.segmentIndex)} disabled={state.playing && !state.paused} data-speak-play>
                <Play className="size-4 mr-1.5" aria-hidden />
                {state.paused ? "Reprendre" : "Lire"}
              </Button>
              <Button
                variant="secondary"
                onClick={() => (state.paused ? speak.resume() : speak.pause())}
                disabled={!state.playing}
                aria-label={state.paused ? "Reprendre la lecture" : "Mettre en pause"}
              >
                <Pause className="size-4" aria-hidden />
              </Button>
              <Button
                variant="secondary"
                onClick={() => speak.stop()}
                disabled={!state.playing && !state.paused}
                aria-label="Arrêter la lecture"
              >
                <Square className="size-4" aria-hidden />
              </Button>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Voix installée sur cet appareil</Label>
                <Select value={voiceURI} onValueChange={setVoiceURI}>
                  <SelectTrigger className="text-xs" aria-label="Choisir la voix">
                    <SelectValue placeholder={voices.length ? "Voix du système" : "Voix par défaut"} />
                  </SelectTrigger>
                  <SelectContent>
                    {voices.slice(0, 30).map((v) => (
                      <SelectItem key={v.voiceURI} value={v.voiceURI}>
                        {v.name} ({v.lang})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {voices.length === 0 && (
                  <p className="text-[11px] text-muted-foreground/80">
                    Aucune voix détectée pour l&apos;instant — la voix par défaut du système sera utilisée.
                  </p>
                )}
              </div>
              <div className="flex items-center gap-3">
                <Label className="text-xs text-muted-foreground w-20 shrink-0">Vitesse</Label>
                <Slider value={[rate]} min={0.5} max={2} step={0.1} onValueChange={(v) => setRate(v[0])} aria-label="Vitesse de lecture" className="flex-1" />
                <span className="text-xs tabular-nums text-muted-foreground w-10">{rate.toFixed(1)}×</span>
              </div>
            </div>

            {/* File d'attente cliquable */}
            <div className="max-h-36 overflow-y-auto editor-scroll rounded-lg border divide-y" data-speak-queue>
              {segments.map((seg, i) => (
                <button
                  key={i}
                  className={cn(
                    "w-full text-left px-2.5 py-1.5 text-xs hover:bg-accent/50 transition-colors flex items-center gap-2",
                    i === state.segmentIndex && state.playing && "bg-accent/70"
                  )}
                  onClick={() => speak.start(segments, i)}
                  aria-label={`Lire à partir du passage ${i + 1}`}
                >
                  <span className="tabular-nums text-muted-foreground w-5 shrink-0">{i + 1}</span>
                  <span className="truncate">{seg.label}</span>
                </button>
              ))}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
