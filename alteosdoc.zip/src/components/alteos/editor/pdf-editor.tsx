"use client";

/**
 * AlteOS Editor — mode PDF.
 * Lecteur pdf.js (rendu virtuel), couche de texte sélectionnable,
 * annotations, zoom, navigation et organisation des pages.
 */

import { useCallback, useEffect, useRef, useState } from "react";

import { useEditorStore } from "@/store/editor-store";
import { editorBackdropClass, useUiPrefs } from "@/store/ui-prefs";
import { renderPageToCanvas, renderTextLayer, loadPdfDocument, renderThumb } from "@/lib/pdf/engine";
import { pageTransform } from "@/lib/pdf/transform";
import { PageSurface } from "./page-surface";
import { ToolRail } from "./tool-rail";
import { ContextBar } from "./context-bar";
import { ThumbsPanel } from "./thumbs-panel";
import { LayersPanel } from "./layers-panel";
import { SignatureModal } from "./signature-modal";
import { CropDialog } from "./crop-dialog";
import { ZoomControls } from "./zoom-controls";
import { EditorStatusBar, StatusItem } from "./status-bar";
import { TextSelectionToolbar } from "./text-selection-toolbar";
import { mergePdfSources, extractPagesToDoc } from "@/lib/pdf/export";
import { putAsset } from "@/lib/idb";
import { uid, type ImageItem, type PageRef } from "@/lib/types";
import { downloadBlob, sanitizeFilename } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function PdfEditor({
  onExport,
  onOpenSignature,
  onCropImage,
}: {
  onExport: () => void;
  onOpenSignature: () => void;
  onCropImage: (item: ImageItem) => void;
}) {
  const doc = useEditorStore((s) => s.doc);
  const pdfDoc = useEditorStore((s) => s.pdfDoc);
  const tool = useEditorStore((s) => s.tool);
  const setTool = useEditorStore((s) => s.setTool);
  const zoom = useEditorStore((s) => s.zoom);
  const setZoom = useEditorStore((s) => s.setZoom);
  const addItems = useEditorStore((s) => s.addItems);
  const color = useEditorStore((s) => s.color);
  const highlightColor = useEditorStore((s) => s.highlightColor);
  const selectedPageIds = useEditorStore((s) => s.selectedPageIds);
  const setThumb = useEditorStore((s) => s.setThumb);
  const layersOpen = useEditorStore((s) => s.layersOpen);
  const currentPageIndex = useEditorStore((s) => s.currentPageIndex);
  const editorPrefs = useUiPrefs((s) => s.editor);
  const updateEditorPrefs = useUiPrefs((s) => s.updateEditor);
  const showThumbs = editorPrefs.thumbs;
  const [selectionInfo, setSelectionInfo] = useState<{
    pageId: string;
    quads: { x: number; y: number; w: number; h: number }[];
    toolbar: { x: number; y: number };
  } | null>(null);
  const mergeRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const spaceDown = useRef(false);

  const pages = doc?.pages ?? [];

  // Signature depuis le rail d'outils
  useEffect(() => {
    if (tool === "signature") {
      onOpenSignature();
      setTool("select");
    }
  }, [tool, onOpenSignature, setTool]);

  // Zoom initial : largeur de page
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !doc || doc.pages.length === 0) return;
    const firstSize = doc.srcPageSizes[doc.pages[0].src] ?? { w: 595.28, h: 841.89 };
    const fit = (el.clientWidth - 90) / firstSize.w;
    setZoom(Math.min(1.5, Math.max(0.35, fit)));
     
  }, []);

  // Ctrl + molette = zoom
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.12 : 0.12;
      setZoom(useEditorStore.getState().zoom + delta);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [setZoom]);

  // Pan : outil main ou espace
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    let panning = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;
    const isPanContext = () => useEditorStore.getState().tool === "pan" || spaceDown.current;
    const onDown = (e: MouseEvent) => {
      if (e.button !== 0 || !isPanContext()) return;
      panning = true;
      startX = e.clientX;
      startY = e.clientY;
      startLeft = el.scrollLeft;
      startTop = el.scrollTop;
      el.style.cursor = "grabbing";
      e.preventDefault();
    };
    const onMove = (e: MouseEvent) => {
      if (!panning) return;
      el.scrollLeft = startLeft - (e.clientX - startX);
      el.scrollTop = startTop - (e.clientY - startY);
    };
    const onUp = () => {
      panning = false;
      el.style.cursor = "";
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space" && !(e.target as HTMLElement).isContentEditable && (e.target as HTMLElement).tagName !== "INPUT" && (e.target as HTMLElement).tagName !== "TEXTAREA") {
        spaceDown.current = e.type === "keydown";
        if (e.type === "keydown") e.preventDefault();
      }
    };
    el.addEventListener("mousedown", onDown);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKey);
    return () => {
      el.removeEventListener("mousedown", onDown);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKey);
    };
  }, []);

  // Ferme la barre de sélection de texte au clic ailleurs
  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if ((e.target as HTMLElement).closest("[data-selection-toolbar]")) return;
      setSelectionInfo(null);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  async function applyTextMark(type: "highlight" | "underline" | "strike") {
    if (!selectionInfo || selectionInfo.quads.length === 0) return;
    const xs = selectionInfo.quads.map((q) => q.x);
    const ys = selectionInfo.quads.map((q) => q.y);
    addItems([
      {
        id: uid(),
        pageId: selectionInfo.pageId,
        createdAt: Date.now(),
        type,
        x: Math.min(...xs),
        y: Math.min(...ys),
        w: Math.max(...selectionInfo.quads.map((q) => q.x + q.w)) - Math.min(...xs),
        h: Math.max(...selectionInfo.quads.map((q) => q.y + q.h)) - Math.min(...ys),
        quads: selectionInfo.quads,
        color: type === "highlight" ? highlightColor : color,
      },
    ]);
    window.getSelection()?.removeAllRanges();
    setSelectionInfo(null);
  }

  async function handleMerge(file: File) {
    const srcBytes = doc?.pdfBytes;
    if (!srcBytes) return;
    toast.promise(
      (async () => {
        const extraBytes = await file.arrayBuffer();
        const { bytes, baseCount, extraCount } = await mergePdfSources(srcBytes, extraBytes);
        const loaded = await loadPdfDocument(bytes);
        const existingPages = doc.pages;
        const newRefs: PageRef[] = [];
        for (let i = 0; i < extraCount; i++) {
          newRefs.push({ id: `pg-${uid()}`, src: baseCount + i, rotation: 0 });
        }
        useEditorStore.setState({
          doc: { ...doc, pdfBytes: bytes, pages: [...existingPages, ...newRefs], srcPageSizes: loaded.pageSizes },
          pdfDoc: loaded.doc,
          dirty: true,
        });
        try {
          const { blob } = await renderThumb(loaded.doc, existingPages[0]?.src ?? 0, 240, existingPages[0]?.rotation ?? 0);
          setThumb(blob);
        } catch {
          /* vignette optionnelle */
        }
        return extraCount;
      })(),
      {
        loading: "Fusion des documents…",
        success: (n: number) => `${extraCountLabel(n)} — fusion terminée`,
        error: "La fusion a échoué",
      }
    );
  }

  function extraCountLabel(n: number) {
    return `${n} page${n > 1 ? "s" : ""} ajoutée${n > 1 ? "s" : ""}`;
  }

  async function handleExtract(pageIds: string[]) {
    if (!doc) return;
    toast.promise(
      (async () => {
        const blob = await extractPagesToDoc(doc, pageIds);
        downloadBlob(blob, `${sanitizeFilename(doc.name)}-extrait.pdf`);
      })(),
      { loading: "Extraction des pages…", success: "PDF extrait — enregistré dans vos téléchargements", error: "L'extraction a échoué" }
    );
  }

  const onAddImage = useCallback(
    async (file: File) => {
      const state = useEditorStore.getState();
      const currentDoc = state.doc;
      if (!currentDoc) return;
      const pageRef = currentDoc.pages[Math.min(state.currentPageIndex, currentDoc.pages.length - 1)];
      if (!pageRef) return;
      const assetId = uid();
      await putAsset({ id: assetId, blob: file, mime: file.type, createdAt: Date.now() });
      const dims = await new Promise<{ w: number; h: number }>((resolve) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => {
          resolve({ w: img.naturalWidth, h: img.naturalHeight });
          URL.revokeObjectURL(url);
        };
        img.onerror = () => {
          resolve({ w: 400, h: 300 });
          URL.revokeObjectURL(url);
        };
        img.src = url;
      });
      const size = currentDoc.srcPageSizes[pageRef.src] ?? { w: 595.28, h: 841.89 };
      const wPt = Math.min(dims.w * 0.75, size.w * 0.7);
      const hPt = wPt * (dims.h / dims.w);
      state.addItems([
        {
          id: uid(),
          pageId: pageRef.id,
          createdAt: Date.now(),
          type: "image",
          x: (size.w - wPt) / 2,
          y: Math.min(size.h * 0.35, Math.max(20, size.h - hPt - 20)),
          w: wPt,
          h: hPt,
          assetId,
          rotation: 0,
          opacity: 1,
        },
      ]);
      state.setTool("select");
    },
    []
  );

  if (!doc || !pdfDoc) {
    return (
      <div className="flex-1 grid place-items-center" role="status">
        <p className="text-sm text-muted-foreground">Ouverture du document…</p>
      </div>
    );
  }

  return (
    <div className="flex flex-1 min-h-0">
      <ToolRail mode="pdf" />
      {showThumbs && <ThumbsPanel onExtract={handleExtract} onMerge={() => mergeRef.current?.click()} className="hidden md:flex" />}
      <div className="flex-1 flex flex-col min-w-0">
        <ContextBar onRequestCrop={onCropImage} />
        <div
          ref={scrollRef}
          className={cn(
            "relative flex-1 overflow-auto editor-scroll",
            editorBackdropClass(editorPrefs.backdrop)
          )}
        >
          <div
            className={cn(
              "flex flex-col items-center px-6 w-fit min-w-full",
              editorPrefs.pageGap === "aeree" ? "gap-10 py-14" : "gap-6 py-8"
            )}
          >
            {doc.pages.map((p, i) => (
              <PdfPageSlot
                key={p.id}
                index={i}
                src={p.src}
                rotation={p.rotation}
                pageId={p.id}
                zoom={zoom}
                pdfDoc={pdfDoc}
                showTextLayer={tool === "select"}
                selection={selectionInfo?.pageId === p.id ? selectionInfo : null}
                onSelection={(payload) => setSelectionInfo(payload ? { pageId: p.id, ...payload } : null)}
                onTextMark={applyTextMark}
              />
            ))}
          </div>
        </div>
        {editorPrefs.statusBar ? (
          <EditorStatusBar
            pageLabel={`Page ${Math.min(currentPageIndex + 1, doc.pages.length)} / ${doc.pages.length}`}
            extra={
              selectedPageIds.length > 0 ? (
                <StatusItem>
                  {selectedPageIds.length} page{selectedPageIds.length > 1 ? "s" : ""} sélectionnée
                  {selectedPageIds.length > 1 ? "s" : ""}
                </StatusItem>
              ) : undefined
            }
            onToggleThumbs={() => updateEditorPrefs({ thumbs: !showThumbs })}
            thumbsOpen={showThumbs}
          />
        ) : (
          <ZoomControls />
        )}
      </div>
      {layersOpen && doc.pages[Math.min(currentPageIndex, doc.pages.length - 1)] && (
        <LayersPanel pageId={doc.pages[Math.min(currentPageIndex, doc.pages.length - 1)].id} className="hidden md:flex" />
      )}
      <input
        ref={mergeRef}
        type="file"
        accept="application/pdf,.pdf"
        className="sr-only"
        aria-label="Fusionner un PDF"
        onChange={(e) => {
          const f = e.target.files?.[0];
          e.currentTarget.value = "";
          if (f) handleMerge(f);
        }}
      />
      <ImageToolBridge onAddImage={onAddImage} />
    </div>
  );
}

/** Outil « image » : ouvre le sélecteur de fichier. */
function ImageToolBridge({ onAddImage }: { onAddImage: (f: File) => void }) {
  const tool = useEditorStore((s) => s.tool);
  const setTool = useEditorStore((s) => s.setTool);
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (tool === "image") ref.current?.click();
  }, [tool]);
  return (
    <input
      ref={ref}
      type="file"
      accept="image/png,image/jpeg,image/webp"
      className="sr-only"
      aria-label="Ajouter une image"
      onChange={(e) => {
        const f = e.target.files?.[0];
        e.currentTarget.value = "";
        if (f) onAddImage(f);
        setTool("select");
      }}
    />
  );
}

// ---------------------------------------------------------------------------
// Une page PDF : canvas + couche de texte + surface interactive
// ---------------------------------------------------------------------------

interface SelectionPayload {
  quads: { x: number; y: number; w: number; h: number }[];
  toolbar: { x: number; y: number };
}

function PdfPageSlot({
  index,
  src,
  rotation,
  pageId,
  zoom,
  pdfDoc,
  showTextLayer,
  selection,
  onSelection,
  onTextMark,
}: {
  index: number;
  src: number;
  rotation: number;
  pageId: string;
  zoom: number;
  pdfDoc: import("pdfjs-dist").PDFDocumentProxy;
  showTextLayer: boolean;
  selection: SelectionPayload | null;
  onSelection: (payload: SelectionPayload | null) => void;
  onTextMark: (type: "highlight" | "underline" | "strike") => void;
}) {
  const setCurrentPageIndex = useEditorStore((s) => s.setCurrentPageIndex);
  const tool = useEditorStore((s) => s.tool);
  const sizes = useEditorStore((s) => s.doc?.srcPageSizes ?? []);
  const size = sizes[src] ?? { w: 595.28, h: 841.89 };
  const uw = size.w;
  const uh = size.h;
  const swap = ((rotation % 180) + 360) % 360 !== 0;
  const placeholderW = (swap ? uh : uw) * zoom;
  const placeholderH = (swap ? uw : uh) * zoom;

  const slotRef = useRef<HTMLDivElement>(null);
  const canvasHostRef = useRef<HTMLDivElement>(null);
  const textHostRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(index < 2);
  const [renderedZoom, setRenderedZoom] = useState<number | null>(null);

  // Visibilité (rendu virtuel)
  useEffect(() => {
    const el = slotRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const en of entries) {
          if (en.isIntersecting) {
            setVisible(true);
            if (en.intersectionRatio > 0.35) setCurrentPageIndex(index);
          }
        }
      },
      { root: null, rootMargin: "500px 0px", threshold: [0, 0.35, 0.6] }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [index, setCurrentPageIndex]);

  // Rendu canvas (débounce lors des changements de zoom)
  useEffect(() => {
    if (!visible || !canvasHostRef.current) return;
    if (renderedZoom === zoom) return;
    const host = canvasHostRef.current;
    const timer = setTimeout(
      async () => {
        try {
          const canvas = document.createElement("canvas");
          await renderPageToCanvas(pdfDoc, src, canvas, zoom, rotation);
          host.replaceChildren(canvas);
          setRenderedZoom(zoom);
        } catch {
          /* rendu interrompu */
        }
      },
      renderedZoom === null ? 0 : 140
    );
    return () => clearTimeout(timer);
  }, [visible, zoom, src, rotation, pdfDoc, renderedZoom]);

  // Couche de texte (outil Sélectionner)
  useEffect(() => {
    const host = textHostRef.current;
    if (!host) return;
    if (!showTextLayer || !visible) {
      host.replaceChildren();
      return;
    }
    let cancelled = false;
    let cleanup = () => {};
    (async () => {
      try {
        const div = document.createElement("div");
        div.className = "textLayer";
        cleanup = await renderTextLayer(pdfDoc, src, div, zoom, rotation);
        if (cancelled) {
          cleanup();
          return;
        }
        host.replaceChildren(div);
      } catch {
        /* pas de texte sur cette page */
      }
    })();
    return () => {
      cancelled = true;
      cleanup();
    };
  }, [showTextLayer, visible, zoom, src, rotation, pdfDoc]);

  // Sélection de texte → quads + barre d'outils flottante
  useEffect(() => {
    const host = textHostRef.current;
    if (!host) return;
    const onMouseUp = () => {
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed || sel.rangeCount === 0) return;
      const anchor = sel.anchorNode;
      if (!anchor || !host.contains(anchor)) return;
      const range = sel.getRangeAt(0);
      const rects = Array.from(range.getClientRects()).filter((r) => r.width > 1 && r.height > 1);
      if (rects.length === 0) return;
      const hostRect = host.getBoundingClientRect();
      const t = pageTransform(uw, uh, zoom, rotation);
      const quads = rects.map((r) => {
        const p1 = t.toUser(r.left - hostRect.left, r.top - hostRect.top);
        const p2 = t.toUser(r.right - hostRect.left, r.bottom - hostRect.top);
        return { x: Math.min(p1.x, p2.x), y: Math.min(p1.y, p2.y), w: Math.abs(p2.x - p1.x), h: Math.abs(p2.y - p1.y) };
      });
      const first = rects[0];
      onSelection({
        quads,
        toolbar: {
          x: first.left - hostRect.left + Math.min(first.width / 2, 140),
          y: first.top - hostRect.top - 8,
        },
      });
    };
    host.addEventListener("mouseup", onMouseUp);
    return () => host.removeEventListener("mouseup", onMouseUp);
  }, [uw, uh, zoom, rotation, onSelection]);

  return (
    <div data-page-slot={index} ref={slotRef} className="relative flex flex-col items-center">
      <div style={{ width: placeholderW, height: placeholderH }} className="relative">
        <PageSurface pageId={pageId} uw={uw} uh={uh} rotation={rotation} scale={zoom}>
          <div ref={canvasHostRef} style={{ position: "absolute", inset: 0 }} />
          <div
            ref={textHostRef}
            data-text-layer=""
            style={{ position: "absolute", inset: 0, zIndex: 2, pointerEvents: showTextLayer && visible ? "auto" : "none" }}
          />
        </PageSurface>
        {renderedZoom === null && (
          <div className="absolute inset-0 grid place-items-center bg-secondary/40 aos-page" role="status">
            <span className="text-xs text-muted-foreground/70">Rendu de la page…</span>
          </div>
        )}
        {selection && tool === "select" && (
          <TextSelectionToolbar
            x={selection.toolbar.x}
            y={selection.toolbar.y}
            onHighlight={() => onTextMark("highlight")}
            onUnderline={() => onTextMark("underline")}
            onStrike={() => onTextMark("strike")}
            onCopy={async () => {
              const text = window.getSelection()?.toString() ?? "";
              if (text) await navigator.clipboard.writeText(text).catch(() => undefined);
              onSelection(null);
            }}
          />
        )}
      </div>
      <span className="text-[10px] text-muted-foreground/60 mt-2 tabular-nums">Page {index + 1}</span>
    </div>
  );
}
