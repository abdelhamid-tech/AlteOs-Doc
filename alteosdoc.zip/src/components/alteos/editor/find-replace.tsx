"use client";

/**
 * Recherche & remplacement — parcours les blocs du document (titres,
 * paragraphes, listes, citations, encadrés, code) et remplace dans les
 * nœuds texte du HTML afin de préserver la mise en forme (gras, italique…).
 */

import { useMemo, useState } from "react";
import { CaseSensitive, Replace, ReplaceAll, Search, X } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import type { Block } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";

function blockTexts(block: Block): string {
  if ("text" in block) return block.text;
  if (block.type === "checklist") return block.entries.map((e) => e.text).join("\n");
  if ("html" in block) {
    const div = document.createElement("div");
    div.innerHTML = block.html;
    return div.textContent ?? "";
  }
  return "";
}

/** Remplace dans les nœuds texte d'un HTML (conserve les balises). */
function replaceInHtml(html: string, find: string, replace: string, caseSensitive: boolean): { html: string; count: number } {
  const div = document.createElement("div");
  div.innerHTML = html;
  let count = 0;
  const flags = caseSensitive ? "g" : "gi";
  let pattern: RegExp;
  try {
    pattern = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), flags);
  } catch {
    return { html, count: 0 };
  }
  const walker = document.createTreeWalker(div, NodeFilter.SHOW_TEXT);
  const nodes: Text[] = [];
  while (walker.nextNode()) nodes.push(walker.currentNode as Text);
  for (const node of nodes) {
    if (!node.nodeValue) continue;
    const matches = node.nodeValue.match(pattern);
    if (!matches) continue;
    count += matches.length;
    node.nodeValue = node.nodeValue.replace(pattern, replace);
  }
  return { html: div.innerHTML, count };
}

function replaceInText(text: string, find: string, replace: string, caseSensitive: boolean): { text: string; count: number } {
  const flags = caseSensitive ? "g" : "gi";
  const pattern = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), flags);
  const matches = text.match(pattern);
  return { text: text.replace(pattern, replace), count: matches?.length ?? 0 };
}

interface Match {
  blockId: string;
  index: number;
  snippet: string;
}

export function FindReplaceDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const doc = useEditorStore((s) => s.doc);
  const updateBlock = useEditorStore((s) => s.updateBlock);
  const [find, setFind] = useState("");
  const [replaceWith, setReplaceWith] = useState("");
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [cursor, setCursor] = useState(0);

  const matches = useMemo<Match[]>(() => {
    if (!doc || !find.trim()) return [];
    const needle = caseSensitive ? find : find.toLowerCase();
    const out: Match[] = [];
    for (const block of doc.blocks) {
      const text = blockTexts(block);
      if (!text) continue;
      const hay = caseSensitive ? text : text.toLowerCase();
      let from = 0;
      let idx = hay.indexOf(needle, from);
      while (idx !== -1) {
        const start = Math.max(0, idx - 22);
        const end = Math.min(text.length, idx + needle.length + 26);
        out.push({
          blockId: block.id,
          index: out.length,
          snippet: `${start > 0 ? "…" : ""}${text.slice(start, end).replace(/\s+/g, " ")}${end < text.length ? "…" : ""}`,
        });
        from = idx + needle.length;
        idx = hay.indexOf(needle, from);
      }
    }
    return out;
  }, [doc, find, caseSensitive]);

  if (!open) return null;

  function scrollToMatch(blockId: string) {
    const host = document.querySelector(`[data-block-id="${blockId}"]`);
    host?.scrollIntoView({ behavior: "smooth", block: "center" });
    if (host) {
      host.classList.add("aos-find-flash");
      setTimeout(() => host.classList.remove("aos-find-flash"), 1200);
    }
  }

  function replaceOne(match: Match) {
    if (!doc) return;
    const block = doc.blocks.find((b) => b.id === match.blockId);
    if (!block) return;
    if ("text" in block) {
      const { text, count } = replaceInText(block.text, find, replaceWith, caseSensitive);
      if (count > 0) updateBlock(block.id, { text } as Partial<Block>);
    } else if (block.type === "checklist") {
      const entries = block.entries.map((e) => ({ ...e, ...replaceInText(e.text, find, replaceWith, caseSensitive) }));
      updateBlock(block.id, { entries } as Partial<Block>);
    } else if ("html" in block) {
      const { html, count } = replaceInHtml(block.html, find, replaceWith, caseSensitive);
      if (count > 0) updateBlock(block.id, { html } as Partial<Block>);
    }
  }

  function replaceAll() {
    if (!doc || !find.trim()) return;
    let total = 0;
    for (const block of doc.blocks) {
      if ("text" in block) {
        const { text, count } = replaceInText(block.text, find, replaceWith, caseSensitive);
        if (count > 0) {
          updateBlock(block.id, { text } as Partial<Block>);
          total += count;
        }
      } else if (block.type === "checklist") {
        let blockCount = 0;
        const entries = block.entries.map((e) => {
          const r = replaceInText(e.text, find, replaceWith, caseSensitive);
          blockCount += r.count;
          return { ...e, text: r.text };
        });
        if (blockCount > 0) {
          updateBlock(block.id, { entries } as Partial<Block>);
          total += blockCount;
        }
      } else if ("html" in block) {
        const { html, count } = replaceInHtml(block.html, find, replaceWith, caseSensitive);
        if (count > 0) {
          updateBlock(block.id, { html } as Partial<Block>);
          total += count;
        }
      }
    }
    toast.success(
      total > 0 ? `${total} remplacement${total > 1 ? "s" : ""} effectué${total > 1 ? "s" : ""}` : "Aucune occurrence trouvée",
      { description: "« " + find + " » → « " + replaceWith + " »" }
    );
  }

  return (
    <div className="fixed inset-0 z-40 bg-black/20" onClick={onClose} role="dialog" aria-modal="true" aria-label="Rechercher et remplacer">
      <div
        className="absolute top-4 left-1/2 -translate-x-1/2 w-[min(92vw,560px)] rounded-xl border bg-background shadow-xl"
        onClick={(e) => e.stopPropagation()}
        data-find-replace
      >
        <div className="flex items-center gap-2 px-3 pt-3">
          <Search className="size-4 text-muted-foreground shrink-0" aria-hidden />
          <span className="text-sm font-medium flex-1">Rechercher et remplacer</span>
          <Button variant="ghost" size="icon" className="size-7" onClick={onClose} aria-label="Fermer">
            <X className="size-3.5" aria-hidden />
          </Button>
        </div>
        <div className="flex items-center gap-2 px-3 py-2.5">
          <Input
            autoFocus
            value={find}
            onChange={(e) => {
              setFind(e.target.value);
              setCursor(0);
            }}
            placeholder="Texte à rechercher…"
            className="h-8 text-sm flex-1"
            aria-label="Texte à rechercher"
            data-find-input
          />
          <Button
            variant={caseSensitive ? "default" : "secondary"}
            size="icon"
            className="size-8 shrink-0"
            onClick={() => setCaseSensitive((c) => !c)}
            aria-pressed={caseSensitive}
            aria-label="Respecter la casse"
            title="Respecter la casse"
          >
            <CaseSensitive className="size-4" aria-hidden />
          </Button>
        </div>
        <div className="flex items-center gap-2 px-3 pb-2.5">
          <Replace className="size-4 text-muted-foreground/50 shrink-0" aria-hidden />
          <Input
            value={replaceWith}
            onChange={(e) => setReplaceWith(e.target.value)}
            placeholder="Remplacer par…"
            className="h-8 text-sm flex-1"
            aria-label="Remplacer par"
          />
        </div>
        <div className="flex items-center justify-between gap-2 px-3 pb-3">
          <span className="text-xs text-muted-foreground tabular-nums" data-find-count>
            {find.trim() ? `${matches.length} occurrence${matches.length > 1 ? "s" : ""}` : "—"}
          </span>
          <div className="flex items-center gap-1.5">
            <Button
              variant="secondary"
              size="sm"
              className="h-8"
              disabled={matches.length === 0}
              onClick={() => {
                const m = matches[cursor % matches.length];
                if (m) {
                  scrollToMatch(m.blockId);
                  setCursor((c) => (c + 1) % matches.length);
                }
              }}
            >
              Suivant
            </Button>
            <Button
              variant="secondary"
              size="sm"
              className="h-8"
              disabled={matches.length === 0}
              onClick={() => {
                const m = matches[cursor % matches.length];
                if (m) {
                  replaceOne(m);
                  toast.success("Remplacement effectué");
                }
              }}
            >
              Remplacer
            </Button>
            <Button size="sm" className="h-8" disabled={matches.length === 0} onClick={replaceAll}>
              <ReplaceAll className="size-3.5 mr-1" aria-hidden />
              Tout remplacer
            </Button>
          </div>
        </div>
        {find.trim() && matches.length > 0 && (
          <div className="max-h-44 overflow-y-auto editor-scroll border-t px-2 py-1.5 space-y-0.5" data-find-results>
            {matches.slice(0, 60).map((m) => (
              <button
                key={m.index}
                className={cn(
                  "w-full text-left text-xs rounded px-2 py-1.5 hover:bg-accent/60 transition-colors",
                  m.index === cursor % matches.length && "bg-accent"
                )}
                onClick={() => {
                  scrollToMatch(m.blockId);
                  setCursor(m.index);
                }}
              >
                <span className="text-muted-foreground/70 mr-1 tabular-nums">{m.index + 1}.</span>
                {m.snippet}
              </button>
            ))}
            {matches.length > 60 && <p className="text-[11px] text-muted-foreground/60 px-2 py-1">… {matches.length - 60} autres occurrences</p>}
          </div>
        )}
      </div>
    </div>
  );
}
