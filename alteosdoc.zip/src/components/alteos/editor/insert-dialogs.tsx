"use client";

/**
 * Dialogues d'insertion — QR (généré localement) et icônes vectorielles.
 * Appelés par l'outil correspondant : un clic sur la page ouvre le dialogue,
 * la validation place l'élément à l'endroit cliqué.
 */

import { useEffect, useMemo, useState } from "react";
import { QrCode, Search, Shapes } from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import { qrPreview } from "@/lib/qr";
import { ICONS } from "@/lib/icon-paths";
import { uid, type IconItem, type QrItem } from "@/lib/types";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

export interface PlaceAt {
  x: number;
  y: number;
  pageId: string;
}

function clampedPlacement(at: PlaceAt, w: number, h: number, pageW: number, pageH: number) {
  return {
    x: Math.max(8, Math.min(at.x - w / 2, Math.max(8, pageW - w - 8))),
    y: Math.max(8, Math.min(at.y - h / 2, Math.max(8, pageH - h - 8))),
  };
}

// ---------------------------------------------------------------------------
// QR
// ---------------------------------------------------------------------------

export function QrPlaceDialog({ at, pageW, pageH, onClose }: { at: PlaceAt | null; pageW: number; pageH: number; onClose: () => void }) {
  const addItems = useEditorStore((s) => s.addItems);
  const [data, setData] = useState("https://exemple.fr");
  const [size, setSize] = useState(110);
  const [dark, setDark] = useState("#1C1B1A");
  const [light, setLight] = useState("#FFFFFF");
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const value = data.trim() || " ";
    qrPreview(value, dark, light)
      .then((url) => {
        if (cancelled) return;
        setPreview(url);
        setError(null);
      })
      .catch(() => {
        if (cancelled) return;
        setPreview(null);
        setError("Ce contenu ne peut pas être encodé en code QR.");
      });
    return () => {
      cancelled = true;
    };
  }, [data, dark, light]);

  if (!at) return null;

  function place() {
    const value = data.trim();
    if (!value || !at) return;
    const pos = clampedPlacement(at, size, size, pageW, pageH);
    const item: QrItem = {
      id: uid(),
      pageId: at.pageId,
      createdAt: Date.now(),
      type: "qr",
      x: pos.x,
      y: pos.y,
      w: size,
      h: size,
      data: value,
      fg: dark,
      bg: light,
    };
    addItems([item]);
    onClose();
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="size-4 text-primary" aria-hidden />
            Ajouter un code QR
          </DialogTitle>
          <DialogDescription>
            Généré sur cet appareil — aucune donnée n&apos;est envoyée sur le réseau.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-1">
          <div className="space-y-1.5">
            <Label htmlFor="qr-data">Contenu (URL, texte, Wi-Fi, contact…)</Label>
            <Input
              id="qr-data"
              value={data}
              onChange={(e) => setData(e.target.value)}
              placeholder="https://…"
              autoFocus
              aria-label="Contenu du code QR"
            />
          </div>

          <div className="flex items-center gap-4">
            <div
              className="grid place-items-center size-[104px] rounded-lg border bg-white shrink-0"
              aria-live="polite"
              data-qr-preview
            >
              {preview ? (
                <img src={preview} alt="Aperçu du code QR" className="size-[96px]" draggable={false} />
              ) : (
                <span className="text-[11px] text-muted-foreground p-2 text-center">{error ?? "Génération…"}</span>
              )}
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">Taille</Label>
                <div className="flex items-center gap-2">
                  <Slider value={[size]} min={48} max={240} step={2} onValueChange={(v) => setSize(v[0])} aria-label="Taille du QR (points)" />
                  <span className="text-xs tabular-nums text-muted-foreground w-12">{size} pt</span>
                </div>
              </div>
              <div className="flex gap-2">
                <div className="flex-1">
                  <Label className="text-xs text-muted-foreground" htmlFor="qr-dark">Modules</Label>
                  <input
                    id="qr-dark"
                    type="color"
                    value={dark}
                    onChange={(e) => setDark(e.target.value)}
                    className="h-8 w-full cursor-pointer rounded border bg-transparent p-0.5"
                    aria-label="Couleur des modules"
                  />
                </div>
                <div className="flex-1">
                  <Label className="text-xs text-muted-foreground" htmlFor="qr-light">Fond</Label>
                  <input
                    id="qr-light"
                    type="color"
                    value={light}
                    onChange={(e) => setLight(e.target.value)}
                    className="h-8 w-full cursor-pointer rounded border bg-transparent p-0.5"
                    aria-label="Couleur de fond"
                  />
                </div>
              </div>
            </div>
          </div>

          <p className="text-xs text-muted-foreground/80">
            Astuce : contraste élevé recommandé pour la lecture. Le QR exporté est un PNG haute résolution (512 px).
          </p>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Annuler</Button>
          <Button onClick={place} disabled={!data.trim() || !!error} data-qr-place>
            Placer sur la page
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------------------------------------------------------------------------
// Icônes
// ---------------------------------------------------------------------------

const PAGE_SIZE = 60;

export function IconPlaceDialog({ at, pageW, pageH, onClose }: { at: PlaceAt | null; pageW: number; pageH: number; onClose: () => void }) {
  const addItems = useEditorStore((s) => s.addItems);
  const [query, setQuery] = useState("");
  const [shown, setShown] = useState(PAGE_SIZE);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return ICONS;
    return ICONS.filter((i) => i.label.toLowerCase().includes(q) || i.id.includes(q));
  }, [query]);

  const page = filtered.slice(0, shown);

  if (!at) return null;

  function place(iconId: string, label: string) {
    if (!at) return;
    const size = 64;
    const pos = clampedPlacement(at, size, size, pageW, pageH);
    const item: IconItem = {
      id: uid(),
      pageId: at.pageId,
      createdAt: Date.now(),
      type: "icon",
      x: pos.x,
      y: pos.y,
      w: size,
      h: size,
      iconId,
      color: "#1C1B1A",
    };
    void label;
    addItems([item]);
    onClose();
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shapes className="size-4 text-primary" aria-hidden />
            Ajouter une icône
          </DialogTitle>
          <DialogDescription>
            {ICONS.length} icônes vectorielles libres (tracés lucide, ISC) — recolorables et nettes à l&apos;impression.
          </DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" aria-hidden />
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setShown(PAGE_SIZE);
            }}
            placeholder="Rechercher (étoile, courrier, carte…)"
            className="pl-8"
            aria-label="Rechercher une icône"
            autoFocus
          />
        </div>

        <div className="grid grid-cols-8 sm:grid-cols-10 gap-1 max-h-[300px] overflow-y-auto editor-scroll p-0.5" data-icons-grid>
          {page.map((icon) => (
            <button
              key={icon.id}
              onClick={() => place(icon.id, icon.label)}
              title={icon.label}
              aria-label={`Insérer l'icône ${icon.label}`}
              className="grid place-items-center aspect-square rounded-lg border bg-background hover:border-primary/60 hover:bg-accent transition-colors"
            >
              <span
                className="w-5 h-5 [&>svg]:w-full [&>svg]:h-full"
                style={{ color: "#3C3A36" }}
                dangerouslySetInnerHTML={{ __html: icon.svg }}
              />
            </button>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-full py-6 text-center text-sm text-muted-foreground">Aucune icône ne correspond.</p>
          )}
        </div>

        {filtered.length > shown && (
          <Button variant="outline" size="sm" className="mx-auto" onClick={() => setShown((s) => s + PAGE_SIZE)}>
            Afficher plus ({filtered.length - shown} restantes)
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
