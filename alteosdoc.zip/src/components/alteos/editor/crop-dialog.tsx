"use client";

/**
 * Recadrage d'image — applique un recadrage réel : l'image est redécoupée
 * en canvas et un nouvel asset remplace l'ancien.
 */

import { useEffect, useRef, useState } from "react";
import { Crop } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import { getAsset, putAsset } from "@/lib/idb";
import { uid, type ImageItem } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

export function CropDialog({ item, onClose }: { item: ImageItem | null; onClose: () => void }) {
  const updateItem = useEditorStore((s) => s.updateItem);
  const [inset, setInset] = useState({ top: 0, right: 0, bottom: 0, left: 0 });
  const [busy, setBusy] = useState(false);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [src, setSrc] = useState<string | null>(null);

  // Charge l'image à recadrer
  useEffect(() => {
    if (!item) {
      setSrc((old) => {
        if (old) URL.revokeObjectURL(old);
        return null;
      });
      setInset({ top: 0, right: 0, bottom: 0, left: 0 });
      return;
    }
    let cancelled = false;
    let created: string | null = null;
    getAsset(item.assetId).then((a) => {
      if (!a || cancelled) return;
      created = URL.createObjectURL(a.blob);
      setSrc(created);
    });
    return () => {
      cancelled = true;
      if (created) URL.revokeObjectURL(created);
    };
  }, [item]);

  async function apply() {
    if (!item || !imgRef.current) return;
    setBusy(true);
    try {
      const img = imgRef.current;
      const W = img.naturalWidth;
      const H = img.naturalHeight;
      const sx = Math.round((inset.left / 100) * W);
      const sy = Math.round((inset.top / 100) * H);
      const sw = Math.max(8, W - sx - Math.round((inset.right / 100) * W));
      const sh = Math.max(8, H - sy - Math.round((inset.bottom / 100) * H));
      const canvas = document.createElement("canvas");
      canvas.width = sw;
      canvas.height = sh;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
      if (!blob) throw new Error("Recadrage impossible");
      const assetId = uid();
      await putAsset({ id: assetId, blob, mime: "image/png", createdAt: Date.now() });
      updateItem(item.id, { assetId });
      toast.success("Image recadrée");
      onClose();
      if (src) URL.revokeObjectURL(src);
      setSrc(null);
      setInset({ top: 0, right: 0, bottom: 0, left: 0 });
    } catch {
      toast.error("Le recadrage a échoué", { description: "Cette image ne peut pas être redécoupée." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={!!item} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crop className="size-4 text-primary" aria-hidden />
            Recadrer l&apos;image
          </DialogTitle>
          <DialogDescription>Ajustez les marges à conserver, puis appliquez : l&apos;image est réellement redécoupée.</DialogDescription>
        </DialogHeader>

        {src ? (
          <div className="space-y-4">
            <div className="relative rounded-lg overflow-hidden bg-secondary/50 grid place-items-center max-h-64">
              { }
              <img
                ref={imgRef}
                src={src}
                alt="Image à recadrer"
                className="max-h-64 w-auto object-contain"
                style={{
                  clipPath: `inset(${inset.top}% ${inset.right}% ${inset.bottom}% ${inset.left}%)`,
                }}
              />
            </div>
            {(
              [
                { key: "top", label: "Haut" },
                { key: "right", label: "Droite" },
                { key: "bottom", label: "Bas" },
                { key: "left", label: "Gauche" },
              ] as const
            ).map(({ key, label }) => (
              <div key={key} className="flex items-center gap-3">
                <Label className="text-xs text-muted-foreground w-14 shrink-0">{label}</Label>
                <Slider
                  value={[inset[key]]}
                  min={0}
                  max={45}
                  step={1}
                  onValueChange={(v) => setInset((s) => ({ ...s, [key]: v[0] }))}
                  className="flex-1"
                  aria-label={`Marge ${label} (pour cent)`}
                />
                <span className="text-xs tabular-nums text-muted-foreground w-10">{inset[key]} %</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-48 grid place-items-center text-sm text-muted-foreground">Chargement de l&apos;image…</div>
        )}

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={apply} disabled={busy || !src}>
            <Crop className="size-4 mr-1.5" aria-hidden />
            {busy ? "Application…" : "Appliquer le recadrage"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
