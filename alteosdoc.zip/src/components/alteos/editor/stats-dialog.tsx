"use client";

/**
 * Statistiques du document — mots, caractères, structure, dates.
 * Tout est calculé depuis le contenu réel (aucune donnée inventée).
 */

import { useMemo } from "react";
import { BarChart3, CalendarDays, Clock3, FileText, Layers, ListChecks, Table2, Type } from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import { formatDateFR } from "@/lib/utils";
import type { Block } from "@/lib/types";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

function blockText(b: Block): string {
  if ("text" in b) return b.text;
  if ("html" in b) {
    if (typeof document === "undefined") return "";
    const div = document.createElement("div");
    div.innerHTML = b.html;
    return div.textContent ?? "";
  }
  if (b.type === "checklist") return b.entries.map((e) => e.text).join(" ");
  if (b.type === "table") return b.rows.flat().join(" ");
  return "";
}

export function StatsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const doc = useEditorStore((s) => s.doc);
  const stats = useMemo(() => {
    if (!doc) return null;
    let words = 0;
    let chars = 0;
    const counts: Record<string, number> = {};
    for (const b of doc.blocks) {
      counts[b.type] = (counts[b.type] ?? 0) + 1;
      const t = blockText(b).trim();
      if (t) {
        words += t.split(/\s+/).length;
        chars += t.replace(/\s+/g, " ").length;
      }
    }
    let itemWords = 0;
    for (const it of doc.items) {
      if (it.type === "text") itemWords += it.text.trim() ? it.text.trim().split(/\s+/).length : 0;
      if (it.type === "note") itemWords += it.text.trim() ? it.text.trim().split(/\s+/).length : 0;
    }
    const pages = doc.kind === "pdf" ? doc.pages.length : doc.kind === "design" ? doc.designPages.length : 1;
    return {
      words: words + itemWords,
      chars,
      blocks: doc.blocks.length,
      items: doc.items.filter((i) => !i.hidden).length,
      pages,
      readingMin: Math.max(1, Math.round((words + itemWords) / 220)),
      speakingMin: Math.max(1, Math.round(((words + itemWords) * 60) / 150)),
      counts,
      created: doc.createdAt,
      updated: doc.updatedAt,
    };
  }, [doc]);

  if (!open || !doc || !stats) return null;

  const rows: { icon: typeof Type; label: string; value: string }[] = [
    { icon: Type, label: "Mots", value: stats.words.toLocaleString("fr-FR") },
    { icon: FileText, label: "Caractères", value: stats.chars.toLocaleString("fr-FR") },
    { icon: Layers, label: "Pages", value: String(stats.pages) },
    { icon: FileText, label: "Blocs (documents)", value: String(stats.blocks) },
    { icon: Layers, label: "Éléments visibles (PDF/Design)", value: String(stats.items) },
    { icon: Clock3, label: "Temps de lecture", value: `≈ ${stats.readingMin} min` },
    { icon: Clock3, label: "Lecture à voix haute", value: `≈ ${stats.speakingMin} min` },
  ];

  const typeLabels: Record<string, string> = {
    title: "titres",
    subtitle: "sous-titres",
    h1: "titres 1",
    h2: "titres 2",
    h3: "titres 3",
    paragraph: "paragraphes",
    list: "listes",
    checklist: "listes de tâches",
    quote: "citations",
    code: "blocs de code",
    callout: "encadrés",
    divider: "séparateurs",
    spacer: "espaces",
    image: "images",
    table: "tableaux",
    field: "champs",
  };

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-sm" data-stats-dialog>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="size-4 text-primary" aria-hidden />
            Statistiques
          </DialogTitle>
          <DialogDescription>« {doc.name} » — mesuré sur le contenu réel.</DialogDescription>
        </DialogHeader>

        <dl className="grid grid-cols-2 gap-2">
          {rows.map((r) => (
            <div key={r.label} className="rounded-lg border p-2.5">
              <dt className="text-[11px] text-muted-foreground flex items-center gap-1">
                <r.icon className="size-3" aria-hidden />
                {r.label}
              </dt>
              <dd className="text-lg font-semibold tabular-nums mt-0.5">{r.value}</dd>
            </div>
          ))}
        </dl>

        {Object.keys(stats.counts).length > 0 && (
          <div className="rounded-lg border p-2.5">
            <p className="text-[11px] text-muted-foreground mb-1 flex items-center gap-1">
              <ListChecks className="size-3" aria-hidden />
              Structure
            </p>
            <p className="text-xs leading-relaxed">
              {Object.entries(stats.counts)
                .map(([k, v]) => `${v} ${typeLabels[k] ?? k}`)
                .join(" · ")}
            </p>
          </div>
        )}

        <div className="rounded-lg border p-2.5 space-y-1">
          <p className="text-xs flex items-center gap-1.5 text-muted-foreground">
            <CalendarDays className="size-3" aria-hidden />
            Créé le {formatDateFR(stats.created)}
          </p>
          <p className="text-xs flex items-center gap-1.5 text-muted-foreground">
            <CalendarDays className="size-3" aria-hidden />
            Modifié le {formatDateFR(stats.updated)}
          </p>
        </div>

        <p className="text-[11px] text-muted-foreground/70 flex items-center gap-1">
          <Table2 className="size-3 shrink-0" aria-hidden />
          Le temps de lecture suppose ~220 mots/min ; la voix haute ~150 mots/min.
        </p>
      </DialogContent>
    </Dialog>
  );
}
