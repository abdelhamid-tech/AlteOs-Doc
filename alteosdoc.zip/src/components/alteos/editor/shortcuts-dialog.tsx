"use client";

/**
 * Aide-mémoire des raccourcis clavier de l'éditeur AlteOS.
 */

import { Keyboard } from "lucide-react";

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const SECTIONS: { title: string; rows: [string, string][] }[] = [
  {
    title: "Général",
    rows: [
      ["Ctrl + Z", "Annuler"],
      ["Ctrl + Maj + Z / Ctrl + Y", "Rétablir"],
      ["Ctrl + S", "Enregistrer sur cet appareil (automatique)"],
      ["Ctrl + E", "Exporter"],
      ["Ctrl + P", "Imprimer"],
      ["Ctrl + K", "Palette de commandes (hors éditeur)"],
      ["Suppr / Retour arrière", "Supprimer l'élément sélectionné"],
      ["Échap", "Quitter le texte en cours d'édition"],
    ],
  },
  {
    title: "Sélection & presse-papiers",
    rows: [
      ["V", "Outil Sélectionner"],
      ["Glisser sur la page", "Sélection rectangle (multi-sélection)"],
      ["Maj + clic / Ctrl + clic", "Ajouter ou retirer un élément de la sélection"],
      ["Ctrl + D", "Dupliquer la sélection"],
      ["Ctrl + C / Ctrl + V", "Copier / coller les éléments"],
      ["Ctrl + V (image copiée)", "Coller une image du système sur la page"],
      ["Alt + glisser", "Dupliquer l'élément en le déplaçant"],
      ["Flèches", "Déplacer la sélection (1 pt ; Maj = 10 pt)"],
    ],
  },
  {
    title: "Outils d'annotation",
    rows: [
      ["H", "Outil Main (déplacer la vue)"],
      ["S", "Surligner"],
      ["U", "Souligner"],
      ["B", "Barrer"],
      ["T", "Texte"],
      ["C", "Commentaire"],
      ["D", "Tracé libre"],
      ["A", "Flèche"],
      ["L", "Ligne"],
      ["R", "Rectangle"],
      ["E", "Ellipse"],
      ["I", "Image"],
      ["G", "Signature"],
      ["Q", "Code QR"],
      ["N", "Icône"],
      ["Ctrl + molette", "Zoomer"],
      ["Espace (maintenu)", "Déplacer la vue temporairement"],
    ],
  },
  {
    title: "Documents (mode Document)",
    rows: [
      ["Ctrl + F", "Rechercher et remplacer"],
      ["Entrée", "Nouveau paragraphe"],
      ["Maj + Entrée", "Saut de ligne"],
    ],
  },
];

export function ShortcutsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Keyboard className="size-4 text-primary" aria-hidden />
            Raccourcis clavier
          </DialogTitle>
          <DialogDescription>Tous ces raccourcis fonctionnent réellement dans l&apos;AlteOS Editor.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-5 max-h-[60vh] overflow-y-auto editor-scroll pr-1" data-shortcuts-list>
          {SECTIONS.map((section) => (
            <section key={section.title} aria-label={section.title}>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{section.title}</h3>
              <dl className="space-y-1.5">
                {section.rows.map(([keys, desc]) => (
                  <div key={keys} className="flex items-baseline justify-between gap-4">
                    <dt>
                      <kbd className="rounded border bg-secondary/70 px-1.5 py-0.5 font-mono text-[11px] whitespace-nowrap">{keys}</kbd>
                    </dt>
                    <dd className="text-sm text-muted-foreground text-right">{desc}</dd>
                  </div>
                ))}
              </dl>
            </section>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
