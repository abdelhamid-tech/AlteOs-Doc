"use client";

/**
 * Signature — dessiner, importer ou enregistrer des signatures réutilisables.
 * La signature devient un PNG transparent placé sur la page, réellement
 * intégré à l'export.
 */

import { useEffect, useRef, useState } from "react";
import { Eraser, PenTool, Upload } from "lucide-react";

import { getSignatures, putSignature, deleteSignature } from "@/lib/idb";
import { uid } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

export interface SignatureResult {
  blob: Blob;
}

export function SignatureModal({
  open,
  onClose,
  onPlace,
}: {
  open: boolean;
  onClose: () => void;
  onPlace: (result: SignatureResult) => void;
}) {
  const [tab, setTab] = useState<"dessiner" | "importer" | "enregistrees">("dessiner");
  const [strokes, setStrokes] = useState<{ x: number; y: number }[][]>([]);
  const drawing = useRef(false);
  const canvasBox = useRef<HTMLDivElement>(null);
  const [saved, setSaved] = useState<{ id: string; url: string }[]>([]);
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open && tab === "enregistrees") {
      getSignatures().then((sigs) => {
        setSaved(sigs.map((s) => ({ id: s.id, url: URL.createObjectURL(s.blob) })));
      });
    }
  }, [open, tab]);

  useEffect(() => {
    setStrokes([]);
  }, [open]);

  function pointerPos(e: React.PointerEvent): { x: number; y: number } {
    const rect = canvasBox.current!.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  const onPointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    drawing.current = true;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setStrokes((s) => [...s, [pointerPos(e)]]);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drawing.current) return;
    const p = pointerPos(e);
    setStrokes((s) => {
      if (s.length === 0) return s;
      const last = s[s.length - 1];
      const lastP = last[last.length - 1];
      if (Math.hypot(p.x - lastP.x, p.y - lastP.y) < 1.5) return s;
      return [...s.slice(0, -1), [...last, p]];
    });
  };
  const onPointerUp = () => {
    drawing.current = false;
  };

  function strokesToBlob(): Promise<Blob | null> {
    const box = canvasBox.current;
    if (!box || strokes.length === 0) return Promise.resolve(null);
    const rect = box.getBoundingClientRect();
    const W = Math.round(rect.width);
    const H = Math.round(rect.height);
    // Recadrage sur les traits
    const all = strokes.flat();
    const minX = Math.max(0, Math.floor(Math.min(...all.map((p) => p.x)) - 14));
    const minY = Math.max(0, Math.floor(Math.min(...all.map((p) => p.y)) - 14));
    const maxX = Math.min(W, Math.ceil(Math.max(...all.map((p) => p.x)) + 14));
    const maxY = Math.min(H, Math.ceil(Math.max(...all.map((p) => p.y)) + 14));
    const cw = Math.max(20, maxX - minX);
    const ch = Math.max(20, maxY - minY);
    const canvas = document.createElement("canvas");
    canvas.width = cw * 2;
    canvas.height = ch * 2;
    const ctx = canvas.getContext("2d")!;
    ctx.scale(2, 2);
    ctx.strokeStyle = "#1a3c35";
    ctx.lineWidth = 2.6;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    for (const stroke of strokes) {
      ctx.beginPath();
      stroke.forEach((p, i) => {
        if (i === 0) ctx.moveTo(p.x - minX, p.y - minY);
        else ctx.lineTo(p.x - minX, p.y - minY);
      });
      ctx.stroke();
    }
    return new Promise((res) => canvas.toBlob(res, "image/png"));
  }

  async function place() {
    if (tab === "dessiner") {
      const blob = await strokesToBlob();
      if (!blob) return;
      onPlace({ blob });
      onClose();
      return;
    }
    if (tab === "importer") {
      importRef.current?.click();
    }
  }

  async function importFile(file: File) {
    // Normalise en PNG transparent via canvas (fond blanc → conservé tel quel)
    const url = URL.createObjectURL(file);
    try {
      const img = await new Promise<HTMLImageElement>((res, rej) => {
        const el = new Image();
        el.onload = () => res(el);
        el.onerror = () => rej(new Error("Image illisible"));
        el.src = url;
      });
      const maxW = 900;
      const scale = Math.min(1, maxW / img.naturalWidth);
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.naturalWidth * scale);
      canvas.height = Math.round(img.naturalHeight * scale);
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
      if (blob) {
        onPlace({ blob });
        onClose();
      }
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Signature</DialogTitle>
          <DialogDescription>Dessinez ou importez votre signature, puis placez-la sur le document.</DialogDescription>
        </DialogHeader>

        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="dessiner">Dessiner</TabsTrigger>
            <TabsTrigger value="importer">Importer</TabsTrigger>
            <TabsTrigger value="enregistrees">Enregistrées</TabsTrigger>
          </TabsList>

          <div className="mt-3">
            {tab === "dessiner" && (
              <>
                <div
                  ref={canvasBox}
                  className={cn(
                    "relative h-40 rounded-lg border-2 border-dashed bg-[repeating-linear-gradient(0deg,transparent,transparent_34px,var(--muted)_34px,var(--muted)_35px)] touch-none",
                    "cursor-crosshair"
                  )}
                  onPointerDown={onPointerDown}
                  onPointerMove={onPointerMove}
                  onPointerUp={onPointerUp}
                  role="application"
                  aria-label="Zone de dessin de la signature"
                >
                  <SignatureSvg strokes={strokes} />
                  {strokes.length === 0 && (
                    <span className="absolute inset-0 grid place-items-center text-xs text-muted-foreground/70 pointer-events-none">
                      Signez ici avec la souris, le doigt ou le stylet
                    </span>
                  )}
                </div>
                <div className="flex justify-end mt-2">
                  <Button variant="ghost" size="sm" onClick={() => setStrokes([])} disabled={strokes.length === 0}>
                    <Eraser className="size-3.5 mr-1.5" aria-hidden />
                    Effacer
                  </Button>
                </div>
              </>
            )}

            {tab === "importer" && (
              <div
                className="rounded-lg border-2 border-dashed p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-accent/25 transition-colors"
                onClick={() => importRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const f = e.dataTransfer.files?.[0];
                  if (f) importFile(f);
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === "Enter" && importRef.current?.click()}
              >
                <Upload className="size-7 mx-auto text-muted-foreground/60" aria-hidden />
                <p className="text-sm mt-2 font-medium">Choisir une image de signature</p>
                <p className="text-xs text-muted-foreground mt-1">PNG de préférence (fond transparent)</p>
                <input
                  ref={importRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="sr-only"
                  aria-label="Importer une image de signature"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    e.currentTarget.value = "";
                    if (f) importFile(f);
                  }}
                />
              </div>
            )}

            {tab === "enregistrees" && (
              <div className="space-y-2 max-h-56 overflow-y-auto editor-scroll">
                {saved.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    Aucune signature enregistrée sur cet appareil.
                    <br />
                    Dessinez-en une puis utilisez « Enregistrer ».
                  </p>
                )}
                {saved.map((s) => (
                  <div key={s.id} className="flex items-center gap-3 rounded-lg border p-2">
                    { }
                    <img src={s.url} alt="Signature enregistrée" className="h-12 bg-[linear-gradient(45deg,var(--secondary)_25%,transparent_25%,transparent_75%,var(--secondary)_75%)] bg-[length:12px_12px] bg-[position:0_0,0_6px,6px_-6px,-6px_0px] rounded" />
                    <Button
                      size="sm"
                      className="ml-auto"
                      onClick={async () => {
                        const sigs = await getSignatures();
                        const found = sigs.find((x) => x.id === s.id);
                        if (found) {
                          onPlace({ blob: found.blob });
                          onClose();
                        }
                      }}
                    >
                      Placer
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={async () => {
                        await deleteSignature(s.id);
                        setSaved((cur) => cur.filter((x) => x.id !== s.id));
                      }}
                    >
                      Supprimer
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Tabs>

        <DialogFooter className="flex items-center gap-2 sm:justify-between">
          <Button
            variant="outline"
            size="sm"
            disabled={tab !== "dessiner" || strokes.length === 0}
            onClick={async () => {
              const blob = await strokesToBlob();
              if (!blob) return;
              await putSignature({ id: uid(), blob, createdAt: Date.now(), label: "Signature" });
            }}
          >
            Enregistrer pour plus tard
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose}>
              Annuler
            </Button>
            <Button onClick={place} disabled={tab === "dessiner" && strokes.length === 0}>
              <PenTool className="size-4 mr-1.5" aria-hidden />
              Placer la signature
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SignatureSvg({ strokes }: { strokes: { x: number; y: number }[][] }) {
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
      {strokes.map((stroke, i) => (
        <polyline
          key={i}
          points={stroke.map((p) => `${p.x},${p.y}`).join(" ")}
          fill="none"
          stroke="#1a3c35"
          strokeWidth={2.6}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      ))}
    </svg>
  );
}
