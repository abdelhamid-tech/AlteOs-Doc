"use client";

/**
 * PageSurface — surface interactive générique (PDF et Design).
 * Rend le cadre de page (canvas PDF / fond Design) + calque d'éléments :
 * création d'annotations, sélection, déplacement, redimensionnement, édition.
 *
 * Toutes les interactions convertissent les pixels écran ⇄ points utilisateur
 * via src/lib/pdf/transform.ts (rotation-safe).
 */

import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MessageSquare } from "lucide-react";

import { useEditorStore } from "@/store/editor-store";
import { pageTransform, userRectToScreen, type PureTransform } from "@/lib/pdf/transform";
import { fontStack } from "@/lib/fonts";
import { qrPreview } from "@/lib/qr";
import { ICON_MAP } from "@/lib/icon-paths";
import {
  INK_COLORS,
  ANNOTATION_COLORS,
  filtersToCss,
  uid,
  type HighlightItem,
  type IconItem,
  type Item,
  type MarkItem,
  type QrItem,
  type ShapeItem,
  type TextItem,
  type Tool,
} from "@/lib/types";
import { useAssetUrl } from "./asset-image";
import { IconPlaceDialog, QrPlaceDialog, type PlaceAt } from "./insert-dialogs";
import { cn } from "@/lib/utils";

const DRAW_TOOLS: Tool[] = ["highlight", "underline", "strike", "rect", "ellipse", "line", "arrow", "draw"];
const CORNERS = ["nw", "ne", "se", "sw"] as const;

interface PageSurfaceProps {
  pageId: string;
  uw: number;
  uh: number;
  rotation: number;
  scale: number;
  /** Fond de page (Design) ; null = contenu injecté par le parent (canvas PDF, couche de texte). */
  background?: string | null;
  grid?: boolean;
  children?: React.ReactNode;
}

export const PageSurface = memo(function PageSurface({
  pageId,
  uw,
  uh,
  rotation,
  scale,
  background = null,
  grid = false,
  children,
}: PageSurfaceProps) {
  const tool = useEditorStore((s) => s.tool);
  const color = useEditorStore((s) => s.color);
  const highlightColor = useEditorStore((s) => s.highlightColor);
  const strokeWidth = useEditorStore((s) => s.strokeWidth);
  const textFont = useEditorStore((s) => s.textFont);
  const textSize = useEditorStore((s) => s.textSize);
  const textBold = useEditorStore((s) => s.textBold);
  const textItalic = useEditorStore((s) => s.textItalic);
  const items = useEditorStore((s) => s.doc?.items ?? EMPTY_ITEMS);
  const selectedItemId = useEditorStore((s) => s.selectedItemId);
  const selectedIds = useEditorStore((s) => s.selectedIds);
  const snapEnabled = useEditorStore((s) => s.snapEnabled);
  const setSelectedItemId = useEditorStore((s) => s.setSelectedItemId);
  const setSelectedIds = useEditorStore((s) => s.setSelectedIds);
  const addItems = useEditorStore((s) => s.addItems);
  const updateItem = useEditorStore((s) => s.updateItem);
  const pushHistory = useEditorStore((s) => s.pushHistory);

  const containerRef = useRef<HTMLDivElement>(null);
  const [draft, setDraft] = useState<Item | null>(null);
  const [editingTextId, setEditingTextId] = useState<string | null>(null);
  const [drag, setDrag] = useState<{ mode: "move" | "resize" | "endpoint"; handle?: string; itemId: string } | null>(null);
  const dragStart = useRef<{ ux: number; uy: number; item: Item; group: Item[] } | null>(null);
  /** Rectangle de sélection (espace utilisateur) pendant le glissement. */
  const [marquee, setMarquee] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  /** Miroir en ref du rectangle (logique) — les setters de store ne sont JAMAIS appelés dans un updater. */
  const marqueeRef = useRef<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  /** Guides magnétiques actifs (coordonnées utilisateur). */
  const [guides, setGuides] = useState<{ v: number[]; h: number[] }>({ v: [], h: [] });
  /** Placement en attente d'un QR ou d'une icône (outil correspondant). */
  const [pendingQr, setPendingQr] = useState<PlaceAt | null>(null);
  const [pendingIcon, setPendingIcon] = useState<PlaceAt | null>(null);

  const t: PureTransform = useMemo(() => pageTransform(uw, uh, scale, rotation), [uw, uh, scale, rotation]);
  const pageItems = useMemo(() => items.filter((it) => it.pageId === pageId && !it.hidden), [items, pageId]);
  /** Ref sur les éléments visibles de la page (évite de réabonner l'effet de glissement). */
  const pageItemsRef = useRef<Item[]>(pageItems);
  useEffect(() => {
    pageItemsRef.current = pageItems;
  }, [pageItems]);
  const selectedItem = pageItems.find((it) => it.id === selectedItemId) ?? null;
  const multiSelected = selectedIds.length > 1 || (selectedIds.length === 1 && selectedIds[0] !== selectedItemId);
  const singleSelection = selectedIds.length <= 1 ? selectedItem : null;

  const toUserFromEvent = useCallback(
    (e: { clientX: number; clientY: number }) => {
      const rect = containerRef.current!.getBoundingClientRect();
      return t.toUser(e.clientX - rect.left, e.clientY - rect.top);
    },
    [t]
  );

  // -----------------------------------------------------------------------
  // Création d'éléments (outils de tracé)
  // -----------------------------------------------------------------------

  const onLayerPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    if (!DRAW_TOOLS.includes(tool)) return;
    if (tool === "draw") {
      const p = toUserFromEvent(e);
      const drawItem: Item = {
        id: uid(),
        pageId,
        createdAt: Date.now(),
        type: "draw",
        x: p.x,
        y: p.y,
        w: 0,
        h: 0,
        points: [p],
        color,
        strokeWidth,
      };
      setDraft(drawItem);
    } else if (tool === "line" || tool === "arrow") {
      const p = toUserFromEvent(e);
      const lineItem: Item = {
        id: uid(),
        pageId,
        createdAt: Date.now(),
        type: tool,
        x: p.x,
        y: p.y,
        w: 0,
        h: 0,
        x2: p.x,
        y2: p.y,
        color,
        strokeWidth,
      };
      setDraft(lineItem);
    } else {
      const p = toUserFromEvent(e);
      const base = { id: uid(), pageId, createdAt: Date.now(), x: p.x, y: p.y, w: 0, h: 0 };
      let item: Item;
      if (tool === "highlight" || tool === "underline" || tool === "strike") {
        item = { ...base, type: tool, quads: [{ x: p.x, y: p.y, w: 0, h: 0 }], color: tool === "highlight" ? highlightColor : color } as HighlightItem | MarkItem;
      } else {
        item = { ...base, type: tool, color, strokeWidth, fill: false, fillColor: color, opacity: 1 } as ShapeItem;
      }
      setDraft(item);
    }
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    e.stopPropagation();
  };

  const onLayerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draft) return;
    const p = toUserFromEvent(e);
    setDraft((d) => {
      if (!d) return d;
      if (d.type === "draw") {
        const last = d.points[d.points.length - 1];
        if (Math.abs(last.x - p.x) + Math.abs(last.y - p.y) < 0.75) return d;
        const points = [...d.points, p];
        const xs = points.map((q) => q.x);
        const ys = points.map((q) => q.y);
        return { ...d, points, x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
      }
      if (d.type === "line" || d.type === "arrow") {
        return { ...d, x2: p.x, y2: p.y };
      }
      const rect = { x: Math.min(d.x, p.x), y: Math.min(d.y, p.y), w: Math.abs(p.x - d.x), h: Math.abs(p.y - d.y) };
      if (d.type === "highlight" || d.type === "underline" || d.type === "strike") {
        return { ...d, ...rect, quads: [rect] };
      }
      return { ...d, ...rect };
    });
  };

  const onLayerPointerUp = () => {
    if (!draft) return;
    const minSize = draft.type === "highlight" || draft.type === "underline" || draft.type === "strike" ? 3 : 5;
    const big =
      draft.type === "draw"
        ? draft.points.length > 2
        : draft.type === "line" || draft.type === "arrow"
          ? Math.hypot(draft.x2 - draft.x, draft.y2 - draft.y) > 6
          : draft.w > minSize && draft.h > minSize;
    if (big) {
      addItems([draft]);
      if (draft.type !== "draw") setSelectedItemId(null);
    }
    setDraft(null);
  };

  // -----------------------------------------------------------------------
  // Placement d'outils « clic » (texte, note)
  // -----------------------------------------------------------------------

  const onLayerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Un clic sur un élément (hitBox enfant) ne doit pas désélectionner :
    // la sélection a déjà été posée par startItemDrag.
    if (e.target !== e.currentTarget) return;
    if (tool === "text") {
      const p = toUserFromEvent(e);
      const item: TextItem = {
        id: uid(),
        pageId,
        createdAt: Date.now(),
        type: "text",
        x: p.x,
        y: p.y,
        w: 220,
        h: 28,
        text: "",
        fontSize: textSize,
        fontFamily: textFont,
        bold: textBold,
        italic: textItalic,
        underline: false,
        color,
        align: "left",
      };
      addItems([item]);
      setSelectedItemId(item.id);
      setEditingTextId(item.id);
      return;
    }
    if (tool === "note") {
      const p = toUserFromEvent(e);
      const item: Item = {
        id: uid(),
        pageId,
        createdAt: Date.now(),
        type: "note",
        x: p.x,
        y: p.y,
        w: 170,
        h: 40,
        text: "",
        color,
      };
      addItems([item]);
      setSelectedItemId(item.id);
      return;
    }
    if (tool === "qr" || tool === "icon") {
      const p = toUserFromEvent(e);
      const place: PlaceAt = { x: p.x, y: p.y, pageId };
      if (tool === "qr") setPendingQr(place);
      else setPendingIcon(place);
      return;
    }
    if (tool === "select") {
      setSelectedItemId(null);
      setSelectedIds([]);
    }
  };

  // -----------------------------------------------------------------------
  // Sélection rectangle (outil Sélectionner, zone vide)
  // -----------------------------------------------------------------------

  const beginMarquee = (e: React.PointerEvent<HTMLDivElement>) => {
    if (tool !== "select" || e.button !== 0) return;
    const target = e.target as HTMLElement;
    if (target.closest("[data-items-layer]")) return;
    // La couche de texte PDF sert à la sélection de texte (surlignage) : pas de marquee ici.
    if (target.closest("[data-text-layer]")) return;
    const p = toUserFromEvent(e);
    const m = { x0: p.x, y0: p.y, x1: p.x, y1: p.y };
    marqueeRef.current = m;
    setMarquee(m);
  };

  useEffect(() => {
    if (!marquee) return;
    const onMove = (e: PointerEvent) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const p = t.toUser(e.clientX - rect.left, e.clientY - rect.top);
      marqueeRef.current = marqueeRef.current ? { ...marqueeRef.current, x1: p.x, y1: p.y } : null;
      setMarquee((m) => (m ? { ...m, x1: p.x, y1: p.y } : m));
    };
    const onUp = () => {
      const m = marqueeRef.current;
      marqueeRef.current = null;
      setMarquee(null);
      if (!m) return;
      const x = Math.min(m.x0, m.x1);
      const y = Math.min(m.y0, m.y1);
      const w = Math.abs(m.x1 - m.x0);
      const h = Math.abs(m.y1 - m.y0);
      if (w > 3 && h > 3) {
        const hitIds = pageItemsRef.current
          .filter((it) => !it.locked)
          .filter((it) => it.x < x + w && it.x + it.w > x && it.y < y + h && it.y + it.h > y)
          .map((it) => it.id);
        if (hitIds.length > 0) setSelectedIds(hitIds);
        else {
          setSelectedIds([]);
          setSelectedItemId(null);
        }
      } else {
        setSelectedIds([]);
        setSelectedItemId(null);
      }
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [marquee, t, setSelectedIds, setSelectedItemId]);

  // -----------------------------------------------------------------------
  // Déplacement / redimensionnement d'un élément sélectionné
  // -----------------------------------------------------------------------
  const startItemDrag = (e: React.PointerEvent, item: Item, mode: "move" | "resize" | "endpoint", handle?: string) => {
    if (tool !== "select" || editingTextId === item.id) return;
    if (item.locked && mode !== "move") return;
    if (item.locked) return; // élément verrouillé : non manipulable (calques)
    e.stopPropagation();
    e.preventDefault();

    // Maj/clic ou Ctrl+clic : ajoute/retire de la sélection, sans démarrer de glissement.
    if (mode === "move" && (e.shiftKey || e.ctrlKey || e.metaKey)) {
      useEditorStore.getState().toggleSelectedId(item.id);
      return;
    }

    const curIds = useEditorStore.getState().selectedIds;
    let group: Item[];
    if (mode === "move" && curIds.includes(item.id) && curIds.length > 1) {
      group = pageItems.filter((it) => curIds.includes(it.id) && !it.locked);
    } else {
      group = [item];
      setSelectedIds([item.id]);
      setSelectedItemId(item.id);
    }

    // Alt+glisser : duplique la sélection puis déplace les COPIES
    // (clones à position identique → glissement parfaitement fluide).
    if (mode === "move" && e.altKey) {
      const copies: Item[] = group.map((g) => {
        const copy = JSON.parse(JSON.stringify(g)) as Item;
        copy.id = uid();
        copy.createdAt = Date.now();
        return copy;
      });
      if (copies.length > 0) {
        addItems(copies);
        setSelectedIds(copies.map((c) => c.id));
        setSelectedItemId(copies[0].id);
        group = copies;
      }
    }

    pushHistory();
    dragStart.current = { ux: toUserFromEvent(e).x, uy: toUserFromEvent(e).y, item: { ...group[0] }, group: group.map((g) => ({ ...g })) };
    setDrag({ mode, handle, itemId: group[0].id });
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      // Capture impossible (pointeur déjà relâché, événement synthétique…) :
      // le glissement fonctionne aussi via les écouteurs fenêtre.
    }
  };

  useEffect(() => {
    if (!drag || !dragStart.current) return;
    const onMove = (e: PointerEvent) => {
      const p = toUserFromEventAbs(e);
      const start = dragStart.current!;
      let dx = p.x - start.ux;
      let dy = p.y - start.uy;
      const base = start.item;

      if (drag.mode === "move") {
        // Guides magnétiques : bords/centres de la page et des autres éléments.
        if (snapEnabled) {
          const moving = start.group;
          const xs = moving.map((it) => it.x);
          const xe = moving.map((it) => it.x + it.w);
          const ys = moving.map((it) => it.y);
          const ye = moving.map((it) => it.y + it.h);
          const bbox = {
            l: Math.min(...xs),
            r: Math.max(...xe),
            t: Math.min(...ys),
            b: Math.max(...ye),
          };
          const others = pageItemsRef.current.filter((it) => !moving.some((m) => m.id === it.id));
          const vCands = [0, uw / 2, uw, ...others.flatMap((it) => [it.x, it.x + it.w / 2, it.x + it.w])];
          const hCands = [0, uh / 2, uh, ...others.flatMap((it) => [it.y, it.y + it.h / 2, it.y + it.h])];
          const thr = Math.min(12, Math.max(4, 6 / scale));
          const vTargets = [bbox.l, (bbox.l + bbox.r) / 2, bbox.r].map((v) => v + dx);
          const hTargets = [bbox.t, (bbox.t + bbox.b) / 2, bbox.b].map((v) => v + dy);
          let bestV: { delta: number; guide: number } | null = null;
          for (const target of vTargets) {
            for (const cand of vCands) {
              const delta = cand - target;
              if (Math.abs(delta) < thr && (!bestV || Math.abs(delta) < Math.abs(bestV.delta))) bestV = { delta, guide: cand };
            }
          }
          let bestH: { delta: number; guide: number } | null = null;
          for (const target of hTargets) {
            for (const cand of hCands) {
              const delta = cand - target;
              if (Math.abs(delta) < thr && (!bestH || Math.abs(delta) < Math.abs(bestH.delta))) bestH = { delta, guide: cand };
            }
          }
          if (bestV) dx += bestV.delta;
          if (bestH) dy += bestH.delta;
          setGuides({ v: bestV ? [bestV.guide] : [], h: bestH ? [bestH.guide] : [] });
        }
        // Déplace le groupe entier (bases préservées), coordonnées bornées à la page.
        const minX0 = Math.min(...start.group.map((it) => it.x));
        const minY0 = Math.min(...start.group.map((it) => it.y));
        const cdx = minX0 + dx < 0 ? -minX0 : dx;
        const cdy = minY0 + dy < 0 ? -minY0 : dy;
        for (const g of start.group) {
          const patch: Record<string, number> = { x: Math.max(0, g.x + cdx), y: Math.max(0, g.y + cdy) };
          if ("x2" in g) patch.x2 = g.x2 + cdx;
          if ("y2" in g) patch.y2 = g.y2 + cdy;
          updateItem(g.id, patch);
        }
        return;
      }
      if (drag.mode === "endpoint" && (base.type === "line" || base.type === "arrow")) {
        updateItem(drag.itemId, { x2: p.x, y2: p.y });
        return;
      }
      // resize : coin opposé fixe (dans l'espace utilisateur — rotation-safe)
      if (drag.handle) {
        if (base.type === "text") {
          // texte : les poignées règlent la largeur uniquement
          if (drag.handle.includes("e")) {
            updateItem(drag.itemId, { x: base.x, y: base.y, w: Math.max(24, p.x - base.x), h: base.h });
          } else {
            updateItem(drag.itemId, { x: p.x, y: base.y, w: Math.max(24, base.x + base.w - p.x), h: base.h });
          }
          return;
        }
        const oppX = drag.handle.includes("w") ? base.x + base.w : base.x;
        const oppY = drag.handle.includes("n") ? base.y + base.h : base.y;
        const nx = Math.min(oppX, p.x);
        const ny = Math.min(oppY, p.y);
        const nw = Math.abs(oppX - p.x);
        const nh = Math.abs(oppY - p.y);
        updateItem(drag.itemId, { x: nx, y: ny, w: Math.max(6, nw), h: Math.max(6, nh) });
      }
    };
    const onUp = () => {
      setDrag(null);
      setGuides({ v: [], h: [] });
    };
    const toUserFromEventAbs = (e: PointerEvent) => {
      const rect = containerRef.current!.getBoundingClientRect();
      return t.toUser(e.clientX - rect.left, e.clientY - rect.top);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [drag, t, updateItem, snapEnabled, scale, uw, uh]);

  const layerPointerEvents = DRAW_TOOLS.includes(tool) || tool === "text" || tool === "note" || tool === "qr" || tool === "icon";
  const itemHit = tool === "select";

  const itemsLayerStyle: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    zIndex: 5,
    pointerEvents: layerPointerEvents ? "auto" : "none",
    cursor: DRAW_TOOLS.includes(tool) ? "crosshair" : tool === "text" ? "text" : tool === "qr" || tool === "icon" ? "copy" : "default",
  };

  return (
    <div
      ref={containerRef}
      className={cn("aos-page relative bg-white select-none", tool === "pan" && "tool-pan")}
      style={{ width: t.vw, height: t.vh }}
      data-page-surface={pageId}
      onPointerDown={(e) => {
        // Clic sur zone vide (canvas / couche de texte) → désélection + début de sélection rectangle
        if (tool !== "select") return;
        const target = e.target as HTMLElement;
        if (target.closest("[data-items-layer]")) return;
        if (selectedItemId) setSelectedItemId(null);
        if (selectedIds.length) setSelectedIds([]);
        beginMarquee(e);
      }}
    >
      {background ? (
        <div className="absolute inset-0" style={{ background }} />
      ) : (
        children
      )}
      {grid && <div className="absolute inset-0 design-grid pointer-events-none" />}

      {/* Calque d'éléments */}
      <div
        style={itemsLayerStyle}
        data-items-layer={pageId}
        onPointerDown={onLayerPointerDown}
        onPointerMove={onLayerPointerMove}
        onPointerUp={onLayerPointerUp}
        onClick={onLayerClick}
        role="application"
        aria-label={`Zone d'édition de la page`}
      >
        {pageItems.map((item) => (
          <ItemView
            key={item.id}
            item={item}
            t={t}
            scale={scale}
            selected={selectedIds.length > 1 ? selectedIds.includes(item.id) : item.id === selectedItemId}
            hit={itemHit && !item.locked}
            editing={editingTextId === item.id}
            onStartDrag={startItemDrag}
            onDoubleClick={(it) => {
              if (it.type === "text" && !it.locked) setEditingTextId(it.id);
            }}
            onEditDone={(id, text) => {
              updateItem(id, { text });
              setEditingTextId(null);
            }}
          />
        ))}
        {draft && <ItemView item={draft} t={t} scale={scale} selected={false} hit={false} editing={false} onStartDrag={() => {}} onDoubleClick={() => {}} onEditDone={() => {}} />}

        {/* Poignées de l'élément sélectionné (sélection simple uniquement) */}
        {singleSelection && tool === "select" && !drag && !multiSelected && !singleSelection.locked && (
          <SelectionHandles item={singleSelection} t={t} onStartDrag={startItemDrag} />
        )}

        {/* Compteur de sélection multiple */}
        {multiSelected && selectedIds.length > 0 && tool === "select" && (
          <span className="absolute -top-3 left-0 z-20 rounded-full bg-primary px-2 py-0.5 text-[10px] font-medium text-primary-foreground shadow" data-marquee-count={selectedIds.length}>
            {selectedIds.length} élément{selectedIds.length > 1 ? "s" : ""} sélectionné{selectedIds.length > 1 ? "s" : ""}
          </span>
        )}

        {/* Rectangle de sélection en cours */}
        {marquee && (() => {
          const r = userRectToScreen(t, Math.min(marquee.x0, marquee.x1), Math.min(marquee.y0, marquee.y1), Math.abs(marquee.x1 - marquee.x0), Math.abs(marquee.y1 - marquee.y0));
          return <div className="aos-marquee" data-marquee-rect style={{ left: r.x, top: r.y, width: r.w, height: r.h }} aria-hidden />;
        })()}

        {/* Guides magnétiques */}
        {(guides.v.length > 0 || guides.h.length > 0) && (
          <svg className="pointer-events-none absolute inset-0 z-10" width={t.vw} height={t.vh} data-smart-guides aria-hidden>
            {guides.v.map((gx) => {
              const a = t.toScreen(gx, 0);
              const b = t.toScreen(gx, uh);
              return <line key={`v${gx}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#E2597A" strokeWidth={1} strokeDasharray="4 3" />;
            })}
            {guides.h.map((gy) => {
              const a = t.toScreen(0, gy);
              const b = t.toScreen(uw, gy);
              return <line key={`h${gy}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#E2597A" strokeWidth={1} strokeDasharray="4 3" />;
            })}
          </svg>
        )}
      </div>

      {/* Dialogues d'insertion (QR / icônes) */}
      <QrPlaceDialog at={pendingQr} pageW={uw} pageH={uh} onClose={() => setPendingQr(null)} />
      <IconPlaceDialog at={pendingIcon} pageW={uw} pageH={uh} onClose={() => setPendingIcon(null)} />
    </div>
  );
});

const EMPTY_ITEMS: Item[] = [];

// ---------------------------------------------------------------------------
// Poignées de sélection
// ---------------------------------------------------------------------------

function SelectionHandles({
  item,
  t,
  onStartDrag,
}: {
  item: Item;
  t: PureTransform;
  onStartDrag: (e: React.PointerEvent, item: Item, mode: "move" | "resize" | "endpoint", handle?: string) => void;
}) {
  if (item.type === "line" || item.type === "arrow") {
    const p1 = t.toScreen(item.x, item.y);
    const p2 = t.toScreen(item.x2, item.y2);
    return (
      <>
        {[
          { p: p1, key: "p1" },
          { p: p2, key: "p2" },
        ].map(({ p, key }) => (
          <div
            key={key}
            className="aos-handle"
            style={{ left: p.x - 5.5, top: p.y - 5.5, cursor: "crosshair" }}
            onPointerDown={(e) => onStartDrag(e, item, "endpoint", key)}
            role="button"
            aria-label={`Extrémité ${key}`}
          />
        ))}
      </>
    );
  }
  const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
  return (
    <>
      {CORNERS.map((c) => (
        <div
          key={c}
          className="aos-handle"
          style={{
            left: r.x + (c.includes("w") ? -5.5 : r.w - 5.5),
            top: r.y + (c.includes("n") ? -5.5 : r.h - 5.5),
            cursor: c === "nw" || c === "se" ? "nwse-resize" : "nesw-resize",
          }}
          onPointerDown={(e) => onStartDrag(e, item, "resize", c)}
          role="button"
          aria-label={`Poignée ${c}`}
        />
      ))}
    </>
  );
}

// ---------------------------------------------------------------------------
// Rendu d'un élément
// ---------------------------------------------------------------------------

function ItemView({
  item,
  t,
  scale,
  selected,
  hit,
  editing,
  onStartDrag,
  onDoubleClick,
  onEditDone,
}: {
  item: Item;
  t: PureTransform;
  scale: number;
  selected: boolean;
  hit: boolean;
  editing: boolean;
  onStartDrag: (e: React.PointerEvent, item: Item, mode: "move" | "resize" | "endpoint", handle?: string) => void;
  onDoubleClick: (item: Item) => void;
  onEditDone: (id: string, text: string) => void;
}) {
  const common = {
    position: "absolute" as const,
    pointerEvents: "none" as const,
  };

  const hitBox = (): React.CSSProperties => {
    if (item.type === "line" || item.type === "arrow") {
      const p1 = t.toScreen(item.x, item.y);
      const p2 = t.toScreen(item.x2, item.y2);
      return {
        position: "absolute",
        left: Math.min(p1.x, p2.x) - 4,
        top: Math.min(p1.y, p2.y) - 4,
        width: Math.abs(p2.x - p1.x) + 8,
        height: Math.abs(p2.y - p1.y) + 8,
        pointerEvents: hit ? "auto" : "none",
        cursor: "move",
      };
    }
    const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
    return {
      position: "absolute",
      left: r.x,
      top: r.y,
      width: Math.max(r.w, 12),
      height: Math.max(r.h, 12),
      pointerEvents: hit ? "auto" : "none",
      cursor: "move",
    };
  };

  const selectionRing = selected ? { outline: `1.5px solid var(--primary)`, outlineOffset: "2px" } : {};

  switch (item.type) {
    case "highlight": {
      return (
        <>
          {item.quads.map((q, i) => {
            const r = userRectToScreen(t, q.x, q.y, q.w, q.h);
            return (
              <div
                key={i}
                style={{ ...common, left: r.x, top: r.y, width: r.w, height: r.h, background: item.color, opacity: 0.38, mixBlendMode: "multiply" }}
              />
            );
          })}
          <div style={hitBox()} onPointerDown={(e) => onStartDrag(e, item, "move")} aria-label="Surlignage" />
        </>
      );
    }
    case "underline":
    case "strike": {
      return (
        <>
          {item.quads.map((q, i) => {
            const r = userRectToScreen(t, q.x, q.y, q.w, q.h);
            const band = Math.max(1.5, r.h * 0.07);
            return (
              <div
                key={i}
                style={{
                  ...common,
                  left: r.x,
                  top: item.type === "underline" ? r.y + r.h - band : r.y + r.h / 2 - band / 2,
                  width: r.w,
                  height: band,
                  background: item.color,
                }}
              />
            );
          })}
          <div style={hitBox()} onPointerDown={(e) => onStartDrag(e, item, "move")} aria-label={item.type === "underline" ? "Soulignement" : "Texte barré"} />
        </>
      );
    }
    case "rect": {
      const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
      return (
        <>
          <div
            style={{
              ...common,
              ...r,
              ...selectionRing,
              border: `${Math.max(1, item.strokeWidth * scale)}px solid ${item.color}`,
              background: item.fill ? item.fillColor : "transparent",
              opacity: item.opacity,
              borderRadius: 1.5,
            }}
          />
          <div style={{ ...hitBox(), ...selectionRing }} onPointerDown={(e) => onStartDrag(e, item, "move")} aria-label="Rectangle" />
        </>
      );
    }
    case "ellipse": {
      const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
      return (
        <>
          <div
            style={{
              ...common,
              ...r,
              ...selectionRing,
              border: `${Math.max(1, item.strokeWidth * scale)}px solid ${item.color}`,
              background: item.fill ? item.fillColor : "transparent",
              opacity: item.opacity,
              borderRadius: "50%",
            }}
          />
          <div style={{ ...hitBox(), ...selectionRing }} onPointerDown={(e) => onStartDrag(e, item, "move")} aria-label="Ellipse" />
        </>
      );
    }
    case "line":
    case "arrow": {
      const p1 = t.toScreen(item.x, item.y);
      const p2 = t.toScreen(item.x2, item.y2);
      const sw = Math.max(1, item.strokeWidth * scale);
      const headLen = Math.max(9, item.strokeWidth * 3.5) * scale;
      const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);
      const h1 = { x: p2.x + Math.cos(angle + Math.PI - 0.42) * headLen, y: p2.y + Math.sin(angle + Math.PI - 0.42) * headLen };
      const h2 = { x: p2.x + Math.cos(angle + Math.PI + 0.42) * headLen, y: p2.y + Math.sin(angle + Math.PI + 0.42) * headLen };
      return (
        <>
          <svg style={{ ...common, left: 0, top: 0, width: t.vw, height: t.vh, overflow: "visible" }} aria-hidden>
            <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke={item.color} strokeWidth={sw} strokeLinecap="round" />
            {item.type === "arrow" && (
              <>
                <line x1={p2.x} y1={p2.y} x2={h1.x} y2={h1.y} stroke={item.color} strokeWidth={sw} strokeLinecap="round" />
                <line x1={p2.x} y1={p2.y} x2={h2.x} y2={h2.y} stroke={item.color} strokeWidth={sw} strokeLinecap="round" />
              </>
            )}
          </svg>
          <div style={{ ...hitBox(), ...(selected ? selectionRing : {}) }} onPointerDown={(e) => onStartDrag(e, item, "move")} aria-label={item.type === "arrow" ? "Flèche" : "Ligne"} />
        </>
      );
    }
    case "draw": {
      if (item.points.length < 2) return null;
      const pts = item.points.map((p) => t.toScreen(p.x, p.y));
      const sw = Math.max(1, item.strokeWidth * scale);
      return (
        <>
          <svg style={{ ...common, left: 0, top: 0, width: t.vw, height: t.vh, overflow: "visible" }} aria-hidden>
            <polyline
              points={pts.map((p) => `${p.x},${p.y}`).join(" ")}
              fill="none"
              stroke={item.color}
              strokeWidth={sw}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <div style={{ ...hitBox(), ...(selected ? selectionRing : {}) }} onPointerDown={(e) => onStartDrag(e, item, "move")} aria-label="Tracé" />
        </>
      );
    }
    case "text": {
      const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
      const fontSizePx = item.fontSize * scale;
      return (
        <>
          <div
            style={{
              position: "absolute",
              left: r.x,
              top: r.y,
              width: r.w,
              minHeight: r.h,
              fontFamily: fontStack(item.fontFamily),
              fontSize: fontSizePx,
              fontWeight: item.bold ? 700 : 400,
              fontStyle: item.italic ? "italic" : "normal",
              textDecoration: item.underline ? "underline" : "none",
              color: item.color,
              textAlign: item.align,
              lineHeight: 1.28,
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              pointerEvents: editing ? "auto" : "none",
              ...selectionRing,
              cursor: editing ? "text" : undefined,
            }}
            contentEditable={editing}
            suppressContentEditableWarning
            data-placeholder="Saisissez le texte…"
            className={cn(editing && "aos-block-editable bg-white/70 outline-dashed outline-1 outline-primary/50")}
            ref={(el) => {
              if (editing && el && !el.textContent) {
                el.focus();
              }
            }}
            onBlur={(e) => {
              if (editing) onEditDone(item.id, e.currentTarget.innerText);
            }}
            onKeyDown={(e) => {
              if (e.key === "Escape" && editing) (e.currentTarget as HTMLElement).blur();
              e.stopPropagation();
            }}
          >
            {item.text}
          </div>
          {!editing && (
            <div style={{ ...hitBox(), ...selectionRing }} onPointerDown={(e) => onStartDrag(e, item, "move")} onDoubleClick={() => onDoubleClick(item)} aria-label="Zone de texte" />
          )}
        </>
      );
    }
    case "note": {
      const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
      return (
        <>
          <div
            style={{
              position: "absolute",
              left: r.x,
              top: r.y,
              pointerEvents: "none",
              ...selectionRing,
              borderRadius: 6,
            }}
            className="bg-accent/90 border border-accent-foreground/25"
          >
            <span className="flex items-center gap-1 px-2 py-1 text-[10px] font-medium text-accent-foreground" style={{ fontSize: Math.max(9, 9 * scale) }}>
              <MessageSquare className="size-3" aria-hidden />
              {item.text ? `${item.text.length} car.` : "Commentaire"}
            </span>
          </div>
          <div style={{ ...hitBox() }} onPointerDown={(e) => onStartDrag(e, item, "move")} aria-label="Commentaire" />
        </>
      );
    }
    case "image":
    case "signature": {
      const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
      return <ImageItemView item={item} r={r} selected={selected} hit={hit} onStartDrag={onStartDrag} />;
    }
    case "qr": {
      return <QrItemView item={item} t={t} selected={selected} hit={hit} onStartDrag={onStartDrag} />;
    }
    case "icon": {
      return <IconItemView item={item} t={t} selected={selected} hit={hit} onStartDrag={onStartDrag} />;
    }
  }
}

function ImageItemView({
  item,
  r,
  selected,
  hit,
  onStartDrag,
}: {
  item: Extract<Item, { type: "image" }> | Extract<Item, { type: "signature" }>;
  r: { x: number; w: number; h: number; y: number };
  selected: boolean;
  hit: boolean;
  onStartDrag: (e: React.PointerEvent, item: Item, mode: "move" | "resize" | "endpoint", handle?: string) => void;
}) {
  const url = useAssetUrl(item.assetId);
  const filters = item.type === "image" ? filtersToCss(item.filters) : "none";
  const transforms: string[] = [];
  if (item.rotation) transforms.push(`rotate(${item.rotation}deg)`);
  if (item.type === "image" && item.flipH) transforms.push("scaleX(-1)");
  if (item.type === "image" && item.flipV) transforms.push("scaleY(-1)");
  return (
    <>
      {url ? (
        <img
          src={url}
          alt={item.type === "signature" ? "Signature" : "Image ajoutée"}
          draggable={false}
          style={{
            position: "absolute",
            left: r.x,
            top: r.y,
            width: r.w,
            height: r.h,
            transform: transforms.length ? transforms.join(" ") : undefined,
            transformOrigin: "center",
            opacity: item.opacity,
            filter: filters !== "none" ? filters : undefined,
            pointerEvents: "none",
            ...(selected ? { outline: "1.5px solid var(--primary)", outlineOffset: "2px" } : {}),
          }}
        />
      ) : (
        <div
          style={{
            position: "absolute",
            left: r.x,
            top: r.y,
            width: r.w,
            height: r.h,
            background: "var(--muted)",
            pointerEvents: "none",
          }}
          className="grid place-items-center text-[10px] text-muted-foreground"
        >
          …
        </div>
      )}
      <div
        style={{
          position: "absolute",
          left: r.x,
          top: r.y,
          width: Math.max(r.w, 12),
          height: Math.max(r.h, 12),
          pointerEvents: hit ? "auto" : "none",
          cursor: "move",
        }}
        onPointerDown={(e) => onStartDrag(e, item, "move")}
        aria-label={item.type === "signature" ? "Signature" : "Image"}
      />
    </>
  );
}

// ---------------------------------------------------------------------------
// QR et icônes — rendu écran
// ---------------------------------------------------------------------------

/** Charge l'aperçu PNG d'un QR (cache interne de src/lib/qr.ts). */
function useQrUrl(item: QrItem): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    qrPreview(item.data.trim() || " ", item.fg, item.bg)
      .then((u) => {
        if (!cancelled) setUrl(u);
      })
      .catch(() => {
        if (!cancelled) setUrl(null);
      });
    return () => {
      cancelled = true;
    };
  }, [item.data, item.fg, item.bg]);
  return url;
}

function QrItemView({
  item,
  t,
  selected,
  hit,
  onStartDrag,
}: {
  item: QrItem;
  t: PureTransform;
  selected: boolean;
  hit: boolean;
  onStartDrag: (e: React.PointerEvent, item: Item, mode: "move" | "resize" | "endpoint", handle?: string) => void;
}) {
  const url = useQrUrl(item);
  const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
  const selectionRing = selected ? { outline: "1.5px solid var(--primary)", outlineOffset: "2px" } : {};
  return (
    <>
      {url ? (
        <img
          src={url}
          alt={`Code QR : ${item.data}`}
          draggable={false}
          data-qr-item
          style={{
            position: "absolute",
            left: r.x,
            top: r.y,
            width: r.w,
            height: r.h,
            pointerEvents: "none",
            ...selectionRing,
          }}
        />
      ) : (
        <div
          style={{
            position: "absolute",
            left: r.x,
            top: r.y,
            width: r.w,
            height: r.h,
            border: "1px dashed",
            borderRadius: 4,
            pointerEvents: "none",
            ...selectionRing,
          }}
          className="grid place-items-center text-[10px] text-muted-foreground"
          aria-label="Code QR en cours de génération"
        >
          QR…
        </div>
      )}
      <div
        style={{
          position: "absolute",
          left: r.x,
          top: r.y,
          width: Math.max(r.w, 12),
          height: Math.max(r.h, 12),
          pointerEvents: hit ? "auto" : "none",
          cursor: "move",
        }}
        onPointerDown={(e) => onStartDrag(e, item, "move")}
        aria-label="Code QR"
      />
    </>
  );
}

function IconItemView({
  item,
  t,
  selected,
  hit,
  onStartDrag,
}: {
  item: IconItem;
  t: PureTransform;
  selected: boolean;
  hit: boolean;
  onStartDrag: (e: React.PointerEvent, item: Item, mode: "move" | "resize" | "endpoint", handle?: string) => void;
}) {
  const def = ICON_MAP.get(item.iconId);
  const r = userRectToScreen(t, item.x, item.y, item.w, item.h);
  const selectionRing = selected ? { outline: "1.5px solid var(--primary)", outlineOffset: "2px" } : {};
  return (
    <>
      <div
        data-icon-item={item.iconId}
        style={{
          position: "absolute",
          left: r.x,
          top: r.y,
          width: r.w,
          height: r.h,
          color: item.color,
          pointerEvents: "none",
          ...selectionRing,
          borderRadius: 3,
        }}
        aria-label={`Icône ${def?.label ?? item.iconId}`}
      >
        {def && (
          <svg
            viewBox="0 0 24 24"
            width="100%"
            height="100%"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <g dangerouslySetInnerHTML={{ __html: def.svg }} />
          </svg>
        )}
      </div>
      <div
        style={{
          position: "absolute",
          left: r.x,
          top: r.y,
          width: Math.max(r.w, 12),
          height: Math.max(r.h, 12),
          pointerEvents: hit ? "auto" : "none",
          cursor: "move",
        }}
        onPointerDown={(e) => onStartDrag(e, item, "move")}
        aria-label={`Icône ${def?.label ?? item.iconId}`}
      />
    </>
  );
}

export { ANNOTATION_COLORS, INK_COLORS };
