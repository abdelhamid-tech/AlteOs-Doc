"use client";

/**
 * Barre contextuelle — affiche UNIQUEMENT les contrôles pertinents
 * pour l'élément sélectionné ou l'outil actif (interface contextuelle).
 */

import { useRef, useState } from "react";
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  Bold,
  Italic,
  Trash2,
  Underline as UnderlineIcon,
  Crop,
  Replace,
  AlignCenterHorizontal,
  AlignEndHorizontal,
  AlignStartHorizontal,
  BringToFront,
  CopyPlus,
  AlignHorizontalDistributeCenter,
  Lock,
  LockOpen,
  Magnet,
  SendToBack,
  FlipHorizontal2,
  FlipVertical2,
  Sun,
  Contrast,
  Droplets,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import { putAsset } from "@/lib/idb";
import { NEUTRAL_IMAGE_FILTERS, uid, ANNOTATION_COLORS, INK_COLORS, type ImageFilters, type Item } from "@/lib/types";
import { FontPicker } from "@/components/alteos/font-picker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

export function ContextBar({ onRequestCrop }: { onRequestCrop: (item: Extract<Item, { type: "image" }>) => void }) {
  const doc = useEditorStore((s) => s.doc);
  const tool = useEditorStore((s) => s.tool);
  const color = useEditorStore((s) => s.color);
  const highlightColor = useEditorStore((s) => s.highlightColor);
  const strokeWidth = useEditorStore((s) => s.strokeWidth);
  const setColor = useEditorStore((s) => s.setColor);
  const setHighlightColor = useEditorStore((s) => s.setHighlightColor);
  const setStrokeWidth = useEditorStore((s) => s.setStrokeWidth);
  const selectedItemId = useEditorStore((s) => s.selectedItemId);
  const selectedIds = useEditorStore((s) => s.selectedIds);
  const updateItem = useEditorStore((s) => s.updateItem);
  const deleteItem = useEditorStore((s) => s.deleteItem);
  const deleteItems = useEditorStore((s) => s.deleteItems);
  const duplicateItems = useEditorStore((s) => s.duplicateItems);
  const bringToFront = useEditorStore((s) => s.bringToFront);
  const sendToBack = useEditorStore((s) => s.sendToBack);
  const alignSelection = useEditorStore((s) => s.alignSelection);
  const distributeSelection = useEditorStore((s) => s.distributeSelection);
  const setItemLocked = useEditorStore((s) => s.setItemLocked);
  const snapEnabled = useEditorStore((s) => s.snapEnabled);
  const setSnapEnabled = useEditorStore((s) => s.setSnapEnabled);
  const textFont = useEditorStore((s) => s.textFont);
  const textSize = useEditorStore((s) => s.textSize);
  const textBold = useEditorStore((s) => s.textBold);
  const textItalic = useEditorStore((s) => s.textItalic);
  const setTextFont = useEditorStore((s) => s.setTextFont);
  const setTextSize = useEditorStore((s) => s.setTextSize);
  const setTextBold = useEditorStore((s) => s.setTextBold);
  const setTextItalic = useEditorStore((s) => s.setTextItalic);
  const fileRef = useRef<HTMLInputElement>(null);

  const items = doc?.items ?? [];
  const selected = items.find((it) => it.id === selectedItemId) ?? null;
  const fileInputFor = useRef<string | null>(null);

  if (!doc) return null;

  // ----- Sélection multiple d'éléments : alignement, répartition, position -----
  if (selectedIds.length > 1) {
    return (
      <Bar>
        <span className="text-xs text-muted-foreground mr-1 shrink-0">{selectedIds.length} éléments</span>
        <span className="text-xs text-muted-foreground/70 hidden lg:inline shrink-0">Aligner</span>
        <Toggle on={false} onClick={() => alignSelection("left")} label="Aligner à gauche" ariaLabel="Aligner à gauche">
          <AlignLeft className="size-3.5" aria-hidden />
        </Toggle>
        <Toggle on={false} onClick={() => alignSelection("hcenter")} label="Centrer horizontalement" ariaLabel="Centrer horizontalement">
          <AlignCenter className="size-3.5" aria-hidden />
        </Toggle>
        <Toggle on={false} onClick={() => alignSelection("right")} label="Aligner à droite" ariaLabel="Aligner à droite">
          <AlignRight className="size-3.5" aria-hidden />
        </Toggle>
        <Toggle on={false} onClick={() => alignSelection("top")} label="Aligner en haut" ariaLabel="Aligner en haut">
          <AlignStartHorizontal className="size-3.5" aria-hidden />
        </Toggle>
        <Toggle on={false} onClick={() => alignSelection("vmiddle")} label="Centrer verticalement" ariaLabel="Centrer verticalement">
          <AlignCenterHorizontal className="size-3.5" aria-hidden />
        </Toggle>
        <Toggle on={false} onClick={() => alignSelection("bottom")} label="Aligner en bas" ariaLabel="Aligner en bas">
          <AlignEndHorizontal className="size-3.5" aria-hidden />
        </Toggle>
        <Separator orientation="vertical" className="h-5" />
        <Toggle on={false} onClick={() => distributeSelection("h")} label="Répartir horizontalement" ariaLabel="Répartir horizontalement (3 éléments min.)">
          <AlignHorizontalDistributeCenter className="size-3.5" aria-hidden />
        </Toggle>
        <Hint>Répartir (3+)</Hint>
        <Separator orientation="vertical" className="h-5" />
        <Toggle on={false} onClick={() => bringToFront(selectedIds)} label="Premier plan" ariaLabel="Mettre au premier plan">
          <BringToFront className="size-3.5" aria-hidden />
        </Toggle>
        <Toggle on={false} onClick={() => sendToBack(selectedIds)} label="Arrière-plan" ariaLabel="Mettre en arrière-plan">
          <SendToBack className="size-3.5" aria-hidden />
        </Toggle>
        <Toggle on={false} onClick={() => duplicateItems(selectedIds)} label="Dupliquer (Ctrl+D)" ariaLabel="Dupliquer la sélection">
          <CopyPlus className="size-3.5" aria-hidden />
        </Toggle>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 text-xs gap-1.5 text-destructive hover:text-destructive"
          onClick={() => {
            deleteItems(selectedIds);
            toast.success("Sélection supprimée");
          }}
        >
          <Trash2 className="size-3.5" aria-hidden />
          Supprimer
        </Button>
      </Bar>
    );
  }

  // ----- Aucun élément sélectionné : options de l'outil actif -----
  if (!selected) {
    if (tool === "select") {
      return (
        <Bar>
          <Toggle on={snapEnabled} onClick={() => setSnapEnabled(!snapEnabled)} label="Magnétisme des guides d'alignement" ariaLabel="Magnétisme des guides d'alignement">
            <Magnet className="size-3.5" aria-hidden />
            <span className="text-[10px] font-medium px-0.5">Guides</span>
          </Toggle>
          <Hint>Glissez sur la page pour sélectionner plusieurs éléments · Maj+clic pour ajouter à la sélection.</Hint>
        </Bar>
      );
    }
    if (tool === "highlight") {
      return (
        <Bar>
          <span className="text-xs text-muted-foreground mr-1">Couleur du surlignage</span>
          <Swatches colors={ANNOTATION_COLORS} value={highlightColor} onChange={setHighlightColor} />
          <Hint>Sélectionnez du texte à la souris pour surligner précisément, ou tracez une zone.</Hint>
        </Bar>
      );
    }
    if (tool === "underline" || tool === "strike") {
      return (
        <Bar>
          <span className="text-xs text-muted-foreground mr-1">Couleur</span>
          <Swatches colors={INK_COLORS} value={color} onChange={setColor} />
          <Hint>Sélectionnez du texte à la souris, ou tracez une zone.</Hint>
        </Bar>
      );
    }
    if (tool === "draw" || tool === "rect" || tool === "ellipse" || tool === "line" || tool === "arrow" || tool === "note") {
      return (
        <Bar>
          <span className="text-xs text-muted-foreground mr-1">Couleur</span>
          <Swatches colors={INK_COLORS} value={color} onChange={setColor} />
          <Separator orientation="vertical" className="h-5" />
          <span className="text-xs text-muted-foreground">Épaisseur</span>
          <Slider value={[strokeWidth]} min={1} max={8} step={0.5} onValueChange={(v) => setStrokeWidth(v[0])} className="w-24" aria-label="Épaisseur du trait" />
          <span className="text-xs tabular-nums text-muted-foreground w-7">{strokeWidth.toFixed(1)}</span>
        </Bar>
      );
    }
    if (tool === "text") {
      return (
        <Bar>
          <span className="text-xs text-muted-foreground mr-1">Nouveau texte</span>
          <FontPicker value={textFont} onChange={setTextFont} ariaLabel="Police des nouveaux textes" className="w-[150px]" />
          <Input
            type="number"
            min={6}
            max={96}
            value={textSize}
            onChange={(e) => setTextSize(Number(e.target.value) || 12)}
            className="h-8 w-16 text-xs"
            aria-label="Taille de police (points)"
          />
          <Toggle on={textBold} onClick={() => setTextBold(!textBold)} label="Gras" ariaLabel="Gras par défaut">
            <Bold className="size-3.5" aria-hidden />
          </Toggle>
          <Toggle on={textItalic} onClick={() => setTextItalic(!textItalic)} label="Italique" ariaLabel="Italique par défaut">
            <Italic className="size-3.5" aria-hidden />
          </Toggle>
          <Separator orientation="vertical" className="h-5" />
          <span className="text-xs text-muted-foreground">Couleur</span>
          <Swatches colors={INK_COLORS} value={color} onChange={setColor} />
          <Hint>Cliquez sur la page pour placer le texte.</Hint>
        </Bar>
      );
    }
    return null;
  }

  // ----- Élément sélectionné : contrôles adaptés au type -----
  const positionControls = (
    <>
      <Separator orientation="vertical" className="h-5" />
      <Toggle on={false} onClick={() => bringToFront([selected.id])} label="Premier plan" ariaLabel="Mettre au premier plan">
        <BringToFront className="size-3.5" aria-hidden />
      </Toggle>
      <Toggle on={false} onClick={() => sendToBack([selected.id])} label="Arrière-plan" ariaLabel="Mettre en arrière-plan">
        <SendToBack className="size-3.5" aria-hidden />
      </Toggle>
      <Toggle on={false} onClick={() => duplicateItems([selected.id])} label="Dupliquer (Ctrl+D)" ariaLabel="Dupliquer l'élément">
        <CopyPlus className="size-3.5" aria-hidden />
      </Toggle>
      <Toggle
        on={!!selected.locked}
        onClick={() => setItemLocked(selected.id, !selected.locked)}
        label={selected.locked ? "Déverrouiller" : "Verrouiller"}
        ariaLabel={selected.locked ? "Déverrouiller l'élément" : "Verrouiller l'élément"}
      >
        {selected.locked ? <Lock className="size-3.5" aria-hidden /> : <LockOpen className="size-3.5" aria-hidden />}
      </Toggle>
    </>
  );

  switch (selected.type) {
    case "text":
      return (
        <Bar>
          <FontPicker
            value={selected.fontFamily}
            onChange={(v) => updateItem(selected.id, { fontFamily: v })}
            ariaLabel="Police du texte"
            className="w-[170px]"
          />
          <Input
            type="number"
            min={6}
            max={96}
            value={selected.fontSize}
            onChange={(e) => updateItem(selected.id, { fontSize: Math.max(6, Math.min(96, Number(e.target.value) || 12)) })}
            className="h-8 w-16 text-xs"
            aria-label="Taille de police (points)"
          />
          <Toggle on={selected.bold} onClick={() => updateItem(selected.id, { bold: !selected.bold })} label="Gras" ariaLabel="Gras">
            <Bold className="size-3.5" aria-hidden />
          </Toggle>
          <Toggle on={selected.italic} onClick={() => updateItem(selected.id, { italic: !selected.italic })} label="Italique" ariaLabel="Italique">
            <Italic className="size-3.5" aria-hidden />
          </Toggle>
          <Toggle on={selected.underline} onClick={() => updateItem(selected.id, { underline: !selected.underline })} label="Souligné" ariaLabel="Souligné">
            <UnderlineIcon className="size-3.5" aria-hidden />
          </Toggle>
          <Separator orientation="vertical" className="h-5" />
          <Swatches colors={INK_COLORS} value={selected.color} onChange={(c) => updateItem(selected.id, { color: c })} />
          <Toggle on={selected.align === "left"} onClick={() => updateItem(selected.id, { align: "left" })} label="Aligner à gauche" ariaLabel="Aligner à gauche">
            <AlignLeft className="size-3.5" aria-hidden />
          </Toggle>
          <Toggle on={selected.align === "center"} onClick={() => updateItem(selected.id, { align: "center" })} label="Centrer" ariaLabel="Centrer">
            <AlignCenter className="size-3.5" aria-hidden />
          </Toggle>
          <Toggle on={selected.align === "right"} onClick={() => updateItem(selected.id, { align: "right" })} label="Aligner à droite" ariaLabel="Aligner à droite">
            <AlignRight className="size-3.5" aria-hidden />
          </Toggle>
          {positionControls}
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    case "image":
    case "signature": {
      const isImage = selected.type === "image";
      return (
        <Bar>
          {isImage && (
            <>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-xs gap-1.5"
                onClick={() => {
                  fileInputFor.current = selected.id;
                  fileRef.current?.click();
                }}
              >
                <Replace className="size-3.5" aria-hidden />
                Remplacer
              </Button>
              <Button variant="ghost" size="sm" className="h-8 text-xs gap-1.5" onClick={() => onRequestCrop(selected as Extract<Item, { type: "image" }>)}>
                <Crop className="size-3.5" aria-hidden />
                Recadrer
              </Button>
              <ImageFiltersPopover
                value={selected.filters ?? NEUTRAL_IMAGE_FILTERS}
                flipH={!!selected.flipH}
                flipV={!!selected.flipV}
                onChange={(filters) => updateItem(selected.id, { filters })}
                onFlipH={() => updateItem(selected.id, { flipH: !selected.flipH })}
                onFlipV={() => updateItem(selected.id, { flipV: !selected.flipV })}
              />
            </>
          )}
          <span className="text-xs text-muted-foreground">Taille</span>
          <Input
            type="number"
            min={10}
            value={Math.round(selected.w)}
            onChange={(e) => updateItem(selected.id, { w: Math.max(10, Number(e.target.value) || selected.w) })}
            className="h-8 w-20 text-xs"
            aria-label="Largeur (points)"
          />
          <Input
            type="number"
            min={10}
            value={Math.round(selected.h)}
            onChange={(e) => updateItem(selected.id, { h: Math.max(10, Number(e.target.value) || selected.h) })}
            className="h-8 w-20 text-xs"
            aria-label="Hauteur (points)"
          />
          <Separator orientation="vertical" className="h-5" />
          <span className="text-xs text-muted-foreground">Rotation</span>
          <Slider
            value={[selected.rotation || 0]}
            min={0}
            max={359}
            step={1}
            onValueChange={(v) => updateItem(selected.id, { rotation: v[0] })}
            className="w-24"
            aria-label="Rotation (degrés)"
          />
          <span className="text-xs tabular-nums text-muted-foreground w-9">{Math.round(selected.rotation || 0)}°</span>
          <Separator orientation="vertical" className="h-5" />
          <span className="text-xs text-muted-foreground">Opacité</span>
          <Slider
            value={[Math.round((selected.opacity ?? 1) * 100)]}
            min={20}
            max={100}
            step={5}
            onValueChange={(v) => updateItem(selected.id, { opacity: v[0] / 100 })}
            className="w-20"
            aria-label="Transparence (pour cent)"
          />
          {positionControls}
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="sr-only"
            aria-label="Remplacer l'image"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              e.currentTarget.value = "";
              const targetId = fileInputFor.current;
              if (!f || !targetId) return;
              const assetId = uid();
              await putAsset({ id: assetId, blob: f, mime: f.type, createdAt: Date.now() });
              updateItem(targetId, { assetId });
              toast.success("Image remplacée");
            }}
          />
        </Bar>
      );
    }

    case "rect":
    case "ellipse":
      return (
        <Bar>
          <span className="text-xs text-muted-foreground">Trait</span>
          <Swatches colors={INK_COLORS} value={selected.color} onChange={(c) => updateItem(selected.id, { color: c })} />
          <Slider value={[selected.strokeWidth]} min={0.5} max={12} step={0.5} onValueChange={(v) => updateItem(selected.id, { strokeWidth: v[0] })} className="w-20" aria-label="Épaisseur du trait" />
          <Separator orientation="vertical" className="h-5" />
          <Toggle on={selected.fill} onClick={() => updateItem(selected.id, { fill: !selected.fill })} label="Remplir" ariaLabel="Remplir la forme">
            <span className="text-[10px] font-medium px-1">Remplir</span>
          </Toggle>
          {selected.fill && <Swatches colors={ANNOTATION_COLORS} value={selected.fillColor} onChange={(c) => updateItem(selected.id, { fillColor: c })} />}
          <Separator orientation="vertical" className="h-5" />
          <span className="text-xs text-muted-foreground">Opacité</span>
          <Slider value={[Math.round(selected.opacity * 100)]} min={20} max={100} step={5} onValueChange={(v) => updateItem(selected.id, { opacity: v[0] / 100 })} className="w-20" aria-label="Transparence" />
          {positionControls}
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    case "line":
    case "arrow":
    case "draw":
      return (
        <Bar>
          <span className="text-xs text-muted-foreground">Couleur</span>
          <Swatches colors={INK_COLORS} value={selected.color} onChange={(c) => updateItem(selected.id, { color: c })} />
          <Separator orientation="vertical" className="h-5" />
          <span className="text-xs text-muted-foreground">Épaisseur</span>
          <Slider value={[selected.strokeWidth]} min={0.5} max={12} step={0.5} onValueChange={(v) => updateItem(selected.id, { strokeWidth: v[0] })} className="w-20" aria-label="Épaisseur du trait" />
          {positionControls}
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    case "highlight":
      return (
        <Bar>
          <span className="text-xs text-muted-foreground">Couleur</span>
          <Swatches colors={ANNOTATION_COLORS} value={selected.color} onChange={(c) => updateItem(selected.id, { color: c })} />
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    case "underline":
    case "strike":
      return (
        <Bar>
          <span className="text-xs text-muted-foreground">Couleur</span>
          <Swatches colors={INK_COLORS} value={selected.color} onChange={(c) => updateItem(selected.id, { color: c })} />
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    case "note":
      return (
        <Bar>
          <Input
            value={selected.text}
            placeholder="Écrivez votre commentaire…"
            onChange={(e) => updateItem(selected.id, { text: e.target.value })}
            className="h-8 w-72 text-xs"
            aria-label="Texte du commentaire"
          />
          <Swatches colors={INK_COLORS} value={selected.color} onChange={(c) => updateItem(selected.id, { color: c })} />
          {positionControls}
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    case "qr":
      return (
        <Bar>
          <span className="text-xs text-muted-foreground shrink-0">Contenu</span>
          <Input
            value={selected.data}
            onChange={(e) => updateItem(selected.id, { data: e.target.value })}
            className="h-8 w-64 text-xs"
            placeholder="https://… ou texte"
            aria-label="Contenu du code QR"
          />
          <span className="text-xs text-muted-foreground shrink-0">Taille</span>
          <Input
            type="number"
            min={24}
            max={360}
            value={Math.round(selected.w)}
            onChange={(e) => {
              const s = Math.max(24, Math.min(360, Number(e.target.value) || selected.w));
              updateItem(selected.id, { w: s, h: s });
            }}
            className="h-8 w-16 text-xs"
            aria-label="Taille du QR (points)"
          />
          <Separator orientation="vertical" className="h-5" />
          <ColorField label="Modules" value={selected.fg} onChange={(c) => updateItem(selected.id, { fg: c })} id="qr-fg" />
          <ColorField label="Fond" value={selected.bg} onChange={(c) => updateItem(selected.id, { bg: c })} id="qr-bg" />
          {positionControls}
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    case "icon":
      return (
        <Bar>
          <span className="text-xs text-muted-foreground shrink-0">Icône · {selected.iconId}</span>
          <Separator orientation="vertical" className="h-5" />
          <Swatches colors={INK_COLORS} value={selected.color} onChange={(c) => updateItem(selected.id, { color: c })} />
          <span className="text-xs text-muted-foreground shrink-0">Taille</span>
          <Input
            type="number"
            min={10}
            max={400}
            value={Math.round(selected.w)}
            onChange={(e) => {
              const s = Math.max(10, Math.min(400, Number(e.target.value) || selected.w));
              updateItem(selected.id, { w: s, h: s });
            }}
            className="h-8 w-16 text-xs"
            aria-label="Taille de l'icône (points)"
          />
          {positionControls}
          <DeleteButton onDelete={() => deleteItem(selected.id)} />
        </Bar>
      );

    default:
      return null;
  }
}

function Bar({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 px-3 h-12 border-b bg-card/80 backdrop-blur overflow-x-auto editor-scroll shrink-0">
      {children}
    </div>
  );
}

function Swatches({ colors, value, onChange }: { colors: readonly string[]; value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex items-center gap-1" role="radiogroup" aria-label="Couleur">
      {colors.map((c) => (
        <button
          key={c}
          role="radio"
          aria-checked={value === c}
          aria-label={`Couleur ${c}`}
          onClick={() => onChange(c)}
          className={cn("size-5 rounded-full border shadow-inner transition-transform", value === c ? "ring-2 ring-ring ring-offset-1 scale-110" : "hover:scale-105")}
          style={{ backgroundColor: c, borderColor: "rgba(0,0,0,0.18)" }}
        />
      ))}
    </div>
  );
}

function Toggle({ on, onClick, label, ariaLabel, children }: { on: boolean; onClick: () => void; label: string; ariaLabel: string; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={on}
      aria-label={ariaLabel}
      title={label}
      className={cn(
        "grid place-items-center h-8 min-w-8 px-1.5 rounded-md text-xs transition-colors focus-visible:outline-2 focus-visible:outline-ring",
        on ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
      )}
    >
      {children}
    </button>
  );
}

function DeleteButton({ onDelete }: { onDelete: () => void }) {
  return (
    <>
      <Separator orientation="vertical" className="h-5" />
      <Button variant="ghost" size="sm" className="h-8 text-xs gap-1.5 text-destructive hover:text-destructive" onClick={onDelete}>
        <Trash2 className="size-3.5" aria-hidden />
        Supprimer
      </Button>
    </>
  );
}

function Hint({ children }: { children: React.ReactNode }) {
  return <span className="text-xs text-muted-foreground/70 ml-2 hidden lg:inline">{children}</span>;
}

/** Champ couleur libre (QR, formes) avec pastille native. */
function ColorField({ label, value, onChange, id }: { label: string; value: string; onChange: (c: string) => void; id: string }) {
  return (
    <span className="flex items-center gap-1.5 shrink-0">
      <label htmlFor={id} className="text-xs text-muted-foreground">
        {label}
      </label>
      <input
        id={id}
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-7 w-8 cursor-pointer rounded border bg-transparent p-0.5"
        aria-label={`${label} du code QR`}
      />
    </span>
  );
}

/** Filtres d'image : réellement appliqués à l'écran ET ré-encodés à l'export. */
function ImageFiltersPopover({
  value,
  flipH,
  flipV,
  onChange,
  onFlipH,
  onFlipV,
}: {
  value: ImageFilters;
  flipH: boolean;
  flipV: boolean;
  onChange: (f: ImageFilters) => void;
  onFlipH: () => void;
  onFlipV: () => void;
}) {
  const [open, setOpen] = useState(false);
  const set = (patch: Partial<ImageFilters>) => onChange({ ...value, ...patch });
  const active =
    value.grayscale > 0 || value.sepia > 0 || Math.abs(value.brightness - 1) > 0.001 || Math.abs(value.contrast - 1) > 0.001 || value.blur > 0;
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className={cn("h-8 text-xs gap-1.5", active && "text-primary")}>
          <Droplets className="size-3.5" aria-hidden />
          Filtres
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-72" data-filters-popover>
        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="flex items-center gap-1 text-muted-foreground">
                <Contrast className="size-3" aria-hidden /> Noir et blanc
              </span>
              <span className="tabular-nums text-muted-foreground">{Math.round(value.grayscale * 100)} %</span>
            </div>
            <Slider value={[value.grayscale]} min={0} max={1} step={0.05} onValueChange={(v) => set({ grayscale: v[0] })} aria-label="Noir et blanc" />
          </div>
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="flex items-center gap-1 text-muted-foreground">
                <Sun className="size-3" aria-hidden /> Sépia
              </span>
              <span className="tabular-nums text-muted-foreground">{Math.round(value.sepia * 100)} %</span>
            </div>
            <Slider value={[value.sepia]} min={0} max={1} step={0.05} onValueChange={(v) => set({ sepia: v[0] })} aria-label="Sépia" />
          </div>
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Luminosité</span>
              <span className="tabular-nums text-muted-foreground">{Math.round(value.brightness * 100)} %</span>
            </div>
            <Slider value={[value.brightness]} min={0.4} max={1.6} step={0.05} onValueChange={(v) => set({ brightness: v[0] })} aria-label="Luminosité" />
          </div>
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Contraste</span>
              <span className="tabular-nums text-muted-foreground">{Math.round(value.contrast * 100)} %</span>
            </div>
            <Slider value={[value.contrast]} min={0.4} max={1.6} step={0.05} onValueChange={(v) => set({ contrast: v[0] })} aria-label="Contraste" />
          </div>
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Flou</span>
              <span className="tabular-nums text-muted-foreground">{value.blur.toFixed(1)} pt</span>
            </div>
            <Slider value={[value.blur]} min={0} max={6} step={0.5} onValueChange={(v) => set({ blur: v[0] })} aria-label="Flou" />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={onFlipH} aria-pressed={flipH}>
                <FlipHorizontal2 className="size-3.5" aria-hidden />
                Miroir H
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={onFlipV} aria-pressed={flipV}>
                <FlipVertical2 className="size-3.5" aria-hidden />
                Miroir V
              </Button>
            </span>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs gap-1"
              onClick={() => onChange({ ...NEUTRAL_IMAGE_FILTERS })}
              disabled={!active}
            >
              <RotateCcw className="size-3.5" aria-hidden />
              Réinitialiser
            </Button>
          </div>
          <p className="text-[11px] leading-relaxed text-muted-foreground/80">
            Les filtres sont ré-encodés dans l&apos;image lors de l&apos;export PDF — ce n&apos;est pas un simple effet d&apos;affichage.
          </p>
        </div>
      </PopoverContent>
    </Popover>
  );
}
