"use client";

import { cn } from "@/lib/utils";

/**
 * Marque AlteOS Docs — monogramme original.
 * Un « A » construit de deux traits montants et d'une barre accent,
 * posé sur une silhouette de page à coin plié.
 */
export function AlteosMark({ className, size = 28 }: { className?: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* silhouette de page, coin plié */}
      <path
        d="M7 3.5h12.2L26 10.3V26.5a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5.5a2 2 0 0 1 2-2Z"
        fill="currentColor"
        fillOpacity="0.12"
      />
      <path d="M19.2 3.5 26 10.3h-4.8a2 2 0 0 1-2-2V3.5Z" fill="currentColor" fillOpacity="0.3" />
      {/* A — deux montants */}
      <path d="M11 24.5 16 11l5 13.5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      {/* barre jade */}
      <path d="M12.9 19.6h6.2" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" className="text-primary" />
    </svg>
  );
}

export function AlteosLogo({ compact = false, className }: { compact?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5 select-none", className)}>
      <span className="text-primary grid place-items-center">
        <AlteosMark size={26} />
      </span>
      {!compact && (
        <span className="font-display text-[17px] font-semibold tracking-tight leading-none">
          AlteOS <span className="text-muted-foreground font-medium">Docs</span>
        </span>
      )}
    </span>
  );
}
