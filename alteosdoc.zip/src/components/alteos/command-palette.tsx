"use client";

/**
 * Palette de commandes globale (Ctrl+K) — actions rapides partout dans l'app :
 * navigation, création, thème, accents, personnalisation, documents récents.
 * cmdk (shadcn/ui) : filtrage local, aucune requête réseau.
 */

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import {
  BookOpen,
  ClipboardList,
  FilePlus2,
  Home,
  LayoutTemplate,
  Moon,
  Palette,
  Settings,
  SlidersHorizontal,
  Sparkles,
  Sun,
} from "lucide-react";
import { toast } from "sonner";

import { useAppStore, type View } from "@/store/app-store";
import { KIND_ICON } from "@/lib/types";
import { relativeDateFR } from "@/lib/utils";
import { ACCENTS, useUiPrefs, type AccentId } from "@/store/ui-prefs";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator, CommandShortcut } from "@/components/ui/command";

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const docs = useAppStore((s) => s.docs);
  const createDoc = useAppStore((s) => s.createDoc);
  const openDoc = useAppStore((s) => s.openDoc);
  const { theme, setTheme } = useTheme();
  const setAccent = useUiPrefs((s) => s.setAccent);
  const setHomeCustomOpen = useUiPrefs((s) => s.setHomeCustomOpen);
  const setEditorCustomOpen = useUiPrefs((s) => s.setEditorCustomOpen);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "k") {
        // Pas dans l'éditeur : les raccourcis d'édition restent prioritaires.
        if (useAppStore.getState().view === "editor") return;
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    const onOpenEvent = () => setOpen(true);
    window.addEventListener("keydown", onKey);
    window.addEventListener("alteos:open-command", onOpenEvent);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("alteos:open-command", onOpenEvent);
    };
  }, []);

  const go = (v: View) => {
    setView(v);
    setOpen(false);
  };

  const recents = [...docs]
    .filter((d) => !d.deletedAt)
    .sort((a, b) => b.openedAt - a.openedAt)
    .slice(0, 6);

  async function create(kind: "document" | "design" | "form") {
    setOpen(false);
    const id = await createDoc(kind);
    void id;
    toast.success(kind === "document" ? "Nouveau document créé" : kind === "design" ? "Nouveau design créé" : "Nouveau formulaire créé");
  }

  return (
    <CommandDialog open={open} onOpenChange={setOpen} title="Palette de commandes" description="Tapez pour filtrer — tout s'exécute localement.">
      <CommandInput placeholder="Aller à… créer… personnaliser…" />
      <CommandList>
        <CommandEmpty>Aucune action ne correspond.</CommandEmpty>

        <CommandGroup heading="Navigation">
          <CommandItem onSelect={() => go("home")}>
            <Home className="size-4" aria-hidden />
            Accueil
          </CommandItem>
          <CommandItem onSelect={() => go("create")}>
            <FilePlus2 className="size-4" aria-hidden />
            Créer / Importer
          </CommandItem>
          <CommandItem onSelect={() => go("documents")}>
            <BookOpen className="size-4" aria-hidden />
            Mes documents
          </CommandItem>
          <CommandItem onSelect={() => go("templates")}>
            <LayoutTemplate className="size-4" aria-hidden />
            Modèles
          </CommandItem>
          <CommandItem onSelect={() => go("assist")}>
            <Sparkles className="size-4" aria-hidden />
            AlteOS Assist
          </CommandItem>
          <CommandItem onSelect={() => go("settings")}>
            <Settings className="size-4" aria-hidden />
            Paramètres
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Créer">
          <CommandItem onSelect={() => create("document")}>
            <FilePlus2 className="size-4" aria-hidden />
            Nouveau document
          </CommandItem>
          <CommandItem onSelect={() => create("design")}>
            <LayoutTemplate className="size-4" aria-hidden />
            Nouveau design
          </CommandItem>
          <CommandItem onSelect={() => create("form")}>
            <ClipboardList className="size-4" aria-hidden />
            Nouveau formulaire
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Personnalisation">
          <CommandItem
            onSelect={() => {
              setView("home");
              setHomeCustomOpen(true);
              setOpen(false);
            }}
          >
            <SlidersHorizontal className="size-4" aria-hidden />
            Personnaliser la page d&apos;accueil
          </CommandItem>
          <CommandItem
            onSelect={() => {
              setEditorCustomOpen(true);
              setOpen(false);
            }}
          >
            <SlidersHorizontal className="size-4" aria-hidden />
            Personnaliser la page d&apos;édition
          </CommandItem>
          <CommandItem
            onSelect={() => {
              setTheme(theme === "dark" ? "light" : "dark");
              setOpen(false);
            }}
          >
            {theme === "dark" ? <Sun className="size-4" aria-hidden /> : <Moon className="size-4" aria-hidden />}
            {theme === "dark" ? "Passer en thème clair" : "Passer en thème sombre"}
            <CommandShortcut>local</CommandShortcut>
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Couleur d'accent">
          {ACCENTS.map((a) => (
            <CommandItem
              key={a.id}
              onSelect={() => {
                setAccent(a.id as AccentId);
                setOpen(false);
                toast.success(`Accent ${a.label.toLowerCase()} appliqué`);
              }}
              value={`accent-${a.label}`}
            >
              <Palette className="size-4" aria-hidden style={{ color: a.swatch }} />
              Accent {a.label}
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandSeparator />

        {recents.length > 0 && (
          <CommandGroup heading="Documents récents">
            {recents.map((d) => (
              <CommandItem
                key={d.id}
                onSelect={async () => {
                  setOpen(false);
                  await openDoc(d.id);
                }}
                value={`doc-${d.name}-${d.id}`}
              >
                <BookOpen className="size-4" aria-hidden data-kind={KIND_ICON[d.kind]} />
                <span className="truncate max-w-[280px]">{d.name}</span>
                <span className="ml-auto text-[10px] text-muted-foreground">{relativeDateFR(d.openedAt)}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
    </CommandDialog>
  );
}
