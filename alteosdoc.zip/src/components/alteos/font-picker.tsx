"use client";

/**
 * AlteOS Docs — Sélecteur de police.
 * -----------------------------------
 * Recherche instantanée, filtres par catégorie et aperçu de chaque police
 * DANS sa propre typo (chargement paresseux : seules les familles visibles
 * sont téléchargées). 153 polices : Google Fonts gratuites + système.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, Search } from "lucide-react";

import {
  CATEGORY_LABEL,
  CATEGORY_ORDER,
  FONT_REGISTRY,
  fontStack,
  getFont,
  searchFonts,
  type FontCategory,
  type FontDef,
} from "@/lib/fonts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const PAGE = 40; // lignes rendues par lot (limite les téléchargements)

const TABS: { id: FontCategory | "all"; label: string }[] = [
  { id: "all", label: "Toutes" },
  ...CATEGORY_ORDER.map((c) => ({ id: c, label: CATEGORY_LABEL[c] })),
];

export interface FontPickerProps {
  value: string;
  onChange: (id: string) => void;
  ariaLabel?: string;
  /** Largeur du déclencheur (barre contextuelle). */
  className?: string;
}

export function FontPicker({ value, onChange, ariaLabel = "Police", className }: FontPickerProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<FontCategory | "all">("all");
  // Rendu incrémental : « génération » (recherche/filtre) + nombre de lignes affichées.
  // Le décompte est dérivé : changer de génération réinitialise sans effet ni re-rendu en cascade.
  const key = `${cat}|${query}`;
  const [gen, setGen] = useState<{ key: string; n: number }>({ key: "", n: PAGE });
  const visible = gen.key === key ? gen.n : PAGE;
  const sentinelRef = useRef<HTMLDivElement>(null);

  const current = getFont(value);
  const results = useMemo(() => searchFonts(query, cat), [query, cat]);

  // Rendu incrémental : ajoute un lot quand le marqueur bas devient visible
  useEffect(() => {
    if (!open) return;
    const el = sentinelRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setGen((g) => (g.key === key ? { key, n: Math.min(g.n + PAGE, results.length) } : { key, n: 2 * PAGE }));
        }
      },
      { rootMargin: "300px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [open, key, results.length]);

  const shown = results.slice(0, visible);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          aria-label={ariaLabel}
          className={cn("h-8 justify-between gap-1.5 px-2.5 font-normal", className)}
          style={{ fontFamily: fontStack(value), minWidth: 120 }}
        >
          <span className="truncate text-sm">{current?.name ?? value}</span>
          <ChevronDown className="size-3.5 opacity-60 shrink-0" aria-hidden />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[340px] p-0" align="start">
        <div className="flex items-center gap-2 border-b px-3 py-2">
          <Search className="size-3.5 text-muted-foreground shrink-0" aria-hidden />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Rechercher parmi ${FONT_REGISTRY.length} polices…`}
            className="h-7 border-none shadow-none focus-visible:ring-0 text-sm"
            aria-label="Rechercher une police"
          />
        </div>

        <div className="flex gap-1 overflow-x-auto px-2 py-1.5 editor-scroll" role="tablist" aria-label="Catégories de polices">
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={cat === t.id}
              onClick={() => setCat(t.id)}
              className={cn(
                "shrink-0 rounded-full px-2.5 py-0.5 text-xs transition-colors focus-visible:outline-2 focus-visible:outline-ring",
                cat === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="max-h-80 overflow-y-auto editor-scroll px-1 py-1" role="listbox" aria-label="Polices disponibles">
          {shown.length === 0 && (
            <p className="px-3 py-6 text-center text-sm text-muted-foreground">Aucune police ne correspond à « {query} ».</p>
          )}
          {shown.map((f) => (
            <FontRow key={f.id} font={f} active={f.id === value} onSelect={() => { onChange(f.id); setOpen(false); }} />
          ))}
          {shown.length < results.length && <div ref={sentinelRef} className="h-px" aria-hidden />}
        </div>

        <p className="border-t px-3 py-1.5 text-[11px] text-muted-foreground">
          {FONT_REGISTRY.length} polices — Google Fonts gratuites + polices de votre appareil
        </p>
      </PopoverContent>
    </Popover>
  );
}

function FontRow({ font, active, onSelect }: { font: FontDef; active: boolean; onSelect: () => void }) {
  return (
    <button
      role="option"
      aria-selected={active}
      onClick={onSelect}
      className={cn(
        "flex w-full items-center justify-between gap-2 rounded-md px-2.5 py-1.5 text-left transition-colors focus-visible:outline-2 focus-visible:outline-ring",
        active ? "bg-primary/10" : "hover:bg-accent"
      )}
    >
      <span className="min-w-0">
        <span className="block truncate text-[17px] leading-snug" style={{ fontFamily: fontStack(font.id) }}>
          {font.name}
        </span>
        <span className="mt-0.5 flex items-center gap-1.5 text-[10px] text-muted-foreground">
          <span>{CATEGORY_LABEL[font.cat]}</span>
          <span aria-hidden>·</span>
          {font.src === "google" ? <span>Google Fonts</span> : <span>Appareil</span>}
        </span>
      </span>
      {active && <Check className="size-4 shrink-0 text-primary" aria-hidden />}
    </button>
  );
}
