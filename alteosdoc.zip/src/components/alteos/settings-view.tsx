"use client";

/**
 * Paramètres — apparence, stockage local, signatures, plan, à propos.
 * Tout est réel : usage mesuré via navigator.storage, signatures réellement
 * enregistrées, plan Free affiché sans paiement.
 */

import { useEffect, useRef, useState } from "react";
import { useTheme } from "next-themes";
import { Check, Download, HardDrive, Monitor, Moon, PackagePlus, PenTool, SlidersHorizontal, Sun, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useAppStore } from "@/store/app-store";
import { useUiPrefs, type Density } from "@/store/ui-prefs";
import { AccentPicker } from "@/components/alteos/customize/accent-picker";
import { Segmented } from "@/components/alteos/customize/segmented";
import { deleteSignature, getSignatures, storageEstimate, getAllDocs, listAssets, putDoc, putAsset } from "@/lib/idb";
import { PLANS, getPlan } from "@/lib/plans";
import { FontLibrary } from "@/components/alteos/font-library";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn, downloadBlob, formatBytes, sanitizeFilename } from "@/lib/utils";
import type { AlteosDoc, AssetRecord } from "@/lib/types";

export default function SettingsView() {
  const { theme, setTheme } = useTheme();
  const accent = useUiPrefs((s) => s.accent);
  const setAccent = useUiPrefs((s) => s.setAccent);
  const density = useUiPrefs((s) => s.density);
  const setDensity = useUiPrefs((s) => s.setDensity);
  const setHomeCustomOpen = useUiPrefs((s) => s.setHomeCustomOpen);
  const setEditorCustomOpen = useUiPrefs((s) => s.setEditorCustomOpen);
  const setView = useAppStore((s) => s.setView);
  const [usage, setUsage] = useState<{ usage: number; quota: number } | null>(null);
  const refreshStorage = useAppStore((s) => s.refreshStorage);
  const [sigCount, setSigCount] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const est = await storageEstimate();
      if (!cancelled) setUsage(est);
      const sigs = await getSignatures();
      if (!cancelled) setSigCount(sigs.length);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const plan = getPlan();
  const docsCount = useAppStore((s) => s.docs.filter((d) => !d.deletedAt).length);
  const refreshDocs = useAppStore((s) => s.refreshDocs);
  const restoreInputRef = useRef<HTMLInputElement>(null);
  const [backupBusy, setBackupBusy] = useState(false);

  async function clearSignatures() {
    const sigs = await getSignatures();
    for (const s of sigs) await deleteSignature(s.id);
    setSigCount(0);
    toast.success("Signatures supprimées de cet appareil");
  }

  /** Sauvegarde complète (documents + images) vers un fichier .alteos.json local. */
  async function exportBackup() {
    setBackupBusy(true);
    try {
      const docs = await getAllDocs();
      const assets = await listAssets();
      const encodeB64 = async (blob: Blob | null): Promise<string | null> => {
        if (!blob) return null;
        const buf = await blob.arrayBuffer();
        let binary = "";
        const bytes = new Uint8Array(buf);
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
          binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
        }
        return btoa(binary);
      };
      const payload = {
        app: "AlteOS Docs",
        version: 1,
        createdAt: new Date().toISOString(),
        docs: await Promise.all(
          docs.map(async (d) => ({
            ...d,
            thumb: await encodeB64(d.thumb),
            pdfBytes: d.pdfBytes ? await encodeB64(new Blob([d.pdfBytes])) : null,
          }))
        ),
        assets: await Promise.all(
          assets.map(async (a) => ({ id: a.id, mime: a.mime, createdAt: a.createdAt, data: await encodeB64(a.blob) }))
        ),
      };
      const blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
      const date = new Date().toISOString().slice(0, 10);
      downloadBlob(blob, `alteos-docs-sauvegarde-${date}.alteos.json`);
      toast.success("Sauvegarde créée", {
        description: `${docs.length} document(s) et ${assets.length} image(s) — fichier enregistré dans vos téléchargements.`,
      });
    } catch {
      toast.error("La sauvegarde a échoué", { description: "L'espace mémoire est peut-être insuffisant pour ce volume." });
    } finally {
      setBackupBusy(false);
    }
  }

  /** Restaure les documents d'un fichier de sauvegarde (fusion, jamais d'effacement). */
  async function importBackup(file: File) {
    setBackupBusy(true);
    try {
      const text = await file.text();
      const data = JSON.parse(text) as {
        app?: string;
        docs?: (Omit<AlteosDoc, "thumb" | "pdfBytes"> & { thumb: string | null; pdfBytes: string | null })[];
        assets?: (Omit<AssetRecord, "blob"> & { data: string | null })[];
      };
      if (data.app !== "AlteOS Docs" || !Array.isArray(data.docs)) {
        throw new Error("format");
      }
      const decodeB64 = (b64: string | null): ArrayBuffer | null => {
        if (!b64) return null;
        const binary = atob(b64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        return bytes.buffer;
      };
      let restoredAssets = 0;
      for (const a of data.assets ?? []) {
        if (!a.data) continue;
        const buf = decodeB64(a.data);
        if (!buf) continue;
        await putAsset({ id: a.id, blob: new Blob([buf], { type: a.mime || "image/png" }), mime: a.mime || "image/png", createdAt: a.createdAt ?? Date.now() });
        restoredAssets++;
      }
      const existing = new Set((await getAllDocs()).map((d) => d.id));
      let restoredDocs = 0;
      for (const d of data.docs) {
        if (existing.has(d.id)) continue; // fusion : ne remplace jamais un document existant
        const thumbBuf = decodeB64(d.thumb);
        const pdfBuf = decodeB64(d.pdfBytes);
        const doc: AlteosDoc = {
          ...(d as unknown as AlteosDoc),
          thumb: thumbBuf ? new Blob([thumbBuf], { type: "image/png" }) : null,
          pdfBytes: pdfBuf,
        };
        await putDoc(doc);
        restoredDocs++;
      }
      await refreshDocs();
      toast.success("Sauvegarde restaurée", {
        description: `${restoredDocs} document(s) et ${restoredAssets} image(s) ajoutés. Les documents existants n'ont pas été modifiés.`,
      });
    } catch (err) {
      toast.error("Restauration impossible", {
        description: err instanceof Error && err.message === "format" ? "Ce fichier n'est pas une sauvegarde AlteOS Docs valide." : "Le fichier est illisible ou endommagé.",
      });
    } finally {
      setBackupBusy(false);
    }
  }

  return (
    <div className="aos-appear max-w-2xl mx-auto space-y-6">
      <header>
        <h1 className="text-2xl font-display font-semibold tracking-tight">Paramètres</h1>
        <p className="text-muted-foreground mt-1">Réglages d&apos;AlteOS Docs sur cet appareil.</p>
      </header>

      {/* Apparence & personnalisation */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Apparence &amp; personnalisation</CardTitle>
          <CardDescription>
            Thème, couleur d&apos;accent et densité — appliqués immédiatement à toute l&apos;interface.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid grid-cols-3 gap-2 max-w-sm" role="radiogroup" aria-label="Thème">
            {(
                [
                  { value: "light", label: "Clair", icon: Sun },
                  { value: "dark", label: "Sombre", icon: Moon },
                  { value: "system", label: "Système", icon: Monitor },
                ] as const
              ).map((t) => (
                <button
                  key={t.value}
                  role="radio"
                  aria-checked={theme === t.value}
                  onClick={() => setTheme(t.value)}
                  className={cn(
                    "flex flex-col items-center gap-1.5 rounded-lg border p-3 text-sm transition-colors focus-visible:outline-2 focus-visible:outline-ring",
                    theme === t.value ? "border-primary bg-accent/50 font-medium" : "hover:border-primary/40"
                  )}
                >
                  <t.icon className="size-4" aria-hidden />
                  {t.label}
                  {theme === t.value && <Check className="size-3 text-primary" aria-hidden />}
                </button>
              ))}
          </div>

          <div className="space-y-2">
            <p className="text-sm font-medium">Couleur d&apos;accent</p>
            <AccentPicker value={accent} onChange={setAccent} />
            <p className="text-xs text-muted-foreground/80">
              L&apos;accent colore boutons, sélection, marque et éditeur — enregistré sur cet appareil.
            </p>
          </div>

          <div className="flex items-center justify-between gap-3">
            <p className="text-sm">Densité de l&apos;interface</p>
            <Segmented<Density>
              value={density}
              onChange={setDensity}
              options={[
                { value: "confortable", label: "Confortable" },
                { value: "compacte", label: "Compacte" },
              ]}
              ariaLabel="Densité de l'interface"
            />
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setView("home");
                setHomeCustomOpen(true);
              }}
            >
              <SlidersHorizontal className="size-3.5 mr-1.5" aria-hidden />
              Personnaliser l&apos;accueil
            </Button>
            <Button variant="outline" size="sm" onClick={() => setEditorCustomOpen(true)}>
              <SlidersHorizontal className="size-3.5 mr-1.5" aria-hidden />
              Personnaliser l&apos;éditeur
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Bibliothèque de polices */}
      <FontLibrary />

      {/* Stockage */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <HardDrive className="size-4 text-primary" aria-hidden />
            Stockage
          </CardTitle>
          <CardDescription>Vos documents sont enregistrés localement (IndexedDB), sur cet appareil uniquement.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Documents</span>
            <span className="font-medium">
              {docsCount} document{docsCount > 1 ? "s" : ""}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Espace utilisé</span>
            <span className="font-medium">
              {usage ? formatBytes(usage.usage) : "Indisponible sur ce navigateur"}
              {usage && usage.quota > 0 ? ` sur ${formatBytes(usage.quota)} disponibles` : ""}
            </span>
          </div>
          <p className="text-xs text-muted-foreground/80 leading-relaxed pt-1 border-t">
            Aucune donnée n&apos;est envoyée à un serveur. AlteOS Cloud (synchronisation, sauvegarde, partage)
            est prévu dans l&apos;architecture mais n&apos;est pas encore disponible — il ne sera activé qu&apos;une
            fois réellement fonctionnel.
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              const est = await storageEstimate();
              setUsage(est);
              await refreshStorage();
              toast.success("Mesure du stockage actualisée");
            }}
          >
            Recalculer l&apos;espace utilisé
          </Button>
        </CardContent>
      </Card>

      {/* Sauvegarde / restauration locales */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Download className="size-4 text-primary" aria-hidden />
            Sauvegarde de l&apos;espace
          </CardTitle>
          <CardDescription>
            Exportez tous vos documents et images vers un fichier unique, ou restaurez-les plus tard sur cet appareil ou un autre.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" onClick={exportBackup} disabled={backupBusy} data-backup-export>
              <Download className="size-3.5 mr-1.5" aria-hidden />
              Créer une sauvegarde
            </Button>
            <Button variant="outline" size="sm" onClick={() => restoreInputRef.current?.click()} disabled={backupBusy} data-backup-import>
              <PackagePlus className="size-3.5 mr-1.5" aria-hidden />
              Restaurer une sauvegarde
            </Button>
            <input
              ref={restoreInputRef}
              type="file"
              accept=".json,.alteos.json,application/json"
              className="sr-only"
              aria-label="Choisir un fichier de sauvegarde AlteOS Docs"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.currentTarget.value = "";
                if (f) void importBackup(f);
              }}
            />
          </div>
          <p className="text-xs text-muted-foreground/80 leading-relaxed">
            Le fichier contient vos documents (y compris les PDF importés) et leurs images. La restauration fusionne :
            elle ajoute les documents manquants sans jamais effacer ceux déjà présents. Tout se passe sur cet appareil —
            c&apos;est votre copie de sécurité personnelle, sans cloud.
          </p>
          <p className="text-[11px] text-muted-foreground/60">
            Astuce : conservez le fichier <code className="font-mono">{sanitizeFilename("alteos-docs-sauvegarde")}…json</code> sur une clé USB ou un disque externe.
          </p>
        </CardContent>
      </Card>

      {/* Signatures */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <PenTool className="size-4 text-primary" aria-hidden />
            Signatures enregistrées
          </CardTitle>
          <CardDescription>Signatures dessinées ou importées, réutilisables dans vos documents.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Signatures sur cet appareil</span>
            <span className="font-medium">{sigCount}</span>
          </div>
          {sigCount > 0 && (
            <Button variant="outline" size="sm" onClick={clearSignatures}>
              <Trash2 className="size-3.5 mr-1.5" aria-hidden />
              Supprimer toutes les signatures
            </Button>
          )}
          <p className="text-xs text-muted-foreground/80 leading-relaxed">
            Pour ajouter ou gérer une signature, ouvrez un document et choisissez l&apos;outil Signature.
          </p>
        </CardContent>
      </Card>

      {/* Plan */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Votre plan</CardTitle>
          <CardDescription>
            Actuellement : {plan.name} — {plan.tagline}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {Object.values(PLANS).map((p) => (
              <div
                key={p.id}
                className={cn(
                  "rounded-lg border p-3 text-sm",
                  p.available ? "border-primary/50 bg-accent/30" : "opacity-70"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{p.name}</span>
                  {p.available ? (
                    <Badge className="text-[10px]">Plan actuel</Badge>
                  ) : (
                    <Badge variant="secondary" className="text-[10px]">
                      Bientôt disponible
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">{p.tagline}</p>
                <p className="text-xs text-muted-foreground/70 mt-1.5">{p.ai.actionsPerMonth} actions IA / mois</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground/80 leading-relaxed">
            Aucun paiement n&apos;est configuré dans cette version : les plans payants sont préparés dans
            l&apos;architecture et seront activés plus tard, sans changement de structure. Les limites sont
            définies dans une configuration centrale, jamais dispersées dans le code.
          </p>
        </CardContent>
      </Card>

      {/* À propos */}
      <Card className="bg-secondary/30">
        <CardHeader>
          <CardTitle className="text-sm">À propos</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p className="font-medium text-foreground">AlteOS Docs — version 1.0</p>
          <p className="leading-relaxed">Créer sans limites. Modifier sans complexité. Garder le contrôle.</p>
          <p className="leading-relaxed text-xs text-muted-foreground/80">
            Traitement des documents réalisé localement dans votre navigateur (pdf.js, pdf-lib). Aucun service
            payant n&apos;est requis pour utiliser l&apos;application.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
