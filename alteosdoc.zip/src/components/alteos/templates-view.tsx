"use client";

/**
 * Vue Modèles — bibliothèque de modèles originaux, par catégorie.
 * Les vignettes sont des rendus CSS du contenu réel du modèle (pas des images).
 */

import { useMemo, useState } from "react";
import { ArrowRight } from "lucide-react";
import { toast } from "sonner";

import { useAppStore } from "@/store/app-store";
import { CATEGORY_LABEL, TEMPLATES, instantiateTemplate, type TemplateCategory } from "@/lib/templates";
import { fontStack } from "@/lib/fonts";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const ORDER: TemplateCategory[] = ["cv", "rapports", "école", "lettres", "brochures", "affiches", "guides", "portfolios", "formulaires"];

export default function TemplatesView() {
  const [category, setCategory] = useState<TemplateCategory | "tous">("tous");
  const createDoc = useAppStore((s) => s.createDoc);
  const setView = useAppStore((s) => s.setView);

  const list = useMemo(
    () => (category === "tous" ? TEMPLATES : TEMPLATES.filter((t) => t.category === category)),
    [category]
  );

  async function openTemplate(templateId: string) {
    const tpl = TEMPLATES.find((t) => t.id === templateId);
    if (!tpl) return;
    const data = instantiateTemplate(tpl);
    const id = await createDoc(data.kind, {
      name: data.name,
      blocks: data.kind === "design" ? [] : data.blocks,
      templateId,
    });
    // Les éléments Design et pages sont injectés après création
    const { getDoc, putDoc } = await import("@/lib/idb");
    const doc = await getDoc(id);
    if (doc) {
      doc.designPages = data.designPages;
      doc.items = data.items;
      doc.settings = data.settings;
      await putDoc(doc);
    }
    toast.success(`Modèle « ${tpl.name} » ouvert`, { description: "Personnalisez-le puis enregistrez : tout reste sur cet appareil." });
    setView("editor");
  }

  return (
    <div className="aos-appear space-y-6">
      <header>
        <h1 className="text-2xl font-display font-semibold tracking-tight">Modèles</h1>
        <p className="text-muted-foreground mt-1">Des points de départ originaux, prêts à personnaliser.</p>
      </header>

      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Catégories de modèles">
        <CategoryChip label="Tous" active={category === "tous"} onClick={() => setCategory("tous")} />
        {ORDER.map((c) => (
          <CategoryChip key={c} label={CATEGORY_LABEL[c]} active={category === c} onClick={() => setCategory(c)} />
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map((t) => (
          <button
            key={t.id}
            onClick={() => openTemplate(t.id)}
            className="group rounded-xl border bg-card overflow-hidden text-left transition-all hover:shadow-md focus-visible:outline-2 focus-visible:outline-ring"
            aria-label={`Utiliser le modèle ${t.name}`}
          >
            <div className="aspect-[4/3] bg-secondary/50 relative overflow-hidden p-4">
              <TemplatePreview templateId={t.id} />
              <span
                className="absolute bottom-2 left-2 rounded-full text-[10px] font-medium px-2 py-0.5 text-white"
                style={{ backgroundColor: t.accent }}
              >
                {CATEGORY_LABEL[t.category]}
              </span>
            </div>
            <div className="p-4">
              <p className="font-medium">{t.name}</p>
              <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed">{t.description}</p>
              <span className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-primary">
                Utiliser ce modèle
                <ArrowRight className="size-3 transition-transform group-hover:translate-x-0.5" aria-hidden />
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function CategoryChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={cn(
        "rounded-full border px-3 h-8 text-sm font-medium transition-colors focus-visible:outline-2 focus-visible:outline-ring",
        active ? "border-primary bg-primary text-primary-foreground" : "hover:border-primary/45 hover:bg-accent/40"
      )}
    >
      {label}
    </button>
  );
}

/** Aperçu schématique honnête : rendu du contenu réel du modèle en miniature. */
function TemplatePreview({ templateId }: { templateId: string }) {
  const tpl = TEMPLATES.find((t) => t.id === templateId);
  if (!tpl) return null;
  const data = tpl.make();

  if (data.kind === "design") {
    const page = data.designPages[0];
    const isLandscape = page.w > page.h;
    return (
      <div className="w-full h-full grid place-items-center">
        <div
          className="relative bg-white border shadow-sm overflow-hidden"
          style={{
            width: "100%",
            aspectRatio: isLandscape ? "297/210" : "210/297",
            backgroundColor: page.background,
            maxWidth: "100%",
            maxHeight: "100%",
          }}
        >
          {data.items.slice(0, 8).map((it) => {
            const scale = (isLandscape ? 297 : 210) / page.w;
            if (it.type === "text") {
              return (
                <div
                  key={it.id}
                  style={{
                    position: "absolute",
                    left: `${(it.x / page.w) * 100}%`,
                    top: `${(it.y / page.h) * 100}%`,
                    width: `${(it.w / page.w) * 100}%`,
                    color: it.color,
                    fontFamily: fontStack(it.fontFamily),
                    fontSize: Math.max(3, it.fontSize * scale * 0.75),
                    fontWeight: it.bold ? 700 : 400,
                    fontStyle: it.italic ? "italic" : "normal",
                    textAlign: it.align,
                    lineHeight: 1.15,
                    whiteSpace: "pre-wrap",
                    overflow: "hidden",
                  }}
                >
                  {it.text.slice(0, 120)}
                </div>
              );
            }
            if (it.type === "rect") {
              return (
                <div
                  key={it.id}
                  style={{
                    position: "absolute",
                    left: `${(it.x / page.w) * 100}%`,
                    top: `${(it.y / page.h) * 100}%`,
                    width: `${(it.w / page.w) * 100}%`,
                    height: `${(it.h / page.h) * 100}%`,
                    backgroundColor: it.fill ? it.fillColor : undefined,
                    border: it.strokeWidth ? `${Math.max(0.5, it.strokeWidth * scale)}px solid ${it.color}` : undefined,
                    opacity: it.opacity,
                  }}
                />
              );
            }
            return null;
          })}
        </div>
      </div>
    );
  }

  // Aperçu blocs : premières lignes du document — dans la police du modèle
  const blocks = data.blocks.slice(0, 9);
  const previewFont = fontStack(data.settings.baseFont ?? "Helvetica");
  return (
    <div className="w-full h-full grid place-items-center">
      <div className="w-full bg-white border shadow-sm rounded-[2px] px-4 py-4 space-y-1.5 max-h-full overflow-hidden" style={{ fontFamily: previewFont }}>
        {blocks.map((b) => {
          if (b.type === "title")
            return <div key={b.id} className="font-bold text-[13px] truncate" style={{ color: tpl.accent }}>{b.text}</div>;
          if (b.type === "subtitle") return <div key={b.id} className="text-[9px] text-neutral-500 truncate">{b.text}</div>;
          if (b.type === "h1" || b.type === "h2" || b.type === "h3")
            return <div key={b.id} className="font-semibold text-[9.5px] truncate">{b.text}</div>;
          if (b.type === "paragraph")
            return (
              <div key={b.id} className="space-y-0.5">
                {(b.html.match(/<p>(.*?)<\/p>/g) ?? []).slice(0, 2).map((m, i) => (
                  <div key={i} className="text-[7px] text-neutral-600 leading-snug line-clamp-2">
                    {m.replace(/<\/?p>/g, "").slice(0, 90)}
                  </div>
                ))}
              </div>
            );
          if (b.type === "list")
            return (
              <div key={b.id} className="space-y-0.5">
                {(b.html.match(/<p>(.*?)<\/p>/g) ?? []).slice(0, 3).map((m, i) => (
                  <div key={i} className="text-[7px] text-neutral-600 truncate">• {m.replace(/<\/?p>/g, "").slice(0, 60)}</div>
                ))}
              </div>
            );
          if (b.type === "table")
            return <div key={b.id} className="h-6 border border-neutral-300 grid grid-cols-3 divide-x divide-neutral-300"><span /><span /><span /></div>;
          if (b.type === "field")
            return (
              <div key={b.id} className="space-y-0.5">
                <div className="text-[7px] text-neutral-600">{b.label}</div>
                <div className="h-2 border border-neutral-300 rounded-[1px]" />
              </div>
            );
          if (b.type === "divider") return <div key={b.id} className="h-px bg-neutral-200" />;
          return null;
        })}
      </div>
    </div>
  );
}
