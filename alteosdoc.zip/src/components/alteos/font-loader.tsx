"use client";

/**
 * AlteOS Docs — Chargement des familles Google Fonts.
 * -----------------------------------------------
 * Injecte au montage :
 *  - deux <link rel="preconnect"> (fonts.googleapis.com, fonts.gstatic.com) ;
 *  - des feuilles CSS2 groupées (~28 familles par requête) construites à
 *    partir de la table vérifiée src/lib/fonts-ttf.ts.
 *
 * Les polices sont demandées avec display=swap : le texte reste lisible
 * pendant le chargement, et le navigateur ne télécharge que les familles
 * réellement utilisées à l'écran (aperçus incrémentaux du sélecteur).
 *
 * Aucune clé, aucun compte, aucun coût : Google Fonts est gratuit.
 */

import { useEffect } from "react";

import { GOOGLE_TTF } from "@/lib/fonts-ttf";

/** Construit la spécification d'axes css2 d'après les fichiers vérifiés. */
function familySpec(family: string): string | null {
  const files = GOOGLE_TTF[family];
  if (!files || !files.r400) return null;
  const enc = family.replace(/ /g, "+");
  const hasBold = !!files.r700;
  const hasItalic = !!files.i400;
  if (hasBold && hasItalic) return `${enc}:ital,wght@0,400;0,700;1,400`;
  if (hasBold) return `${enc}:wght@400;700`;
  if (hasItalic) return `${enc}:ital,wght@0,400;1,400`;
  return enc;
}

/** URL des feuilles de styles, groupées pour rester sous ~28 familles. */
export function googleFontCssUrls(chunkSize = 28): string[] {
  const families = Object.keys(GOOGLE_TTF)
    .map(familySpec)
    .filter((s): s is string => s !== null);
  const urls: string[] = [];
  for (let i = 0; i < families.length; i += chunkSize) {
    const chunk = families.slice(i, i + chunkSize);
    urls.push(`https://fonts.googleapis.com/css2?family=${chunk.join("&family=")}&display=swap`);
  }
  return urls;
}

const LINK_BASE = "alteos-webfonts";

function ensureLink(href: string, id: string) {
  if (document.getElementById(id)) return;
  const link = document.createElement("link");
  link.id = id;
  link.rel = "stylesheet";
  link.href = href;
  link.crossOrigin = "anonymous";
  document.head.appendChild(link);
}

function ensurePreconnect(href: string, crossorigin: boolean) {
  const id = `alteos-preconnect-${href}`;
  if (document.getElementById(id)) return;
  const link = document.createElement("link");
  link.id = id;
  link.rel = "preconnect";
  link.href = href;
  if (crossorigin) link.crossOrigin = "anonymous";
  document.head.appendChild(link);
}

export function FontLoader() {
  useEffect(() => {
    try {
      ensurePreconnect("https://fonts.googleapis.com", false);
      ensurePreconnect("https://fonts.gstatic.com", true);
      googleFontCssUrls().forEach((url, i) => ensureLink(url, `${LINK_BASE}-${i}`));
    } catch {
      // Hors ligne ou réseau bloqué : les piles CSS de repli prennent le relais.
    }
  }, []);
  return null;
}
