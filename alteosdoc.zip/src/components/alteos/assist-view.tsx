"use client";

import { useState } from "react";
import { CheckCircle2, ShieldCheck, Sparkles, Send } from "lucide-react";
import { toast } from "sonner";
import { ASSIST_ACTIONS, runAssistAction, type AssistActionId } from "@/lib/assist/gateway";
import { getPlan } from "@/lib/plans";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";

export default function AssistView() {
  const [action, setAction] = useState<AssistActionId>("improve");
  const [text, setText] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const plan = getPlan();

  async function run() {
    if (!text.trim()) return toast.error("Ajoutez du texte à traiter.");
    setBusy(true);
    try {
      setResult(await runAssistAction({ action, text }));
      toast.success("AlteOS Assist a terminé.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "AlteOS Assist est indisponible.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="aos-appear max-w-4xl mx-auto space-y-6">
      <header>
        <div className="flex items-center gap-2.5">
          <span className="grid place-items-center size-10 rounded-lg bg-primary text-primary-foreground"><Sparkles className="size-5" /></span>
          <div>
            <h1 className="text-2xl font-display font-semibold tracking-tight">AlteOS Assist</h1>
            <p className="text-sm text-muted-foreground">Assistant d’écriture connecté au serveur AlteOS.</p>
          </div>
        </div>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Assistant</CardTitle>
          <CardDescription>Les clés API sont conservées exclusivement côté serveur. Les utilisateurs ne peuvent jamais les lire.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {ASSIST_ACTIONS.map((item) => (
              <Button key={item.id} size="sm" variant={action === item.id ? "default" : "outline"} onClick={() => setAction(item.id)}>
                {item.label}
              </Button>
            ))}
          </div>
          <Textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Collez ou écrivez le texte à traiter…" className="min-h-48" maxLength={60000} />
          <div className="flex items-center justify-between gap-3">
            <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
              <Badge variant="outline" className="gap-1"><ShieldCheck className="size-3" /> Clé serveur uniquement</Badge>
              <Badge variant="outline">{plan.ai.actionsPerMonth} actions/mois — {plan.name}</Badge>
            </div>
            <Button onClick={run} disabled={busy || !text.trim()}><Send className="size-4 mr-2" />{busy ? "Traitement…" : "Lancer Assist"}</Button>
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><CheckCircle2 className="size-4 text-primary" /> Résultat</CardTitle></CardHeader>
          <CardContent><div className="whitespace-pre-wrap text-sm leading-7 rounded-lg border bg-muted/30 p-4">{result}</div></CardContent>
        </Card>
      )}

      <Card className="bg-secondary/30">
        <CardContent className="pt-6 text-sm text-muted-foreground leading-relaxed">
          Le serveur AlteOS sélectionne une clé active, tente la requête et bascule automatiquement vers la prochaine clé lorsque le fournisseur renvoie une erreur récupérable ou un quota atteint. Aucune clé n’est envoyée au navigateur.
        </CardContent>
      </Card>
    </div>
  );
}
