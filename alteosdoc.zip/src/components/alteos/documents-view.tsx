"use client";

/**
 * Bibliothèque — Récents, Documents, Favoris, Corbeille.
 */

import { useMemo, useState } from "react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  ArrowUpNarrowWide,
  Copy,
  Download,
  FileText,
  FolderOpen,
  LayoutGrid,
  List as ListIcon,
  MoreHorizontal,
  RotateCcw,
  Star,
  Trash2,
  Pencil,
  Search,
} from "lucide-react";
import { toast } from "sonner";

import { useAppStore } from "@/store/app-store";
import { getDoc } from "@/lib/idb";
import { KIND_LABEL, type DocKind, type DocSummary } from "@/lib/types";
import { downloadBlob, relativeDateFR, sanitizeFilename } from "@/lib/utils";
import { DocThumb } from "@/components/alteos/doc-thumb";
import { cn } from "@/lib/utils";

type Tab = "recents" | "documents" | "favoris" | "corbeille";
type SortMode = "updated-desc" | "updated-asc" | "name-asc" | "name-desc" | "kind";

const SORT_LABEL: Record<SortMode, string> = {
  "updated-desc": "Modifié (récent)",
  "updated-asc": "Modifié (ancien)",
  "name-asc": "Nom (A→Z)",
  "name-desc": "Nom (Z→A)",
  kind: "Type",
};

const KIND_ORDER: Record<DocKind, number> = { document: 0, pdf: 1, design: 2, form: 3 };

export default function DocumentsView() {
  const docs = useAppStore((s) => s.docs);
  const openDoc = useAppStore((s) => s.openDoc);
  const [tab, setTab] = useState<Tab>("documents");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortMode>("updated-desc");
  const [layout, setLayout] = useState<"grid" | "list">("grid");

  const filtered = useMemo(() => {
    let list = docs.filter((d) => !d.deletedAt);
    if (tab === "recents") list = [...list].sort((a, b) => b.openedAt - a.openedAt);
    if (tab === "favoris") list = list.filter((d) => d.favorite);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((d) => d.name.toLowerCase().includes(q));
    }
    if (tab !== "recents") {
      list = [...list].sort((a, b) => {
        switch (sort) {
          case "updated-asc":
            return a.updatedAt - b.updatedAt;
          case "name-asc":
            return a.name.localeCompare(b.name, "fr");
          case "name-desc":
            return b.name.localeCompare(a.name, "fr");
          case "kind":
            return KIND_ORDER[a.kind] - KIND_ORDER[b.kind] || b.updatedAt - a.updatedAt;
          default:
            return b.updatedAt - a.updatedAt;
        }
      });
    }
    return list;
  }, [docs, tab, query, sort]);

  const trashed = useMemo(
    () => docs.filter((d) => d.deletedAt && (query.trim() === "" || d.name.toLowerCase().includes(query.trim().toLowerCase()))),
    [docs, query]
  );

  const list = tab === "corbeille" ? trashed : filtered;

  return (
    <div className="aos-appear space-y-5">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-display font-semibold tracking-tight">Documents</h1>
          <p className="text-sm text-muted-foreground mt-1 inline-flex items-center gap-1.5">
            <span className="inline-block size-1.5 rounded-full bg-primary" aria-hidden />
            Stocké sur cet appareil
          </p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" aria-hidden />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher par nom…"
            className="pl-8 h-9"
            aria-label="Rechercher un document"
          />
        </div>
      </header>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2" data-library-controls>
        <Tabs value={tab} onValueChange={(v) => setTab(v as Tab)}>
          <TabsList className="h-auto min-h-9 flex-wrap justify-start w-full sm:w-fit">
            <TabsTrigger value="recents" className="gap-1.5">
              <RotateCcw className="size-3.5" aria-hidden />
              Récents
            </TabsTrigger>
            <TabsTrigger value="documents" className="gap-1.5">
              <FolderOpen className="size-3.5" aria-hidden />
              Documents
            </TabsTrigger>
            <TabsTrigger value="favoris" className="gap-1.5">
              <Star className="size-3.5" aria-hidden />
              Favoris
            </TabsTrigger>
            <TabsTrigger value="corbeille" className="gap-1.5">
              <Trash2 className="size-3.5" aria-hidden />
              Corbeille
            </TabsTrigger>
          </TabsList>
        </Tabs>
        {tab !== "recents" && tab !== "corbeille" && (
          <div className="flex items-center gap-2">
            <Select value={sort} onValueChange={(v) => setSort(v as SortMode)}>
              <SelectTrigger className="h-8 w-[170px] text-xs" aria-label="Trier les documents">
                <ArrowUpNarrowWide className="size-3.5 text-muted-foreground" aria-hidden />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(SORT_LABEL) as SortMode[]).map((k) => (
                  <SelectItem key={k} value={k} className="text-xs">
                    {SORT_LABEL[k]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant={layout === "grid" ? "secondary" : "ghost"}
              size="icon"
              className="size-8"
              onClick={() => setLayout("grid")}
              aria-label="Vue grille"
              aria-pressed={layout === "grid"}
            >
              <LayoutGrid className="size-4" aria-hidden />
            </Button>
            <Button
              variant={layout === "list" ? "secondary" : "ghost"}
              size="icon"
              className="size-8"
              onClick={() => setLayout("list")}
              aria-label="Vue liste"
              aria-pressed={layout === "list"}
            >
              <ListIcon className="size-4" aria-hidden />
            </Button>
          </div>
        )}
      </div>

      {list.length === 0 ? (
        <EmptyState tab={tab} />
      ) : layout === "list" && tab !== "corbeille" ? (
        <div className="rounded-xl border divide-y overflow-hidden" data-library-list>
          {list.map((d) => (
            <LibraryRow key={d.id} doc={d} onOpen={() => openDoc(d.id)} />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {list.map((d) => (
            <LibraryCard key={d.id} doc={d} tab={tab} onOpen={() => openDoc(d.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

function LibraryRow({ doc, onOpen }: { doc: DocSummary; onOpen: () => void }) {
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const trashDoc = useAppStore((s) => s.trashDoc);
  const duplicateDoc = useAppStore((s) => s.duplicateDoc);
  return (
    <div className="flex items-center gap-3 px-3 py-2 hover:bg-accent/40 transition-colors" data-lib-row>
      <div className="w-14 h-10 rounded border bg-secondary/50 shrink-0 overflow-hidden grid place-items-center">
        <DocThumb docId={doc.id} />
      </div>
      <button className="flex-1 min-w-0 text-left" onClick={onOpen} title={doc.name}
        aria-label={`Ouvrir ${doc.name}`}>
        <span className="flex items-center gap-2">
          <span className="text-sm font-medium truncate">{doc.name}</span>
          {doc.favorite && <Star className="size-3 fill-current text-amber-500 shrink-0" aria-hidden />}
        </span>
        <span className="flex items-center gap-2 mt-0.5">
          <Badge variant="outline" className="text-[9px] px-1 py-0 h-auto font-medium">
            {KIND_LABEL[doc.kind]}
          </Badge>
          {doc.pageCount > 1 && <span className="text-[10px] text-muted-foreground tabular-nums">{doc.pageCount} pages</span>}
          <span className="text-[11px] text-muted-foreground">{relativeDateFR(doc.updatedAt)}</span>
        </span>
      </button>
      <div className="flex items-center gap-0.5 shrink-0">
        <Button variant="ghost" size="icon" className="size-7" onClick={() => toggleFavorite(doc.id)} aria-label={doc.favorite ? "Retirer des favoris" : "Ajouter aux favoris"}>
          <Star className={cn("size-3.5", doc.favorite && "fill-current text-amber-500")} aria-hidden />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-7"
          onClick={() =>
            toast.promise(duplicateDoc(doc.id).then(() => undefined), {
              loading: "Duplication…",
              success: "Copie créée",
              error: "La duplication a échoué",
            })
          }
          aria-label="Dupliquer le document"
        >
          <Copy className="size-3.5" aria-hidden />
        </Button>
        <Button variant="ghost" size="icon" className="size-7 text-destructive hover:text-destructive" onClick={() => trashDoc(doc.id)} aria-label="Mettre à la corbeille">
          <Trash2 className="size-3.5" aria-hidden />
        </Button>
      </div>
    </div>
  );
}

function EmptyState({ tab }: { tab: Tab }) {
  const setView = useAppStore((s) => s.setView);
  return (
    <div className="rounded-xl border border-dashed p-12 text-center">
      <FileText className="size-10 mx-auto text-muted-foreground/40" aria-hidden />
      <p className="mt-3 font-medium">
        {tab === "corbeille" ? "La corbeille est vide" : tab === "favoris" ? "Aucun favori pour le moment" : "Aucun document"}
      </p>
      <p className="text-sm text-muted-foreground mt-1">
        {tab === "corbeille" ? "Les documents supprimés apparaîtront ici." : "Créez un document ou importez un fichier pour commencer."}
      </p>
      {tab !== "corbeille" && (
        <Button className="mt-4" size="sm" onClick={() => setView("create")}>
          Créer un document
        </Button>
      )}
    </div>
  );
}

function LibraryCard({ doc, tab, onOpen }: { doc: DocSummary; tab: Tab; onOpen: () => void }) {
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const trashDoc = useAppStore((s) => s.trashDoc);
  const restoreDoc = useAppStore((s) => s.restoreDoc);
  const deleteForever = useAppStore((s) => s.deleteForever);
  const renameDoc = useAppStore((s) => s.renameDoc);
  const duplicateDoc = useAppStore((s) => s.duplicateDoc);
  const [renaming, setRenaming] = useState(false);
  const [name, setName] = useState(doc.name);

  async function exportDoc() {
    const full = await getDoc(doc.id);
    if (!full) return;
    try {
      toast.promise(
        (async () => {
          const { exportPdfDoc, exportDesignPdf, exportBlocksPdf } = await import("@/lib/pdf/export");
          let blob: Blob;
          if (full.kind === "pdf") blob = await exportPdfDoc(full, { quality: "standard", compact: true });
          else if (full.kind === "design") blob = await exportDesignPdf(full, { quality: "standard", compact: true });
          else blob = await exportBlocksPdf(full, { quality: "standard", compact: true, fillableForm: full.kind === "form" });
          downloadBlob(blob, `${sanitizeFilename(full.name)}.pdf`);
        })(),
        { loading: "Préparation de l'export…", success: "Export terminé — enregistré dans vos téléchargements", error: "L'export a échoué" }
      );
    } catch {
      toast.error("L'export a échoué");
    }
  }

  return (
    <Card className="group overflow-hidden transition-shadow hover:shadow-md">
      <button className="block w-full aspect-[4/3] bg-secondary/60 grid place-items-center relative" onClick={onOpen} aria-label={`Ouvrir ${doc.name}`}>
        <DocThumb docId={doc.id} />
        {doc.favorite && (
          <span className="absolute top-2 right-2 text-amber-500 bg-background/80 rounded-full p-1">
            <Star className="size-3.5 fill-current" aria-hidden />
          </span>
        )}
      </button>
      <div className="p-3 flex items-start gap-2">
        <div className="min-w-0 flex-1">
          {renaming ? (
            <Input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              onBlur={async () => {
                setRenaming(false);
                if (name.trim() && name !== doc.name) await renameDoc(doc.id, name);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                if (e.key === "Escape") {
                  setName(doc.name);
                  setRenaming(false);
                }
              }}
              className="h-7 text-sm"
              aria-label="Nouveau nom"
            />
          ) : (
            <button className="block w-full text-left" onClick={onOpen} onDoubleClick={() => setRenaming(true)} title={doc.name}>
              <p className="text-sm font-medium truncate">{doc.name}</p>
            </button>
          )}
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-auto font-medium">
              {KIND_LABEL[doc.kind]}
            </Badge>
            {doc.pageCount > 1 && (
              <span className="text-[10px] text-muted-foreground tabular-nums">{doc.pageCount} pages</span>
            )}
            <span className="text-xs text-muted-foreground">{relativeDateFR(doc.updatedAt)}</span>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="size-7 shrink-0 opacity-60 group-hover:opacity-100" aria-label={`Actions pour ${doc.name}`}>
              <MoreHorizontal className="size-4" aria-hidden />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            {tab !== "corbeille" ? (
              <>
                <DropdownMenuItem onClick={onOpen}>
                  <FileText className="size-4" aria-hidden /> Ouvrir
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setRenaming(true)}>
                  <Pencil className="size-4" aria-hidden /> Renommer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => toggleFavorite(doc.id)}>
                  <Star className={cn("size-4", doc.favorite && "fill-current text-amber-500")} aria-hidden />
                  {doc.favorite ? "Retirer des favoris" : "Ajouter aux favoris"}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={exportDoc}>
                  <Download className="size-4" aria-hidden /> Exporter en PDF
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() =>
                    toast.promise(duplicateDoc(doc.id).then(() => undefined), {
                      loading: "Duplication du document…",
                      success: "Copie créée",
                      error: "La duplication a échoué",
                    })
                  }
                >
                  <Copy className="size-4" aria-hidden /> Dupliquer
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem variant="destructive" onClick={() => trashDoc(doc.id)}>
                  <Trash2 className="size-4" aria-hidden /> Mettre à la corbeille
                </DropdownMenuItem>
              </>
            ) : (
              <>
                <DropdownMenuItem onClick={() => restoreDoc(doc.id)}>
                  <RotateCcw className="size-4" aria-hidden /> Restaurer
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  variant="destructive"
                  onClick={() =>
                    toast("Supprimer définitivement ?", {
                      description: "Cette action est irréversible.",
                      action: { label: "Supprimer", onClick: () => deleteForever(doc.id) },
                    })
                  }
                >
                  <Trash2 className="size-4" aria-hidden /> Supprimer définitivement
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </Card>
  );
}
