"use client";

/**
 * Accueil AlteOS Docs — « Qu'allez-vous créer ? »
 * Page entièrement personnalisable : salutation nominative, sections
 * affichables et réordonnables, fond, nombre de récents.
 */

import { Fragment, useMemo, useState } from "react";
import {
  ArrowRight,
  ClipboardList,
  FileText,
  FileUp,
  FolderOpen,
  HardDrive,
  LayoutTemplate,
  Layers,
  PenLine,
  SlidersHorizontal,
  Star,
  Trash2,
  Upload,
} from "lucide-react";

import { useAppStore } from "@/store/app-store";
import { homeBackgroundClass, useUiPrefs, type HomeWidgetId } from "@/store/ui-prefs";
import { KIND_LABEL, type DocKind } from "@/lib/types";
import { formatBytes, relativeDateFR } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DocThumb } from "@/components/alteos/doc-thumb";
import { CustomizeHomeSheet } from "@/components/alteos/customize/customize-home";
import { fontCount, fontStack } from "@/lib/fonts";
import { cn } from "@/lib/utils";

const ACTIONS: { kind: DocKind | "import"; title: string; desc: string; icon: typeof FileText; accent: boolean }[] = [
  { kind: "document", title: "Document", desc: "Rédiger, mettre en page, exporter en PDF.", icon: FileText, accent: true },
  { kind: "pdf", title: "PDF", desc: "Ouvrir, annoter et réorganiser un PDF.", icon: PenLine, accent: false },
  { kind: "design", title: "Design", desc: "Composer librement : textes, formes, images.", icon: LayoutTemplate, accent: false },
  { kind: "form", title: "Formulaire", desc: "Créer des champs remplissables.", icon: ClipboardList, accent: false },
  { kind: "import", title: "Importer", desc: "PDF, images, texte — depuis l'appareil.", icon: FileUp, accent: false },
];

const FONT_COUNT = fontCount();
const FONT_SAMPLES: { id: string; label: string }[] = [
  { id: "Playfair Display", label: "Playfair" },
  { id: "Space Grotesk", label: "Space Grotesk" },
  { id: "EB Garamond", label: "Garamond" },
  { id: "Caveat", label: "Caveat" },
  { id: "Bebas Neue", label: "Bebas" },
  { id: "JetBrains Mono", label: "JetBrains" },
];

function greetingWord(): string {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return "Bonjour";
  if (h >= 12 && h < 18) return "Bon après-midi";
  return "Bonsoir";
}

export default function HomeView() {
  const docs = useAppStore((s) => s.docs);
  const setView = useAppStore((s) => s.setView);
  const openDoc = useAppStore((s) => s.openDoc);
  const createDoc = useAppStore((s) => s.createDoc);
  const importFile = useAppStore((s) => s.importFile);
  const storageUsage = useAppStore((s) => s.storageUsage);
  const [importing, setImporting] = useState(false);

  const home = useUiPrefs((s) => s.home);
  const homeCustomOpen = useUiPrefs((s) => s.homeCustomOpen);
  const setHomeCustomOpen = useUiPrefs((s) => s.setHomeCustomOpen);

  const active = useMemo(() => docs.filter((d) => !d.deletedAt), [docs]);
  const recents = useMemo(
    () => [...active].sort((a, b) => b.openedAt - a.openedAt).slice(0, home.recentsCount),
    [active, home.recentsCount]
  );
  const favorites = useMemo(() => active.filter((d) => d.favorite).slice(0, 4), [active]);
  const trashed = useMemo(() => docs.filter((d) => d.deletedAt).length, [docs]);
  const totalPages = useMemo(() => active.reduce((sum, d) => sum + (d.pageCount ?? 0), 0), [active]);

  const compact = home.heroSize === "compact";
  const hasName = home.displayName.trim().length > 0;

  async function handleAction(kind: DocKind | "import") {
    if (kind === "import" || kind === "pdf") {
      setView("create");
      return;
    }
    await createDoc(kind, {
      name: kind === "form" ? "Formulaire sans titre" : undefined,
    });
  }

  async function quickImport(file: File) {
    setImporting(true);
    try {
      const res = await importFile(file);
      if (!res.ok) {
        const { toast } = await import("sonner").then((m) => ({ toast: m.toast }));
        toast.error(res.message ?? "Impossible d'ouvrir ce fichier", {
          description: "Le fichier semble endommagé ou son format n'est pas encore pris en charge.",
          action: { label: "Choisir un autre fichier", onClick: () => setView("create") },
        });
      }
    } finally {
      setImporting(false);
    }
  }

  const WIDGET_COMPONENTS: Record<HomeWidgetId, React.ReactNode> = {
    actions: (
      <WidgetActions
        onAction={handleAction}
        onImport={quickImport}
        importing={importing}
        compact={compact}
      />
    ),
    recents:
      recents.length > 0 ? (
        <section key="w-recents" aria-labelledby="recent-title" className="aos-appear">
          <div className="flex items-center justify-between mb-3">
            <h2 id="recent-title" className={cn("font-display font-semibold tracking-tight", compact ? "text-base" : "text-lg")}>
              Reprendre
            </h2>
            <Button variant="ghost" size="sm" className="h-8 text-muted-foreground" onClick={() => setView("documents")}>
              Tout voir
              <ArrowRight className="size-3.5 ml-1" aria-hidden />
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {recents.map((d) => (
              <DocCard key={d.id} id={d.id} name={d.name} kind={d.kind} date={d.openedAt} onOpen={() => openDoc(d.id)} />
            ))}
          </div>
        </section>
      ) : null,
    favorites:
      favorites.length > 0 ? (
        <section key="w-favorites" aria-labelledby="fav-title" className="aos-appear">
          <div className="flex items-center justify-between mb-3">
            <h2 id="fav-title" className={cn("font-display font-semibold tracking-tight inline-flex items-center gap-2", compact ? "text-base" : "text-lg")}>
              <Star className="size-4 text-primary" aria-hidden />
              Favoris
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {favorites.map((d) => (
              <DocCard key={d.id} id={d.id} name={d.name} kind={d.kind} date={d.updatedAt} onOpen={() => openDoc(d.id)} />
            ))}
          </div>
        </section>
      ) : null,
    stats: (
      <section key="w-stats" aria-labelledby="stats-title" className="aos-appear rounded-xl border bg-card/70 p-5">
        <h2 id="stats-title" className="font-display text-base font-semibold tracking-tight mb-4">
          Votre espace en chiffres
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatTile icon={FileText} label="Documents" value={String(active.length)} />
          <StatTile icon={Layers} label="Pages" value={String(totalPages)} />
          <StatTile icon={Star} label="Favoris" value={String(favorites.length)} />
          <StatTile
            icon={HardDrive}
            label="Espace utilisé"
            value={storageUsage != null ? formatBytes(storageUsage) : "—"}
          />
        </div>
        <p className="mt-4 text-[11px] text-muted-foreground/75 inline-flex items-center gap-1.5">
          <span className="inline-block size-1.5 rounded-full bg-primary" aria-hidden />
          Mesuré sur cet appareil — aucune donnée ne quitte le navigateur.
        </p>
      </section>
    ),
    fonts: (
      <section key="w-fonts" aria-labelledby="fonts-title" className="aos-appear rounded-xl border bg-card/70 p-5">
        <div className="flex items-baseline justify-between gap-3 mb-3">
          <h2 id="fonts-title" className="font-display text-base font-semibold tracking-tight">
            Typothèque
          </h2>
          <span className="text-[11px] text-muted-foreground/75">{FONT_COUNT} polices intégrées</span>
        </div>
        <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2 text-sm text-muted-foreground">
          {FONT_SAMPLES.map((s) => (
            <span key={s.id} style={{ fontFamily: fontStack(s.id) }} className="text-base">
              {s.label}
            </span>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground/70">
          Chargées à la demande, incorporées réellement dans les PDF exportés.
        </p>
      </section>
    ),
    features: (
      <section key="w-features" aria-labelledby="features-title" className="aos-appear rounded-xl border bg-card/70 p-4 sm:p-5">
        <div className="flex items-baseline justify-between gap-3 mb-3">
          <h2 id="features-title" className="font-display text-sm font-semibold tracking-tight">
            Tout ce que fait AlteOS Docs — réellement, et sur cet appareil
          </h2>
          <span className="text-[11px] text-muted-foreground/70 hidden sm:inline">Ctrl + K pour agir vite</span>
        </div>
        <ul className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
          {[
            `${FONT_COUNT} polices, incorporées à l'export`,
            "133 icônes vectorielles recolorables",
            "Codes QR générés localement",
            "Filtres d'images ré-encodés au PDF",
            "Filigrane, numéros et en-têtes d'export",
            "Métadonnées PDF (auteur, sujet…)",
            "Export Markdown, HTML et texte",
            "Listes de tâches interactives",
            "Lecture à voix haute (voix du système)",
            "Historique de versions restaurable",
            "Signets de pages et filtres de lecture",
            "Alt+glisser pour dupliquer, flèches pour ajuster",
          ].map((f) => (
            <li key={f} className="flex items-start gap-1.5 leading-relaxed">
              <span className="mt-[7px] size-1 shrink-0 rounded-full bg-primary/70" aria-hidden />
              {f}
            </li>
          ))}
        </ul>
      </section>
    ),
    space: (
      <section key="w-space" aria-labelledby="espace-title" className="aos-appear rounded-xl border bg-card/70 p-5">
        <h2 id="espace-title" className="font-display text-base font-semibold tracking-tight mb-1">
          Votre espace
        </h2>
        <p className="text-xs text-muted-foreground mb-4 inline-flex items-center gap-1.5">
          <span className="inline-block size-1.5 rounded-full bg-primary" aria-hidden />
          Stocké sur cet appareil — {active.length} document{active.length > 1 ? "s" : ""}
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <SpaceLink icon={FileText} label="Récents" count={active.length} onClick={() => setView("documents")} />
          <SpaceLink icon={FolderOpen} label="Documents" count={active.length} onClick={() => setView("documents")} />
          <SpaceLink icon={Star} label="Favoris" count={favorites.length} onClick={() => setView("documents")} />
          <SpaceLink icon={Trash2} label="Corbeille" count={trashed} onClick={() => setView("documents")} />
        </div>
      </section>
    ),
  };

  return (
    <div className={cn("aos-home -mx-4 sm:-mx-6 lg:-mx-10 px-4 sm:px-6 lg:px-10", homeBackgroundClass(home.background))}>
      <div className={cn("max-w-6xl mx-auto", compact ? "space-y-6 py-4" : "space-y-9 py-6")}>
        {/* Héro */}
        <section aria-labelledby="hero-title" className={cn(compact ? "pt-2" : "pt-6")}>
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="text-[11px] font-semibold text-primary mb-2 tracking-[0.14em] uppercase">
                AlteOS Docs · Studio local
              </p>
              <h1
                id="hero-title"
                className={cn(
                  "font-display font-semibold tracking-tight",
                  compact ? "text-2xl sm:text-3xl" : "text-3xl sm:text-[2.6rem] sm:leading-[1.1]"
                )}
              >
                {hasName ? (
                  <>
                    {greetingWord()},{" "}
                    <span className="text-primary">{home.displayName.trim()}</span>
                  </>
                ) : (
                  "Qu'allez-vous créer\u00a0?"
                )}
              </h1>
              <p className={cn("text-muted-foreground max-w-xl", compact ? "text-sm mt-1.5" : "mt-3")}>
                {home.tagline.trim() ||
                  "Documents, PDF, designs et formulaires — créés, modifiés et enregistrés directement sur cet appareil."}
              </p>
              {hasName && (
                <p className="text-xs text-muted-foreground/70 mt-1">Qu&apos;allez-vous créer{"\u00a0"}?</p>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-8 shrink-0 mt-1"
              onClick={() => setHomeCustomOpen(true)}
              data-personalize-home
            >
              <SlidersHorizontal className="size-3.5 mr-1.5" aria-hidden />
              Personnaliser
            </Button>
          </div>
        </section>

        {/* Sections dans l'ordre choisi */}
        {home.widgets.map((w) => {
          if (!w.visible) return null;
          const node = WIDGET_COMPONENTS[w.id];
          return node ? <Fragment key={w.id}>{node}</Fragment> : null;
        })}
      </div>

      <CustomizeHomeSheet open={homeCustomOpen} onOpenChange={setHomeCustomOpen} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Section « Créer » — les cinq actions
// ---------------------------------------------------------------------------

function WidgetActions({
  onAction,
  onImport,
  importing,
  compact,
}: {
  onAction: (kind: DocKind | "import") => void;
  onImport: (file: File) => void;
  importing: boolean;
  compact: boolean;
}) {
  return (
    <section key="w-actions" aria-label="Créer" className={compact ? "aos-appear" : "aos-appear"}>
      <div className={cn("grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3", compact && "sm:grid-cols-3 lg:grid-cols-5")}>
        {ACTIONS.map((a) => {
          const Icon = a.icon;
          if (a.kind === "import" || a.kind === "pdf") {
            return (
              <label
                key={a.kind}
                className="group cursor-pointer rounded-xl border bg-card p-4 flex flex-col gap-3 min-h-[128px] transition-all hover:border-primary/50 hover:shadow-md focus-within:outline-2 focus-within:outline-ring"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const f = e.dataTransfer.files?.[0];
                  if (f) onImport(f);
                }}
              >
                <span
                  className={cn(
                    "grid place-items-center size-9 rounded-lg transition-colors",
                    a.accent
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "bg-secondary text-secondary-foreground/80 group-hover:bg-accent group-hover:text-accent-foreground"
                  )}
                >
                  <Icon className="size-[18px]" aria-hidden />
                </span>
                <span>
                  <span className="block font-medium text-sm">{a.title}</span>
                  <span className="block text-xs text-muted-foreground mt-0.5 leading-relaxed">{a.desc}</span>
                </span>
                <input
                  type="file"
                  accept={
                    a.kind === "pdf"
                      ? "application/pdf,.pdf"
                      : "application/pdf,image/png,image/jpeg,image/webp,.txt,.md,.pdf"
                  }
                  className="sr-only"
                  aria-label={`${a.title} — importer un fichier`}
                  disabled={importing}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) onImport(f);
                    e.currentTarget.value = "";
                  }}
                />
                <span className="mt-auto text-xs text-muted-foreground/70 group-hover:text-primary inline-flex items-center gap-1 transition-colors">
                  <Upload className="size-3" aria-hidden />
                  {importing ? "Ouverture…" : "Choisir un fichier"}
                </span>
              </label>
            );
          }
          return (
            <button
              key={a.kind}
              onClick={() => onAction(a.kind)}
              className={cn(
                "group rounded-xl border bg-card p-4 flex flex-col gap-3 min-h-[128px] text-left transition-all hover:shadow-md focus-visible:outline-2 focus-visible:outline-ring",
                a.accent ? "border-primary/40 hover:border-primary/60" : "hover:border-primary/50"
              )}
            >
              <span
                className={cn(
                  "grid place-items-center size-9 rounded-lg transition-colors",
                  a.accent
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-secondary text-secondary-foreground/80 group-hover:bg-accent group-hover:text-accent-foreground"
                )}
              >
                <Icon className="size-[18px]" aria-hidden />
              </span>
              <span>
                <span className="block font-medium text-sm">{a.title}</span>
                <span className="block text-xs text-muted-foreground mt-0.5 leading-relaxed">{a.desc}</span>
              </span>
              <span className="mt-auto text-xs text-muted-foreground/70 group-hover:text-primary inline-flex items-center gap-1 transition-colors">
                Commencer
                <ArrowRight className="size-3 transition-transform group-hover:translate-x-0.5" aria-hidden />
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Petites pièces
// ---------------------------------------------------------------------------

function StatTile({ icon: Icon, label, value }: { icon: typeof FileText; label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-background p-3.5">
      <div className="flex items-center gap-2 text-muted-foreground mb-1.5">
        <Icon className="size-3.5" aria-hidden />
        <span className="text-[11px] font-medium">{label}</span>
      </div>
      <p className="font-display text-2xl font-semibold tabular-nums tracking-tight">{value}</p>
    </div>
  );
}

function SpaceLink({ icon: Icon, label, count, onClick }: { icon: typeof FileText; label: string; count: number; onClick: () => void }) {
  return (
    <button
      className="flex items-center gap-3 rounded-lg border bg-background p-3 text-left transition-colors hover:border-primary/50 hover:bg-accent/40 focus-visible:outline-2 focus-visible:outline-ring"
      onClick={onClick}
    >
      <span className="grid place-items-center size-8 rounded-md bg-secondary text-secondary-foreground/80">
        <Icon className="size-4" aria-hidden />
      </span>
      <span>
        <span className="block text-sm font-medium leading-tight">{label}</span>
        <span className="block text-xs text-muted-foreground">{count}</span>
      </span>
    </button>
  );
}

export function DocCard({
  id,
  name,
  kind,
  date,
  onOpen,
}: {
  id: string;
  name: string;
  kind: DocKind;
  date: number;
  onOpen: () => void;
}) {
  return (
    <button
      onClick={onOpen}
      className="group rounded-xl border bg-card overflow-hidden text-left transition-all hover:shadow-md hover:border-primary/40 focus-visible:outline-2 focus-visible:outline-ring"
      aria-label={`Ouvrir ${name}`}
    >
      <div className="aspect-[4/3] bg-secondary/50 grid place-items-center overflow-hidden relative">
        <DocThumb docId={id} />
      </div>
      <div className="p-3">
        <p className="text-sm font-medium truncate">{name}</p>
        <div className="flex items-center gap-2 mt-1">
          <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-auto font-medium">
            {KIND_LABEL[kind]}
          </Badge>
          <span className="text-xs text-muted-foreground">{relativeDateFR(date)}</span>
        </div>
      </div>
    </button>
  );
}
