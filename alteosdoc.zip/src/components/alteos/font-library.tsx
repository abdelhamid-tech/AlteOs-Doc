"use client";

/**
 * AlteOS Docs — Bibliothèque de polices (Paramètres).
 * ----------------------------------------------------
 * Exploration des 153 polices : recherche, filtres par catégorie,
 * aperçu réel de chaque famille et choix de la police par défaut
 * (utilisée pour les nouveaux documents et les nouveaux textes).
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Search, Type } from "lucide-react";
import { toast } from "sonner";

import {
  CATEGORY_LABEL,
  CATEGORY_ORDER,
  FONT_REGISTRY,
  fontStack,
  getFont,
  googleFontCount,
  searchFonts,
  systemFontCount,
  type FontCategory,
  type FontDef,
} from "@/lib/fonts";
import { getPref, setPref } from "@/lib/idb";
import { useEditorStore } from "@/store/editor-store";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const PAGE = 24;

const PANGRAM = "Portez ce vieux whisky au juge blond qui fume";

const TABS: { id: FontCategory | "all"; label: string }[] = [
  { id: "all", label: "Toutes" },
  ...CATEGORY_ORDER.map((c) => ({ id: c, label: CATEGORY_LABEL[c] })),
];

export function FontLibrary() {
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<FontCategory | "all">("all");
  // Rendu incrémental : « génération » (recherche/filtre) + nombre de cartes affichées (dérivé, sans effet).
  const key = `${cat}|${query}`;
  const [gen, setGen] = useState<{ key: string; n: number }>({ key: "", n: PAGE });
  const visible = gen.key === key ? gen.n : PAGE;
  const [defaultFont, setDefaultFont] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);
  const sentinelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const pref = await getPref<string>("defaultFont");
      if (!cancelled) {
        setDefaultFont(pref ?? "Helvetica");
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const results = useMemo(() => searchFonts(query, cat), [query, cat]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setGen((g) => (g.key === key ? { key, n: Math.min(g.n + PAGE, results.length) } : { key, n: 2 * PAGE }));
        }
      },
      { rootMargin: "400px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [key, results.length]);

  function chooseFont(id: string) {
    setDefaultFont(id);
    setPref("defaultFont", id).catch(() => undefined);
    useEditorStore.getState().setTextFont(id);
    toast.success(`Police par défaut : ${getFont(id)?.name ?? id}`, {
      description: "Utilisée pour les nouveaux documents et les nouveaux textes.",
    });
  }

  const shown = results.slice(0, visible);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Type className="size-4 text-primary" aria-hidden />
          Bibliothèque de polices
        </CardTitle>
        <CardDescription>
          {FONT_REGISTRY.length} polices intégrées : {googleFontCount()} familles Google Fonts gratuites et{" "}
          {systemFontCount()} polices de votre appareil. La police par défaut s&apos;applique aux nouveaux
          documents et nouveaux textes.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          <Search className="size-3.5 text-muted-foreground shrink-0" aria-hidden />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Rechercher parmi ${FONT_REGISTRY.length} polices…`}
            className="h-8 text-sm"
            aria-label="Rechercher une police"
          />
        </div>

        <div className="flex gap-1 overflow-x-auto pb-1 editor-scroll" role="tablist" aria-label="Catégories de polices">
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={cat === t.id}
              onClick={() => setCat(t.id)}
              className={cn(
                "shrink-0 rounded-full px-2.5 py-0.5 text-xs transition-colors focus-visible:outline-2 focus-visible:outline-ring",
                cat === t.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2" role="listbox" aria-label="Polices">
          {shown.map((f) => (
            <FontCard key={f.id} font={f} active={loaded && defaultFont === f.id} onChoose={() => chooseFont(f.id)} />
          ))}
        </div>

        {shown.length === 0 && (
          <p className="py-6 text-center text-sm text-muted-foreground">Aucune police ne correspond à « {query} ».</p>
        )}
        {shown.length < results.length && <div ref={sentinelRef} className="h-px" aria-hidden />}

        <p className="text-xs text-muted-foreground/80 leading-relaxed border-t pt-3">
          Les familles Google se chargent depuis fonts.googleapis.com (gratuit, sans compte) et restent affichées
          avec une police de repli si vous êtes hors ligne. À l&apos;export PDF, les polices choisies sont
          réellement incorporées au fichier — hors ligne, une police standard équivalente est utilisée.
        </p>
      </CardContent>
    </Card>
  );
}

function FontCard({ font, active, onChoose }: { font: FontDef; active: boolean; onChoose: () => void }) {
  return (
    <button
      role="option"
      aria-selected={active}
      onClick={onChoose}
      className={cn(
        "group text-left rounded-lg border p-3 transition-colors focus-visible:outline-2 focus-visible:outline-ring",
        active ? "border-primary/60 bg-accent/40" : "hover:border-primary/40 hover:bg-accent/20"
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="font-medium text-sm truncate" style={{ fontFamily: fontStack(font.id) }}>
          {font.name}
        </span>
        {active ? (
          <Badge className="text-[10px] shrink-0 gap-1">
            <Check className="size-2.5" aria-hidden />
            Par défaut
          </Badge>
        ) : (
          <Badge variant="secondary" className="text-[10px] shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
            Choisir
          </Badge>
        )}
      </div>
      <p className="mt-1.5 text-xs text-muted-foreground truncate" style={{ fontFamily: fontStack(font.id) }}>
        {PANGRAM}
      </p>
      <p className="mt-1 text-[10px] text-muted-foreground/70">
        {CATEGORY_LABEL[font.cat]} · {font.src === "google" ? "Google Fonts" : "Appareil"}
      </p>
    </button>
  );
}
