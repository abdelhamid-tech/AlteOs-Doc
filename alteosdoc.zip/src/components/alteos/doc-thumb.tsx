"use client";

/**
 * Vignette d'un document — réelle (PNG stocké en IndexedDB) ou repère de type.
 * Aucune fausse prévisualisation : sans vignette, on affiche le type.
 */

import { useEffect, useState } from "react";
import { FileText, ClipboardList, LayoutTemplate, File } from "lucide-react";

import { getDoc } from "@/lib/idb";
import type { DocKind } from "@/lib/types";

const ICONS: Record<DocKind, typeof FileText> = {
  document: FileText,
  pdf: File,
  design: LayoutTemplate,
  form: ClipboardList,
};

export function DocThumb({ docId, className }: { docId: string; className?: string }) {
  const [url, setUrl] = useState<string | null>(null);
  const [kind, setKind] = useState<DocKind | null>(null);

  useEffect(() => {
    let revoked: string | null = null;
    let cancelled = false;
    (async () => {
      const doc = await getDoc(docId);
      if (!doc || cancelled) return;
      setKind(doc.kind);
      if (doc.thumb) {
        const u = URL.createObjectURL(doc.thumb);
        revoked = u;
        setUrl(u);
      }
    })();
    return () => {
      cancelled = true;
      if (revoked) URL.revokeObjectURL(revoked);
    };
  }, [docId]);

  if (url) {
     
    return <img src={url} alt="" className={className ?? "max-h-full max-w-full object-contain"} />;
  }
  const Icon = kind ? ICONS[kind] : FileText;
  return (
    <span className="grid place-items-center text-muted-foreground/40 h-full w-full">
      <Icon className="size-10" aria-hidden />
    </span>
  );
}
