"use client";

/**
 * Personnalisation de la page d'accueil — nom affiché, accroche,
 * taille du héros, fond, nombre de récents, widgets affichables
 * et réordonnables. Persisté sur cet appareil (IndexedDB).
 */

import { ArrowDown, ArrowUp, Eye, EyeOff, RotateCcw } from "lucide-react";
import { toast } from "sonner";

import {
  HOME_BACKGROUNDS,
  HOME_WIDGETS,
  useUiPrefs,
  type HeroSize,
  type HomeBackground,
} from "@/store/ui-prefs";
import { AccentPickerInline } from "./accent-picker";
import { Segmented } from "./segmented";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export function CustomizeHomeSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const home = useUiPrefs((s) => s.home);
  const updateHome = useUiPrefs((s) => s.updateHome);
  const toggleHomeWidget = useUiPrefs((s) => s.toggleHomeWidget);
  const moveHomeWidget = useUiPrefs((s) => s.moveHomeWidget);
  const resetHome = useUiPrefs((s) => s.resetHome);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[380px] sm:max-w-[380px] overflow-y-auto" data-customize-home>
        <SheetHeader>
          <SheetTitle>Personnaliser l&apos;accueil</SheetTitle>
          <SheetDescription>
            Votre page d&apos;accueil, à votre image. Enregistré sur cet appareil uniquement.
          </SheetDescription>
        </SheetHeader>

        <div className="px-4 pb-8 space-y-6">
          {/* Salutation */}
          <section className="space-y-3" aria-labelledby="cst-greeting">
            <h3 id="cst-greeting" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Salutation
            </h3>
            <div className="space-y-1.5">
              <Label htmlFor="cst-name">Prénom affiché</Label>
              <Input
                id="cst-name"
                value={home.displayName}
                maxLength={30}
                placeholder="Ex. Camille — laissez vide pour « Qu'allez-vous créer ? »"
                onChange={(e) => updateHome({ displayName: e.target.value })}
              />
              <p className="text-[11px] text-muted-foreground/80">
                Avec un prénom, l&apos;accueil affiche « Bonjour, Camille » (ou « Bonsoir » selon l&apos;heure).
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cst-tagline">Phrase d&apos;accroche</Label>
              <Input
                id="cst-tagline"
                value={home.tagline}
                maxLength={90}
                placeholder="Par défaut : « Documents, PDF, designs et formulaires… »"
                onChange={(e) => updateHome({ tagline: e.target.value })}
              />
            </div>
          </section>

          {/* Mise en page */}
          <section className="space-y-3" aria-labelledby="cst-layout">
            <h3 id="cst-layout" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Mise en page
            </h3>
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">Taille de l&apos;en-tête</span>
              <Segmented<HeroSize>
                value={home.heroSize}
                onChange={(v) => updateHome({ heroSize: v })}
                options={[
                  { value: "grand", label: "Grand" },
                  { value: "compact", label: "Compact" },
                ]}
                ariaLabel="Taille de l'en-tête"
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">Fond de page</span>
              <Segmented<HomeBackground>
                value={home.background}
                onChange={(v) => updateHome({ background: v })}
                options={HOME_BACKGROUNDS.map((b) => ({ value: b.id, label: b.label }))}
                ariaLabel="Fond de la page d'accueil"
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">Documents dans « Reprendre »</span>
              <Segmented<string>
                value={String(home.recentsCount)}
                onChange={(v) => updateHome({ recentsCount: Number(v) })}
                options={[2, 4, 6, 8].map((n) => ({ value: String(n), label: String(n) }))}
                ariaLabel="Nombre de documents récents"
              />
            </div>
          </section>

          {/* Widgets */}
          <section className="space-y-2" aria-labelledby="cst-widgets">
            <div className="flex items-center justify-between">
              <h3 id="cst-widgets" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                Sections affichées
              </h3>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs text-muted-foreground"
                onClick={() => {
                  resetHome();
                  toast.success("Accueil réinitialisé");
                }}
              >
                <RotateCcw className="size-3 mr-1" aria-hidden />
                Réinitialiser
              </Button>
            </div>
            <ul className="space-y-1.5">
              {home.widgets.map((w, i) => {
                const def = HOME_WIDGETS.find((d) => d.id === w.id);
                if (!def) return null;
                return (
                  <li
                    key={w.id}
                    className={cn(
                      "rounded-lg border p-2.5 flex items-center gap-2.5 transition-opacity",
                      !w.visible && "opacity-60"
                    )}
                  >
                    <Switch
                      checked={w.visible}
                      onCheckedChange={() => toggleHomeWidget(w.id)}
                      aria-label={`Afficher la section ${def.label}`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium leading-tight">{def.label}</p>
                      <p className="text-[11px] text-muted-foreground/80 truncate">{def.desc}</p>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-6"
                        onClick={() => moveHomeWidget(w.id, -1)}
                        disabled={i === 0}
                        aria-label={`Monter la section ${def.label}`}
                      >
                        <ArrowUp className="size-3" aria-hidden />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-6"
                        onClick={() => moveHomeWidget(w.id, 1)}
                        disabled={i === home.widgets.length - 1}
                        aria-label={`Descendre la section ${def.label}`}
                      >
                        <ArrowDown className="size-3" aria-hidden />
                      </Button>
                    </div>
                    <span className="text-muted-foreground/60 w-4 grid place-items-center" aria-hidden>
                      {w.visible ? <Eye className="size-3.5" /> : <EyeOff className="size-3.5" />}
                    </span>
                  </li>
                );
              })}
            </ul>
          </section>

          {/* Accent */}
          <section className="space-y-2.5" aria-labelledby="cst-accent">
            <h3 id="cst-accent" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Couleur d&apos;accent
            </h3>
            <AccentPickerInline />
            <p className="text-[11px] text-muted-foreground/80">
              L&apos;accent colore toute l&apos;interface : boutons, sélection, marque. Il s&apos;applique aussi à l&apos;éditeur.
            </p>
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}
