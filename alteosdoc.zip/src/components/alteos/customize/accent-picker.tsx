"use client";

/**
 * Sélecteur d'accent signature — 6 ambiances originales.
 * Chaque pastille applique l'accent immédiatement (persisté sur l'appareil).
 */

import { Check } from "lucide-react";

import { ACCENTS, useUiPrefs, type AccentId } from "@/store/ui-prefs";
import { cn } from "@/lib/utils";

export function AccentPicker({
  value,
  onChange,
  size = "md",
  className,
}: {
  value: AccentId;
  onChange: (id: AccentId) => void;
  size?: "sm" | "md";
  className?: string;
}) {
  const swatch = size === "sm" ? "size-7" : "size-9";
  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)} role="radiogroup" aria-label="Couleur d'accent">
      {ACCENTS.map((a) => {
        const active = value === a.id;
        return (
          <button
            key={a.id}
            role="radio"
            aria-checked={active}
            aria-label={`Accent ${a.label}`}
            title={a.label}
            onClick={() => onChange(a.id)}
            className={cn(
              "grid place-items-center rounded-full transition-transform focus-visible:outline-2 focus-visible:outline-ring",
              swatch,
              active ? "scale-110 ring-2 ring-ring ring-offset-2 ring-offset-background" : "hover:scale-105"
            )}
            style={{ background: a.swatch }}
          >
            {active && <Check className="size-3.5 text-white" strokeWidth={3} aria-hidden />}
          </button>
        );
      })}
    </div>
  );
}

/** Sélecteur d'accent autoconnecté au magasin (usage compact : en-têtes, dialogues). */
export function AccentPickerInline({ size = "sm" }: { size?: "sm" | "md" }) {
  const accent = useUiPrefs((s) => s.accent);
  const setAccent = useUiPrefs((s) => s.setAccent);
  return <AccentPicker value={accent} onChange={setAccent} size={size} />;
}
