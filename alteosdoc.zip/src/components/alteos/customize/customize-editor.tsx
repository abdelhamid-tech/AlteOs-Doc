"use client";

/**
 * Personnalisation de la page d'édition — disposition des panneaux,
 * densité du rail d'outils, toile de fond, espacement des pages.
 * Les réglages s'appliquent immédiatement aux éditeurs PDF, Design
 * et Document, et survivent à la fermeture (IndexedDB local).
 */

import { useTheme } from "next-themes";
import { Check, Monitor, Moon, RotateCcw, Sun } from "lucide-react";
import { toast } from "sonner";

import { useEditorStore } from "@/store/editor-store";
import {
  EDITOR_BACKDROPS,
  EDITOR_PRESETS,
  useUiPrefs,
  type EditorBackdrop,
  type PageGap,
  type ToolbarDensity,
} from "@/store/ui-prefs";
import { AccentPickerInline } from "./accent-picker";
import { Segmented } from "./segmented";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

export function CustomizeEditorDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const editor = useUiPrefs((s) => s.editor);
  const updateEditor = useUiPrefs((s) => s.updateEditor);
  const applyEditorPreset = useUiPrefs((s) => s.applyEditorPreset);
  const resetEditor = useUiPrefs((s) => s.resetEditor);
  const { theme, setTheme } = useTheme();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[460px] overflow-y-auto max-h-[85vh]" data-customize-editor>
        <DialogHeader>
          <DialogTitle>Personnaliser l&apos;éditeur</DialogTitle>
          <DialogDescription>
            Disposez l&apos;atelier à votre façon — appliqué aux documents, PDF, designs et formulaires.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Dispositions prêtes à l'emploi */}
          <section className="space-y-2" aria-labelledby="ced-presets">
            <h3 id="ced-presets" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Dispositions
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {EDITOR_PRESETS.map((p) => {
                const active = editor.preset === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => {
                      applyEditorPreset(p.id);
                      // Synchronisation en direct du panneau Calques si un éditeur est ouvert.
                      useEditorStore.getState().setLayersOpen(p.id === "studio");
                      toast.success(`Disposition « ${p.label} » appliquée`);
                    }}
                    aria-pressed={active}
                    className={cn(
                      "rounded-lg border p-3 text-left transition-colors focus-visible:outline-2 focus-visible:outline-ring",
                      active ? "border-primary/60 bg-accent/50" : "hover:border-primary/40"
                    )}
                  >
                    <span className="flex items-center justify-between">
                      <span className="text-sm font-medium">{p.label}</span>
                      {active && <Check className="size-3.5 text-primary" aria-hidden />}
                    </span>
                    <PresetGlyph preset={p.id} active={active} />
                    <span className="block text-[11px] leading-snug text-muted-foreground/85 mt-1">{p.desc}</span>
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-muted-foreground/70">
              Les dispositions règlent les panneaux ci-dessous d&apos;un geste — vous pouvez ensuite les ajuster une à une.
            </p>
          </section>

          {/* Panneaux */}
          <section className="space-y-1" aria-labelledby="ced-panels">
            <h3 id="ced-panels" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase mb-2">
              Panneaux
            </h3>
            {(
              [
                { key: "thumbs", label: "Panneau des pages", desc: "Vignettes des pages, à gauche de la toile." },
                { key: "layers", label: "Panneau Calques", desc: "Ordre, visibilité et verrouillage des éléments." },
                { key: "statusBar", label: "Barre d'état", desc: "Page courante, pages sélectionnées et zoom, en bas." },
              ] as const
            ).map((row) => (
              <div key={row.key} className="flex items-center justify-between rounded-lg border p-3">
                <div className="pr-3">
                  <Label className="text-sm font-normal">{row.label}</Label>
                  <p className="text-[11px] text-muted-foreground/80">{row.desc}</p>
                </div>
                <Switch
                  checked={editor[row.key]}
                  onCheckedChange={(v) => {
                    updateEditor({ [row.key]: v });
                    if (row.key === "layers") useEditorStore.getState().setLayersOpen(v);
                  }}
                  aria-label={row.label}
                />
              </div>
            ))}
          </section>

          {/* Confort de la toile */}
          <section className="space-y-3" aria-labelledby="ced-canvas">
            <h3 id="ced-canvas" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Toile
            </h3>
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">Rail d&apos;outils</span>
              <Segmented<ToolbarDensity>
                value={editor.toolbar}
                onChange={(v) => updateEditor({ toolbar: v })}
                options={[
                  { value: "confortable", label: "Confortable" },
                  { value: "compacte", label: "Compact" },
                ]}
                ariaLabel="Densité du rail d'outils"
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">Toile de fond</span>
              <Segmented<EditorBackdrop>
                value={editor.backdrop}
                onChange={(v) => updateEditor({ backdrop: v })}
                options={EDITOR_BACKDROPS.map((b) => ({ value: b.id, label: b.label }))}
                ariaLabel="Toile de fond de la zone d'édition"
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">Espacement des pages</span>
              <Segmented<PageGap>
                value={editor.pageGap}
                onChange={(v) => updateEditor({ pageGap: v })}
                options={[
                  { value: "normal", label: "Normal" },
                  { value: "aeree", label: "Aéré" },
                ]}
                ariaLabel="Espacement des pages"
              />
            </div>
          </section>

          {/* Ambiance globale */}
          <section className="space-y-3" aria-labelledby="ced-ambiance">
            <h3 id="ced-ambiance" className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Ambiance
            </h3>
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">Thème de l&apos;interface</span>
              <Segmented<string>
                value={theme ?? "light"}
                onChange={(v) => setTheme(v)}
                options={[
                  { value: "light", label: "Clair", title: "Thème clair" },
                  { value: "dark", label: "Sombre", title: "Thème sombre" },
                  { value: "system", label: "Système", title: "Suivre le système" },
                ]}
                ariaLabel="Thème de l'interface"
              />
            </div>
            <div className="space-y-2">
              <span className="text-sm">Couleur d&apos;accent</span>
              <AccentPickerInline />
            </div>
          </section>

          <div className="flex items-center justify-between gap-3 pt-1 border-t">
            <p className="text-[11px] text-muted-foreground/80">Réglages enregistrés sur cet appareil.</p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                resetEditor();
                toast.success("Éditeur réinitialisé");
              }}
            >
              <RotateCcw className="size-3.5 mr-1.5" aria-hidden />
              Réinitialiser
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Miniature schématique d'une disposition (représentation honnête des panneaux). */
function PresetGlyph({ preset, active }: { preset: "studio" | "focus" | "minimal"; active: boolean }) {
  const panel = active ? "bg-primary/70" : "bg-muted-foreground/45";
  const page = active ? "bg-primary/25" : "bg-muted-foreground/20";
  return (
    <span className="mt-2 flex gap-1 h-8 rounded-md border bg-background p-1" aria-hidden>
      {preset === "studio" && <span className={cn("w-2 rounded-sm", panel)} />}
      {preset === "focus" && <span className={cn("w-2 rounded-sm", panel)} />}
      <span className="flex-1 flex flex-col items-center justify-center gap-1">
        <span className={cn("w-5 h-4 rounded-sm", page)} />
        <span className={cn("w-3.5 h-3 rounded-sm", page)} />
      </span>
      {preset === "studio" && <span className={cn("w-2 rounded-sm", panel)} />}
      {preset === "minimal" && <span className="w-0" />}
    </span>
  );
}

/** Boutons de thème réutilisables (icônes seules). */
export function ThemeIconChoice() {
  const { theme, setTheme } = useTheme();
  const options = [
    { value: "light", label: "Clair", icon: Sun },
    { value: "dark", label: "Sombre", icon: Moon },
    { value: "system", label: "Système", icon: Monitor },
  ] as const;
  return (
    <div className="flex items-center gap-1" role="radiogroup" aria-label="Thème">
      {options.map((o) => (
        <Button
          key={o.value}
          variant={theme === o.value ? "secondary" : "ghost"}
          size="icon"
          className="size-8"
          onClick={() => setTheme(o.value)}
          aria-label={`Thème ${o.label}`}
          aria-checked={theme === o.value}
          role="radio"
        >
          <o.icon className="size-4" aria-hidden />
        </Button>
      ))}
    </div>
  );
}
