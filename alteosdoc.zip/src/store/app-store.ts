"use client";

/**
 * AlteOS Docs — État applicatif global
 * Navigation, bibliothèque de documents, création et import.
 */

import { create } from "zustand";

import { getAllDocs, getDoc, putDoc, getPref, storageEstimate } from "@/lib/idb";
import { DEFAULT_DOC_SETTINGS, uid, type AlteosDoc, type Block, type DocKind, type DocSummary, type PageRef } from "@/lib/types";

export type View = "home" | "create" | "documents" | "templates" | "assist" | "settings" | "editor";

export interface ImportResult {
  ok: boolean;
  docId?: string;
  error?: "invalid" | "unsupported" | "corrupted";
  message?: string;
}

interface AppState {
  view: View;
  docs: DocSummary[];
  loading: boolean;
  editingDocId: string | null;
  storageUsage: number | null;

  setView: (v: View) => void;
  refreshDocs: () => Promise<void>;
  refreshStorage: () => Promise<void>;

  openDoc: (id: string) => Promise<boolean>;
  closeEditor: () => void;

  createDoc: (kind: DocKind, opts?: { name?: string; blocks?: Block[]; templateId?: string }) => Promise<string>;
  importFile: (file: File) => Promise<ImportResult>;

  toggleFavorite: (id: string) => Promise<void>;
  renameDoc: (id: string, name: string) => Promise<void>;
  trashDoc: (id: string) => Promise<void>;
  restoreDoc: (id: string) => Promise<void>;
  deleteForever: (id: string) => Promise<void>;
  touchDoc: (id: string) => Promise<void>;
  /** Copie complète d'un document (contenu, éléments, PDF, vignette) avec nouveaux ids. */
  duplicateDoc: (id: string) => Promise<string | null>;
}

function emptyDoc(kind: DocKind, name: string, blocks: Block[]): AlteosDoc {
  const now = Date.now();
  return {
    id: uid(),
    name,
    kind,
    createdAt: now,
    updatedAt: now,
    openedAt: now,
    favorite: false,
    deletedAt: null,
    thumb: null,
    pdfBytes: null,
    pages: [],
    designPages: kind === "design" ? [{ id: `pg-${uid()}`, w: 595.28, h: 841.89, background: "#FFFFFF" }] : [],
    items: [],
    blocks,
    formValues: {},
    settings: { ...DEFAULT_DOC_SETTINGS },
    srcPageSizes: [],
  };
}

const DEFAULT_NAMES: Record<DocKind, string> = {
  document: "Document sans titre",
  pdf: "PDF importé",
  design: "Design sans titre",
  form: "Formulaire sans titre",
};

export const useAppStore = create<AppState>((set, get) => ({
  view: "home",
  docs: [],
  loading: true,
  editingDocId: null,
  storageUsage: null,

  setView: (v) => set({ view: v }),

  refreshDocs: async () => {
    const docs = await getAllDocs();
    const summaries: DocSummary[] = docs.map((d) => ({
      id: d.id,
      name: d.name,
      kind: d.kind,
      createdAt: d.createdAt,
      updatedAt: d.updatedAt,
      openedAt: d.openedAt,
      favorite: d.favorite,
      deletedAt: d.deletedAt ?? null,
      pageCount: d.kind === "pdf" ? d.pages.length : d.kind === "design" ? d.designPages.length : 1,
    }));
    set({ docs: summaries });
  },

  refreshStorage: async () => {
    const est = await storageEstimate();
    set({ storageUsage: est ? est.usage : null });
  },

  openDoc: async (id) => {
    const doc = await getDoc(id);
    if (!doc) return false;
    doc.openedAt = Date.now();
    await putDoc(doc);
    set({ view: "editor", editingDocId: id });
    await get().refreshDocs();
    return true;
  },

  closeEditor: () => set({ view: "documents", editingDocId: null }),

  createDoc: async (kind, opts) => {
    let blocks: Block[] = [];
    if (opts?.blocks && opts.blocks.length) {
      blocks = opts.blocks;
    } else if (kind === "document") {
      blocks = [
        { id: uid(), type: "title", text: opts?.name ?? "Document sans titre" },
        { id: uid(), type: "paragraph", html: "" },
      ];
    } else if (kind === "form") {
      blocks = [
        { id: uid(), type: "title", text: opts?.name ?? "Formulaire sans titre" },
        { id: uid(), type: "paragraph", html: "<p>Renseignez les champs ci-dessous.</p>" },
        { id: uid(), type: "field", fieldType: "text", label: "Nom complet", required: true },
        { id: uid(), type: "field", fieldType: "text", label: "Adresse e-mail", required: false },
        { id: uid(), type: "field", fieldType: "date", label: "Date", required: false },
        { id: uid(), type: "field", fieldType: "multiline", label: "Message", required: false },
        { id: uid(), type: "field", fieldType: "checkbox", label: "J'accepte d'être contacté·e par e-mail", required: false },
      ];
    }
    const doc = emptyDoc(kind, opts?.name ?? DEFAULT_NAMES[kind], blocks);
    if (opts?.templateId) doc.templateOf = opts.templateId;
    // Police par défaut choisie dans les Paramètres (préférence locale)
    if (kind === "document" || kind === "form") {
      const baseFont = await getPref<string>("defaultFont");
      if (baseFont) doc.settings = { ...doc.settings, baseFont };
    }
    await putDoc(doc);
    await get().refreshDocs();
    set({ view: "editor", editingDocId: doc.id });
    return doc.id;
  },

  importFile: async (file) => {
    const lower = file.name.toLowerCase();
    try {
      if (lower.endsWith(".pdf") || file.type === "application/pdf") {
        return await importPdf(file, get, set);
      }
      if (file.type.startsWith("image/")) {
        return await importImage(file, get, set);
      }
      if (lower.endsWith(".txt") || lower.endsWith(".md")) {
        return await importText(file, get, set);
      }
      return { ok: false, error: "unsupported", message: "Ce format n'est pas encore pris en charge." };
    } catch {
      return { ok: false, error: "corrupted", message: "Le fichier semble endommagé ou illisible." };
    }
  },

  toggleFavorite: async (id) => {
    const doc = await getDoc(id);
    if (!doc) return;
    doc.favorite = !doc.favorite;
    doc.updatedAt = Date.now();
    await putDoc(doc);
    await get().refreshDocs();
  },

  renameDoc: async (id, name) => {
    const doc = await getDoc(id);
    if (!doc) return;
    doc.name = name.trim() || "Sans titre";
    doc.updatedAt = Date.now();
    await putDoc(doc);
    await get().refreshDocs();
  },

  trashDoc: async (id) => {
    const doc = await getDoc(id);
    if (!doc) return;
    doc.deletedAt = Date.now();
    await putDoc(doc);
    await get().refreshDocs();
  },

  restoreDoc: async (id) => {
    const doc = await getDoc(id);
    if (!doc) return;
    doc.deletedAt = null;
    await putDoc(doc);
    await get().refreshDocs();
  },

  deleteForever: async (id) => {
    const { deleteDocForever } = await import("@/lib/idb");
    await deleteDocForever(id);
    await get().refreshDocs();
    await get().refreshStorage();
  },

  touchDoc: async (id) => {
    const doc = await getDoc(id);
    if (!doc) return;
    doc.updatedAt = Date.now();
    await putDoc(doc);
    await get().refreshDocs();
  },

  duplicateDoc: async (id) => {
    const src = await getDoc(id);
    if (!src) return null;
    const { listAssets, getAsset, putAsset } = await import("@/lib/idb");
    const assets = await listAssets();
    const assetIdSet = new Set(assets.map((a) => a.id));
    // Collecte les assets réellement référencés, puis duplique chacun.
    const used = new Set<string>();
    for (const it of src.items) if ("assetId" in it && it.assetId) used.add(it.assetId);
    for (const b of src.blocks) if (b.type === "image" && b.assetId) used.add(b.assetId);
    const remap = new Map<string, string>();
    for (const oldId of used) {
      if (assetIdSet.has(oldId)) remap.set(oldId, uid());
    }
    for (const [oldId, newId] of remap) {
      const asset = await getAsset(oldId);
      if (asset) await putAsset({ id: newId, blob: asset.blob, mime: asset.mime, createdAt: Date.now() });
    }
    const remapAsset = (oldId: string): string => remap.get(oldId) ?? oldId;
    const items = src.items.map((it) => {
      const copy = JSON.parse(JSON.stringify(it)) as typeof it;
      copy.id = uid();
      if ("assetId" in copy) copy.assetId = remapAsset(copy.assetId);
      return copy;
    });
    const blocks = src.blocks.map((b) => {
      const copy = JSON.parse(JSON.stringify(b)) as typeof b;
      copy.id = uid();
      if (copy.type === "image") copy.assetId = remapAsset(copy.assetId);
      return copy;
    });
    const pages = src.pages.map((p) => ({ ...p, id: `pg-${uid()}` }));
    const designPages = src.designPages.map((p) => ({ ...p, id: `pg-${uid()}` }));
    const pageIdMap = new Map<string, string>();
    src.pages.forEach((p, i) => pageIdMap.set(p.id, pages[i].id));
    src.designPages.forEach((p, i) => pageIdMap.set(p.id, designPages[i].id));
    const mappedItems = items.map((it) => ({ ...it, pageId: pageIdMap.get(it.pageId) ?? it.pageId }));
    const now = Date.now();
    const copyDoc: AlteosDoc = {
      ...src,
      id: uid(),
      name: `${src.name.replace(/ \(copie( \d+)?\)$/i, "")} (copie)`,
      createdAt: now,
      updatedAt: now,
      openedAt: now,
      favorite: false,
      deletedAt: null,
      thumb: src.thumb,
      pdfBytes: src.pdfBytes ? src.pdfBytes.slice(0) : null,
      pages,
      designPages,
      items: mappedItems,
      blocks,
      formValues: {},
      templateOf: src.templateOf,
    };
    await putDoc(copyDoc);
    await get().refreshDocs();
    await get().refreshStorage();
    return copyDoc.id;
  },
}));

// ---------------------------------------------------------------------------
// Importeurs (locaux : aucun octet ne quitte l'appareil)
// ---------------------------------------------------------------------------

async function importPdf(file: File, get: () => AppState, set: (partial: Partial<AppState>) => void): Promise<ImportResult> {
  const bytes = await file.arrayBuffer();
  if (bytes.byteLength === 0) return { ok: false, error: "invalid", message: "Ce fichier est vide." };

  const { loadPdfDocument, renderThumb } = await import("@/lib/pdf/engine");
  let loaded;
  try {
    loaded = await loadPdfDocument(bytes);
  } catch {
    return { ok: false, error: "corrupted", message: "Le fichier semble endommagé ou son format n'est pas encore pris en charge." };
  }
  if (loaded.doc.numPages === 0) {
    return { ok: false, error: "invalid", message: "Ce PDF ne contient aucune page." };
  }

  const pages: PageRef[] = [];
  for (let i = 0; i < loaded.doc.numPages; i++) {
    pages.push({ id: `pg-${uid()}`, src: i, rotation: 0 });
  }

  let thumb: Blob | null = null;
  try {
    const t = await renderThumb(loaded.doc, 0, 240, 0);
    thumb = t.blob;
  } catch {
    thumb = null;
  }

  const doc = emptyDoc("pdf", file.name.replace(/\.pdf$/i, ""), []);
  doc.pdfBytes = bytes;
  doc.pages = pages;
  doc.srcPageSizes = loaded.pageSizes;
  doc.thumb = thumb;
  await putDoc(doc);
  await get().refreshDocs();
  await get().refreshStorage();
  set({ view: "editor", editingDocId: doc.id });
  return { ok: true, docId: doc.id };
}

async function importImage(file: File, get: () => AppState, set: (partial: Partial<AppState>) => void): Promise<ImportResult> {
  const blob = file.slice(0, file.size, file.type);
  if (!/image\/(png|jpeg|jpg|webp)/.test(file.type)) {
    // Conversion webp → png pour l'export PDF (canvas local)
    // Les formats exotiques sont refusés proprement.
  }
  const assetId = uid();
  const { putAsset } = await import("@/lib/idb");
  await putAsset({ id: assetId, blob, mime: file.type, createdAt: Date.now() });

  // Dimensions pour placer l'image à taille réelle sur un canevas A4
  const dims = await new Promise<{ w: number; h: number }>((resolve) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      resolve({ w: img.naturalWidth, h: img.naturalHeight });
      URL.revokeObjectURL(url);
    };
    img.onerror = () => {
      resolve({ w: 400, h: 300 });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  });

  const doc = emptyDoc("design", file.name.replace(/\.[a-z0-9]+$/i, ""), []);
  const pageId = doc.designPages[0].id;
  // Point → pixel : 1 pt = 1.333 px ; on place l'image à 72 dpi réelle
  const wPt = Math.min(dims.w * 0.75, 595.28 - 80);
  const hPt = wPt * (dims.h / dims.w);
  doc.items = [
    {
      id: uid(),
      pageId,
      createdAt: Date.now(),
      type: "image",
      x: (595.28 - wPt) / 2,
      y: 120,
      w: wPt,
      h: hPt,
      assetId,
      rotation: 0,
      opacity: 1,
    },
  ];
  await putDoc(doc);
  await get().refreshDocs();
  set({ view: "editor", editingDocId: doc.id });
  return { ok: true, docId: doc.id };
}

async function importText(file: File, get: () => AppState, set: (partial: Partial<AppState>) => void): Promise<ImportResult> {
  const text = await file.text();
  const lines = text.split(/\r?\n/);
  const blocks: Block[] = [{ id: uid(), type: "title", text: file.name.replace(/\.(txt|md)$/i, "") }];
  const paragraphIds: string[] = [];
  for (const line of lines) {
    if (line.trim() === "") continue;
    const id = uid();
    paragraphIds.push(id);
    const escaped = line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    blocks.push({ id, type: "paragraph", html: `<p>${escaped}</p>` });
  }
  if (paragraphIds.length === 0) {
    blocks.push({ id: uid(), type: "paragraph", html: "" });
  }
  const doc = emptyDoc("document", file.name.replace(/\.(txt|md)$/i, ""), blocks);
  await putDoc(doc);
  await get().refreshDocs();
  set({ view: "editor", editingDocId: doc.id });
  return { ok: true, docId: doc.id };
}
