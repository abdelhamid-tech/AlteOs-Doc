"use client";

/**
 * AlteOS Docs — Préférences d'interface (personnalisation).
 * -----------------------------------------------------------------
 * Accent signature, densité, personnalisation de la page d'accueil
 * et de la page d'édition. Persisté dans IndexedDB (prefs) avec un
 * miroir localStorage pour appliquer l'accent avant le premier rendu.
 * Aucune donnée ne quitte l'appareil.
 */

import { create } from "zustand";
import { getPref, setPref } from "@/lib/idb";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type AccentId = "corail" | "ambre" | "jade" | "prune" | "rose" | "olive";
export type Density = "confortable" | "compacte";

export type HomeWidgetId = "actions" | "recents" | "favorites" | "stats" | "fonts" | "features" | "space";
export type HomeBackground = "papier" | "grille" | "halo" | "aucun";
export type HeroSize = "grand" | "compact";

export interface HomePrefs {
  /** Prénom affiché dans la salutation (« » = salutation générique). */
  displayName: string;
  /** Phrase d'accroche personnalisée (« » = phrase par défaut). */
  tagline: string;
  heroSize: HeroSize;
  background: HomeBackground;
  /** Widgets visibles et leur ordre d'affichage. */
  widgets: { id: HomeWidgetId; visible: boolean }[];
  /** Nombre de documents dans « Reprendre ». */
  recentsCount: number;
}

export type EditorBackdrop = "gris" | "encre" | "nuit" | "damier";
export type ToolbarDensity = "confortable" | "compacte";
export type EditorPreset = "studio" | "focus" | "minimal";
export type PageGap = "normal" | "aeree";

export interface EditorPrefs {
  preset: EditorPreset;
  /** Panneau des vignettes de pages (gauche). */
  thumbs: boolean;
  /** Panneau Calques (droite). */
  layers: boolean;
  /** Barre d'état en bas de l'éditeur. */
  statusBar: boolean;
  /** Densité du rail d'outils. */
  toolbar: ToolbarDensity;
  /** Toile de fond derrière les pages. */
  backdrop: EditorBackdrop;
  /** Espacement vertical entre les pages. */
  pageGap: PageGap;
}

export interface UiPrefs {
  accent: AccentId;
  density: Density;
  home: HomePrefs;
  editor: EditorPrefs;
}

// ---------------------------------------------------------------------------
// Catalogues (libellés et pastilles pour l'interface de personnalisation)
// ---------------------------------------------------------------------------

export const ACCENTS: { id: AccentId; label: string; swatch: string }[] = [
  { id: "corail", label: "Corail", swatch: "#DF5C3F" },
  { id: "ambre", label: "Ambre", swatch: "#D3A049" },
  { id: "jade", label: "Jade", swatch: "#14907A" },
  { id: "prune", label: "Prune", swatch: "#AC4E96" },
  { id: "rose", label: "Rose", swatch: "#DC5876" },
  { id: "olive", label: "Olive", swatch: "#7A8531" },
];

export const HOME_WIDGETS: { id: HomeWidgetId; label: string; desc: string }[] = [
  { id: "actions", label: "Créer", desc: "Les cinq actions : Document, PDF, Design, Formulaire, Importer." },
  { id: "recents", label: "Reprendre", desc: "Vos documents récemment ouverts." },
  { id: "favorites", label: "Favoris", desc: "Vos documents épinglés d'un coup d'œil." },
  { id: "stats", label: "Votre espace en chiffres", desc: "Documents, pages, favoris et espace utilisé." },
  { id: "fonts", label: "Typothèque", desc: "Un aperçu des 153 polices intégrées." },
  { id: "features", label: "Tout ce que fait AlteOS Docs", desc: "La liste des fonctions réelles, exécutées sur cet appareil." },
  { id: "space", label: "Votre espace", desc: "Accès rapides : Récents, Documents, Favoris, Corbeille." },
];

export const HOME_BACKGROUNDS: { id: HomeBackground; label: string }[] = [
  { id: "papier", label: "Papier" },
  { id: "grille", label: "Grille" },
  { id: "halo", label: "Halo" },
  { id: "aucun", label: "Aucun" },
];

export const EDITOR_BACKDROPS: { id: EditorBackdrop; label: string }[] = [
  { id: "gris", label: "Gris" },
  { id: "encre", label: "Encre" },
  { id: "nuit", label: "Nuit" },
  { id: "damier", label: "Damier" },
];

export const EDITOR_PRESETS: { id: EditorPreset; label: string; desc: string }[] = [
  { id: "studio", label: "Studio", desc: "Panneaux pages et calques, barre d'état — l'atelier complet." },
  { id: "focus", label: "Focus", desc: "Pages visibles, calques et barre d'état masqués — concentré sur le contenu." },
  { id: "minimal", label: "Minimal", desc: "Aucun panneau — la page et vous." },
];

// ---------------------------------------------------------------------------
// Valeurs par défaut
// ---------------------------------------------------------------------------

export const DEFAULT_HOME_PREFS: HomePrefs = {
  displayName: "",
  tagline: "",
  heroSize: "grand",
  background: "papier",
  widgets: [
    { id: "actions", visible: true },
    { id: "recents", visible: true },
    { id: "favorites", visible: true },
    { id: "stats", visible: true },
    { id: "fonts", visible: true },
    { id: "features", visible: true },
    { id: "space", visible: true },
  ],
  recentsCount: 4,
};

export const DEFAULT_EDITOR_PREFS: EditorPrefs = {
  preset: "studio",
  thumbs: true,
  layers: true,
  statusBar: true,
  toolbar: "confortable",
  backdrop: "gris",
  pageGap: "normal",
};

const DEFAULT_PREFS: UiPrefs = {
  accent: "corail",
  density: "confortable",
  home: DEFAULT_HOME_PREFS,
  editor: DEFAULT_EDITOR_PREFS,
};

// ---------------------------------------------------------------------------
// Magasin
// ---------------------------------------------------------------------------

interface UiPrefsState extends UiPrefs {
  ready: boolean;
  /** Volets de personnalisation ouverts (état d'interface, non persisté). */
  homeCustomOpen: boolean;
  editorCustomOpen: boolean;

  hydrate: () => Promise<void>;
  setAccent: (accent: AccentId) => void;
  setDensity: (density: Density) => void;

  updateHome: (partial: Partial<HomePrefs>) => void;
  toggleHomeWidget: (id: HomeWidgetId) => void;
  moveHomeWidget: (id: HomeWidgetId, dir: -1 | 1) => void;
  resetHome: () => void;

  updateEditor: (partial: Partial<EditorPrefs>) => void;
  applyEditorPreset: (preset: EditorPreset) => void;
  resetEditor: () => void;

  setHomeCustomOpen: (open: boolean) => void;
  setEditorCustomOpen: (open: boolean) => void;
}

/** Miroir localStorage : applique l'accent/densité avant le premier rendu. */
const LS_KEY = "alteos.ui";

function persist(state: UiPrefsState) {
  const prefs: UiPrefs = {
    accent: state.accent,
    density: state.density,
    home: state.home,
    editor: state.editor,
  };
  void setPref("uiPrefs", prefs).catch(() => undefined);
  try {
    localStorage.setItem(LS_KEY, JSON.stringify({ accent: prefs.accent, density: prefs.density }));
  } catch {
    /* stockage indisponible : l'accent reste appliqué pour cette session */
  }
}

/** Fusionne des préférences stockées avec les valeurs par défaut (robustesse). */
function mergePrefs(stored: Partial<UiPrefs> | undefined): UiPrefs {
  if (!stored) return structuredClone(DEFAULT_PREFS);
  const storedAccent = stored.accent;
  const accent: AccentId =
    storedAccent && ACCENTS.some((a) => a.id === storedAccent) ? storedAccent : DEFAULT_PREFS.accent;
  return {
    accent,
    density: stored.density === "compacte" ? "compacte" : "confortable",
    home: {
      ...DEFAULT_PREFS.home,
      ...(stored.home ?? {}),
      widgets: normalizeWidgets(stored.home?.widgets),
    },
    editor: { ...DEFAULT_PREFS.editor, ...(stored.editor ?? {}) },
  };
}

function normalizeWidgets(widgets: HomePrefs["widgets"] | undefined): HomePrefs["widgets"] {
  const known = new Set(widgets?.filter((w) => HOME_WIDGETS.some((d) => d.id === w.id)).map((w) => w.id) ?? []);
  // Ordre : celui de l'utilisateur d'abord (items connus), puis les nouveaux widgets ajoutés par les versions futures.
  const ordered = (widgets ?? []).filter((w) => known.has(w.id));
  const missing = DEFAULT_HOME_PREFS.widgets.filter((w) => !known.has(w.id)).map((w) => ({ ...w }));
  return [...ordered, ...missing];
}

export const useUiPrefs = create<UiPrefsState>((set, get) => ({
  ...structuredClone(DEFAULT_PREFS),
  ready: false,
  homeCustomOpen: false,
  editorCustomOpen: false,

  hydrate: async () => {
    if (get().ready) return;
    try {
      const stored = await getPref<Partial<UiPrefs>>("uiPrefs");
      const merged = mergePrefs(stored);
      set({ ...merged, ready: true });
    } catch {
      set({ ready: true });
    }
  },

  setAccent: (accent) => {
    set({ accent });
    persist(get());
  },

  setDensity: (density) => {
    set({ density });
    persist(get());
  },

  updateHome: (partial) => {
    set({ home: { ...get().home, ...partial } });
    persist(get());
  },

  toggleHomeWidget: (id) => {
    set({
      home: {
        ...get().home,
        widgets: get().home.widgets.map((w) => (w.id === id ? { ...w, visible: !w.visible } : w)),
      },
    });
    persist(get());
  },

  moveHomeWidget: (id, dir) => {
    const widgets = [...get().home.widgets];
    const idx = widgets.findIndex((w) => w.id === id);
    const target = idx + dir;
    if (idx < 0 || target < 0 || target >= widgets.length) return;
    const [item] = widgets.splice(idx, 1);
    widgets.splice(target, 0, item);
    set({ home: { ...get().home, widgets } });
    persist(get());
  },

  resetHome: () => {
    set({ home: structuredClone(DEFAULT_HOME_PREFS) });
    persist(get());
  },

  updateEditor: (partial) => {
    set({ editor: { ...get().editor, ...partial } });
    persist(get());
  },

  applyEditorPreset: (preset) => {
    const table: Record<EditorPreset, Partial<EditorPrefs>> = {
      studio: { thumbs: true, layers: true, statusBar: true },
      focus: { thumbs: true, layers: false, statusBar: false },
      minimal: { thumbs: false, layers: false, statusBar: false },
    };
    set({ editor: { ...get().editor, ...table[preset], preset } });
    persist(get());
  },

  resetEditor: () => {
    set({ editor: structuredClone(DEFAULT_EDITOR_PREFS) });
    persist(get());
  },

  setHomeCustomOpen: (open) => set({ homeCustomOpen: open }),
  setEditorCustomOpen: (open) => set({ editorCustomOpen: open }),
}));

/** Classe CSS de toile de fond pour la zone d'édition. */
export function editorBackdropClass(backdrop: EditorBackdrop): string {
  return `aos-backdrop-${backdrop}`;
}

/** Classe CSS de fond pour la page d'accueil. */
export function homeBackgroundClass(background: HomeBackground): string {
  return `aos-home-${background}`;
}
