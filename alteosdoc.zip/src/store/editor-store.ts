"use client";

/**
 * AlteOS Docs — État de l'AlteOS Editor
 * Documents PDF, Design, Document et Formulaire.
 * Historique annuler/rétablir limité aux opérations structurelles.
 */

import { create } from "zustand";

import { putDoc } from "@/lib/idb";
import {
  DEFAULT_DOC_SETTINGS,
  PAGE_PRESETS,
  uid,
  type AlteosDoc,
  type Block,
  type DesignPage,
  type DocSettings,
  type Item,
  type PageRef,
  type Tool,
} from "@/lib/types";
import type { PDFDocumentProxy } from "pdfjs-dist";

interface Snapshot {
  items: Item[];
  pages: PageRef[];
  blocks: Block[];
}

interface EditorState {
  doc: AlteosDoc | null;
  pdfDoc: PDFDocumentProxy | null;
  dirty: boolean;
  saving: boolean;
  savedAt: number | null;

  tool: Tool;
  color: string;
  highlightColor: string;
  strokeWidth: number;
  /** Défauts de l'outil Texte (police, taille, style) — nouveaux éléments. */
  textFont: string;
  textSize: number;
  textBold: boolean;
  textItalic: boolean;

  zoom: number;
  currentPageIndex: number;
  selectedItemId: string | null;
  selectedPageIds: string[];
  /** Sélection multiple d'éléments (PDF / Design). selectedItemId reste le pivot. */
  selectedIds: string[];
  /** Presse-papiers interne d'éléments (copier / coller entre pages). */
  clipboard: Item[];
  /** Panneau Calques ouvert. */
  layersOpen: boolean;
  /** Magnétisme des guides d'alignement pendant le déplacement. */
  snapEnabled: boolean;

  past: Snapshot[];
  future: Snapshot[];

  load: (doc: AlteosDoc, pdfDoc: PDFDocumentProxy | null) => void;
  reset: () => void;
  save: () => Promise<void>;

  setTool: (t: Tool) => void;
  setColor: (c: string) => void;
  setHighlightColor: (c: string) => void;
  setStrokeWidth: (w: number) => void;
  setTextFont: (f: string) => void;
  setTextSize: (s: number) => void;
  setTextBold: (b: boolean) => void;
  setTextItalic: (i: boolean) => void;
  setZoom: (z: number) => void;
  setCurrentPageIndex: (i: number) => void;
  setSelectedItemId: (id: string | null) => void;
  setSelectedPageIds: (ids: string[]) => void;
  toggleSelectedPage: (id: string) => void;
  setSelectedIds: (ids: string[]) => void;
  toggleSelectedId: (id: string) => void;
  setLayersOpen: (v: boolean) => void;
  setSnapEnabled: (v: boolean) => void;

  setPdfDoc: (d: PDFDocumentProxy | null) => void;
  setDocBytes: (bytes: ArrayBuffer, pageSizes: { w: number; h: number }[]) => Promise<PageRef[]>;
  setThumb: (blob: Blob | null) => void;

  addItems: (items: Item[]) => void;
  updateItem: (id: string, patch: Partial<Item> | ((it: Item) => Partial<Item>)) => void;
  /** Mise à jour multiple d'éléments (déplacement de groupe, alignements). */
  updateItems: (ids: string[], patch: Partial<Item> | ((it: Item) => Partial<Item>)) => void;
  /** Page courante (PDF ou Design) — cible du collage presse-papiers. */
  currentPagePageId: () => string | null;
  deleteItem: (id: string) => void;
  deleteSelected: () => void;
  deleteItems: (ids: string[]) => void;

  /** Duplique les éléments sélectionnés (décalage de 12 pt) ou les ids fournis. */
  duplicateItems: (ids?: string[]) => void;
  copySelection: () => void;
  pasteClipboard: (pageId?: string) => void;

  /** Ordre d'empilement (PDF / Design). */
  bringToFront: (ids: string[]) => void;
  sendToBack: (ids: string[]) => void;
  moveUp: (ids: string[]) => void;
  moveDown: (ids: string[]) => void;

  /** Alignement / répartition de la sélection multiple. */
  alignSelection: (mode: "left" | "hcenter" | "right" | "top" | "vmiddle" | "bottom") => void;
  distributeSelection: (axis: "h" | "v") => void;

  /** Calques : visibilité / verrou. */
  setItemHidden: (id: string, hidden: boolean) => void;
  setItemLocked: (id: string, locked: boolean) => void;

  /** Déplacement au clavier de la sélection (flèches ; Maj = pas large). */
  nudgeSelection: (dx: number, dy: number) => void;

  /** Signet de page PDF (navigation rapide). */
  togglePageBookmark: (pageId: string) => void;

  /** Blocs Checklist : opérations sur les entrées. */
  addChecklistEntry: (blockId: string, text: string) => void;
  updateChecklistEntry: (blockId: string, entryId: string, patch: { text?: string; done?: boolean }) => void;
  removeChecklistEntry: (blockId: string, entryId: string) => void;
  moveChecklistEntry: (blockId: string, from: number, to: number) => void;

  /** Restaure un instantané (historique de versions). */
  applyVersionSnapshot: (snap: {
    name: string;
    blocks: Block[];
    items: Item[];
    pages: PageRef[];
    designPages: DesignPage[];
    formValues: Record<string, string | boolean>;
    settings: DocSettings;
  }) => void;

  duplicatePage: (pageId: string) => void;
  deletePages: (pageIds: string[]) => void;
  movePage: (from: number, to: number) => void;
  rotatePages: (pageIds: string[], delta: number) => void;

  /** Pages Design : ajout, duplication, suppression, format, fond. */
  addDesignPage: () => void;
  duplicateDesignPage: (pageId: string) => void;
  deleteDesignPage: (pageId: string) => void;
  updateDesignPage: (pageId: string, patch: Partial<DesignPage>) => void;
  applyDesignPreset: (pageId: string, presetId: string) => void;

  setName: (name: string) => void;
  updateSettings: (patch: Partial<DocSettings>) => void;

  insertBlock: (index: number, block: Block) => void;
  updateBlock: (id: string, patch: Partial<Block> | ((b: Block) => Partial<Block>)) => void;
  removeBlock: (id: string) => void;
  moveBlock: (from: number, to: number) => void;
  setFormValue: (fieldId: string, value: string | boolean) => void;

  /** Pose un point d'annulation (avant une manipulation continue : glisser, redimensionner). */
  pushHistory: () => void;

  undo: () => void;
  redo: () => void;
}

function snapshot(doc: AlteosDoc): Snapshot {
  return {
    items: JSON.parse(JSON.stringify(doc.items)),
    pages: JSON.parse(JSON.stringify(doc.pages)),
    blocks: JSON.parse(JSON.stringify(doc.blocks)),
  };
}

function applySnapshot(doc: AlteosDoc, s: Snapshot): AlteosDoc {
  return { ...doc, items: s.items, pages: s.pages, blocks: s.blocks };
}

const MAX_HISTORY = 40;

export const useEditorStore = create<EditorState>((set, get) => ({
  doc: null,
  pdfDoc: null,
  dirty: false,
  saving: false,
  savedAt: null,

  tool: "select",
  color: "#1C1B1A",
  highlightColor: "#F5D90A",
  strokeWidth: 2,
  textFont: "Helvetica",
  textSize: 12,
  textBold: false,
  textItalic: false,

  zoom: 1,
  currentPageIndex: 0,
  selectedItemId: null,
  selectedPageIds: [],
  selectedIds: [],
  clipboard: [],
  layersOpen: false,
  snapEnabled: true,

  past: [],
  future: [],

  load: (doc, pdfDoc) => {
    set({
      doc,
      pdfDoc,
      dirty: false,
      saving: false,
      savedAt: Date.now(),
      tool: "select",
      zoom: 1,
      currentPageIndex: 0,
      selectedItemId: null,
      selectedPageIds: [],
      selectedIds: [],
      past: [],
      future: [],
    });
  },

  reset: () => set({ doc: null, pdfDoc: null, dirty: false, past: [], future: [], selectedItemId: null, selectedPageIds: [], selectedIds: [], clipboard: [] }),

  save: async () => {
    const { doc, dirty } = get();
    if (!doc || !dirty) return;
    set({ saving: true });
    try {
      const toSave = { ...doc, updatedAt: Date.now() };
      await putDoc(toSave);
      set({ dirty: false, saving: false, savedAt: Date.now(), doc: toSave });
    } catch {
      set({ saving: false });
      throw new Error("L'enregistrement local a échoué.");
    }
  },

  setTool: (t) => set({ tool: t, selectedItemId: t === "select" ? get().selectedItemId : null, selectedIds: t === "select" ? get().selectedIds : [] }),
  setColor: (c) => set({ color: c }),
  setHighlightColor: (c) => set({ highlightColor: c }),
  setStrokeWidth: (w) => set({ strokeWidth: w }),
  setTextFont: (f) => set({ textFont: f }),
  setTextSize: (s) => set({ textSize: Math.max(6, Math.min(96, s)) }),
  setTextBold: (b) => set({ textBold: b }),
  setTextItalic: (i) => set({ textItalic: i }),
  setZoom: (z) => set({ zoom: Math.min(4, Math.max(0.25, z)) }),
  setCurrentPageIndex: (i) => set({ currentPageIndex: i }),
  setSelectedItemId: (id) => set({ selectedItemId: id }),
  setSelectedPageIds: (ids) => set({ selectedPageIds: ids }),
  toggleSelectedPage: (id) => {
    const cur = get().selectedPageIds;
    set({ selectedPageIds: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id] });
  },
  setSelectedIds: (ids) => set({ selectedIds: ids, selectedItemId: ids.length === 1 ? ids[0] : ids.length ? get().selectedItemId && ids.includes(get().selectedItemId!) ? get().selectedItemId : ids[0] : null }),
  toggleSelectedId: (id) => {
    const cur = get().selectedIds;
    const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
    set({ selectedIds: next, selectedItemId: next.length === 1 ? next[0] : next.length === 0 ? null : get().selectedItemId && next.includes(get().selectedItemId!) ? get().selectedItemId : next[0] });
  },
  setLayersOpen: (v) => set({ layersOpen: v }),
  setSnapEnabled: (v) => set({ snapEnabled: v }),

  setPdfDoc: (d) => set({ pdfDoc: d }),

  currentPagePageId: () => currentPageIdOf(get().doc, get().currentPageIndex),

  setDocBytes: async (bytes, pageSizes) => {
    const { doc } = get();
    if (!doc) return [];
    const newRefs: PageRef[] = [];
    for (let i = 0; i < pageSizes.length; i++) {
      newRefs.push({ id: `pg-${uid()}`, src: i, rotation: 0 });
    }
    set({
      doc: { ...doc, pdfBytes: bytes, srcPageSizes: pageSizes, pages: newRefs },
      dirty: true,
    });
    return newRefs;
  },

  setThumb: (blob) => {
    const { doc } = get();
    if (!doc) return;
    set({ doc: { ...doc, thumb: blob }, dirty: true });
  },

  // --- Éléments ----------------------------------------------------------

  addItems: (items) => {
    const { doc, past } = get();
    if (!doc) return;
    set({
      doc: { ...doc, items: [...doc.items, ...items] },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  updateItem: (id, patch) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        items: doc.items.map((it) => (it.id === id ? ({ ...it, ...(typeof patch === "function" ? patch(it) : patch) } as Item) : it)),
      },
      dirty: true,
    });
  },

  updateItems: (ids, patch) => {
    const { doc } = get();
    if (!doc) return;
    const idSet = new Set(ids);
    set({
      doc: {
        ...doc,
        items: doc.items.map((it) =>
          idSet.has(it.id) ? ({ ...it, ...(typeof patch === "function" ? patch(it) : patch) } as Item) : it
        ),
      },
      dirty: true,
    });
  },

  deleteItem: (id) => {
    const { doc, past } = get();
    if (!doc) return;
    set({
      doc: { ...doc, items: doc.items.filter((it) => it.id !== id) },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
      selectedItemId: get().selectedItemId === id ? null : get().selectedItemId,
      selectedIds: get().selectedIds.filter((x) => x !== id),
    });
  },

  deleteSelected: () => {
    const id = get().selectedItemId;
    if (id) get().deleteItem(id);
  },

  deleteItems: (ids) => {
    const { doc, past } = get();
    if (!doc || ids.length === 0) return;
    const idSet = new Set(ids);
    set({
      doc: { ...doc, items: doc.items.filter((it) => !idSet.has(it.id)) },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
      selectedItemId: null,
      selectedIds: [],
    });
  },

  duplicateItems: (ids) => {
    const { doc } = get();
    if (!doc) return;
    const target = ids ?? get().selectedIds;
    if (target.length === 0) return;
    const idSet = new Set(target);
    const copies: Item[] = [];
    for (const it of doc.items) {
      if (!idSet.has(it.id)) continue;
      const copy = JSON.parse(JSON.stringify(it)) as Item;
      copy.id = uid();
      copy.createdAt = Date.now();
      if ("x" in copy) copy.x += 14;
      if ("y" in copy) copy.y += 14;
      // Décale aussi l'extrémité des lignes / points des tracés.
      if ("x2" in (copy as object)) (copy as { x2: number }).x2 += 14;
      if ("y2" in (copy as object)) (copy as { y2: number }).y2 += 14;
      if ("points" in (copy as object)) {
        (copy as { points: { x: number; y: number }[] }).points = (copy as { points: { x: number; y: number }[] }).points.map((p) => ({ x: p.x + 14, y: p.y + 14 }));
      }
      if ("quads" in (copy as object)) {
        (copy as { quads: { x: number; y: number }[] }).quads = (copy as { quads: { x: number; y: number; w: number; h: number }[] }).quads.map((q) => ({ ...q, x: q.x + 14, y: q.y + 14 }));
      }
      copies.push(copy);
    }
    if (copies.length === 0) return;
    get().addItems(copies);
    set({ selectedIds: copies.map((c) => c.id), selectedItemId: copies[0].id });
  },

  copySelection: () => {
    const { doc, selectedIds } = get();
    if (!doc || selectedIds.length === 0) return;
    const idSet = new Set(selectedIds);
    set({ clipboard: JSON.parse(JSON.stringify(doc.items.filter((it) => idSet.has(it.id)))) });
  },

  pasteClipboard: (pageId) => {
    const { clipboard, doc } = get();
    if (!doc || clipboard.length === 0) return;
    const targetPage = pageId ?? get().currentPagePageId() ?? null;
    const copies: Item[] = clipboard.map((it) => {
      const copy = JSON.parse(JSON.stringify(it)) as Item;
      copy.id = uid();
      copy.createdAt = Date.now();
      if (targetPage) copy.pageId = targetPage;
      if ("x" in copy) copy.x += 18;
      if ("y" in copy) copy.y += 18;
      if ("x2" in (copy as object)) (copy as { x2: number }).x2 += 18;
      if ("y2" in (copy as object)) (copy as { y2: number }).y2 += 18;
      if ("points" in (copy as object)) {
        (copy as { points: { x: number; y: number }[] }).points = (copy as { points: { x: number; y: number }[] }).points.map((p) => ({ x: p.x + 18, y: p.y + 18 }));
      }
      if ("quads" in (copy as object)) {
        (copy as { quads: { x: number; y: number; w: number; h: number }[] }).quads = (copy as { quads: { x: number; y: number; w: number; h: number }[] }).quads.map((q) => ({ ...q, x: q.x + 18, y: q.y + 18 }));
      }
      return copy;
    });
    get().addItems(copies);
    set({ selectedIds: copies.map((c) => c.id), selectedItemId: copies[0].id });
  },

  bringToFront: (ids) => reorderItems(get, set, ids, "front"),
  sendToBack: (ids) => reorderItems(get, set, ids, "back"),
  moveUp: (ids) => reorderItems(get, set, ids, "up"),
  moveDown: (ids) => reorderItems(get, set, ids, "down"),

  alignSelection: (mode) => {
    const { doc, selectedIds } = get();
    if (!doc || selectedIds.length < 2) return;
    const sel = doc.items.filter((it) => selectedIds.includes(it.id) && it.pageId === doc.items.find((o) => o.id === selectedIds[0])?.pageId);
    if (sel.length < 2) return;
    const minX = Math.min(...sel.map((it) => it.x));
    const maxX = Math.max(...sel.map((it) => it.x + it.w));
    const minY = Math.min(...sel.map((it) => it.y));
    const maxY = Math.max(...sel.map((it) => it.y + it.h));
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    get().pushHistory();
    for (const it of sel) {
      const patch: Partial<Item> = {};
      if (mode === "left") patch.x = minX;
      if (mode === "right") patch.x = maxX - it.w;
      if (mode === "hcenter") patch.x = cx - it.w / 2;
      if (mode === "top") patch.y = minY;
      if (mode === "bottom") patch.y = maxY - it.h;
      if (mode === "vmiddle") patch.y = cy - it.h / 2;
      get().updateItem(it.id, patch);
    }
    set({ dirty: true });
  },

  distributeSelection: (axis) => {
    const { doc, selectedIds } = get();
    if (!doc || selectedIds.length < 3) return;
    const sel = doc.items.filter((it) => selectedIds.includes(it.id));
    if (sel.length < 3) return;
    const sorted = [...sel].sort((a, b) => (axis === "h" ? a.x - b.x : a.y - b.y));
    const first = sorted[0];
    const last = sorted[sorted.length - 1];
    const span = axis === "h" ? last.x + last.w - first.x : last.y + last.h - first.y;
    const totalSize = sorted.reduce((acc, it) => acc + (axis === "h" ? it.w : it.h), 0);
    const gap = (span - totalSize) / (sorted.length - 1);
    get().pushHistory();
    let pos = axis === "h" ? first.x : first.y;
    for (const it of sorted) {
      const patch: Partial<Item> = axis === "h" ? { x: pos } : { y: pos };
      get().updateItem(it.id, patch);
      pos += (axis === "h" ? it.w : it.h) + gap;
    }
    set({ dirty: true });
  },

  setItemHidden: (id, hidden) => {
    get().updateItem(id, { hidden });
  },

  setItemLocked: (id, locked) => {
    get().updateItem(id, { locked });
  },

  // --- Nudge clavier -------------------------------------------------------

  nudgeSelection: (dx, dy) => {
    const { doc, selectedIds } = get();
    if (!doc || selectedIds.length === 0) return;
    const idSet = new Set(selectedIds);
    const next = doc.items.map((it) => {
      if (!idSet.has(it.id) || it.locked) return it;
      const copy = { ...it } as Item & { points?: { x: number; y: number }[] };
      copy.x = it.x + dx;
      copy.y = it.y + dy;
      if ("x2" in copy) copy.x2 = (copy as unknown as { x2: number }).x2 + dx;
      if ("y2" in copy) copy.y2 = (copy as unknown as { y2: number }).y2 + dy;
      if (copy.points) copy.points = copy.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
      return copy as Item;
    });
    set({ doc: { ...doc, items: next }, dirty: true });
  },

  // --- Signets de pages PDF --------------------------------------------------

  togglePageBookmark: (pageId) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        pages: doc.pages.map((p) => (p.id === pageId ? { ...p, bookmarked: !p.bookmarked } : p)),
      },
      dirty: true,
    });
  },

  // --- Blocs Checklist --------------------------------------------------------

  addChecklistEntry: (blockId, text) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        blocks: doc.blocks.map((b) =>
          b.type === "checklist" && b.id === blockId ? { ...b, entries: [...b.entries, { id: uid(), text, done: false }] } : b
        ),
      },
      dirty: true,
    });
  },

  updateChecklistEntry: (blockId, entryId, patch) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        blocks: doc.blocks.map((b) =>
          b.type === "checklist" && b.id === blockId
            ? { ...b, entries: b.entries.map((e) => (e.id === entryId ? { ...e, ...patch } : e)) }
            : b
        ),
      },
      dirty: true,
    });
  },

  removeChecklistEntry: (blockId, entryId) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        blocks: doc.blocks.map((b) =>
          b.type === "checklist" && b.id === blockId ? { ...b, entries: b.entries.filter((e) => e.id !== entryId) } : b
        ),
      },
      dirty: true,
    });
  },

  moveChecklistEntry: (blockId, from, to) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        blocks: doc.blocks.map((b) => {
          if (b.type !== "checklist" || b.id !== blockId) return b;
          if (from === to || from < 0 || from >= b.entries.length) return b;
          const entries = [...b.entries];
          const clamped = Math.max(0, Math.min(entries.length, to));
          const [moved] = entries.splice(from, 1);
          entries.splice(clamped, 0, moved);
          return { ...b, entries };
        }),
      },
      dirty: true,
    });
  },

  // --- Restauration d'instantané -----------------------------------------------

  applyVersionSnapshot: (snap) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        name: snap.name,
        blocks: JSON.parse(JSON.stringify(snap.blocks)),
        items: JSON.parse(JSON.stringify(snap.items)),
        pages: JSON.parse(JSON.stringify(snap.pages)),
        designPages: JSON.parse(JSON.stringify(snap.designPages)),
        formValues: { ...snap.formValues },
        settings: { ...snap.settings },
      },
      dirty: true,
      selectedIds: [],
      selectedItemId: null,
    });
  },

  // --- Pages -------------------------------------------------------------

  duplicatePage: (pageId) => {
    const { doc, past } = get();
    if (!doc) return;
    const idx = doc.pages.findIndex((p) => p.id === pageId);
    if (idx === -1) return;
    const copy: PageRef = { ...doc.pages[idx], id: `pg-${uid()}` };
    const pages = [...doc.pages];
    pages.splice(idx + 1, 0, copy);
    set({
      doc: { ...doc, pages },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  deletePages: (pageIds) => {
    const { doc, past } = get();
    if (!doc) return;
    if (doc.pages.length <= pageIds.length) return; // toujours au moins une page
    set({
      doc: { ...doc, pages: doc.pages.filter((p) => !pageIds.includes(p.id)) },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
      selectedPageIds: [],
      currentPageIndex: Math.min(get().currentPageIndex, doc.pages.length - pageIds.length - 1),
    });
  },

  movePage: (from, to) => {
    const { doc, past } = get();
    if (!doc) return;
    if (from === to || from < 0 || from >= doc.pages.length) return;
    const pages = [...doc.pages];
    const [moved] = pages.splice(from, 1);
    const clamped = Math.max(0, Math.min(pages.length, to));
    pages.splice(clamped, 0, moved);
    set({
      doc: { ...doc, pages },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  rotatePages: (pageIds, delta) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        pages: doc.pages.map((p) =>
          pageIds.includes(p.id) ? { ...p, rotation: (((p.rotation + delta) % 360) + 360) % 360 } : p
        ),
      },
      dirty: true,
    });
  },

  // --- Pages Design --------------------------------------------------------

  addDesignPage: () => {
    const { doc, past } = get();
    if (!doc) return;
    const last = doc.designPages[doc.designPages.length - 1];
    const page: DesignPage = { id: `pg-${uid()}`, w: last?.w ?? 595.28, h: last?.h ?? 841.89, background: last?.background ?? "#FFFFFF" };
    set({
      doc: { ...doc, designPages: [...doc.designPages, page] },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  duplicateDesignPage: (pageId) => {
    const { doc, past } = get();
    if (!doc) return;
    const idx = doc.designPages.findIndex((p) => p.id === pageId);
    if (idx === -1) return;
    const src = doc.designPages[idx];
    const copy: DesignPage = { ...src, id: `pg-${uid()}` };
    const pages = [...doc.designPages];
    pages.splice(idx + 1, 0, copy);
    // Duplique aussi les éléments de la page d'origine.
    const copies: Item[] = doc.items
      .filter((it) => it.pageId === pageId)
      .map((it) => {
        const c = JSON.parse(JSON.stringify(it)) as Item;
        c.id = uid();
        c.pageId = copy.id;
        return c;
      });
    set({
      doc: { ...doc, designPages: pages, items: [...doc.items, ...copies] },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  deleteDesignPage: (pageId) => {
    const { doc, past } = get();
    if (!doc || doc.designPages.length <= 1) return;
    set({
      doc: {
        ...doc,
        designPages: doc.designPages.filter((p) => p.id !== pageId),
        items: doc.items.filter((it) => it.pageId !== pageId),
      },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
      selectedIds: [],
      selectedItemId: null,
    });
  },

  updateDesignPage: (pageId, patch) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: { ...doc, designPages: doc.designPages.map((p) => (p.id === pageId ? { ...p, ...patch } : p)) },
      dirty: true,
    });
  },

  applyDesignPreset: (pageId, presetId) => {
    const preset = PAGE_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    get().updateDesignPage(pageId, { w: preset.w, h: preset.h });
  },

  // --- Métadonnées ---------------------------------------------------------

  setName: (name) => {
    const { doc } = get();
    if (!doc) return;
    set({ doc: { ...doc, name }, dirty: true });
  },

  updateSettings: (patch) => {
    const { doc } = get();
    if (!doc) return;
    set({ doc: { ...doc, settings: { ...DEFAULT_DOC_SETTINGS, ...doc.settings, ...patch } }, dirty: true });
  },

  // --- Blocs (Document / Formulaire) ---------------------------------------

  insertBlock: (index, block) => {
    const { doc, past } = get();
    if (!doc) return;
    const blocks = [...doc.blocks];
    blocks.splice(Math.max(0, Math.min(blocks.length, index)), 0, block);
    set({
      doc: { ...doc, blocks },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  updateBlock: (id, patch) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: {
        ...doc,
        blocks: doc.blocks.map((b) => (b.id === id ? ({ ...b, ...(typeof patch === "function" ? patch(b) : patch) } as Block) : b)),
      },
      dirty: true,
    });
  },

  removeBlock: (id) => {
    const { doc, past } = get();
    if (!doc) return;
    set({
      doc: { ...doc, blocks: doc.blocks.filter((b) => b.id !== id) },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  moveBlock: (from, to) => {
    const { doc, past } = get();
    if (!doc) return;
    if (from === to || from < 0 || from >= doc.blocks.length) return;
    const blocks = [...doc.blocks];
    const [moved] = blocks.splice(from, 1);
    const clamped = Math.max(0, Math.min(blocks.length, to));
    blocks.splice(clamped, 0, moved);
    set({
      doc: { ...doc, blocks },
      dirty: true,
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  setFormValue: (fieldId, value) => {
    const { doc } = get();
    if (!doc) return;
    set({
      doc: { ...doc, formValues: { ...doc.formValues, [fieldId]: value } },
      dirty: true,
    });
  },

  pushHistory: () => {
    const { doc, past } = get();
    if (!doc) return;
    set({
      past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
      future: [],
    });
  },

  // --- Historique -----------------------------------------------------------

  undo: () => {
    const { doc, past, future } = get();
    if (!doc || past.length === 0) return;
    const prev = past[past.length - 1];
    set({
      doc: applySnapshot(doc, prev),
      past: past.slice(0, -1),
      future: [snapshot(doc), ...future].slice(0, MAX_HISTORY),
      dirty: true,
      selectedItemId: null,
      selectedIds: [],
    });
  },

  redo: () => {
    const { doc, past, future } = get();
    if (!doc || future.length === 0) return;
    const next = future[0];
    set({
      doc: applySnapshot(doc, next),
      past: [...past, snapshot(doc)].slice(-MAX_HISTORY),
      future: future.slice(1),
      dirty: true,
      selectedItemId: null,
      selectedIds: [],
    });
  },
}));

/** Page courante selon le type de document (cible du collage). */
function currentPageIdOf(doc: AlteosDoc | null, index: number): string | null {
  if (!doc) return null;
  if (doc.kind === "pdf") return doc.pages[Math.min(Math.max(index, 0), doc.pages.length - 1)]?.id ?? null;
  if (doc.kind === "design") return doc.designPages[Math.min(Math.max(index, 0), doc.designPages.length - 1)]?.id ?? null;
  return null;
}

/** Réorganisation de l'ordre d'empilement des éléments de la page concernée. */
function reorderItems(
  get: () => EditorState,
  set: (partial: Partial<EditorState>) => void,
  ids: string[],
  mode: "front" | "back" | "up" | "down"
) {
  const { doc, past } = get();
  if (!doc || ids.length === 0) return;
  const idSet = new Set(ids);
  const touched = doc.items.filter((it) => idSet.has(it.id));
  if (touched.length === 0) return;
  const pageIds = new Set(touched.map((it) => it.pageId));
  let items = [...doc.items];
  for (const pid of pageIds) {
    const pageItems = items.filter((it) => it.pageId === pid);
    const moving = pageItems.filter((it) => idSet.has(it.id));
    if (moving.length === 0) continue;
    const rest = pageItems.filter((it) => !idSet.has(it.id));
    let next: Item[];
    if (mode === "front") next = [...rest, ...moving];
    else if (mode === "back") next = [...moving, ...rest];
    else {
      next = [...pageItems];
      const step = mode === "up" ? 1 : -1;
      const ordered = mode === "up" ? [...moving].reverse() : [...moving];
      for (const mv of ordered) {
        const idx = next.findIndex((it) => it.id === mv.id);
        const target = idx + step;
        if (target < 0 || target >= next.length) continue;
        const [taken] = next.splice(idx, 1);
        next.splice(target, 0, taken);
      }
    }
    const replaced: Item[] = [];
    let consumed = false;
    for (const it of items) {
      if (it.pageId === pid) {
        if (!consumed) {
          replaced.push(...next);
          consumed = true;
        }
      } else {
        replaced.push(it);
      }
    }
    items = replaced;
  }
  set({
    doc: { ...doc, items },
    dirty: true,
    past: [...past.slice(-MAX_HISTORY + 1), snapshot(doc)],
    future: [],
  });
}
