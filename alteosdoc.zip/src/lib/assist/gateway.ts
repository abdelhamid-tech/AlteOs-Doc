/**
 * AlteOS Assist — client sécurisé.
 * Le navigateur appelle uniquement /api/assist. Aucune clé API n'est
 * stockée ou envoyée au client : le serveur sélectionne une clé disponible.
 */

export type AssistActionId =
  | "improve" | "correct" | "summarize" | "rewrite" | "translate"
  | "shorten" | "expand" | "title" | "outline" | "explain";

export interface AssistAction { id: AssistActionId; label: string; description: string; }

export const ASSIST_ACTIONS: AssistAction[] = [
  { id: "improve", label: "Améliorer", description: "Renforce la clarté et le style du texte." },
  { id: "correct", label: "Corriger", description: "Corrige orthographe et grammaire." },
  { id: "summarize", label: "Résumer", description: "Condense le texte en quelques points." },
  { id: "rewrite", label: "Réécrire", description: "Reformule avec un autre angle." },
  { id: "translate", label: "Traduire", description: "Traduit vers la langue choisie." },
  { id: "shorten", label: "Raccourcir", description: "Supprime le superflu sans perdre le sens." },
  { id: "expand", label: "Développer", description: "Enrichit le texte avec plus de détail." },
  { id: "title", label: "Créer un titre", description: "Propose un titre adapté au contenu." },
  { id: "outline", label: "Créer un plan", description: "Structure le document en sections." },
  { id: "explain", label: "Expliquer", description: "Explique le texte simplement." },
];

export interface AssistRequest { action: AssistActionId; text: string; targetLanguage?: string; }

export class AssistUnavailableError extends Error {
  constructor(message = "AlteOS Assist est temporairement indisponible.") {
    super(message);
    this.name = "AssistUnavailableError";
  }
}

export async function runAssistAction(req: AssistRequest): Promise<string> {
  const res = await fetch("/api/assist", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });
  const data = (await res.json().catch(() => ({}))) as { text?: string; error?: string };
  if (!res.ok || typeof data.text !== "string") {
    const message = data.error ?? "AlteOS Assist est temporairement indisponible.";
    if (res.status === 503) throw new AssistUnavailableError(message);
    throw new Error(message);
  }
  return data.text;
}
