import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ---------------------------------------------------------------------------
// Helpers AlteOS Docs
// ---------------------------------------------------------------------------

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} o`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} Ko`
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} Mo`
  return `${(n / (1024 * 1024 * 1024)).toFixed(2)} Go`
}

export function formatDateFR(ts: number): string {
  return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(ts));
}

export function relativeDateFR(ts: number): string {
  const diff = Date.now() - ts;
  const min = Math.round(diff / 60000);
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `il y a ${h} h`;
  const d = Math.round(h / 24);
  if (d === 1) return "hier";
  if (d < 7) return `il y a ${d} jours`;
  return formatDateFR(ts);
}

/** Télécharge un blob localement (aucun envoi réseau). */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function sanitizeFilename(name: string): string {
  return (
    name
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80) || "sans-titre"
  );
}

/** Convertit '#rrggbb' → composants rgb 0..1 (pdf-lib). */
export function hexToRgb01(hex: string): { r: number; g: number; b: number } {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  const v = m ? m[1] : "000000";
  const n = parseInt(v, 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255 };
}

/** Vérifie qu'un texte est encodable en WinAnsi (polices standard PDF). */
export function isWinAnsiEncodable(text: string): boolean {
  for (const ch of text) {
    const c = ch.codePointAt(0) ?? 0;
    if (c < 32 && ch !== "\n" && ch !== "\t") return false;
    if (c > 0xff) return false;
    // Plage Windows-1252 utile (0x80-0x9F) — pdf-lib gère cette plage via WinAnsi.
  }
  return true;
}

/**
 * Caractères encodables en WinAnsi (Windows-1252) au-delà d'ASCII et
 * Latin-1 : €, guillemets courbes, tirets, œ/Œ, bullet, etc.
 */
const WINANSI_EXTRA = new Set([
  0x20ac, 0x201a, 0x0192, 0x201e, 0x2026, 0x2020, 0x2021, 0x02c6, 0x2030, 0x0160, 0x2039, 0x0152, 0x017d,
  0x2018, 0x2019, 0x201c, 0x201d, 0x2022, 0x2013, 0x2014, 0x02dc, 0x2122, 0x0161, 0x203a, 0x0153, 0x017e,
  0x0178,
]);

/** Nettoie un texte pour les polices standard PDF : conserve tout ce que WinAnsi sait encoder, retire le reste. */
export function toWinAnsi(text: string): string {
  let out = "";
  for (const ch of text) {
    const c = ch.codePointAt(0) ?? 0;
    if (ch === "\n" || ch === "\t") {
      out += ch;
      continue;
    }
    if ((c >= 32 && c <= 126) || (c >= 0xa0 && c <= 0xff) || WINANSI_EXTRA.has(c)) {
      out += ch;
      continue;
    }
    // Emoji et autres : retirés honnêtement (non représentables en police standard)
  }
  return out;
}

/**
 * Nettoie un texte pour une police Google incorporée (TTF plein-jeu) :
 * le jeu de caractères est bien plus large — on conserve œ, «», —, …, ±, etc.
 * et l'on retire seulement les contrôles, l'usage privé et les emoji.
 */
export function toExportText(text: string): string {
  let out = "";
  for (const ch of text) {
    const c = ch.codePointAt(0) ?? 0;
    if (ch === "\n" || ch === "\t") {
      out += ch;
      continue;
    }
    if (c < 32 || c === 0x7f) continue; // caractères de contrôle
    if (c >= 0xd800 && c <= 0xdfff) continue; // moitiés de paires (sécurité)
    if (c >= 0xe000 && c <= 0xf8ff) continue; // zone d'usage privé
    if (c >= 0x1f000) continue; // emoji, pictogrammes, symboles carrés
    out += ch;
  }
  return out.replace(/\u00A0/g, " ");
}
