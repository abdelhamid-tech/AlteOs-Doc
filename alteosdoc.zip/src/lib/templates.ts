/**
 * AlteOS Docs — Bibliothèque de modèles originaux.
 * Chaque modèle est instancié avec des identifiants frais.
 */

import { uid, type AlteosDoc, type Block, type DocKind, type Item } from "@/lib/types";
import { DEFAULT_DOC_SETTINGS } from "@/lib/types";

export interface TemplateDef {
  id: string;
  category: TemplateCategory;
  name: string;
  description: string;
  kind: DocKind;
  /** Couleur d'accent de la vignette. */
  accent: string;
  make: () => Pick<AlteosDoc, "kind" | "blocks" | "designPages" | "items" | "settings" | "name">;
}

export type TemplateCategory = "cv" | "rapports" | "école" | "lettres" | "brochures" | "affiches" | "guides" | "portfolios" | "formulaires";

export const CATEGORY_LABEL: Record<TemplateCategory, string> = {
  cv: "CV",
  rapports: "Rapports",
  école: "École",
  lettres: "Lettres",
  brochures: "Brochures",
  affiches: "Affiches",
  guides: "Guides",
  portfolios: "Portfolios",
  formulaires: "Formulaires",
};

function freshBlocks(blocks: Block[]): Block[] {
  return blocks.map((b) => ({ ...b, id: uid() }));
}

function freshItems(items: Item[]): Item[] {
  return items.map((it) => ({ ...it, id: uid(), createdAt: Date.now() }));
}

const p = (text: string) => ({ id: uid(), type: "paragraph" as const, html: `<p>${text}</p>` });
const h = (level: "h1" | "h2" | "h3", text: string) => ({ id: uid(), type: level, text });
const li = (items: string[], ordered = false) => ({
  id: uid(),
  type: "list" as const,
  ordered,
  html: items.map((i) => `<p>${i}</p>`).join(""),
});

// ---------------------------------------------------------------------------

export const TEMPLATES: TemplateDef[] = [
  {
    id: "cv-sobre",
    category: "cv",
    name: "CV sobre",
    description: "Une page claire : profil, expérience, formation, compétences.",
    kind: "document",
    accent: "#0E7C66",
    make: () => ({
      kind: "document",
      name: "CV — Prénom NOM",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Prénom NOM" },
        { id: uid(), type: "subtitle", text: "Intitulé du poste recherché — Ville" },
        p("Profil : décrivez en deux ou trois phrases votre parcours, vos points forts et ce que vous recherchez."),
        h("h2", "Expérience"),
        h("h3", "Intitulé du poste — Entreprise"),
        p("Période. Décrivez vos missions, responsabilités et résultats concrets avec des chiffres quand c'est possible."),
        h("h3", "Poste précédent — Entreprise"),
        p("Période. Résumez vos réalisations principales."),
        h("h2", "Formation"),
        li(["Diplôme — Établissement, année", "Certification pertinente, année"]),
        h("h2", "Compétences"),
        li(["Compétence technique 1 · Compétence technique 2", "Langues : français (natif), anglais (B2)"]),
        h("h2", "Contact"),
        p("Adresse e-mail — Téléphone — Ville"),
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, header: "", footer: "", pageNumbers: "none", margin: 56, baseFont: "Source Serif 4" },
    }),
  },
  {
    id: "cv-moderne",
    category: "cv",
    name: "CV moderne",
    description: "Sections courtes et mots-clés mis en avant.",
    kind: "document",
    accent: "#33691E",
    make: () => ({
      kind: "document",
      name: "CV moderne — Prénom NOM",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Prénom NOM" },
        { id: uid(), type: "subtitle", text: "Spécialiste — Disponible immédiatement" },
        h("h2", "En bref"),
        li(["X années d'expérience dans le domaine", "Spécialité reconnue, outil maîtrisé", "Réussite marquante chiffrée"]),
        h("h2", "Parcours"),
        h("h3", "2022 — aujourd'hui · Poste"),
        p("Trois lignes maximum : mission, périmètre, impact."),
        h("h3", "2019 — 2022 · Poste"),
        p("Trois lignes maximum."),
        h("h2", "Atouts"),
        p("Rédigez un paragraphe court et percutant qui donne envie de vous rencontrer."),
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, pageNumbers: "none", margin: 56, baseFont: "Space Grotesk" },
    }),
  },
  {
    id: "rapport-pro",
    category: "rapports",
    name: "Rapport professionnel",
    description: "Page de titre, sommaire, sections et conclusion.",
    kind: "document",
    accent: "#1C1B1A",
    make: () => ({
      kind: "document",
      name: "Rapport — Sujet",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Rapport — Sujet" },
        { id: uid(), type: "subtitle", text: "Auteur — Date — Service" },
        h("h1", "Sommaire"),
        li(["1. Contexte", "2. Constats", "3. Analyse", "4. Recommandations"], true),
        h("h1", "1. Contexte"),
        p("Expliquez la raison d'être du rapport : demande, périmètre, destinataires."),
        h("h1", "2. Constats"),
        p("Présentez les faits observés, appuyés par des données."),
        {
          id: uid(),
          type: "table",
          header: true,
          rows: [
            ["Indicateur", "Début de période", "Fin de période", "Évolution"],
            ["Exemple : ventes", "1 200", "1 540", "+28 %"],
            ["Exemple : incidents", "18", "7", "−61 %"],
          ],
        },
        h("h1", "3. Analyse"),
        p("Interprétez les constats : causes, tendances, risques."),
        h("h1", "4. Recommandations"),
        li(["Action prioritaire avec responsable et échéance", "Action complémentaire", "Point de suivi proposé"]),
        h("h1", "Conclusion"),
        p("Terminez par le message clé à retenir et la prochaine étape."),
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, header: "Rapport — Sujet", footer: "Confidentiel", pageNumbers: "bottom-center", baseFont: "Merriweather" },
    }),
  },
  {
    id: "compte-rendu",
    category: "rapports",
    name: "Compte-rendu de réunion",
    description: "Participants, décisions et actions à suivre.",
    kind: "document",
    accent: "#8B5E00",
    make: () => ({
      kind: "document",
      name: "Compte-rendu — Réunion",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Compte-rendu de réunion" },
        { id: uid(), type: "subtitle", text: "Date — Lieu / visio" },
        h("h2", "Participants"),
        li(["Animatrice : Nom", "Participants : Noms", "Absent·e·s : Noms"]),
        h("h2", "Ordre du jour"),
        li(["Point 1", "Point 2", "Point 3"], true),
        h("h2", "Décisions"),
        li(["Décision 1 — validée", "Décision 2 — validée sous condition"]),
        h("h2", "Actions"),
        {
          id: uid(),
          type: "table",
          header: true,
          rows: [
            ["Action", "Responsable", "Échéance"],
            ["Décrire l'action", "Prénom", "jj/mm/aaaa"],
            ["Décrire l'action", "Prénom", "jj/mm/aaaa"],
          ],
        },
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, pageNumbers: "bottom-right", baseFont: "Inter" },
    }),
  },
  {
    id: "expose-ecole",
    category: "école",
    name: "Exposé scolaire",
    description: "Introduction, parties numérotées, sources.",
    kind: "document",
    accent: "#B197FC",
    make: () => ({
      kind: "document",
      name: "Exposé — Sujet",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Sujet de l'exposé" },
        { id: uid(), type: "subtitle", text: "Classe — Prénom NOM" },
        h("h1", "Introduction"),
        p("Présentez le sujet et annoncez le plan en une phrase."),
        h("h1", "I. Première partie"),
        p("Développez la première grande idée avec des exemples."),
        h("h2", "1. Sous-partie"),
        p("Détaillez avec des faits précis."),
        h("h1", "II. Deuxième partie"),
        p("Développez la deuxième grande idée."),
        h("h1", "Conclusion"),
        p("Résumez et ouvrez sur une question plus large."),
        h("h1", "Sources"),
        li(["Source 1 — auteur, année", "Source 2 — site ou ouvrage"]),
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, pageNumbers: "bottom-center", baseFont: "Poppins" },
    }),
  },
  {
    id: "fiche-lecture",
    category: "école",
    name: "Fiche de lecture",
    description: "Référence, résumé, personnages, avis.",
    kind: "document",
    accent: "#F7B32B",
    make: () => ({
      kind: "document",
      name: "Fiche de lecture — Titre",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Fiche de lecture" },
        { id: uid(), type: "subtitle", text: "Titre de l'œuvre — Auteur" },
        h("h2", "Références"),
        li(["Auteur :", "Année de publication :", "Genre :", "Nombre de pages :"]),
        h("h2", "Résumé"),
        p("Racontez l'intrigue en quelques paragraphes, sans révéler la fin si la fiche est destinée à d'autres lecteurs."),
        h("h2", "Personnages principaux"),
        li(["Personnage 1 : rôle, traits", "Personnage 2 : rôle, traits"]),
        h("h2", "Mon avis"),
        p("Ce que j'ai aimé, ce qui m'a moins plu, passage préféré."),
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, pageNumbers: "none", baseFont: "Lora" },
    }),
  },
  {
    id: "lettre-formelle",
    category: "lettres",
    name: "Lettre formelle",
    description: "Expéditeur, destinataire, objet et formule de politesse.",
    kind: "document",
    accent: "#59636E",
    make: () => ({
      kind: "document",
      name: "Lettre — Objet",
      blocks: freshBlocks([
        p("Prénom NOM<br>Adresse<br>Code postal Ville"),
        p("Nom du destinataire<br>Service<br>Adresse du destinataire"),
        p("Fait à Ville, le jj/mm/aaaa"),
        h("h2", "Objet : l'objet de la lettre"),
        p("Madame, Monsieur,"),
        p("Introduisez la raison de votre courrier dès la première phrase."),
        p("Développez votre demande ou votre information avec les éléments utiles (références, dates, montants)."),
        p("Dans l'attente de votre retour, je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées."),
        p("Signature"),
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, pageNumbers: "none", margin: 72, baseFont: "EB Garamond" },
    }),
  },
  {
    id: "affiche-evenement",
    category: "affiches",
    name: "Affiche d'événement",
    description: "A4 portrait : titre fort, date, lieu, informations.",
    kind: "design",
    accent: "#FF6B6B",
    make: () => ({
      kind: "design",
      name: "Affiche — Événement",
      designPages: [{ id: `pg-${uid()}`, w: 595.28, h: 841.89, background: "#FFFFFF" }],
      items: freshItems([
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 0, y: 0, w: 595.28, h: 250,
          color: "#0E7C66", strokeWidth: 0, fill: true, fillColor: "#0E7C66", opacity: 1,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 60, y: 80, w: 475, h: 110,
          text: "GRAND ÉVÉNEMENT", fontSize: 42, fontFamily: "Bebas Neue", bold: false, italic: false,
          underline: false, color: "#FFFFFF", align: "center",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 60, y: 300, w: 475, h: 40,
          text: "Samedi 14 mars — 18 h 00", fontSize: 22, fontFamily: "Inter", bold: false, italic: false,
          underline: false, color: "#1C1B1A", align: "center",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 60, y: 350, w: 475, h: 36,
          text: "Maison des associations — Salle Verlaine", fontSize: 15, fontFamily: "Inter",
          bold: false, italic: false, underline: false, color: "#57544E", align: "center",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 60, y: 430, w: 475, h: 1.5,
          color: "#0E7C66", strokeWidth: 0, fill: true, fillColor: "#0E7C66", opacity: 0.5,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 90, y: 460, w: 415, h: 200,
          text: "Au programme :\nConférences, ateliers et rencontres.\nEntrée libre, dans la limite des places disponibles.\n\nRenseignements : contact@exemple.fr",
          fontSize: 14, fontFamily: "Inter", bold: false, italic: false, underline: false,
          color: "#33322F", align: "center",
        },
      ]),
      blocks: [],
      settings: { ...DEFAULT_DOC_SETTINGS },
    }),
  },
  {
    id: "brochure-trois-volets",
    category: "brochures",
    name: "Brochure 3 volets",
    description: "A4 paysage en trois colonnes, prêt à personnaliser.",
    kind: "design",
    accent: "#3FB950",
    make: () => ({
      kind: "design",
      name: "Brochure — 3 volets",
      designPages: [{ id: `pg-${uid()}`, w: 841.89, h: 595.28, background: "#FFFFFF" }],
      items: freshItems([
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 0, y: 0, w: 1.5, h: 595.28,
          color: "#D8D5CE", strokeWidth: 0, fill: true, fillColor: "#D8D5CE", opacity: 1,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 280.5, y: 0, w: 1.5, h: 595.28,
          color: "#D8D5CE", strokeWidth: 0, fill: true, fillColor: "#D8D5CE", opacity: 1,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 560, y: 0, w: 1.5, h: 595.28,
          color: "#D8D5CE", strokeWidth: 0, fill: true, fillColor: "#D8D5CE", opacity: 1,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 40, y: 70, w: 200, h: 60,
          text: "Volet 1", fontSize: 24, fontFamily: "Oswald", bold: true, italic: false,
          underline: false, color: "#0E7C66", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 40, y: 140, w: 200, h: 300,
          text: "Présentez ici votre activité, votre équipe ou votre produit.\n\nUn paragraphe court par volet garde la lecture fluide.",
          fontSize: 11, fontFamily: "Open Sans", bold: false, italic: false, underline: false, color: "#33322F", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 320, y: 70, w: 200, h: 60,
          text: "Volet 2", fontSize: 24, fontFamily: "Oswald", bold: true, italic: false,
          underline: false, color: "#0E7C66", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 320, y: 140, w: 200, h: 300,
          text: "Détaillez vos services ou votre programme.\n\nUtilisez des listes courtes et des chiffres marquants.",
          fontSize: 11, fontFamily: "Open Sans", bold: false, italic: false, underline: false, color: "#33322F", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 600, y: 70, w: 200, h: 60,
          text: "Volet 3", fontSize: 24, fontFamily: "Oswald", bold: true, italic: false,
          underline: false, color: "#0E7C66", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 600, y: 140, w: 200, h: 300,
          text: "Contact :\n\ncontact@exemple.fr\n06 00 00 00 00\n12 rue des Exemples",
          fontSize: 11, fontFamily: "Open Sans", bold: false, italic: false, underline: false, color: "#33322F", align: "left",
        },
      ]),
      blocks: [],
      settings: { ...DEFAULT_DOC_SETTINGS },
    }),
  },
  {
    id: "guide-pratique",
    category: "guides",
    name: "Guide pratique",
    description: "Étapes numérotées, conseils et encadrés.",
    kind: "document",
    accent: "#33691E",
    make: () => ({
      kind: "document",
      name: "Guide — Sujet",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Guide pratique" },
        { id: uid(), type: "subtitle", text: "Réussir X en Y étapes" },
        p("Expliquez à qui s'adresse ce guide et ce que le lecteur saura faire à la fin."),
        h("h1", "Étape 1 — Préparer"),
        li(["Point essentiel à vérifier", "Outil ou document nécessaire"], true),
        h("h1", "Étape 2 — Réaliser"),
        p("Décrivez précisément les gestes ou la démarche."),
        { id: uid(), type: "quote", html: "<p><em>Astuce : notez ici le conseil qui évite l'erreur la plus fréquente.</em></p>" },
        h("h1", "Étape 3 — Vérifier"),
        p("Listez les critères de réussite."),
        h("h1", "Pour aller plus loin"),
        p("Ressources, contacts ou exercices complémentaires."),
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, header: "Guide — Sujet", pageNumbers: "bottom-center", baseFont: "Work Sans" },
    }),
  },
  {
    id: "portfolio-minimal",
    category: "portfolios",
    name: "Portfolio minimal",
    description: "A4 paysage : nom, discipline, projets à caser.",
    kind: "design",
    accent: "#1C1B1A",
    make: () => ({
      kind: "design",
      name: "Portfolio — Prénom NOM",
      designPages: [{ id: `pg-${uid()}`, w: 841.89, h: 595.28, background: "#FFFFFF" }],
      items: freshItems([
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 0, y: 0, w: 841.89, h: 130,
          color: "#1C1B1A", strokeWidth: 0, fill: true, fillColor: "#1C1B1A", opacity: 1,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 60, y: 40, w: 500, h: 60,
          text: "Prénom NOM — Discipline", fontSize: 30, fontFamily: "Playfair Display", bold: true,
          italic: false, underline: false, color: "#FFFFFF", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 60, y: 170, w: 350, h: 130,
          text: "Projet 01\nBrève description du projet, rôle et résultat.",
          fontSize: 13, fontFamily: "Karla", bold: false, italic: false, underline: false, color: "#33322F", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 470, y: 170, w: 310, h: 130,
          color: "#D8D5CE", strokeWidth: 0, fill: true, fillColor: "#EDEAE3", opacity: 1,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 60, y: 350, w: 350, h: 130,
          text: "Projet 02\nBrève description du projet, rôle et résultat.",
          fontSize: 13, fontFamily: "Karla", bold: false, italic: false, underline: false, color: "#33322F", align: "left",
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "rect", x: 470, y: 350, w: 310, h: 130,
          color: "#D8D5CE", strokeWidth: 0, fill: true, fillColor: "#EDEAE3", opacity: 1,
        },
        {
          id: uid(), pageId: "", createdAt: 0, type: "text", x: 60, y: 520, w: 720, h: 30,
          text: "contact@exemple.fr — site-exemple.fr", fontSize: 11, fontFamily: "Karla",
          bold: false, italic: false, underline: false, color: "#57544E", align: "left",
        },
      ]),
      blocks: [],
      settings: { ...DEFAULT_DOC_SETTINGS },
    }),
  },
  {
    id: "formulaire-inscription",
    category: "formulaires",
    name: "Formulaire d'inscription",
    description: "Champs remplissables, prêts à exporter en PDF interactif.",
    kind: "form",
    accent: "#0E7C66",
    make: () => ({
      kind: "form",
      name: "Formulaire d'inscription",
      blocks: freshBlocks([
        { id: uid(), type: "title", text: "Formulaire d'inscription" },
        { id: uid(), type: "subtitle", text: "À remplir et à remettre sur place ou par e-mail" },
        { id: uid(), type: "field", fieldType: "text", label: "Nom complet", required: true },
        { id: uid(), type: "field", fieldType: "text", label: "Adresse e-mail", required: true },
        { id: uid(), type: "field", fieldType: "text", label: "Téléphone", required: false },
        { id: uid(), type: "field", fieldType: "date", label: "Date de naissance", required: false },
        { id: uid(), type: "field", fieldType: "multiline", label: "Message / informations complémentaires", required: false },
        { id: uid(), type: "field", fieldType: "checkbox", label: "J'accepte d'être contacté·e par e-mail", required: false },
      ]),
      designPages: [],
      items: [],
      settings: { ...DEFAULT_DOC_SETTINGS, pageNumbers: "none", baseFont: "DM Sans" },
    }),
  },
];

/** Instancie un template : identifiants frais + pageId pour les éléments Design. */
export function instantiateTemplate(tpl: TemplateDef): Pick<AlteosDoc, "kind" | "name" | "blocks" | "designPages" | "items" | "settings"> {
  const data = tpl.make();
  const firstPageId = data.designPages[0]?.id;
  const items = data.items.map((it) => ({ ...it, id: uid(), createdAt: Date.now(), pageId: firstPageId ?? "" }));
  return { ...data, items };
}
