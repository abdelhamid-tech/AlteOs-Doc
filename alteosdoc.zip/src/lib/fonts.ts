/**
 * AlteOS Docs — Bibliothèque de polices
 * --------------------------------------
 * 153 polices : 130 familles Google Fonts (gratuites, chargées en ligne avec
 * repli local) + 23 polices système (toujours disponibles hors ligne).
 *
 * Chaque police est identifiée par son nom de famille exact (id). Les valeurs
 * historiques « Helvetica », « Times », « Courier » restent des ids valides
 * pour préserver les documents existants.
 *
 * Les fichiers TTF pour l'export PDF sont résolus via src/lib/fonts-ttf.ts
 * (généré et vérifié par scripts/gen-font-urls.ts).
 */

export type FontCategory = "sans" | "serif" | "mono" | "display" | "script" | "system";

export const CATEGORY_ORDER: FontCategory[] = ["sans", "serif", "mono", "display", "script", "system"];

export const CATEGORY_LABEL: Record<FontCategory, string> = {
  sans: "Sans-serif",
  serif: "Serif",
  mono: "Monospace",
  display: "Titres",
  script: "Manuscrites",
  system: "Système",
};

export interface FontDef {
  /** Nom de famille exact — sert d'identifiant (CSS + stockage IndexedDB). */
  id: string;
  /** Libellé affiché. */
  name: string;
  cat: FontCategory;
  /** "google" (webfont) ou "system" (installée sur l'appareil). */
  src: "google" | "system";
  /** Pile de repli CSS spécifique (facultatif). */
  fallback?: string;
}

// ---------------------------------------------------------------------------
// Familles Google Fonts (gratuites, sans clé, sans compte)
// ---------------------------------------------------------------------------

const G = (id: string, cat: FontCategory, fallback?: string): FontDef => ({
  id,
  name: id,
  cat,
  src: "google",
  fallback,
});

const S = (id: string, name: string, cat: FontCategory, fallback?: string): FontDef => ({
  id,
  name,
  cat,
  src: "system",
  fallback,
});

export const GOOGLE_FONTS: FontDef[] = [
  // ----- Sans-serif (46) ---------------------------------------------------
  G("Inter", "sans"),
  G("Roboto", "sans"),
  G("Open Sans", "sans"),
  G("Lato", "sans"),
  G("Montserrat", "sans"),
  G("Poppins", "sans"),
  G("Nunito", "sans"),
  G("Nunito Sans", "sans"),
  G("Raleway", "sans"),
  G("Ubuntu", "sans"),
  G("Rubik", "sans"),
  G("Work Sans", "sans"),
  G("DM Sans", "sans"),
  G("Manrope", "sans"),
  G("Barlow", "sans"),
  G("Karla", "sans"),
  G("Mulish", "sans"),
  G("Fira Sans", "sans"),
  G("Figtree", "sans"),
  G("Outfit", "sans"),
  G("Sora", "sans"),
  G("Space Grotesk", "sans"),
  G("Plus Jakarta Sans", "sans"),
  G("Public Sans", "sans"),
  G("Cabin", "sans"),
  G("Quicksand", "sans"),
  G("Josefin Sans", "sans"),
  G("Lexend", "sans"),
  G("Urbanist", "sans"),
  G("Epilogue", "sans"),
  G("Onest", "sans"),
  G("Instrument Sans", "sans"),
  G("Schibsted Grotesk", "sans"),
  G("Gabarito", "sans"),
  G("Assistant", "sans"),
  G("Heebo", "sans"),
  G("Overpass", "sans"),
  G("Archivo", "sans"),
  G("Chivo", "sans"),
  G("Exo 2", "sans"),
  G("Hanken Grotesk", "sans"),
  G("Jost", "sans"),
  G("League Spartan", "sans"),
  G("Encode Sans", "sans"),
  G("Arimo", "sans"),
  G("Cantarell", "sans"),

  // ----- Serif (30) --------------------------------------------------------
  G("Playfair Display", "serif"),
  G("Merriweather", "serif"),
  G("Lora", "serif"),
  G("PT Serif", "serif"),
  G("Roboto Slab", "serif"),
  G("Bitter", "serif"),
  G("Crimson Pro", "serif"),
  G("Libre Baskerville", "serif"),
  G("EB Garamond", "serif"),
  G("Cormorant Garamond", "serif"),
  G("Spectral", "serif"),
  G("Source Serif 4", "serif"),
  G("Vollkorn", "serif"),
  G("Alegreya", "serif"),
  G("Zilla Slab", "serif"),
  G("Frank Ruhl Libre", "serif"),
  G("Newsreader", "serif"),
  G("Bodoni Moda", "serif"),
  G("Domine", "serif"),
  G("Arvo", "serif"),
  G("Cardo", "serif"),
  G("Rokkitt", "serif"),
  G("Cinzel", "serif"),
  G("Cormorant", "serif"),
  G("Young Serif", "serif"),
  G("DM Serif Display", "serif"),
  G("Prata", "serif"),
  G("Marcellus", "serif"),
  G("Bree Serif", "serif"),
  G("Libre Caslon Text", "serif"),

  // ----- Monospace (11) ----------------------------------------------------
  G("JetBrains Mono", "mono"),
  G("Fira Code", "mono"),
  G("Source Code Pro", "mono"),
  G("IBM Plex Mono", "mono"),
  G("Space Mono", "mono"),
  G("Roboto Mono", "mono"),
  G("Inconsolata", "mono"),
  G("Ubuntu Mono", "mono"),
  G("Red Hat Mono", "mono"),
  G("Spline Sans Mono", "mono"),
  G("Kode Mono", "mono"),

  // ----- Titres / display (22) ----------------------------------------------
  G("Bebas Neue", "display"),
  G("Anton", "display"),
  G("Oswald", "display"),
  G("Archivo Black", "display"),
  G("Abril Fatface", "display", "serif"),
  G("Lobster", "display", "cursive"),
  G("Bangers", "display", "cursive"),
  G("Righteous", "display"),
  G("Alfa Slab One", "display", "serif"),
  G("Ultra", "display", "serif"),
  G("Fredoka", "display"),
  G("Poetsen One", "display"),
  G("Staatliches", "display"),
  G("Lilita One", "display"),
  G("Teko", "display"),
  G("Russo One", "display"),
  G("Passion One", "display"),
  G("Fjalla One", "display"),
  G("Titan One", "display", "cursive"),
  G("Black Ops One", "display"),
  G("Sigmar", "display"),
  G("Major Mono Display", "mono"),

  // ----- Manuscrites (21) ----------------------------------------------------
  G("Caveat", "script"),
  G("Dancing Script", "script"),
  G("Great Vibes", "script"),
  G("Pacifico", "script"),
  G("Sacramento", "script"),
  G("Indie Flower", "script"),
  G("Shadows Into Light", "script"),
  G("Homemade Apple", "script"),
  G("Kalam", "script"),
  G("Patrick Hand", "script"),
  G("Permanent Marker", "script"),
  G("Satisfy", "script"),
  G("Kaushan Script", "script"),
  G("Parisienne", "script"),
  G("Courgette", "script"),
  G("Tangerine", "script"),
  G("Marck Script", "script"),
  G("Neucha", "script"),
  G("Rock Salt", "script"),
  G("Yellowtail", "script"),
  G("Cedarville Cursive", "script"),
];

// ---------------------------------------------------------------------------
// Polices système (23) — disponibles localement, hors ligne
// ---------------------------------------------------------------------------

export const SYSTEM_FONTS: FontDef[] = [
  // Ids historiques (documents créés avant la bibliothèque étendue)
  S("Helvetica", "Helvetica", "sans"),
  S("Times", "Times", "serif"),
  S("Courier", "Courier", "mono"),
  // Polices installées sur la plupart des appareils
  S("Arial", "Arial", "sans"),
  S("Helvetica Neue", "Helvetica Neue", "sans"),
  S("Verdana", "Verdana", "sans"),
  S("Tahoma", "Tahoma", "sans"),
  S("Trebuchet MS", "Trebuchet MS", "sans"),
  S("Calibri", "Calibri", "sans"),
  S("Century Gothic", "Century Gothic", "sans"),
  S("Lucida Sans", "Lucida Sans Unicode", "sans"),
  S("Lucida Console", "Lucida Console", "mono"),
  S("Times New Roman", "Times New Roman", "serif"),
  S("Georgia", "Georgia", "serif"),
  S("Garamond", "Garamond", "serif"),
  S("Palatino", "Palatino Linotype", "serif"),
  S("Book Antiqua", "Book Antiqua", "serif"),
  S("Cambria", "Cambria", "serif"),
  S("Courier New", "Courier New", "mono"),
  S("Consolas", "Consolas", "mono"),
  S("Impact", "Impact", "display"),
  S("Comic Sans MS", "Comic Sans MS", "script"),
  S("Brush Script MT", "Brush Script MT", "script"),
];

// ---------------------------------------------------------------------------
// Registre fusionné
// ---------------------------------------------------------------------------

export const FONT_REGISTRY: FontDef[] = [...GOOGLE_FONTS, ...SYSTEM_FONTS];

const BY_ID = new Map(FONT_REGISTRY.map((f) => [f.id, f]));

export function getFont(id: string): FontDef | undefined {
  return BY_ID.get(id);
}

/** Pile CSS de repli par catégorie. */
function fallbackStack(f: FontDef): string {
  if (f.fallback) return f.fallback;
  switch (f.cat) {
    case "serif":
      return "Georgia, 'Times New Roman', serif";
    case "mono":
      return "'Courier New', Courier, monospace";
    case "script":
      return "cursive";
    case "display":
      return "'Arial Black', Arial, sans-serif";
    default:
      return "'Helvetica Neue', Arial, sans-serif";
  }
}

/**
 * Pile CSS complète pour une police (identifiant de registre).
 * Les ids inconnus (documents futurs / polices retirées) replient proprement.
 */
export function fontStack(id: string): string {
  const f = BY_ID.get(id);
  if (!f) return `'${id.replace(/'/g, "")}', 'Helvetica Neue', Arial, sans-serif`;
  if (f.src === "system") {
    if (f.id === "Helvetica") return "'Helvetica Neue', Helvetica, Arial, sans-serif";
    if (f.id === "Times") return "'Times New Roman', Times, Liberation Serif, serif";
    if (f.id === "Courier") return "'Courier New', Courier, Liberation Mono, monospace";
    return `'${f.id}', ${fallbackStack(f)}`;
  }
  return `'${f.id}', ${fallbackStack(f)}`;
}

/**
 * Résout n'importe quelle valeur stockée (y compris les anciennes) vers un id
 * de registre valide. Retourne une police Google si disponible.
 */
export function resolveFontId(id: string | undefined | null): string {
  if (!id) return "Helvetica";
  if (BY_ID.has(id)) return id;
  const norm = id.trim();
  if (BY_ID.has(norm)) return norm;
  // Alias historiques → équivalents riches
  if (norm === "Helvetica" || norm === "Arial") return "Helvetica";
  if (norm === "Times" || norm === "Times New Roman") return "Times";
  if (norm === "Courier" || norm === "Courier New") return "Courier";
  return "Helvetica";
}

/** Police standard PDF équivalente (repli d'export hors ligne). */
export function stdFallbackId(f: FontDef): "Helvetica" | "Times" | "Courier" {
  if (f.src === "system") {
    if (f.id === "Times" || f.cat === "serif") return "Times";
    if (f.id === "Courier" || f.cat === "mono") return "Courier";
    return "Helvetica";
  }
  switch (f.cat) {
    case "serif":
      return "Times";
    case "mono":
      return "Courier";
    default:
      return "Helvetica";
  }
}

// ---------------------------------------------------------------------------
// Compteurs et recherche
// ---------------------------------------------------------------------------

export function fontCount(): number {
  return FONT_REGISTRY.length;
}

export function googleFontCount(): number {
  return GOOGLE_FONTS.length;
}

export function systemFontCount(): number {
  return SYSTEM_FONTS.length;
}

/** Normalisation sans accents pour la recherche. */
function norm(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export function searchFonts(query: string, cat: FontCategory | "all"): FontDef[] {
  const q = norm(query.trim());
  return FONT_REGISTRY.filter((f) => {
    if (cat !== "all" && f.cat !== cat) return false;
    if (q === "") return true;
    return norm(f.id).includes(q) || norm(CATEGORY_LABEL[f.cat]).includes(q);
  });
}
