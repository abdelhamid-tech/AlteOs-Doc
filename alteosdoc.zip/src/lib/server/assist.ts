import { prisma } from "@/lib/server/prisma";
import { decryptApiKey } from "@/lib/server/key-vault";

export type AssistActionId = "improve" | "correct" | "summarize" | "rewrite" | "translate" | "shorten" | "expand" | "title" | "outline" | "explain";

const SYSTEM: Record<AssistActionId, string> = {
  improve: "Améliore la clarté, la précision et le style sans changer le sens.",
  correct: "Corrige l'orthographe, la grammaire, la ponctuation et les formulations incorrectes.",
  summarize: "Résume fidèlement le contenu en conservant les informations essentielles.",
  rewrite: "Réécris le contenu de façon naturelle et professionnelle sans inventer d'informations.",
  translate: "Traduis fidèlement le contenu vers la langue demandée.",
  shorten: "Raccourcis le contenu en conservant son sens et les informations importantes.",
  expand: "Développe le contenu avec davantage de détails utiles, sans inventer de faits.",
  title: "Propose un titre clair, précis et adapté au contenu.",
  outline: "Transforme le contenu en plan structuré avec titres et sous-titres.",
  explain: "Explique le contenu simplement et précisément.",
};

const retryable = new Set([401, 403, 408, 409, 429, 500, 502, 503, 504]);

function model() {
  return process.env.ALTEOS_AI_MODEL || "gpt-5-mini";
}

export async function runAssist(action: AssistActionId, text: string, targetLanguage?: string) {
  const keys = await prisma.assistApiKey.findMany({ where: { enabled: true, provider: "openai" }, orderBy: [{ priority: "asc" }, { lastUsedAt: "asc" }] });
  if (!keys.length) throw new Error("NO_AI_KEY");

  const prompt = targetLanguage && action === "translate"
    ? `${SYSTEM[action]} Langue cible : ${targetLanguage}.\n\nCONTENU :\n${text}`
    : `${SYSTEM[action]}\n\nCONTENU :\n${text}`;

  let lastError = "Assist indisponible.";
  for (const key of keys) {
    const apiKey = decryptApiKey(key);
    try {
      const response = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ model: model(), input: prompt }),
        cache: "no-store",
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const message = typeof data?.error?.message === "string" ? data.error.message : `HTTP ${response.status}`;
        await prisma.assistApiKey.update({ where: { id: key.id }, data: { errorCount: { increment: 1 }, lastErrorAt: new Date(), lastError: message } });
        await prisma.assistUsage.create({ data: { provider: "openai", keyId: key.id, action, success: false, statusCode: response.status, inputChars: text.length } });
        lastError = message;
        if (!retryable.has(response.status)) break;
        continue;
      }
      const output = typeof data?.output_text === "string" ? data.output_text.trim() : "";
      if (!output) throw new Error("Réponse vide du modèle.");
      await prisma.assistApiKey.update({ where: { id: key.id }, data: { successCount: { increment: 1 }, lastUsedAt: new Date(), lastError: null } });
      await prisma.assistUsage.create({ data: { provider: "openai", keyId: key.id, action, success: true, statusCode: response.status, inputChars: text.length, outputChars: output.length } });
      return output;
    } catch (error) {
      lastError = error instanceof Error ? error.message : "Erreur réseau";
      await prisma.assistApiKey.update({ where: { id: key.id }, data: { errorCount: { increment: 1 }, lastErrorAt: new Date(), lastError } }).catch(() => undefined);
      if (lastError.includes("Réponse vide")) break;
    }
  }
  throw new Error(lastError || "NO_AI_KEY");
}
