import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { prisma } from "@/lib/server/prisma";

function masterKey() {
  const raw = process.env.ALTEOS_KEY_ENCRYPTION_SECRET;
  if (!raw || raw.length < 32) throw new Error("ALTEOS_KEY_ENCRYPTION_SECRET doit contenir au moins 32 caractères.");
  return createHash("sha256").update(raw).digest();
}

export function encryptApiKey(apiKey: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", masterKey(), iv);
  const encrypted = Buffer.concat([cipher.update(apiKey, "utf8"), cipher.final()]);
  return { encrypted: encrypted.toString("base64url"), iv: iv.toString("base64url"), authTag: cipher.getAuthTag().toString("base64url") };
}

export function decryptApiKey(row: { encrypted: string; iv: string; authTag: string }) {
  const decipher = createDecipheriv("aes-256-gcm", masterKey(), Buffer.from(row.iv, "base64url"));
  decipher.setAuthTag(Buffer.from(row.authTag, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(row.encrypted, "base64url")), decipher.final()]).toString("utf8");
}

export async function publicKeys() {
  const rows = await prisma.assistApiKey.findMany({ orderBy: [{ priority: "asc" }, { createdAt: "asc" }] });
  return rows.map((k) => ({
    id: k.id,
    label: k.label,
    provider: k.provider,
    enabled: k.enabled,
    priority: k.priority,
    lastUsedAt: k.lastUsedAt,
    lastErrorAt: k.lastErrorAt,
    lastError: k.lastError,
    successCount: k.successCount,
    errorCount: k.errorCount,
    createdAt: k.createdAt,
  }));
}
