/**
 * AlteOS Docs — Moteur d'affichage PDF (pdf.js, chargé paresseusement côté client)
 * --------------------------------------------------------------------------------
 * - Aucun fichier n'est envoyé à un serveur : tout reste dans le navigateur.
 * - Les pages sont rendues à la demande (rendu virtuel) pour les PDF volumineux.
 */

export interface RenderedPageInfo {
  /** Dimensions du viewport rendu (rotation appliquée) en px à l'échelle S. */
  vw: number;
  vh: number;
  /** Dimensions de la page NON pivotée en points PDF. */
  uw: number;
  uh: number;
  /** Rotation totale appliquée (page.rotate + utilisateur). */
  rotation: number;
  scale: number;
}

type PdfJsModule = typeof import("pdfjs-dist");

let pdfjsPromise: Promise<PdfJsModule> | null = null;

export async function getPdfJs(): Promise<PdfJsModule> {
  if (!pdfjsPromise) {
    pdfjsPromise = import("pdfjs-dist").then((mod) => {
      // Le worker est servi depuis /public — traitement local, aucun service externe.
      mod.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
      return mod;
    });
  }
  return pdfjsPromise;
}

export interface LoadedPdf {
  doc: import("pdfjs-dist").PDFDocumentProxy;
  pageSizes: { w: number; h: number }[]; // non pivoté, points
}

export async function loadPdfDocument(bytes: ArrayBuffer): Promise<LoadedPdf> {
  const pdfjs = await getPdfJs();
  // pdf.js peut détacher le buffer : toujours passer une copie fraîche.
  const data = bytes.slice(0);
  const doc = await pdfjs.getDocument({
    data,
    cMapUrl: "/pdfjs/cmaps/",
    cMapPacked: true,
    standardFontDataUrl: "/pdfjs/standard_fonts/",
  }).promise;

  const pageSizes: { w: number; h: number }[] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const vp = page.getViewport({ scale: 1 }); // rotation native non appliquée ? si, getViewport applique page.rotate par défaut
    const vp0 = page.getViewport({ scale: 1, rotation: 0 });
    pageSizes.push({ w: vp0.width, h: vp0.height });
    void vp;
  }
  return { doc, pageSizes };
}

export function displayedRotation(nativeRotate: number, userRotation: number): number {
  return (((nativeRotate + userRotation) % 360) + 360) % 360;
}

export async function renderPageToCanvas(
  pdfDoc: import("pdfjs-dist").PDFDocumentProxy,
  srcIndex: number,
  canvas: HTMLCanvasElement,
  scale: number,
  userRotation: number
): Promise<RenderedPageInfo> {
  const pdfjs = await getPdfJs();
  const page = await pdfDoc.getPage(srcIndex + 1);
  const rotation = displayedRotation(page.rotate, userRotation);
  const viewport = page.getViewport({ scale, rotation });

  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("Canvas 2D indisponible dans ce navigateur.");
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.floor(viewport.width * dpr);
  canvas.height = Math.floor(viewport.height * dpr);
  canvas.style.width = `${viewport.width}px`;
  canvas.style.height = `${viewport.height}px`;

  const task = page.render({ canvasContext: ctx, viewport, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined });
  await task.promise;

  return {
    vw: viewport.width,
    vh: viewport.height,
    uw: page.getViewport({ scale: 1, rotation: 0 }).width,
    uh: page.getViewport({ scale: 1, rotation: 0 }).height,
    rotation,
    scale,
  };
}

/**
 * Rend la couche de texte (sélectionnable) pour un page canvas.
 * Retourne un destructeur.
 */
export async function renderTextLayer(
  pdfDoc: import("pdfjs-dist").PDFDocumentProxy,
  srcIndex: number,
  container: HTMLDivElement,
  scale: number,
  userRotation: number
): Promise<() => void> {
  const pdfjs = await getPdfJs();
  const page = await pdfDoc.getPage(srcIndex + 1);
  const rotation = displayedRotation(page.rotate, userRotation);
  const viewport = page.getViewport({ scale, rotation });
  const textContent = await page.getTextContent();
  const layer = new pdfjs.TextLayer({
    textContentSource: textContent,
    container,
    viewport,
  });
  await layer.render();
  return () => {
    container.innerHTML = "";
  };
}

/** Rend une vignette (miniature) pour une page. */
export async function renderThumb(
  pdfDoc: import("pdfjs-dist").PDFDocumentProxy,
  srcIndex: number,
  targetW: number,
  userRotation: number
): Promise<{ blob: Blob | null; w: number; h: number }> {
  const pdfjs = await getPdfJs();
  const page = await pdfDoc.getPage(srcIndex + 1);
  const rotation = displayedRotation(page.rotate, userRotation);
  const base = page.getViewport({ scale: 1, rotation });
  const scale = targetW / base.width;
  const viewport = page.getViewport({ scale, rotation });
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  if (!ctx) return { blob: null, w: viewport.width, h: viewport.height };
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  await page.render({ canvasContext: ctx, viewport }).promise;
  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
  return { blob, w: viewport.width, h: viewport.height };
}

// ---------------------------------------------------------------------------
// Transforms de coordonnées : voir ./transform.ts (implémentation pure).
// pdf.js reste utilisé pour le rendu canvas et la couche de texte.
// ---------------------------------------------------------------------------

/** Extrait le texte intégral d'une page PDF (lecture locale, rien n'est envoyé). */
export async function extractPageText(
  pdfDoc: import("pdfjs-dist").PDFDocumentProxy,
  srcIndex: number
): Promise<string> {
  const page = await pdfDoc.getPage(srcIndex + 1);
  const content = await page.getTextContent();
  let out = "";
  let lastY: number | null = null;
  for (const item of content.items) {
    if (!("str" in item)) continue;
    const y = "transform" in item ? item.transform[5] : null;
    if (lastY !== null && y !== null && Math.abs(y - lastY) > 2) out += "\n";
    out += item.str;
    if ("hasEOL" in item && item.hasEOL) out += "\n";
    lastY = y;
  }
  return out.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}

/**
 * Aperçu SVG réel d'une page Design (fond + éléments, images incluses).
 * Utilisé par le mode Lecture. Rendu local, aucune ressource externe.
 */
export async function renderDesignPageSvg(
  doc: import("@/lib/types").AlteosDoc,
  pageId: string,
  scale: number
): Promise<SVGSVGElement> {
  const { getAsset } = await import("@/lib/idb");
  const { fontStack } = await import("@/lib/fonts");
  const page = doc.designPages.find((p) => p.id === pageId);
  if (!page) throw new Error("Page introuvable.");
  const W = page.w * scale;
  const H = page.h * scale;
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("width", String(Math.round(W)));
  svg.setAttribute("height", String(Math.round(H)));
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  svg.style.maxWidth = "min(100vw - 2rem, 1100px)";
  svg.style.maxHeight = "calc(100vh - 8rem)";
  svg.style.boxShadow = "0 18px 60px rgba(0,0,0,0.55)";
  svg.style.borderRadius = "4px";
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", `Aperçu de la page`);

  const bg = document.createElementNS(NS, "rect");
  bg.setAttribute("x", "0");
  bg.setAttribute("y", "0");
  bg.setAttribute("width", String(W));
  bg.setAttribute("height", String(H));
  bg.setAttribute("fill", page.background || "#FFFFFF");
  svg.appendChild(bg);

  const el = (tag: string, attrs: Record<string, string | number>) => {
    const node = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, String(v));
    return node;
  };

  const items = doc.items.filter((it) => it.pageId === pageId && !it.hidden);
  for (const it of items) {
    const x = it.x * scale;
    const y = it.y * scale;
    const w = it.w * scale;
    const h = it.h * scale;
    switch (it.type) {
      case "highlight":
        for (const q of it.quads) {
          svg.appendChild(el("rect", { x: q.x * scale, y: q.y * scale, width: q.w * scale, height: q.h * scale, fill: it.color, opacity: 0.38 }));
        }
        break;
      case "underline":
      case "strike":
        for (const q of it.quads) {
          const band = Math.max(1.5, q.h * scale * 0.07);
          svg.appendChild(
            el("rect", {
              x: q.x * scale,
              y: (it.type === "underline" ? q.y + q.h : q.y + q.h / 2) * scale - band / 2,
              width: q.w * scale,
              height: band,
              fill: it.color,
            })
          );
        }
        break;
      case "rect":
        svg.appendChild(
          el("rect", {
            x,
            y,
            width: w,
            height: h,
            fill: it.fill ? it.fillColor : "none",
            stroke: it.color,
            "stroke-width": Math.max(1, it.strokeWidth * scale),
            opacity: it.opacity,
          })
        );
        break;
      case "ellipse":
        svg.appendChild(
          el("ellipse", {
            cx: x + w / 2,
            cy: y + h / 2,
            rx: w / 2,
            ry: h / 2,
            fill: it.fill ? it.fillColor : "none",
            stroke: it.color,
            "stroke-width": Math.max(1, it.strokeWidth * scale),
            opacity: it.opacity,
          })
        );
        break;
      case "line":
      case "arrow": {
        const x2 = it.x2 * scale;
        const y2 = it.y2 * scale;
        svg.appendChild(el("line", { x1: x, y1: y, x2, y2, stroke: it.color, "stroke-width": Math.max(1, it.strokeWidth * scale), "stroke-linecap": "round" }));
        if (it.type === "arrow") {
          const angle = Math.atan2(y2 - y, x2 - x);
          const hl = Math.max(9, it.strokeWidth * 3.5) * scale;
          for (const off of [Math.PI - 0.42, Math.PI + 0.42]) {
            svg.appendChild(
              el("line", {
                x1: x2,
                y1: y2,
                x2: x2 + Math.cos(angle + off) * hl,
                y2: y2 + Math.sin(angle + off) * hl,
                stroke: it.color,
                "stroke-width": Math.max(1, it.strokeWidth * scale),
                "stroke-linecap": "round",
              })
            );
          }
        }
        break;
      }
      case "draw": {
        if (it.points.length < 2) break;
        svg.appendChild(
          el("polyline", {
            points: it.points.map((p) => `${p.x * scale},${p.y * scale}`).join(" "),
            fill: "none",
            stroke: it.color,
            "stroke-width": Math.max(1, it.strokeWidth * scale),
            "stroke-linecap": "round",
            "stroke-linejoin": "round",
          })
        );
        break;
      }
      case "text": {
        const fo = document.createElementNS(NS, "foreignObject");
        fo.setAttribute("x", String(x));
        fo.setAttribute("y", String(y));
        fo.setAttribute("width", String(Math.max(w, 40)));
        fo.setAttribute("height", String(Math.max(h, it.fontSize * scale * 1.4)));
        const div = document.createElement("div");
        div.style.cssText = [
          `font-family:${fontStack(it.fontFamily)}`,
          `font-size:${it.fontSize * scale}px`,
          `font-weight:${it.bold ? 700 : 400}`,
          `font-style:${it.italic ? "italic" : "normal"}`,
          `text-decoration:${it.underline ? "underline" : "none"}`,
          `color:${it.color}`,
          `text-align:${it.align}`,
          "line-height:1.28",
          "white-space:pre-wrap",
          "word-break:break-word",
          "overflow:visible",
        ].join(";");
        div.textContent = it.text;
        fo.appendChild(div);
        svg.appendChild(fo);
        break;
      }
      case "note": {
        const g = document.createElementNS(NS, "g");
        g.appendChild(el("rect", { x, y, width: Math.max(w, 90), height: Math.max(h, 22), rx: 5, fill: "#F0EEE9", stroke: "#C9C4BA", "stroke-width": 1 }));
        const fo = document.createElementNS(NS, "foreignObject");
        fo.setAttribute("x", String(x + 5));
        fo.setAttribute("y", String(y + 3));
        fo.setAttribute("width", String(Math.max(w, 90) - 10));
        fo.setAttribute("height", String(Math.max(h, 22) - 6));
        const div = document.createElement("div");
        div.style.cssText = `font-size:${Math.max(9, 10 * scale)}px;color:#4A4844;overflow:hidden`;
        div.textContent = it.text;
        fo.appendChild(div);
        g.appendChild(fo);
        svg.appendChild(g);
        break;
      }
      case "image":
      case "signature": {
        try {
          const asset = await getAsset(it.assetId);
          if (!asset) break;
          const url = URL.createObjectURL(asset.blob);
          const img = el("image", {
            x,
            y,
            width: w,
            height: h,
            href: url,
            opacity: it.opacity ?? 1,
          });
          const isImg = it.type === "image";
          if (it.rotation || (isImg && (it.flipH || it.flipV || it.filters))) {
            const transforms: string[] = [];
            if (it.rotation) transforms.push(`rotate(${it.rotation} ${x + w / 2} ${y + h / 2})`);
            if (isImg && (it.flipH || it.flipV)) transforms.push(`translate(${x + w / 2} ${y + h / 2}) scale(${it.flipH ? -1 : 1} ${it.flipV ? -1 : 1}) translate(${-(x + w / 2)} ${-(y + h / 2)})`);
            img.setAttribute("transform", transforms.join(" "));
          }
          if (isImg && it.filters) {
            const { filtersToCss } = await import("@/lib/types");
            const css = filtersToCss(it.filters);
            if (css !== "none") img.setAttribute("style", `filter:${css}`);
          }
          svg.appendChild(img);
          // L'URL d'objet reste valide tant que le SVG est affiché ; nettoyage à la destruction.
          setTimeout(() => URL.revokeObjectURL(url), 60_000);
        } catch {
          /* asset manquant : ignoré */
        }
        break;
      }
      case "qr": {
        try {
          const { qrDataUrl } = await import("@/lib/qr");
          const url = await qrDataUrl(it.data, it.fg, it.bg, 256);
          svg.appendChild(el("image", { x, y, width: w, height: h, href: url }));
        } catch {
          svg.appendChild(el("rect", { x, y, width: w, height: h, fill: "none", stroke: it.fg, "stroke-width": 1, "stroke-dasharray": "3 3" }));
        }
        break;
      }
      case "icon": {
        const { iconFullSvg } = await import("@/lib/icon-paths");
        const markup = iconFullSvg(it.iconId, it.color);
        if (!markup) break;
        // SVG imbriqué : viewBox 24×24 mis à l'échelle de l'élément.
        const inner = new DOMParser().parseFromString(markup, "image/svg+xml").documentElement;
        inner.removeAttribute("width");
        inner.removeAttribute("height");
        inner.setAttribute("x", String(x));
        inner.setAttribute("y", String(y));
        inner.setAttribute("width", String(w));
        inner.setAttribute("height", String(h));
        svg.appendChild(document.importNode(inner, true));
        break;
      }
    }
  }
  return svg;
}
