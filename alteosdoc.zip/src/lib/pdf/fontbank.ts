/**
 * AlteOS Docs — Banque de polices pour l'export PDF.
 * -----------------------------------------------------
 * Deux sources :
 *  1. Polices standard PDF (Helvetica, Times, Courier) — métriques intégrées
 *     à pdf-lib, toujours disponibles hors ligne.
 *  2. Familles Google choisies par l'utilisateur — le fichier TTF plein-jeu
 *     est téléchargé depuis fonts.gstatic.com DANS le navigateur, puis
 *     incorporé et sous-ensemblé dans le PDF (pdf-lib + fontkit). Aucun
 *     envoi de données : seul le fichier de police transite.
 *
 * Repli honnête : si le téléchargement échoue (hors ligne, réseau bloqué),
 * le texte est exporté avec la police standard PDF équivalente par catégorie
 * (sans-serif → Helvetica, serif → Times, monospace → Courier).
 */

import fontkit from "@pdf-lib/fontkit";
import type { PDFFont, PDFDocument } from "pdf-lib";

import { GOOGLE_TTF } from "@/lib/fonts-ttf";
import { getFont, stdFallbackId, type FontDef } from "@/lib/fonts";
import type { TextItem } from "@/lib/types";

export const STD_FONT_NAMES = [
  "Helvetica",
  "Helvetica-Bold",
  "Helvetica-Oblique",
  "Helvetica-BoldOblique",
  "Times-Roman",
  "Times-Bold",
  "Times-Italic",
  "Times-BoldItalic",
  "Courier",
  "Courier-Bold",
  "Courier-Oblique",
  "Courier-BoldOblique",
] as const;

export type StdFontName = (typeof STD_FONT_NAMES)[number];

/** Nom de police standard PDF équivalente à une police du registre. */
export function stdNameFor(id: string, style: { bold: boolean; italic: boolean }): StdFontName {
  const f: FontDef = getFont(id) ?? { id, name: id, cat: "sans", src: "system" };
  const base = stdFallbackId(f);
  const { bold, italic } = style;
  if (base === "Times") {
    if (bold && italic) return "Times-BoldItalic";
    if (bold) return "Times-Bold";
    if (italic) return "Times-Italic";
    return "Times-Roman";
  }
  if (base === "Courier") {
    if (bold && italic) return "Courier-BoldOblique";
    if (bold) return "Courier-Bold";
    if (italic) return "Courier-Oblique";
    return "Courier";
  }
  if (bold && italic) return "Helvetica-BoldOblique";
  if (bold) return "Helvetica-Bold";
  if (italic) return "Helvetica-Oblique";
  return "Helvetica";
}

type GoogleFile = "r400" | "r700" | "i400";

export interface ResolvedItemFont {
  font: PDFFont;
  /** Vraie police Google incorporée (jeu de caractères étendu autorisé). */
  custom: boolean;
  /** Dessiner un faux gras (double passe décalée) — famille sans graisse 700. */
  fauxBold: boolean;
}

export interface FontVariants {
  r: PDFFont;
  b: PDFFont;
  i: PDFFont;
  bi: PDFFont;
  hasBold: boolean;
  hasItalic: boolean;
  /** Chaque variante est-elle une police Google réellement incorporée ? */
  custom: { r: boolean; b: boolean; i: boolean; bi: boolean };
}

/** Cache module-level des octets TTF — partagé entre les exports de la session. */
const ttfCache = new Map<string, Uint8Array>();

async function fetchTtf(url: string): Promise<Uint8Array | null> {
  const hit = ttfCache.get(url);
  if (hit) return hit;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length < 1024) return null;
    ttfCache.set(url, bytes);
    return bytes;
  } catch {
    return null;
  }
}

export class FontBank {
  /** Polices standard (accès synchrone pour notes, replis, etc.). */
  readonly std = new Map<string, PDFFont>();
  private custom = new Map<string, PDFFont>();
  private failed = new Set<string>();

  private constructor(private pdf: PDFDocument) {
    pdf.registerFontkit(fontkit);
  }

  /** Crée la banque et précharge les 12 polices standard. */
  static async create(pdf: PDFDocument): Promise<FontBank> {
    const bank = new FontBank(pdf);
    for (const name of STD_FONT_NAMES) {
      bank.std.set(name, await pdf.embedFont(name));
    }
    return bank;
  }

  /** Incorpore (ou récupère) un fichier d'une famille Google. null si impossible. */
  private async embedFile(id: string, file: GoogleFile): Promise<PDFFont | null> {
    const key = `${id}|${file}`;
    const cached = this.custom.get(key);
    if (cached) return cached;
    if (this.failed.has(key)) return null;
    const url = GOOGLE_TTF[id]?.[file];
    if (!url) {
      this.failed.add(key);
      return null;
    }
    const bytes = await fetchTtf(url);
    if (!bytes) {
      this.failed.add(key);
      return null;
    }
    try {
      const font = await this.pdf.embedFont(bytes, { subset: true });
      this.custom.set(key, font);
      return font;
    } catch {
      try {
        // Certaines familles ne supportent pas le sous-ensemblage : incorporation complète
        const font = await this.pdf.embedFont(bytes, { subset: false });
        this.custom.set(key, font);
        return font;
      } catch {
        this.failed.add(key);
        return null;
      }
    }
  }

  /** Précharge en parallèle les polices nécessaires aux éléments texte. */
  async preloadItems(items: Array<{ type: string; fontFamily?: string; bold?: boolean; italic?: boolean }>): Promise<void> {
    const jobs: Promise<unknown>[] = [];
    for (const it of items) {
      if (it.type !== "text" || !it.fontFamily) continue;
      jobs.push(
        this.forItem({
          type: "text",
          fontFamily: it.fontFamily,
          bold: !!it.bold,
          italic: !!it.italic,
        } as TextItem)
      );
    }
    await Promise.all(jobs);
  }

  /** Police à utiliser pour un élément texte (Google incorporée ou repli standard). */
  async forItem(item: TextItem): Promise<ResolvedItemFont> {
    const id = item.fontFamily;
    const f = getFont(id);
    const files = GOOGLE_TTF[id];
    const isGoogle = !!f && f.src === "google" && !!files;
    if (!isGoogle) {
      return { font: this.std.get(stdNameFor(id, item))!, custom: false, fauxBold: false };
    }
    const file: GoogleFile = item.bold
      ? files.r700
        ? "r700"
        : "r400"
      : item.italic && files.i400
        ? "i400"
        : "r400";
    const font = await this.embedFile(id, file);
    if (!font) {
      return { font: this.std.get(stdNameFor(id, item))!, custom: false, fauxBold: false };
    }
    return { font, custom: true, fauxBold: item.bold && !files.r700 };
  }

  /** Variantes (régulier / gras / italique / gras-italique) d'une famille, pour le moteur de blocs. */
  async variants(id: string): Promise<FontVariants> {
    const f = getFont(id);
    const files = GOOGLE_TTF[id];
    const isGoogle = !!f && f.src === "google" && !!files;

    if (!isGoogle) {
      return {
        r: this.std.get(stdNameFor(id, { bold: false, italic: false }))!,
        b: this.std.get(stdNameFor(id, { bold: true, italic: false }))!,
        i: this.std.get(stdNameFor(id, { bold: false, italic: true }))!,
        bi: this.std.get(stdNameFor(id, { bold: true, italic: true }))!,
        hasBold: true,
        hasItalic: true,
        custom: { r: false, b: false, i: false, bi: false },
      };
    }

    const rFont = await this.embedFile(id, "r400");
    const bFont = await this.embedFile(id, "r700");
    const iFont = await this.embedFile(id, "i400");
    const r = rFont ?? this.std.get(stdNameFor(id, { bold: false, italic: false }))!;
    const b = bFont ?? r;
    const i = iFont ?? r;
    const bi = bFont ? b : iFont ? i : r;
    return {
      r,
      b,
      i,
      bi,
      hasBold: !!files.r700,
      hasItalic: !!files.i400,
      custom: {
        r: !!rFont,
        b: !!bFont,
        i: !!iFont,
        bi: !!bFont || !!iFont,
      },
    };
  }
}
