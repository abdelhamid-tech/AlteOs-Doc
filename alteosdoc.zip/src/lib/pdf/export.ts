/**
 * AlteOS Docs — Export local (pdf-lib)
 * ------------------------------------
 * PDF et PNG générés intégralement dans le navigateur.
 * Les annotations, textes, images, formes et signatures ajoutés sont
 * réellement intégrés au fichier exporté.
 */

import { PDFDocument, degrees, rgb, type PDFFont } from "pdf-lib";

import { getAsset } from "@/lib/idb";
import type { AlteosDoc, Block, Item, PageRef } from "@/lib/types";
import { hexToRgb01, toExportText, toWinAnsi } from "@/lib/utils";
import { drawItemsOnPage, type DrawContext } from "./items-draw";
import { type ImageQuality } from "./assets";
import { FontBank, type FontVariants } from "./fontbank";

export interface ExportOptions {
  /** Pages à exporter (ids PageRef) — undefined = toutes. */
  pageIds?: string[];
  /** Qualité de ré-encodage des images. */
  quality: ImageQuality;
  /** Compression structurelle (object streams). */
  compact: boolean;
  /** Décor de page (filigrane, numéros, en-tête/pied) — PDF et Design. */
  decor?: PageDecor;
  /** Métadonnées du fichier exporté. */
  metadata?: PdfMetadata;
}

export const DEFAULT_EXPORT_OPTIONS: ExportOptions = {
  quality: "standard",
  compact: true,
};

/** Décor appliqué réellement sur chaque page exportée (pdf-lib). */
export interface PageDecor {
  /** Filigrane diagonal (vide = aucun). */
  watermarkText: string;
  watermarkColor: string;
  watermarkOpacity: number; // 0.03..0.6
  watermarkSize: number; // pt
  watermarkAngle: number; // degrés (sens anti-horaire visuel)
  /** Numéros de page. */
  pageNumbers: "none" | "bottom-center" | "bottom-right" | "bottom-left";
  numberFormat: "n" | "n/total";
  /** En-tête / pied de page (texte simple, centré). */
  header: string;
  footer: string;
}

export const DEFAULT_PAGE_DECOR: PageDecor = {
  watermarkText: "",
  watermarkColor: "#8A8782",
  watermarkOpacity: 0.14,
  watermarkSize: 44,
  watermarkAngle: 45,
  pageNumbers: "none",
  numberFormat: "n",
  header: "",
  footer: "",
};

export interface PdfMetadata {
  title?: string;
  author?: string;
  subject?: string;
  keywords?: string;
}

type FontMap = Map<string, PDFFont>;

/** Crée la banque (12 polices standard incorporées d'avance) + précharge les polices Google des éléments. */
async function makeFonts(out: PDFDocument, textItems: Item[] = [], baseFont?: string): Promise<{ bank: FontBank; fonts: FontMap }> {
  const bank = await FontBank.create(out);
  await bank.preloadItems(textItems);
  if (baseFont) await bank.variants(baseFont);
  return { bank, fonts: bank.std };
}

/** Applique les métadonnées honnêtement présentes dans le fichier exporté. */
function applyMetadata(out: PDFDocument, docName: string, meta?: PdfMetadata): void {
  out.setTitle(toWinAnsi(meta?.title?.trim() || docName));
  out.setProducer("AlteOS Docs");
  out.setCreator("AlteOS Docs — export local");
  if (meta?.author?.trim()) out.setAuthor(toWinAnsi(meta.author.trim()).slice(0, 120));
  if (meta?.subject?.trim()) out.setSubject(toWinAnsi(meta.subject.trim()).slice(0, 200));
  if (meta?.keywords?.trim()) out.setKeywords(toWinAnsi(meta.keywords.trim()).slice(0, 200).split(/[,;\n]/).map((k) => k.trim()).filter(Boolean));
}

/** Dessine le décor d'une page (filigrane sous les annotations, en-tête/pied/numéros au-dessus). */
function drawPageDecor(
  page: import("pdf-lib").PDFPage,
  pageW: number,
  pageH: number,
  decor: PageDecor,
  pageIndex: number,
  total: number,
  font: PDFFont
): void {
  const wm = decor.watermarkText.trim();
  if (wm) {
    const text = toWinAnsi(wm).slice(0, 60);
    const size = Math.max(10, decor.watermarkSize);
    const tw = font.widthOfTextAtSize(text, size);
    const a = ((decor.watermarkAngle % 360) + 360) % 360;
    const rad = (a * Math.PI) / 180;
    // Ancre : centre du texte tourné (mi-longueur le long du tracé).
    const cx = pageW / 2;
    const cy = pageH / 2;
    const x = cx - (tw / 2) * Math.cos(rad);
    const y = cy - (tw / 2) * Math.sin(rad) - size * 0.32;
    const c = hexToRgb01(decor.watermarkColor);
    page.drawText(text, {
      x,
      y,
      size,
      font,
      color: rgb(c.r, c.g, c.b),
      opacity: Math.min(0.6, Math.max(0.03, decor.watermarkOpacity)),
      rotate: degrees(a),
    });
  }
  const gray = rgb(0.45, 0.45, 0.43);
  if (decor.header.trim()) {
    const text = toWinAnsi(decor.header.trim()).slice(0, 90);
    const size = 8.5;
    const w = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: (pageW - w) / 2, y: pageH - 24, size, font, color: gray });
    page.drawLine({ start: { x: 36, y: pageH - 29 }, end: { x: pageW - 36, y: pageH - 29 }, thickness: 0.6, color: rgb(0.85, 0.85, 0.83) });
  }
  const num = decor.numberFormat === "n/total" ? `${pageIndex + 1} / ${total}` : `${pageIndex + 1}`;
  if (decor.pageNumbers !== "none") {
    const size = 9;
    const w = font.widthOfTextAtSize(num, size);
    const x = decor.pageNumbers === "bottom-center" ? (pageW - w) / 2 : decor.pageNumbers === "bottom-right" ? pageW - 36 - w : 36;
    page.drawText(num, { x, y: 16, size, font, color: rgb(0.5, 0.5, 0.48) });
  }
  if (decor.footer.trim()) {
    const text = toWinAnsi(decor.footer.trim()).slice(0, 90);
    const size = 8.5;
    const w = font.widthOfTextAtSize(text, size);
    // Si les numéros occupent le bas-centre, le pied remonte légèrement.
    const y = decor.pageNumbers === "bottom-center" ? 30 : 16;
    page.drawText(text, { x: (pageW - w) / 2, y, size, font, color: gray });
  }
}

// ---------------------------------------------------------------------------
// Export PDF (mode pdf) : pages + éléments
// ---------------------------------------------------------------------------

export async function exportPdfDoc(docState: AlteosDoc, opts: ExportOptions): Promise<Blob> {
  if (!docState.pdfBytes) throw new Error("Ce document ne contient pas de PDF.");
  const src = await PDFDocument.load(docState.pdfBytes.slice(0), { ignoreEncryption: true });
  const out = await PDFDocument.create();

  // Les éléments masqués (panneau Calques) ne partent pas à l'export.
  const visibleItems = docState.items.filter((it) => !it.hidden);
  const pageRefs: PageRef[] = opts.pageIds ? docState.pages.filter((p) => opts.pageIds!.includes(p.id)) : docState.pages;
  if (pageRefs.length === 0) throw new Error("Aucune page à exporter.");

  const itemsByPage = new Map<string, Item[]>();
  for (const it of visibleItems) {
    const arr = itemsByPage.get(it.pageId) ?? [];
    arr.push(it);
    itemsByPage.set(it.pageId, arr);
  }

  const copied = await out.copyPages(
    src,
    pageRefs.map((p) => p.src)
  );
  const { bank, fonts } = await makeFonts(out, visibleItems);
  const decor = opts.decor;

  for (let i = 0; i < pageRefs.length; i++) {
    const ref = pageRefs[i];
    const page = copied[i];
    const native = page.getRotation().angle ?? 0;
    const total = (((native + ref.rotation) % 360) + 360) % 360;
    page.setRotation(degrees(total));

    const size = docState.srcPageSizes[ref.src] ?? { w: 595.28, h: 841.89 };
    const ctx: DrawContext = {
      page,
      pageW: size.w,
      pageH: size.h,
      fonts,
      bank,
      embedImage: async (bytes, mime) => (mime === "image/jpeg" ? out.embedJpg(bytes) : out.embedPng(bytes)),
      quality: opts.quality,
    };
    // Filigrane SOUS les annotations (opacité faible, lisible des deux côtés).
    if (decor && (decor.watermarkText.trim() || decor.header.trim() || decor.footer.trim() || decor.pageNumbers !== "none")) {
      drawPageDecor(page, size.w, size.h, decor, i, pageRefs.length, fonts.get("Helvetica")!);
    }
    const items = (itemsByPage.get(ref.id) ?? []).sort((a, b) => a.createdAt - b.createdAt);
    await drawItemsOnPage(ctx, items);
    out.addPage(page);
  }

  applyMetadata(out, docState.name, opts.metadata);

  const bytes = await out.save({ useObjectStreams: opts.compact, addDefaultPage: false });
  return new Blob([bytes as unknown as BlobPart], { type: "application/pdf" });
}

/** Extraction : exporte uniquement certaines pages, éléments inclus. */
export async function extractPagesToDoc(docState: AlteosDoc, pageIds: string[]): Promise<Blob> {
  return exportPdfDoc(docState, { ...DEFAULT_EXPORT_OPTIONS, pageIds });
}

// ---------------------------------------------------------------------------
// Fusion : concatène les PDF sources COMPLETS en préservant les index de
// pages (les éléments et opérations existantes restent valides).
// ---------------------------------------------------------------------------

export async function mergePdfSources(
  baseBytes: ArrayBuffer,
  extraBytes: ArrayBuffer
): Promise<{ bytes: ArrayBuffer; baseCount: number; extraCount: number }> {
  const base = await PDFDocument.load(baseBytes.slice(0), { ignoreEncryption: true });
  const extra = await PDFDocument.load(extraBytes.slice(0), { ignoreEncryption: true });
  const out = await PDFDocument.create();

  const basePages = await out.copyPages(base, base.getPageIndices());
  for (const p of basePages) out.addPage(p);
  const extraPages = await out.copyPages(extra, extra.getPageIndices());
  for (const p of extraPages) out.addPage(p);

  const bytes = await out.save({ useObjectStreams: true });
  return {
    bytes: bytes.slice().buffer as ArrayBuffer,
    baseCount: base.getPageCount(),
    extraCount: extra.getPageCount(),
  };
}

// ---------------------------------------------------------------------------
// Export PDF (mode Design) — pages vierges + éléments
// ---------------------------------------------------------------------------

export async function exportDesignPdf(docState: AlteosDoc, opts: ExportOptions): Promise<Blob> {
  const out = await PDFDocument.create();
  // Les éléments masqués (panneau Calques) ne partent pas à l'export.
  const visibleItems = docState.items.filter((it) => !it.hidden);
  const { bank, fonts } = await makeFonts(out, visibleItems);

  const itemsByPage = new Map<string, Item[]>();
  for (const it of visibleItems) {
    const arr = itemsByPage.get(it.pageId) ?? [];
    arr.push(it);
    itemsByPage.set(it.pageId, arr);
  }

  const pages = docState.designPages.length
    ? docState.designPages
    : [{ id: "pg-1", w: 595.28, h: 841.89, background: "#FFFFFF" }];
  for (let i = 0; i < pages.length; i++) {
    const dp = pages[i];
    const page = out.addPage([dp.w, dp.h]);
    if (dp.background && dp.background.toUpperCase() !== "#FFFFFF") {
      const bg = hexToRgb01(dp.background);
      page.drawRectangle({ x: 0, y: 0, width: dp.w, height: dp.h, color: rgb(bg.r, bg.g, bg.b) });
    }
    if (opts.decor && (opts.decor.watermarkText.trim() || opts.decor.header.trim() || opts.decor.footer.trim() || opts.decor.pageNumbers !== "none")) {
      drawPageDecor(page, dp.w, dp.h, opts.decor, i, pages.length, fonts.get("Helvetica")!);
    }
    const ctx: DrawContext = {
      page,
      pageW: dp.w,
      pageH: dp.h,
      fonts,
      bank,
      embedImage: async (bytes, mime) => (mime === "image/jpeg" ? out.embedJpg(bytes) : out.embedPng(bytes)),
      quality: opts.quality,
    };
    const items = (itemsByPage.get(dp.id) ?? []).sort((a, b) => a.createdAt - b.createdAt);
    await drawItemsOnPage(ctx, items);
  }

  applyMetadata(out, docState.name, opts.metadata);
  const bytes = await out.save({ useObjectStreams: opts.compact });
  return new Blob([bytes as unknown as BlobPart], { type: "application/pdf" });
}

// ---------------------------------------------------------------------------
// Export PNG d'une page PDF (rendu local via pdf.js)
// ---------------------------------------------------------------------------

export async function exportPdfPageAsPng(
  pdfDoc: import("pdfjs-dist").PDFDocumentProxy,
  srcIndex: number,
  userRotation: number,
  pixelScale = 2
): Promise<Blob> {
  const { getPdfJs } = await import("./engine");
  const pdfjs = await getPdfJs();
  const page = await pdfDoc.getPage(srcIndex + 1);
  const rotation = (((page.rotate + userRotation) % 360) + 360) % 360;
  const viewport = page.getViewport({ scale: pixelScale, rotation });
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  const ctx = canvas.getContext("2d")!;
  await page.render({ canvasContext: ctx, viewport }).promise;
  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
  if (!blob) throw new Error("La génération de l'image a échoué.");
  return blob;
}

// ---------------------------------------------------------------------------
// Blocs → PDF (modes Document et Formulaire)
// ---------------------------------------------------------------------------

export interface BlocksExportOptions {
  quality: ImageQuality;
  compact: boolean;
  /** Formulaires : champs PDF remplissables (sinon valeurs imprimées). */
  fillableForm: boolean;
  /** Métadonnées du fichier exporté. */
  metadata?: PdfMetadata;
}

const A4 = { w: 595.28, h: 841.89 };

interface Run {
  text: string;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  color: string;
  link: string | null;
}

/** Parse le HTML riche des blocs en paragraphes de runs. */
export function parseRichRuns(html: string): Run[][] {
  if (typeof window === "undefined") return [];
  const container = document.createElement("div");
  container.innerHTML = html;
  const paragraphs: Run[][] = [];

  const walk = (node: Node, style: Partial<Run>, sink: (r: Run) => void) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = (node.textContent ?? "").replace(/\u00A0/g, " ");
      if (text) {
        sink({
          text,
          bold: !!style.bold,
          italic: !!style.italic,
          underline: !!style.underline,
          color: style.color ?? "#1C1B1A",
          link: style.link ?? null,
        });
      }
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const el = node as HTMLElement;
    const tag = el.tagName.toLowerCase();
    if (tag === "br") {
      sink({ text: "\n", bold: false, italic: false, underline: false, color: "#1C1B1A", link: null });
      return;
    }
    const next: Partial<Run> = { ...style };
    if (tag === "b" || tag === "strong") next.bold = true;
    if (tag === "i" || tag === "em") next.italic = true;
    if (tag === "u") next.underline = true;
    if (tag === "a") next.link = el.getAttribute("href");
    if (tag === "span") {
      const c = el.style.color;
      if (c) next.color = c;
    }
    for (const child of Array.from(el.childNodes)) walk(child, next, sink);
  };

  const current: Run[] = [];
  const flush = () => {
    if (current.length) paragraphs.push([...current]);
    current.length = 0;
  };
  for (const b of Array.from(container.childNodes)) {
    if (b.nodeType === Node.TEXT_NODE) {
      if ((b.textContent ?? "").trim() === "") continue;
    }
    walk(b, {}, (r) => {
      if (r.text === "\n") {
        flush();
        return;
      }
      current.push(r);
    });
  }
  flush();
  return paragraphs;
}

function styleToFont(ctx: LayoutCtx, style: { bold: boolean; italic: boolean }): { font: PDFFont; fauxBold: boolean; custom: boolean } {
  const V = ctx.docFont;
  if (style.bold && style.italic) return { font: V.bi, fauxBold: !V.hasBold && !V.hasItalic, custom: V.custom.bi };
  if (style.bold) return { font: V.b, fauxBold: !V.hasBold, custom: V.custom.b };
  if (style.italic) return { font: V.i, fauxBold: false, custom: V.custom.i };
  return { font: V.r, fauxBold: false, custom: V.custom.r };
}

interface LayoutCtx {
  out: PDFDocument;
  fonts: FontMap;
  /** Variantes de la police de base du document (Google incorporée ou standard). */
  docFont: FontVariants;
  page: Awaited<ReturnType<PDFDocument["addPage"]>> | null;
  x: number;
  y: number; // haut du curseur, espace TL
  pageW: number;
  pageH: number;
  margin: number;
  pageIndex: number;
  header: string;
  footer: string;
  pageNumbers: "none" | "bottom-center" | "bottom-right";
  showHeaderOnFirstPage: boolean;
}

async function newPage(ctx: LayoutCtx): Promise<void> {
  ctx.page = ctx.out.addPage([ctx.pageW, ctx.pageH]);
  ctx.pageIndex++;
  ctx.x = ctx.margin;
  ctx.y = ctx.margin;
  decoratePage(ctx);
}

function decoratePage(ctx: LayoutCtx): void {
  const page = ctx.page!;
  const showHeader = ctx.header !== "" && (ctx.pageIndex > 0 || ctx.showHeaderOnFirstPage);
  if (showHeader) {
    // En-tête en italique léger quand la police le permet, sinon régulier
    const font = ctx.docFont.hasItalic ? ctx.docFont.i : ctx.docFont.r;
    const text = toWinAnsi(ctx.header).slice(0, 90);
    const size = 8.5;
    const w = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: (ctx.pageW - w) / 2, y: ctx.pageH - ctx.margin + 14, size, font, color: rgb(0.45, 0.45, 0.43) });
    page.drawLine({
      start: { x: ctx.margin, y: ctx.pageH - ctx.margin + 8 },
      end: { x: ctx.pageW - ctx.margin, y: ctx.pageH - ctx.margin + 8 },
      thickness: 0.6,
      color: rgb(0.85, 0.85, 0.83),
    });
  }
  if (ctx.footer !== "") {
    const font = ctx.docFont.r;
    const text = toWinAnsi(ctx.footer).slice(0, 90);
    const size = 8.5;
    const w = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: (ctx.pageW - w) / 2, y: ctx.margin - 22, size, font, color: rgb(0.45, 0.45, 0.43) });
  }
  if (ctx.pageNumbers !== "none") {
    const font = ctx.docFont.r;
    const text = `${ctx.pageIndex + 1}`;
    const size = 9;
    const w = font.widthOfTextAtSize(text, size);
    const x = ctx.pageNumbers === "bottom-center" ? (ctx.pageW - w) / 2 : ctx.pageW - ctx.margin - w;
    page.drawText(text, { x, y: ctx.margin - 36, size, font, color: rgb(0.5, 0.5, 0.48) });
  }
}

function ensureSpace(ctx: LayoutCtx, needed: number): Promise<void> {
  if (ctx.y + needed > ctx.pageH - ctx.margin) {
    return newPage(ctx);
  }
  return Promise.resolve();
}

function drawRunsLine(
  ctx: LayoutCtx,
  page: NonNullable<LayoutCtx["page"]>,
  runs: { text: string; font: PDFFont; fauxBold: boolean; custom: boolean; size: number; color: string; underline: boolean; link: string | null }[],
  x: number,
  yTop: number,
  maxW: number,
  align: "left" | "center" | "right"
): void {
  const totalW = runs.reduce((s, r) => s + r.font.widthOfTextAtSize(r.text, r.size), 0);
  let cursor = x;
  if (align === "center") cursor = x + (maxW - totalW) / 2;
  if (align === "right") cursor = x + maxW - totalW;
  const firstFont = runs[0].font;
  const asc = firstFont.heightAtSize(runs[0].size, { descender: false });
  for (const r of runs) {
    const font = r.font;
    const baselinePdf = ctx.pageH - yTop - asc;
    const drawColor = hexToRgb01(r.link ? "#0E7C66" : r.color);
    // Police Google incorporée → jeu étendu (œ, «», —) ; police standard → WinAnsi
    const text = r.custom ? toExportText(r.text) : toWinAnsi(r.text);
    const textW = font.widthOfTextAtSize(text, r.size);
    const drawAt = (dx: number) =>
      page.drawText(text, {
        x: dx,
        y: baselinePdf,
        size: r.size,
        font,
        color: rgb(drawColor.r, drawColor.g, drawColor.b),
      });
    drawAt(cursor);
    if (r.fauxBold) {
      // Faux gras : seconde passe décalée (police sans graisse 700)
      drawAt(cursor + Math.max(0.2, r.size * 0.02));
    }
    if (r.underline || r.link) {
      page.drawLine({
        start: { x: cursor, y: baselinePdf - 1.6 },
        end: { x: cursor + textW, y: baselinePdf - 1.6 },
        thickness: Math.max(0.6, r.size * 0.055),
        color: rgb(drawColor.r, drawColor.g, drawColor.b),
      });
    }
    if (r.link && /^https?:\/\//i.test(r.link)) {
      try {
        const linkAnnot = ctx.out.context.obj({
          Type: "Annot",
          Subtype: "Link",
          Rect: [cursor, baselinePdf - 2, cursor + textW, baselinePdf + r.size],
          Border: [0, 0, 0],
          C: [0.05, 0.49, 0.4],
          A: { Type: "Action", S: "URI", URI: r.link },
        });
        const ref = ctx.out.context.register(linkAnnot);
        page.node.addAnnot(ref);
      } catch {
        // annotation optionnelle : le texte stylisé reste correct
      }
    }
    cursor += textW;
  }
}

interface WordToken {
  text: string;
  font: PDFFont;
  fauxBold: boolean;
  custom: boolean;
  size: number;
  color: string;
  underline: boolean;
  link: string | null;
  w: number;
}

function tokenizeRuns(ctx: LayoutCtx, runs: Run[], size: number): WordToken[] {
  const tokens: WordToken[] = [];
  for (const run of runs) {
    const { font, fauxBold, custom } = styleToFont(ctx, { bold: run.bold, italic: run.italic });
    const pieces = run.text.split(/(\s+)/).filter((p) => p !== "");
    for (const piece of pieces) {
      tokens.push({
        text: piece,
        font,
        fauxBold,
        custom,
        size,
        color: run.color,
        underline: run.underline,
        link: run.link,
        w: font.widthOfTextAtSize(piece, size),
      });
    }
  }
  return tokens;
}

function wrapTokens(tokens: WordToken[], maxW: number): WordToken[][] {
  const lines: WordToken[][] = [];
  let line: WordToken[] = [];
  let w = 0;
  for (const t of tokens) {
    if (w + t.w > maxW && line.some((x) => x.text.trim() !== "")) {
      while (line.length && line[line.length - 1].text.trim() === "") line.pop();
      lines.push(line);
      line = [];
      w = 0;
      if (t.text.trim() === "") continue;
    }
    if (line.length === 0 && t.text.trim() === "") continue;
    line.push(t);
    w += t.w;
  }
  if (line.length) lines.push(line);
  return lines;
}

async function drawRichParagraph(
  ctx: LayoutCtx,
  runsP: Run[][],
  size: number,
  lineH: number,
  align: "left" | "center" | "right",
  spaceAfter: number
): Promise<void> {
  const maxW = ctx.pageW - ctx.margin * 2;
  for (const runs of runsP) {
    if (runs.length === 0) {
      ctx.y += lineH;
      continue;
    }
    const tokens = tokenizeRuns(ctx, runs, size);
    const lines = wrapTokens(tokens, maxW);
    for (const line of lines) {
      await ensureSpace(ctx, lineH);
      const page = ctx.page!;
      const drawRuns = line.map((t) => ({
        text: t.text,
        font: t.font,
        fauxBold: t.fauxBold,
        custom: t.custom,
        size: t.size,
        color: t.color,
        underline: t.underline,
        link: t.link,
      }));
      drawRunsLine(ctx, page, drawRuns, ctx.x, ctx.y, maxW, align);
      ctx.y += lineH;
    }
  }
  ctx.y += spaceAfter;
}

function sanitizeFieldName(id: string): string {
  return `f_${id.replace(/[^a-zA-Z0-9]/g, "").slice(0, 24)}`;
}

export async function exportBlocksPdf(docState: AlteosDoc, opts: BlocksExportOptions): Promise<Blob> {
  const out = await PDFDocument.create();
  const baseFontId = docState.settings.baseFont ?? "Helvetica";
  const { bank, fonts } = await makeFonts(out, [], baseFontId);
  const docFont = await bank.variants(baseFontId);
  const s = docState.settings;

  const ctx: LayoutCtx = {
    out,
    fonts,
    docFont,
    page: null,
    x: s.margin,
    y: s.margin,
    pageW: A4.w,
    pageH: A4.h,
    margin: s.margin,
    pageIndex: -1,
    header: s.header,
    footer: s.footer,
    pageNumbers: s.pageNumbers,
    showHeaderOnFirstPage: s.showHeaderOnFirstPage,
  };
  await newPage(ctx);

  const contentW = A4.w - s.margin * 2;

  for (const block of docState.blocks as Block[]) {
    switch (block.type) {
      case "title": {
        await ensureSpace(ctx, 40);
        await drawRichParagraph(
          ctx,
          [[{ text: block.text, bold: true, italic: false, underline: false, color: "#1C1B1A", link: null }]],
          24,
          30,
          "left",
          4
        );
        break;
      }
      case "subtitle": {
        await drawRichParagraph(
          ctx,
          [[{ text: block.text, bold: false, italic: true, underline: false, color: "#57544E", link: null }]],
          13,
          18,
          "left",
          22
        );
        break;
      }
      case "h1": {
        ctx.y += 10;
        await ensureSpace(ctx, 30);
        await drawRichParagraph(
          ctx,
          [[{ text: block.text, bold: true, italic: false, underline: false, color: "#1C1B1A", link: null }]],
          17,
          22,
          "left",
          6
        );
        break;
      }
      case "h2": {
        ctx.y += 8;
        await ensureSpace(ctx, 24);
        await drawRichParagraph(
          ctx,
          [[{ text: block.text, bold: true, italic: false, underline: false, color: "#1C1B1A", link: null }]],
          14,
          19,
          "left",
          5
        );
        break;
      }
      case "h3": {
        ctx.y += 6;
        await ensureSpace(ctx, 20);
        await drawRichParagraph(
          ctx,
          [[{ text: block.text, bold: true, italic: false, underline: false, color: "#3C3A36", link: null }]],
          12,
          16,
          "left",
          4
        );
        break;
      }
      case "paragraph": {
        const runsP = parseRichRuns(block.html);
        if (runsP.length === 0) {
          ctx.y += 14;
          break;
        }
        await drawRichParagraph(ctx, runsP, 10.5, 14.5, "left", 8);
        break;
      }
      case "list": {
        const runsP = parseRichRuns(block.html);
        const bulletFont = ctx.docFont.r;
        let n = 1;
        for (const runs of runsP) {
          const lineH = 14.5;
          await ensureSpace(ctx, lineH);
          const indent = 18;
          const marker = block.ordered ? `${n}.` : "•";
          const page = ctx.page!;
          page.drawText(marker, {
            x: ctx.x,
            y: ctx.pageH - ctx.y - bulletFont.heightAtSize(10.5, { descender: false }),
            size: 10.5,
            font: bulletFont,
            color: rgb(0.42, 0.42, 0.4),
          });
          const tokens = tokenizeRuns(ctx, runs, 10.5);
          const lines = wrapTokens(tokens, contentW - indent);
          for (const line of lines) {
            await ensureSpace(ctx, lineH);
            const drawRuns = line.map((t) => ({
              text: t.text,
              font: t.font,
              fauxBold: t.fauxBold,
              custom: t.custom,
              size: t.size,
              color: t.color,
              underline: t.underline,
              link: t.link,
            }));
            drawRunsLine(ctx, ctx.page!, drawRuns, ctx.x + indent, ctx.y, contentW - indent, "left");
            ctx.y += lineH;
          }
          n++;
        }
        ctx.y += 8;
        break;
      }
      case "checklist": {
        // Liste de tâches : case cochée réellement dessinée + texte (grisé si fait).
        const box = 11;
        const lineH = 15;
        const indent = 22;
        for (const entry of block.entries) {
          await ensureSpace(ctx, lineH + 3);
          const page = ctx.page!;
          const yTop = ctx.y;
          const yBox = ctx.pageH - yTop - box - 1;
          page.drawRectangle({ x: ctx.x + 1, y: yBox, width: box, height: box, borderColor: rgb(0.42, 0.42, 0.4), borderWidth: 1 });
          if (entry.done) {
            page.drawLine({ start: { x: ctx.x + 3.5, y: yBox + 2.5 }, end: { x: ctx.x + box - 1.5, y: yBox + box - 2.5 }, thickness: 1.4, color: rgb(0.05, 0.49, 0.4) });
            page.drawLine({ start: { x: ctx.x + 3.5, y: yBox + box - 2.5 }, end: { x: ctx.x + box - 1.5, y: yBox + 2.5 }, thickness: 1.4, color: rgb(0.05, 0.49, 0.4) });
          }
          const run = { text: entry.text || " ", bold: false, italic: false, underline: false, color: entry.done ? "#8A8782" : "#1C1B1A", link: null };
          const tokens = tokenizeRuns(ctx, [run], 10.5);
          const lines = wrapTokens(tokens, contentW - indent);
          if (lines.length === 0) {
            ctx.y += lineH;
            continue;
          }
          let first = true;
          for (const line of lines) {
            if (!first) await ensureSpace(ctx, lineH);
            drawRunsLine(ctx, ctx.page!, line.map((t) => ({ ...t })), ctx.x + indent, ctx.y, contentW - indent, "left");
            if (entry.done) {
              // Texte barré léger pour les tâches accomplies.
              const w = line.reduce((s, t) => s + t.font.widthOfTextAtSize(t.text, t.size), 0);
              ctx.page!.drawLine({
                start: { x: ctx.x + indent, y: ctx.pageH - ctx.y - 8 },
                end: { x: ctx.x + indent + w, y: ctx.pageH - ctx.y - 8 },
                thickness: 0.7,
                color: rgb(0.64, 0.62, 0.58),
              });
            }
            ctx.y += lineH;
            first = false;
          }
        }
        ctx.y += 8;
        break;
      }
      case "quote": {
        const runsP = parseRichRuns(block.html);
        ctx.y += 6;
        for (const runs of runsP) {
          const lineH = 15;
          const tokens = tokenizeRuns(ctx, runs.map((r) => ({ ...r, italic: true })), 10.5);
          const lines = wrapTokens(tokens, contentW - 24);
          for (const line of lines) {
            await ensureSpace(ctx, lineH);
            const drawRuns = line.map((t) => ({ ...t, color: "#4A4844" }));
            drawRunsLine(ctx, ctx.page!, drawRuns, ctx.x + 24, ctx.y, contentW - 24, "left");
            ctx.page!.drawRectangle({
              x: ctx.x + 6,
              y: ctx.pageH - ctx.y - lineH + 3,
              width: 2.4,
              height: lineH - 4,
              color: rgb(0.05, 0.49, 0.4),
            });
            ctx.y += lineH;
          }
        }
        ctx.y += 12;
        break;
      }
      case "code": {
        // Police à chasse fixe réellement incorporée (repli Courier hors ligne).
        const mono = await bank.variants("JetBrains Mono");
        const runsP = parseRichRuns(block.html);
        const plain = runsP.map((runs) => runs.map((r) => ({ ...r, bold: false, italic: false, underline: false })));
        const fontSize = 9.5;
        const lineH = 13.5;
        const padX = 10;
        const padY = 8;
        // Mesure d'abord (fond + lignes), avec saut de page si nécessaire.
        const saved = ctx.docFont;
        ctx.docFont = mono;
        const allLines = plain.map((runs) => {
          const tokens = tokenizeRuns(ctx, runs, fontSize);
          return wrapTokens(tokens, contentW - padX * 2);
        });
        const totalH = allLines.reduce((acc, ls) => acc + ls.length * lineH, 0) + padY * 2;
        await ensureSpace(ctx, totalH + 10);
        const bg = hexToRgb01("#F4F2ED");
        ctx.page!.drawRectangle({
          x: ctx.x,
          y: ctx.pageH - ctx.y - totalH,
          width: contentW,
          height: totalH,
          color: rgb(bg.r, bg.g, bg.b),
          borderWidth: 0.7,
          borderColor: rgb(0.85, 0.84, 0.81),
        });
        ctx.y += padY;
        for (const lines of allLines) {
          for (const line of lines) {
            const drawRuns = line.map((t) => ({ ...t, color: "#33302B" }));
            drawRunsLine(ctx, ctx.page!, drawRuns, ctx.x + padX, ctx.y, contentW - padX * 2, "left");
            ctx.y += lineH;
          }
        }
        ctx.y += padY + 8;
        ctx.docFont = saved;
        break;
      }
      case "callout": {
        const conf =
          block.variant === "warning"
            ? { bg: "#FBF3E4", border: "#B7791F" }
            : block.variant === "success"
              ? { bg: "#EDF3E6", border: "#4C7A34" }
              : { bg: "#EAF3EF", border: "#0E7C66" };
        const runsP = parseRichRuns(block.html);
        const fontSize = 10.5;
        const lineH = 14.5;
        const padX = 12;
        const padY = 9;
        const allLines = runsP.map((runs) => {
          const tokens = tokenizeRuns(ctx, runs, fontSize);
          return wrapTokens(tokens, contentW - padX * 2 - 6);
        });
        const totalH = allLines.reduce((acc, ls) => acc + ls.length * lineH, 0) + padY * 2;
        await ensureSpace(ctx, totalH + 10);
        const bg = hexToRgb01(conf.bg);
        const bd = hexToRgb01(conf.border);
        ctx.page!.drawRectangle({
          x: ctx.x,
          y: ctx.pageH - ctx.y - totalH,
          width: contentW,
          height: totalH,
          color: rgb(bg.r, bg.g, bg.b),
        });
        ctx.page!.drawRectangle({
          x: ctx.x,
          y: ctx.pageH - ctx.y - totalH,
          width: 3,
          height: totalH,
          color: rgb(bd.r, bd.g, bd.b),
        });
        ctx.y += padY;
        for (const lines of allLines) {
          for (const line of lines) {
            drawRunsLine(ctx, ctx.page!, line.map((t) => ({ ...t })), ctx.x + padX, ctx.y, contentW - padX * 2 - 6, "left");
            ctx.y += lineH;
          }
        }
        ctx.y += padY + 8;
        break;
      }
      case "divider": {
        await ensureSpace(ctx, 20);
        ctx.page!.drawLine({
          start: { x: ctx.x, y: ctx.pageH - ctx.y - 8 },
          end: { x: ctx.x + contentW, y: ctx.pageH - ctx.y - 8 },
          thickness: 0.8,
          color: rgb(0.85, 0.85, 0.83),
        });
        ctx.y += 20;
        break;
      }
      case "spacer": {
        ctx.y += block.h;
        break;
      }
      case "image": {
        const asset = await getAsset(block.assetId);
        if (!asset) break;
        let mime = asset.blob.type || "image/png";
        if (mime !== "image/png" && mime !== "image/jpeg") mime = "image/png";
        const bytes = new Uint8Array(await asset.blob.arrayBuffer());
        const img = mime === "image/jpeg" ? await out.embedJpg(bytes) : await out.embedPng(bytes);
        const targetW = (contentW * block.widthPct) / 100;
        const scale = targetW / img.width;
        const targetH = img.height * scale;

        if (targetH > ctx.pageH - ctx.margin * 2) {
          await newPage(ctx);
          const scale2 = (ctx.pageH - ctx.margin * 2) / img.height;
          const w2 = img.width * scale2;
          const x2 =
            block.align === "center"
              ? (ctx.pageW - w2) / 2
              : block.align === "right"
                ? ctx.pageW - ctx.margin - w2
                : ctx.x;
          ctx.page!.drawImage(img, { x: x2, y: ctx.margin, width: w2, height: img.height * scale2 });
          ctx.y = ctx.margin + img.height * scale2 + 16;
          break;
        }
        await ensureSpace(ctx, targetH + 14);
        const x =
          block.align === "center"
            ? (ctx.pageW - targetW) / 2
            : block.align === "right"
              ? ctx.pageW - ctx.margin - targetW
              : ctx.x;
        ctx.page!.drawImage(img, { x, y: ctx.pageH - ctx.y - targetH, width: targetW, height: targetH });
        ctx.y += targetH + 14;
        break;
      }
      case "table": {
        const rows = block.rows;
        if (!rows.length) break;
        const colCount = Math.max(...rows.map((r) => r.length));
        const weights = new Array(colCount).fill(0);
        for (const row of rows) {
          for (let c = 0; c < colCount; c++) {
            const cellText = row[c] ?? "";
            weights[c] = Math.max(weights[c], Math.min(cellText.length, 40));
          }
        }
        const totalW = weights.reduce((a, b) => a + b, 0) || 1;
        const colWs = weights.map((w) => (w / totalW) * contentW);
        const cellPad = 5;
        const fontSize = 9.5;
        const font = ctx.docFont.r;
        const boldFont = ctx.docFont.b;

        let rowIdx = 0;
        while (rowIdx < rows.length) {
          const row = rows[rowIdx];
          const isHeader = block.header && rowIdx === 0;
          const isHeaderRepeat = block.header && rowIdx > 0 && ctx.y <= ctx.margin + 0.5;

          let rowH = 0;
          const cellLines: string[][] = [];
          for (let c = 0; c < colCount; c++) {
            const raw = toWinAnsi(row[c] ?? "");
            const f = isHeader || isHeaderRepeat ? boldFont : font;
            const words = raw.split(/\s+/).filter(Boolean);
            const lines: string[] = [];
            let cur = "";
            for (const w of words) {
              const attempt = cur ? `${cur} ${w}` : w;
              if (f.widthOfTextAtSize(attempt, fontSize) <= colWs[c] - cellPad * 2) cur = attempt;
              else {
                if (cur) lines.push(cur);
                cur = w;
              }
            }
            if (cur) lines.push(cur);
            cellLines.push(lines);
            rowH = Math.max(rowH, lines.length * fontSize * 1.35 + cellPad * 2);
          }
          rowH = Math.max(rowH, 20);

          if (ctx.y + rowH > ctx.pageH - ctx.margin) {
            await newPage(ctx);
            continue;
          }
          const page = ctx.page!;
          const yTop = ctx.y;
          if (isHeader || isHeaderRepeat) {
            page.drawRectangle({ x: ctx.x, y: ctx.pageH - yTop - rowH, width: contentW, height: rowH, color: rgb(0.93, 0.95, 0.94) });
          }
          let cx = ctx.x;
          for (let c = 0; c < colCount; c++) {
            const f = isHeader || isHeaderRepeat ? boldFont : font;
            let ly = yTop + cellPad + fontSize;
            for (const line of cellLines[c]) {
              page.drawText(line, {
                x: cx + cellPad,
                y: ctx.pageH - ly,
                size: fontSize,
                font: f,
                color: rgb(0.16, 0.16, 0.15),
              });
              ly += fontSize * 1.35;
            }
            cx += colWs[c];
          }
          page.drawRectangle({
            x: ctx.x,
            y: ctx.pageH - yTop - rowH,
            width: contentW,
            height: rowH,
            borderColor: rgb(0.82, 0.82, 0.8),
            borderWidth: 0.7,
          });
          cx = ctx.x;
          for (let c = 1; c < colCount; c++) {
            cx += colWs[c - 1];
            page.drawLine({
              start: { x: cx, y: ctx.pageH - yTop },
              end: { x: cx, y: ctx.pageH - yTop - rowH },
              thickness: 0.7,
              color: rgb(0.82, 0.82, 0.8),
            });
          }
          ctx.y += rowH;
          rowIdx++;
        }
        ctx.y += 10;
        break;
      }
      case "field": {
        const labelFont = ctx.docFont.r;
        const labelSize = 10;
        const label = toWinAnsi(block.label) + (block.required ? " *" : "");
        await ensureSpace(ctx, 44);
        ctx.page!.drawText(label, {
          x: ctx.x,
          y: ctx.pageH - ctx.y - labelFont.heightAtSize(labelSize, { descender: false }),
          size: labelSize,
          font: labelFont,
          color: rgb(0.2, 0.2, 0.19),
        });
        ctx.y += 16;
        const value = docState.formValues[block.id];
        const fieldName = sanitizeFieldName(block.id);

        if (block.fieldType === "checkbox") {
          const box = 13;
          const x = ctx.x;
          const yPdf = ctx.pageH - ctx.y - box;
          if (opts.fillableForm) {
            const form = out.getForm();
            const check = form.createCheckBox(fieldName);
            check.addToPage(ctx.page!, { x, y: yPdf, width: box, height: box, borderColor: rgb(0.4, 0.4, 0.38), borderWidth: 1 });
            if (value === true) check.check();
          } else {
            ctx.page!.drawRectangle({ x, y: yPdf, width: box, height: box, borderColor: rgb(0.4, 0.4, 0.38), borderWidth: 1 });
            if (value === true) {
              ctx.page!.drawLine({ start: { x: x + 2.5, y: yPdf + 3 }, end: { x: x + box - 2.5, y: yPdf + box - 3 }, thickness: 1.4, color: rgb(0.05, 0.49, 0.4) });
              ctx.page!.drawLine({ start: { x: x + 2.5, y: yPdf + box - 3 }, end: { x: x + box - 2.5, y: yPdf + 3 }, thickness: 1.4, color: rgb(0.05, 0.49, 0.4) });
            }
          }
          ctx.y += box + 10;
          break;
        }

        const h = block.fieldType === "multiline" ? 70 : 24;
        if (opts.fillableForm) {
          const form = out.getForm();
          const field = form.createTextField(fieldName);
          if (block.fieldType === "multiline") field.enableMultiline();
          field.setText(toWinAnsi(String(value ?? "")));
          field.addToPage(ctx.page!, {
            x: ctx.x,
            y: ctx.pageH - ctx.y - h,
            width: contentW,
            height: h,
            borderColor: rgb(0.62, 0.62, 0.6),
            borderWidth: 1,
          });
        } else {
          ctx.page!.drawRectangle({
            x: ctx.x,
            y: ctx.pageH - ctx.y - h,
            width: contentW,
            height: h,
            borderColor: rgb(0.62, 0.62, 0.6),
            borderWidth: 1,
          });
          if (value) {
            const lines = toWinAnsi(String(value)).split("\n");
            let ly = ctx.y + 6 + labelSize;
            for (const line of lines) {
              ctx.page!.drawText(line, { x: ctx.x + 6, y: ctx.pageH - ly, size: 10, font: labelFont, color: rgb(0.16, 0.16, 0.15) });
              ly += 13;
            }
          }
        }
        ctx.y += h + 12;
        break;
      }
    }
  }

  out.setTitle(toWinAnsi(docState.name));
  out.setProducer("AlteOS Docs");
  out.setCreator("AlteOS Docs — export local");
  applyMetadata(out, docState.name, opts.metadata);
  const bytes = await out.save({ useObjectStreams: opts.compact });
  return new Blob([bytes as unknown as BlobPart], { type: "application/pdf" });
}
