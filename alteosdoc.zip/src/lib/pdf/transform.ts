/**
 * AlteOS Docs — Transforms de coordonnées purs.
 *
 * Espace interne : espace utilisateur PDF, origine HAUT-GAUCHE, page NON pivotée.
 * Éspace écran : pixels du conteneur de page affiché (rotation appliquée).
 *
 * rotation : sens horaire (convention d'affichage pdf.js) — 0, 90, 180 ou 270.
 */

export interface PureTransform {
  /** écran (px) → utilisateur (points, TL). */
  toUser: (px: number, py: number) => { x: number; y: number };
  /** utilisateur (TL) → écran (px). */
  toScreen: (ux: number, uy: number) => { x: number; y: number };
  /** Dimensions affichées (px) à l'échelle donnée. */
  vw: number;
  vh: number;
}

export function pageTransform(uw: number, uh: number, scale: number, rotation: number): PureTransform {
  const r = ((rotation % 360) + 360) % 360;
  const swap = r === 90 || r === 270;
  const vw = (swap ? uh : uw) * scale;
  const vh = (swap ? uw : uh) * scale;

  switch (r) {
    case 90:
      return {
        vw,
        vh,
        toUser: (px, py) => ({ x: py / scale, y: uh - px / scale }),
        toScreen: (ux, uy) => ({ x: (uh - uy) * scale, y: ux * scale }),
      };
    case 180:
      return {
        vw,
        vh,
        toUser: (px, py) => ({ x: uw - px / scale, y: uh - py / scale }),
        toScreen: (ux, uy) => ({ x: (uw - ux) * scale, y: (uh - uy) * scale }),
      };
    case 270:
      return {
        vw,
        vh,
        toUser: (px, py) => ({ x: uw - py / scale, y: px / scale }),
        toScreen: (ux, uy) => ({ x: uy * scale, y: (uw - ux) * scale }),
      };
    default:
      return {
        vw,
        vh,
        toUser: (px, py) => ({ x: px / scale, y: py / scale }),
        toScreen: (ux, uy) => ({ x: ux * scale, y: uy * scale }),
      };
  }
}

/** Rectangle écran (drag) → rectangle utilisateur (min/max, toujours positif). */
export function screenRectToUser(
  t: PureTransform,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): { x: number; y: number; w: number; h: number } {
  const a = t.toUser(x1, y1);
  const b = t.toUser(x2, y2);
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    w: Math.abs(b.x - a.x),
    h: Math.abs(b.y - a.y),
  };
}

/** Rectangle utilisateur → rectangle écran (rotation-safe). */
export function userRectToScreen(
  t: PureTransform,
  x: number,
  y: number,
  w: number,
  h: number
): { x: number; y: number; w: number; h: number } {
  const a = t.toScreen(x, y);
  const b = t.toScreen(x + w, y + h);
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    w: Math.abs(b.x - a.x),
    h: Math.abs(b.y - a.y),
  };
}
