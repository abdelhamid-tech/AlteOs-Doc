/**
 * AlteOS Docs — Dessin des éléments (annotations, textes, images, signatures)
 * sur une page pdf-lib lors de l'export.
 *
 * Les coordonnées internes sont en espace utilisateur, origine HAUT-GAUCHE,
 * page non pivotée. pdf-lib utilise l'origine BAS-GAUCHE : y_pdf = Uh - y.
 */

import type { PDFPage, PDFFont, PDFImage } from "pdf-lib";
import { degrees, rgb } from "pdf-lib";

import { hexToRgb01, toExportText, toWinAnsi } from "@/lib/utils";
import { getEmbeddableForItem, type ImageQuality } from "./assets";
import { FontBank } from "./fontbank";
import { iconFullSvg } from "@/lib/icon-paths";
import { qrDataUrl } from "@/lib/qr";
import { rasterizeSvgBytes } from "@/lib/svg-raster";
import { dataUrlToBlob } from "./assets";
import type { Item, TextItem } from "@/lib/types";

export interface DrawContext {
  page: PDFPage;
  pageW: number; // points, non pivoté
  pageH: number;
  /** Polices standard (accès synchrone). */
  fonts: Map<string, PDFFont>;
  /** Banque de polices — résolution/incorporation des familles Google. */
  bank: FontBank;
  embedImage: (bytes: Uint8Array, mime: string) => Promise<PDFImage>;
  quality: ImageQuality;
}

function col(hex: string) {
  const { r, g, b } = hexToRgb01(hex);
  return rgb(r, g, b);
}

/** Ancre pdf-lib (bas-gauche) pour un rectangle tourné comme en DOM (horaire, autour du centre). */
function rotatedAnchor(cx: number, cyPdf: number, w: number, h: number, domDeg: number): { x: number; y: number; theta: number } {
  const theta = ((360 - (domDeg % 360)) % 360) * (Math.PI / 180); // CCW pdf-lib
  const hw = w / 2;
  const hh = h / 2;
  const rx = Math.cos(theta) * hw - Math.sin(theta) * hh;
  const ry = Math.sin(theta) * hw + Math.cos(theta) * hh;
  return { x: cx - rx, y: cyPdf - ry, theta: (theta * 180) / Math.PI };
}

// ---------------------------------------------------------------------------
// Texte : découpage en lignes (repli identique à l'affichage)
// ---------------------------------------------------------------------------

export function wrapText(
  font: PDFFont,
  item: TextItem,
  sanitize: (s: string) => string
): { lines: string[]; lineHeight: number } {
  const size = item.fontSize;
  const lineHeight = size * 1.28;
  const maxW = Math.max(item.w, size);
  const lines: string[] = [];
  for (const raw of item.text.split("\n")) {
    const text = sanitize(raw);
    if (text === "") {
      lines.push("");
      continue;
    }
    const words = text.split(" ");
    let cur = "";
    for (const word of words) {
      const attempt = cur === "" ? word : `${cur} ${word}`;
      if (font.widthOfTextAtSize(attempt, size) <= maxW) {
        cur = attempt;
      } else {
        if (cur !== "") lines.push(cur);
        // Mot seul trop long : coupe par caractères
        if (font.widthOfTextAtSize(word, size) > maxW) {
          let piece = "";
          for (const ch of word) {
            if (font.widthOfTextAtSize(piece + ch, size) <= maxW) {
              piece += ch;
            } else {
              lines.push(piece);
              piece = ch;
            }
          }
          cur = piece;
        } else {
          cur = word;
        }
      }
    }
    lines.push(cur);
  }
  return { lines, lineHeight };
}

// ---------------------------------------------------------------------------
// Dessin principal
// ---------------------------------------------------------------------------

export async function drawItemsOnPage(ctx: DrawContext, items: Item[]): Promise<void> {
  const Uh = ctx.pageH;
  for (const item of items) {
    switch (item.type) {
      case "highlight": {
        for (const q of item.quads) {
          ctx.page.drawRectangle({
            x: q.x,
            y: Uh - q.y - q.h,
            width: q.w,
            height: q.h,
            color: col(item.color),
            opacity: 0.32,
          });
        }
        break;
      }
      case "underline":
      case "strike": {
        const thickness = 1.4;
        for (const q of item.quads) {
          const y = item.type === "underline" ? Uh - q.y - q.h + 1.2 : Uh - q.y - q.h / 2;
          ctx.page.drawLine({
            start: { x: q.x, y },
            end: { x: q.x + q.w, y },
            thickness,
            color: col(item.color),
          });
        }
        break;
      }
      case "rect": {
        const y = Uh - item.y - item.h;
        if (item.fill) {
          ctx.page.drawRectangle({
            x: item.x,
            y,
            width: item.w,
            height: item.h,
            color: col(item.fillColor),
            opacity: item.opacity,
          });
        }
        ctx.page.drawRectangle({
          x: item.x,
          y,
          width: item.w,
          height: item.h,
          borderColor: col(item.color),
          borderWidth: item.strokeWidth,
          opacity: item.fill ? undefined : item.opacity,
        });
        break;
      }
      case "ellipse": {
        const cx = item.x + item.w / 2;
        const cyPdf = Uh - item.y - item.h / 2;
        if (item.fill) {
          ctx.page.drawEllipse({
            x: cx,
            y: cyPdf,
            xScale: item.w / 2,
            yScale: item.h / 2,
            color: col(item.fillColor),
            opacity: item.opacity,
          });
        }
        ctx.page.drawEllipse({
          x: cx,
          y: cyPdf,
          xScale: item.w / 2,
          yScale: item.h / 2,
          borderColor: col(item.color),
          borderWidth: item.strokeWidth,
        });
        break;
      }
      case "line":
      case "arrow": {
        const y1 = Uh - item.y;
        const y2 = Uh - item.y2;
        ctx.page.drawLine({
          start: { x: item.x, y: y1 },
          end: { x: item.x2, y: y2 },
          thickness: item.strokeWidth,
          color: col(item.color),
        });
        if (item.type === "arrow") {
          const angle = Math.atan2(item.y2 - item.y, item.x2 - item.x); // espace TL
          const headLen = Math.max(9, item.strokeWidth * 3.5);
          for (const spread of [Math.PI - 0.42, Math.PI + 0.42]) {
            const hx = item.x2 + Math.cos(angle + spread) * headLen;
            const hy = item.y2 + Math.sin(angle + spread) * headLen;
            ctx.page.drawLine({
              start: { x: item.x2, y: Uh - item.y2 },
              end: { x: hx, y: Uh - hy },
              thickness: item.strokeWidth,
              color: col(item.color),
            });
          }
        }
        break;
      }
      case "draw": {
        if (item.points.length < 2) break;
        let d = `M ${item.points[0].x.toFixed(2)} ${item.points[0].y.toFixed(2)}`;
        for (let i = 1; i < item.points.length; i++) {
          d += ` L ${item.points[i].x.toFixed(2)} ${item.points[i].y.toFixed(2)}`;
        }
        ctx.page.drawSvgPath(d, {
          x: 0,
          y: Uh,
          borderColor: col(item.color),
          borderWidth: item.strokeWidth,
        });
        break;
      }
      case "text": {
        await drawTextItem(ctx, item);
        break;
      }
      case "note": {
        drawNoteItem(ctx, item);
        break;
      }
      case "image":
      case "signature": {
        const emb = await getEmbeddableForItem(item, ctx.quality);
        if (!emb) break;
        const img = await ctx.embedImage(emb.bytes, emb.mime);
        const cx = item.x + item.w / 2;
        const cyPdf = Uh - item.y - item.h / 2;
        const { x, y, theta } = rotatedAnchor(cx, cyPdf, item.w, item.h, item.rotation || 0);
        ctx.page.drawImage(img, {
          x,
          y,
          width: item.w,
          height: item.h,
          rotate: degrees(theta),
          opacity: item.opacity ?? 1,
        });
        break;
      }
      case "qr": {
        // PNG généré localement (paquet qrcode, MIT) — jamais de service externe.
        try {
          const url = await qrDataUrl(item.data, item.fg, item.bg, 512);
          const blob = await dataUrlToBlob(url);
          const img = await ctx.embedImage(new Uint8Array(await blob.arrayBuffer()), "image/png");
          ctx.page.drawImage(img, { x: item.x, y: Uh - item.y - item.h, width: item.w, height: item.h });
        } catch {
          // Contenu non encodable : cadre en pointillés honnête plutôt qu'un faux QR.
          ctx.page.drawRectangle({
            x: item.x,
            y: Uh - item.y - item.h,
            width: item.w,
            height: item.h,
            borderColor: col(item.fg),
            borderWidth: 1,
            borderDashArray: [3, 3],
          });
        }
        break;
      }
      case "icon": {
        // Icône vectorielle rastérisée en PNG haute résolution (tracés lucide ISC).
        const markup = iconFullSvg(item.iconId, item.color);
        if (!markup) break;
        try {
          const bytes = await rasterizeSvgBytes(markup, Math.max(64, Math.round(item.w * 6)));
          const img = await ctx.embedImage(bytes, "image/png");
          ctx.page.drawImage(img, { x: item.x, y: Uh - item.y - item.h, width: item.w, height: item.h });
        } catch {
          break;
        }
        break;
      }
    }
  }
}

async function drawTextItem(ctx: DrawContext, item: TextItem): Promise<void> {
  const { font, custom, fauxBold } = await ctx.bank.forItem(item);
  const sanitize = custom ? toExportText : toWinAnsi;
  const Uh = ctx.pageH;
  const { lines, lineHeight } = wrapText(font, item, sanitize);
  const size = item.fontSize;
  const ascender = font.heightAtSize(size, { descender: false });
  // Faux gras : seconde passe légèrement décalée (famille sans graisse 700)
  const boldOffset = fauxBold ? Math.max(0.25, size * 0.022) : 0;

  let yTop = item.y;
  for (const line of lines) {
    const lineWidth = line === "" ? 0 : font.widthOfTextAtSize(line, size);
    let x = item.x;
    if (item.align === "center") x = item.x + (item.w - lineWidth) / 2;
    if (item.align === "right") x = item.x + item.w - lineWidth;

    const baselinePdf = Uh - yTop - ascender;
    if (line !== "") {
      const drawAt = (dx: number) =>
        ctx.page.drawText(line, {
          x: dx,
          y: baselinePdf,
          size,
          font,
          color: col(item.color),
        });
      drawAt(x);
      if (boldOffset > 0) drawAt(x + boldOffset);
      if (item.underline) {
        ctx.page.drawLine({
          start: { x, y: baselinePdf - 1.8 },
          end: { x: x + lineWidth, y: baselinePdf - 1.8 },
          thickness: Math.max(0.7, size * 0.06),
          color: col(item.color),
        });
      }
    }
    yTop += lineHeight;
  }
}

function drawNoteItem(ctx: DrawContext, item: { x: number; y: number; text: string; color: string }): void {
  const Uh = ctx.pageH;
  const font = ctx.fonts.get("Helvetica")!;
  const size = 8;
  const pad = 6;
  const maxW = 170;
  // Découpage du texte
  const words = toWinAnsi(item.text).split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const attempt = cur ? `${cur} ${w}` : w;
    if (font.widthOfTextAtSize(attempt, size) <= maxW - pad * 2) cur = attempt;
    else {
      if (cur) lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  const lineH = size * 1.3;
  const boxH = lines.length * lineH + pad * 2;
  const boxW = maxW;

  ctx.page.drawRectangle({
    x: item.x,
    y: Uh - item.y - boxH,
    width: boxW,
    height: boxH,
    color: col(item.color),
    opacity: 0.14,
    borderColor: col(item.color),
    borderWidth: 0.8,
  });
  // Petit repère d'épingle
  ctx.page.drawCircle({ x: item.x + 4, y: Uh - item.y - 4, size: 2.6, color: col(item.color) });
  let yTop = item.y + pad + size;
  for (const line of lines) {
    ctx.page.drawText(line, {
      x: item.x + pad,
      y: Uh - yTop,
      size,
      font,
      color: col("#33322F"),
    });
    yTop += lineH;
  }
}
