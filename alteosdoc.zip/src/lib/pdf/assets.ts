/**
 * AlteOS Docs — Résolution et traitement des assets (images, signatures)
 * pour l'export PDF. Tout se passe en local dans le navigateur.
 */

import { getAsset } from "@/lib/idb";
import { filtersAreNeutral, filtersToCss, type ImageFilters, type ImageItem, type SignatureItem, type TextItem } from "@/lib/types";

export type ImageQuality = "original" | "standard" | "forte";

export interface EmbeddableImage {
  bytes: Uint8Array;
  mime: string; // image/png | image/jpeg
}

const processingCache = new Map<string, EmbeddableImage>();

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error("Image illisible"));
    el.src = url;
  });
}

async function blobToEmbeddable(blob: Blob, quality: ImageQuality, isSignature: boolean): Promise<EmbeddableImage> {
  const mime = blob.type || "image/png";

  // Les signatures restent en PNG (transparence nécessaire).
  if (isSignature || quality === "original") {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    return { bytes, mime: mime === "image/jpeg" ? "image/jpeg" : "image/png" };
  }

  const maxPx = quality === "standard" ? 1400 : 1100;
  const jpegQuality = quality === "standard" ? 0.85 : 0.72;

  // Chargement + redimensionnement éventuel via canvas
  const url = URL.createObjectURL(blob);
  try {
    const img = await loadImage(url);
    const needsResize = img.naturalWidth > maxPx || img.naturalHeight > maxPx;
    if (!needsResize && mime === "image/jpeg") {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      return { bytes, mime: "image/jpeg" };
    }
    const scale = needsResize ? Math.min(maxPx / img.naturalWidth, maxPx / img.naturalHeight, 1) : 1;
    const w = Math.max(1, Math.round(img.naturalWidth * scale));
    const h = Math.max(1, Math.round(img.naturalHeight * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(img, 0, 0, w, h);
    const outBlob = await new Promise<Blob>((res) => canvas.toBlob((b) => res(b!), "image/jpeg", jpegQuality));
    return { bytes: new Uint8Array(await outBlob.arrayBuffer()), mime: "image/jpeg" };
  } finally {
    URL.revokeObjectURL(url);
  }
}

/**
 * Ré-encode une image avec ses filtres et retournements — exactement ce qui
 * est affiché à l'écran (canvas 2D + ctx.filter, natif du navigateur).
 * Le flou est exprimé en points : converti en pixels à la résolution du
 * canevas de sortie pour rester fidèle à l'aperçu éditeur.
 */
async function blobWithEffects(
  blob: Blob,
  filters: ImageFilters,
  flipH: boolean,
  flipV: boolean,
  itemWpt: number,
  quality: ImageQuality
): Promise<EmbeddableImage> {
  const maxPx = quality === "original" ? 2200 : quality === "standard" ? 1400 : 1100;
  const url = URL.createObjectURL(blob);
  try {
    const img = await loadImage(url);
    const scale = Math.min(maxPx / img.naturalWidth, maxPx / img.naturalHeight, 1);
    const w = Math.max(1, Math.round(img.naturalWidth * scale));
    const h = Math.max(1, Math.round(img.naturalHeight * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d")!;
    // Résolution de sortie (px par point) — le flou seul en dépend.
    const pxPerPt = itemWpt > 0 ? w / itemWpt : 1;
    const f: ImageFilters = { ...filters, blur: filters.blur * pxPerPt };
    ctx.filter = filtersToCss(f);
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
    ctx.drawImage(img, -w / 2, -h / 2, w, h);
    ctx.restore();
    const outBlob = await new Promise<Blob>((res) => canvas.toBlob((b) => res(b!), "image/png"));
    return { bytes: new Uint8Array(await outBlob.arrayBuffer()), mime: "image/png" };
  } finally {
    URL.revokeObjectURL(url);
  }
}

/**
 * Retourne une image prête à embarquer pour un item (image ou signature).
 * Les traitements sont mis en cache pour éviter de ré-encoder à chaque export.
 */
export async function getEmbeddableForItem(
  item: ImageItem | SignatureItem,
  quality: ImageQuality
): Promise<EmbeddableImage | null> {
  const hasEffects =
    item.type === "image" && (!filtersAreNeutral(item.filters) || item.flipH || item.flipV);
  const cacheKey = hasEffects
    ? `${item.assetId}:${item.type}:${quality}:fx:${JSON.stringify(item.filters ?? null)}:${item.flipH ? 1 : 0}${item.flipV ? 1 : 0}:${Math.round(item.w)}`
    : `${item.assetId}:${item.type}:${quality}`;
  const hit = processingCache.get(cacheKey);
  if (hit) return hit;
  const asset = await getAsset(item.assetId);
  if (!asset) return null;
  let result: EmbeddableImage;
  if (hasEffects) {
    result = await blobWithEffects(
      asset.blob,
      item.filters ?? { grayscale: 0, sepia: 0, brightness: 1, contrast: 1, blur: 0 },
      !!item.flipH,
      !!item.flipV,
      item.w,
      quality
    );
  } else {
    result = await blobToEmbeddable(asset.blob, quality, item.type === "signature");
  }
  processingCache.set(cacheKey, result);
  return result;
}

/** Blob PNG depuis un dataURL de canevas de signature. */
export function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  return fetch(dataUrl).then((r) => r.blob());
}

/** Famille pdf-lib selon les propriétés d'un TextItem. */
export function standardFontName(item: TextItem): "Helvetica" | "Helvetica-Bold" | "Helvetica-Oblique" | "Helvetica-BoldOblique" | "Times-Roman" | "Times-Bold" | "Times-Italic" | "Times-BoldItalic" | "Courier" | "Courier-Bold" | "Courier-Oblique" | "Courier-BoldOblique" {
  const fam = item.fontFamily;
  const suffix = item.bold && item.italic ? "-BoldOblique" : item.bold ? "-Bold" : item.italic ? "-Oblique" : "";
  if (fam === "Times") {
    if (item.bold && item.italic) return "Times-BoldItalic";
    if (item.bold) return "Times-Bold";
    if (item.italic) return "Times-Italic";
    return "Times-Roman";
  }
  if (fam === "Courier") {
    if (item.bold && item.italic) return "Courier-BoldOblique";
    if (item.bold) return "Courier-Bold";
    if (item.italic) return "Courier-Oblique";
    return "Courier";
  }
  void suffix;
  if (item.bold && item.italic) return "Helvetica-BoldOblique";
  if (item.bold) return "Helvetica-Bold";
  if (item.italic) return "Helvetica-Oblique";
  return "Helvetica";
}
