/**
 * AlteOS Docs — Export texte des documents (blocs)
 * --------------------------------------------------
 * Markdown, HTML autonome et texte brut — générés entièrement en local.
 * Les images sont incorporées en base64 : chaque fichier est autoporteur.
 */

import { getAsset } from "./idb";
import { fontStack } from "./fonts";
import type { AlteosDoc, Block } from "./types";

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/** Texte brut d'un HTML de bloc (runs simples). */
function htmlToText(html: string): string {
  if (typeof window === "undefined") return html;
  const div = document.createElement("div");
  div.innerHTML = html;
  return (div.textContent ?? "").replace(/\u00A0/g, " ").trim();
}

/** HTML de bloc → HTML propre pour l'export complet (conserve b/i/u/a/span). */
function sanitizeRichHtml(html: string): string {
  if (typeof window === "undefined") return escapeHtml(html);
  const div = document.createElement("div");
  div.innerHTML = html;
  const ALLOWED = new Set(["P", "B", "STRONG", "I", "EM", "U", "A", "SPAN", "BR", "S", "DEL"]);
  const walk = (node: Node): string => {
    if (node.nodeType === Node.TEXT_NODE) return escapeHtml(node.textContent ?? "");
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const el = node as HTMLElement;
    const tag = el.tagName.toUpperCase();
    if (tag === "BR") return "<br />";
    if (!ALLOWED.has(tag)) return Array.from(el.childNodes).map(walk).join("");
    const attrs: string[] = [];
    if (tag === "A" && el.getAttribute("href")) attrs.push(`href="${escapeHtml(el.getAttribute("href")!)}"`);
    if (tag === "SPAN" && el.style.color) attrs.push(`style="color:${escapeHtml(el.style.color)}"`);
    const inner = Array.from(el.childNodes).map(walk).join("");
    const tagOut = tag === "STRONG" ? "strong" : tag === "EM" ? "em" : tag === "DEL" ? "del" : tag.toLowerCase();
    return attrs.length ? `<${tagOut} ${attrs.join(" ")}>${inner}</${tagOut}>` : `<${tagOut}>${inner}</${tagOut}>`;
  };
  const out = Array.from(div.childNodes).map(walk).join("");
  return out || "<p></p>";
}

async function assetDataUrl(assetId: string): Promise<string | null> {
  try {
    const asset = await getAsset(assetId);
    if (!asset) return null;
    const buf = await asset.blob.arrayBuffer();
    let binary = "";
    const bytes = new Uint8Array(buf);
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return `data:${asset.mime || "image/png"};base64,${btoa(binary)}`;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Markdown
// ---------------------------------------------------------------------------

export async function blocksToMarkdown(doc: AlteosDoc): Promise<string> {
  const out: string[] = [];
  for (const b of doc.blocks) {
    switch (b.type) {
      case "title":
        out.push(`# ${b.text}`, "");
        break;
      case "subtitle":
        out.push(`*${b.text}*`, "");
        break;
      case "h1":
        out.push(`## ${b.text}`, "");
        break;
      case "h2":
        out.push(`### ${b.text}`, "");
        break;
      case "h3":
        out.push(`#### ${b.text}`, "");
        break;
      case "paragraph":
        out.push(richToMarkdown(b.html), "");
        break;
      case "list":
        out.push(...richListToMarkdown(b.html, b.ordered), "");
        break;
      case "checklist":
        for (const e of b.entries) out.push(`- [${e.done ? "x" : " "}] ${e.text}`);
        out.push("");
        break;
      case "quote":
        for (const line of htmlToText(b.html).split("\n")) out.push(`> ${line}`);
        out.push("");
        break;
      case "code":
        out.push("```", htmlToText(b.html), "```", "");
        break;
      case "callout":
        out.push(`> ${b.variant === "warning" ? "⚠" : b.variant === "success" ? "✔" : "ℹ"} ${htmlToText(b.html)}`, "");
        break;
      case "divider":
        out.push("---", "");
        break;
      case "spacer":
        out.push("", "");
        break;
      case "image": {
        const url = await assetDataUrl(b.assetId);
        if (url) out.push(`![Image](${url})`, "");
        else out.push("<!-- image indisponible -->", "");
        break;
      }
      case "table": {
        const rows = b.rows;
        if (rows.length) {
          const width = Math.max(...rows.map((r) => r.length));
          const norm = rows.map((r) => {
            const cells = [...r];
            while (cells.length < width) cells.push("");
            return cells.map((c) => c.replace(/\|/g, "\\|"));
          });
          out.push(`| ${norm[0].join(" | ")} |`);
          out.push(`| ${norm[0].map(() => "---").join(" | ")} |`);
          for (const r of norm.slice(1)) out.push(`| ${r.join(" | ")} |`);
          out.push("");
        }
        break;
      }
      case "field":
        out.push(`- **${b.label}${b.required ? " *" : ""}** : ${b.fieldType === "checkbox" ? "[ ]" : "____________"}`, "");
        break;
    }
  }
  return `${out.join("\n").replace(/\n{3,}/g, "\n\n").trim()}\n`;
}

function richToMarkdown(html: string): string {
  if (typeof window === "undefined") return html;
  const div = document.createElement("div");
  div.innerHTML = html;
  const walk = (node: Node): string => {
    if (node.nodeType === Node.TEXT_NODE) return node.textContent ?? "";
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const el = node as HTMLElement;
    const inner = Array.from(el.childNodes).map(walk).join("");
    const tag = el.tagName.toLowerCase();
    if (tag === "b" || tag === "strong") return `**${inner}**`;
    if (tag === "i" || tag === "em") return `*${inner}*`;
    if (tag === "u") return inner;
    if (tag === "a") {
      const href = el.getAttribute("href");
      return href ? `[${inner}](${href})` : inner;
    }
    return inner;
  };
  return Array.from(div.childNodes).map(walk).join("").trim();
}

function richListToMarkdown(html: string, ordered: boolean): string[] {
  if (typeof window === "undefined") return [];
  const div = document.createElement("div");
  div.innerHTML = html;
  const lines: string[] = [];
  let n = 1;
  for (const child of Array.from(div.childNodes)) {
    const text = richToMarkdown(child.nodeType === Node.ELEMENT_NODE ? (child as HTMLElement).outerHTML : child.textContent ?? "");
    if (!text.trim()) continue;
    lines.push(ordered ? `${n}. ${text}` : `- ${text}`);
    n++;
  }
  return lines.length ? lines : ["- "];
}

// ---------------------------------------------------------------------------
// HTML autonome
// ---------------------------------------------------------------------------

export async function blocksToHtml(doc: AlteosDoc): Promise<string> {
  const body: string[] = [];
  for (const b of doc.blocks) {
    switch (b.type) {
      case "title":
        body.push(`<h1 class="aos-title">${escapeHtml(b.text)}</h1>`);
        break;
      case "subtitle":
        body.push(`<p class="aos-subtitle">${escapeHtml(b.text)}</p>`);
        break;
      case "h1":
        body.push(`<h2>${escapeHtml(b.text)}</h2>`);
        break;
      case "h2":
        body.push(`<h3>${escapeHtml(b.text)}</h3>`);
        break;
      case "h3":
        body.push(`<h4>${escapeHtml(b.text)}</h4>`);
        break;
      case "paragraph":
        body.push(`<p>${sanitizeRichHtml(b.html)}</p>`);
        break;
      case "list":
        body.push(`<${b.ordered ? "ol" : "ul"}>${listItemsHtml(b.html)}</${b.ordered ? "ol" : "ul"}>`);
        break;
      case "checklist":
        body.push(
          `<ul class="aos-checklist">${b.entries
            .map((e) => `<li${e.done ? ` class="done"` : ""}><input type="checkbox" disabled${e.done ? " checked" : ""} /> ${escapeHtml(e.text)}</li>`)
            .join("")}</ul>`
        );
        break;
      case "quote":
        body.push(`<blockquote>${sanitizeRichHtml(b.html)}</blockquote>`);
        break;
      case "code":
        body.push(`<pre><code>${escapeHtml(htmlToText(b.html))}</code></pre>`);
        break;
      case "callout": {
        const cls = b.variant === "warning" ? "warning" : b.variant === "success" ? "success" : "info";
        body.push(`<div class="aos-callout ${cls}">${sanitizeRichHtml(b.html)}</div>`);
        break;
      }
      case "divider":
        body.push("<hr />");
        break;
      case "spacer":
        body.push(`<div style="height:${b.h}px"></div>`);
        break;
      case "image": {
        const url = await assetDataUrl(b.assetId);
        if (url) {
          const align = b.align === "center" ? "margin:0 auto" : b.align === "right" ? "margin-left:auto" : "";
          body.push(`<img src="${url}" style="width:${b.widthPct}%;${align}" alt="Image du document" />`);
        }
        break;
      }
      case "table": {
        const rows = b.rows;
        if (rows.length) {
          const width = Math.max(...rows.map((r) => r.length));
          const trs = rows
            .map((r, i) => {
              const cells = [...r];
              while (cells.length < width) cells.push("");
              const tag = b.header && i === 0 ? "th" : "td";
              return `<tr>${cells.map((c) => `<${tag}>${escapeHtml(c)}</${tag}>`).join("")}</tr>`;
            })
            .join("");
          body.push(`<table>${b.header ? "" : ""}${trs}</table>`);
        }
        break;
      }
      case "field":
        body.push(
          `<div class="aos-field"><label>${escapeHtml(b.label)}${b.required ? " *" : ""}</label>${
            b.fieldType === "checkbox" ? `<input type="checkbox" />` : b.fieldType === "multiline" ? `<textarea rows="3"></textarea>` : `<input type="${b.fieldType === "date" ? "date" : "text"}" />`
          }</div>`
        );
        break;
    }
  }

  const font = doc.settings.baseFont ?? "Helvetica";
  const googleLink = /^[\w ]+$/.test(font) ? `  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=${encodeURIComponent(font).replace(/%20/g, "+")}&display=swap" />` : "";
  const fontCss = `font-family:${fontStack(font)}`;

  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="generator" content="AlteOS Docs — export local" />
  <title>${escapeHtml(doc.name)}</title>
${googleLink}
  <style>
    :root { color-scheme: light; }
    body { margin: 0; background: #F6F4EF; ${fontCss}; color: #1C1B1A; }
    main { max-width: 820px; margin: 0 auto; padding: 56px 32px; background: #FFFFFF; min-height: calc(100vh - 112px); }
    .aos-title { font-size: 28px; margin: 0 0 4px; letter-spacing: -0.01em; }
    .aos-subtitle { color: #57544E; font-style: italic; margin-top: 0; }
    h2 { font-size: 20px; margin-top: 28px; }
    h3 { font-size: 16px; margin-top: 22px; }
    h4 { font-size: 14px; margin-top: 18px; color: #3C3A36; }
    blockquote { border-left: 3px solid #0E7C66; margin: 14px 0; padding: 2px 0 2px 14px; color: #4A4844; font-style: italic; }
    pre { background: #F4F2ED; border: 1px solid #E3E0D8; border-radius: 8px; padding: 12px 14px; overflow-x: auto; font-size: 13px; }
    code { font-family: 'JetBrains Mono', 'Courier New', monospace; }
    .aos-callout { border-radius: 8px; padding: 10px 14px; margin: 12px 0; }
    .aos-callout.info { background: #EAF3EF; border-left: 3px solid #0E7C66; }
    .aos-callout.warning { background: #FBF3E4; border-left: 3px solid #B7791F; }
    .aos-callout.success { background: #EDF3E6; border-left: 3px solid #4C7A34; }
    .aos-checklist { list-style: none; padding-left: 4px; }
    .aos-checklist li { display: flex; gap: 8px; align-items: baseline; margin: 4px 0; }
    .aos-checklist li.done { color: #8A8782; text-decoration: line-through; }
    .aos-checklist input { accent-color: #0E7C66; }
    table { border-collapse: collapse; width: 100%; margin: 14px 0; }
    th, td { border: 1px solid #D8D4CB; padding: 6px 9px; text-align: left; font-size: 14px; }
    th { background: #EDF0EE; }
    img { display: block; border-radius: 6px; margin: 14px 0; }
    .aos-field { margin: 10px 0; }
    .aos-field label { display: block; font-size: 13px; margin-bottom: 3px; }
    .aos-field input[type="text"], .aos-field input[type="date"], .aos-field textarea { width: 100%; border: 1px solid #B8B4AA; border-radius: 6px; padding: 6px 8px; font: inherit; }
    footer { text-align: center; color: #8A8782; font-size: 12px; padding: 18px; }
  </style>
</head>
<body>
  <main>
${body.map((l) => `    ${l}`).join("\n")}
  </main>
  <footer>Exporté depuis AlteOS Docs — fichier autonome généré sur votre appareil.</footer>
</body>
</html>
`;
}

function listItemsHtml(html: string): string {
  if (typeof window === "undefined") return "";
  const div = document.createElement("div");
  div.innerHTML = html;
  const items: string[] = [];
  for (const child of Array.from(div.childNodes)) {
    const isEl = child.nodeType === Node.ELEMENT_NODE;
    const inner = isEl ? sanitizeRichHtml((child as HTMLElement).innerHTML) : escapeHtml(child.textContent ?? "");
    if (!htmlToText(isEl ? (child as HTMLElement).outerHTML : child.textContent ?? "").trim()) continue;
    items.push(`<li>${inner}</li>`);
  }
  return items.join("");
}

// ---------------------------------------------------------------------------
// Texte brut
// ---------------------------------------------------------------------------

export function blocksToPlainText(doc: AlteosDoc): string {
  const out: string[] = [];
  for (const b of doc.blocks) {
    switch (b.type) {
      case "title":
        out.push(b.text.toUpperCase(), "=".repeat(Math.min(60, b.text.length)), "");
        break;
      case "subtitle":
        out.push(b.text, "");
        break;
      case "h1":
      case "h2":
      case "h3":
        out.push(b.text, "-".repeat(Math.min(50, b.text.length)), "");
        break;
      case "paragraph":
        out.push(htmlToText(b.html), "");
        break;
      case "list":
        out.push(htmlToText(b.html), "");
        break;
      case "checklist":
        for (const e of b.entries) out.push(`[${e.done ? "x" : " "}] ${e.text}`);
        out.push("");
        break;
      case "quote":
        out.push(htmlToText(b.html), "");
        break;
      case "code":
        out.push(htmlToText(b.html), "");
        break;
      case "callout":
        out.push(`[${b.variant}] ${htmlToText(b.html)}`, "");
        break;
      case "image":
        out.push("[image]", "");
        break;
      case "table":
        for (const row of b.rows) out.push(row.join("\t"));
        out.push("");
        break;
      case "field":
        out.push(`${b.label}${b.required ? " *" : ""} : ${b.fieldType === "checkbox" ? "[ ]" : "____________"}`, "");
        break;
    }
  }
  return `${out.join("\n").replace(/\n{3,}/g, "\n\n").trim()}\n`;
}
