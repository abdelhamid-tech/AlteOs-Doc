/**
 * AlteOS Docs — Types du modèle de données
 * ----------------------------------------
 * Toutes les données restent locales (IndexedDB). Aucun cloud, aucun serveur.
 *
 * Système de coordonnées :
 * - Les éléments (annotations, textes, images, formes) sont stockés en espace
 *   utilisateur PDF (points), origine en HAUT-GAUCHE de la page NON PIVOTÉE.
 * - Conversion affichage : pdfjs viewport.convertToViewportPoint / convertToPdfPoint.
 * - Conversion export : pdf-lib (origine bas-gauche) → y_pdf = Uh - y.
 */

// ---------------------------------------------------------------------------
// Types de documents
// ---------------------------------------------------------------------------

export type DocKind = "document" | "pdf" | "design" | "form";

export const KIND_LABEL: Record<DocKind, string> = {
  document: "Document",
  pdf: "PDF",
  design: "Design",
  form: "Formulaire",
};

export const KIND_ICON: Record<DocKind, string> = {
  document: "file-text",
  pdf: "file",
  design: "layout",
  form: "clipboard-list",
};

// ---------------------------------------------------------------------------
// Pages (PDF et Design)
// ---------------------------------------------------------------------------

/** Référence vers une page de PDF source, avec rotation appliquée par l'utilisateur. */
export interface PageRef {
  id: string;
  /** Index de page dans le PDF source (0-based). */
  src: number;
  /** Rotation supplémentaire appliquée : 0 | 90 | 180 | 270. */
  rotation: number;
  /** Page marquée d'un signet (navigation rapide, persistée dans le document). */
  bookmarked?: boolean;
}

/** Page de canevas libre (mode Design). */
export interface DesignPage {
  id: string;
  w: number; // points
  h: number;
  background: string; // couleur hex ou "#ffffff"
}

/** Formats de page prédéfinis (mode Design) — points. */
export const PAGE_PRESETS: { id: string; label: string; w: number; h: number }[] = [
  { id: "a4p", label: "A4 portrait", w: 595.28, h: 841.89 },
  { id: "a4l", label: "A4 paysage", w: 841.89, h: 595.28 },
  { id: "a5p", label: "A5 portrait", w: 419.53, h: 595.28 },
  { id: "letter", label: "Lettre US", w: 612, h: 792 },
  { id: "slide", label: "Diapositive 16:9", w: 960, h: 540 },
  { id: "square", label: "Carré 1:1", w: 720, h: 720 },
  { id: "story", label: "Story 9:16", w: 405, h: 720 },
  { id: "card", label: "Carte de visite", w: 340.16, h: 191.14 },
];

/** Couleurs de fond proposées pour les pages Design. */
export const PAGE_BG_COLORS = [
  "#FFFFFF",
  "#FBF7EF",
  "#F4F1EA",
  "#EAF3EF",
  "#E9F0FA",
  "#FAF0E9",
  "#F5EFE9",
  "#1C1B1A",
] as const;

// ---------------------------------------------------------------------------
// Éléments (annotations + contenus ajoutés) — utilisés par les modes PDF et Design
// ---------------------------------------------------------------------------

export type ItemTool =
  | "highlight"
  | "underline"
  | "strike"
  | "rect"
  | "ellipse"
  | "line"
  | "arrow"
  | "draw"
  | "text"
  | "note"
  | "image"
  | "signature"
  | "qr"
  | "icon";

export interface ItemBase {
  id: string;
  pageId: string;
  createdAt: number;
  /** Position en espace utilisateur (points), origine haut-gauche, page non pivotée. */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Élément verrouillé : position et taille non modifiables (calques). */
  locked?: boolean;
  /** Élément masqué : invisible à l'écran ET à l'export (calques). */
  hidden?: boolean;
}

export interface HighlightItem extends ItemBase {
  type: "highlight";
  /** Quads du surlignage (un par ligne de texte sélectionnée). */
  quads: { x: number; y: number; w: number; h: number }[];
  color: string;
}

export interface MarkItem extends ItemBase {
  type: "underline" | "strike";
  quads: { x: number; y: number; w: number; h: number }[];
  color: string;
}

export interface ShapeItem extends ItemBase {
  type: "rect" | "ellipse";
  color: string;
  strokeWidth: number;
  fill: boolean;
  fillColor: string;
  opacity: number;
}

export interface LineItem extends ItemBase {
  type: "line" | "arrow";
  /** Deuxième point (espace utilisateur, origine haut-gauche). */
  x2: number;
  y2: number;
  color: string;
  strokeWidth: number;
}

export interface DrawItem extends ItemBase {
  type: "draw";
  points: { x: number; y: number }[];
  color: string;
  strokeWidth: number;
}

export interface TextItem extends ItemBase {
  type: "text";
  text: string;
  fontSize: number;
  /** Identifiant de police (registre src/lib/fonts.ts) — 153 familles disponibles. */
  fontFamily: string;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  color: string;
  align: "left" | "center" | "right";
}

export interface NoteItem extends ItemBase {
  type: "note";
  text: string;
  color: string;
}

export interface ImageItem extends ItemBase {
  type: "image";
  assetId: string;
  rotation: number; // degrés, sens horaire (DOM)
  opacity: number; // 0..1
  /** Recadrage appliqué (fractions), appliqué lors de l'ajout → génère un nouvel asset. */
  /** Filtres appliqués — identiques à l'écran et à l'export (ré-encodage réel). */
  filters?: ImageFilters;
  /** Miroir horizontal / vertical. */
  flipH?: boolean;
  flipV?: boolean;
}

/** Réglages de filtres d'image (1 = neutre pour brightness/contraste, 0 = absent). */
export interface ImageFilters {
  grayscale: number; // 0..1
  sepia: number; // 0..1
  brightness: number; // 0.4..1.6 (1 = neutre)
  contrast: number; // 0.4..1.6 (1 = neutre)
  blur: number; // 0..6 (points)
}

export const NEUTRAL_IMAGE_FILTERS: ImageFilters = {
  grayscale: 0,
  sepia: 0,
  brightness: 1,
  contrast: 1,
  blur: 0,
};

/** true si aucun filtre n'est actif (aucun ré-encodage nécessaire à l'export). */
export function filtersAreNeutral(f?: ImageFilters): boolean {
  if (!f) return true;
  return (
    f.grayscale === 0 &&
    f.sepia === 0 &&
    Math.abs(f.brightness - 1) < 0.001 &&
    Math.abs(f.contrast - 1) < 0.001 &&
    f.blur === 0
  );
}

/** Chaîne CSS/canvas équivalente aux filtres d'une image. */
export function filtersToCss(f?: ImageFilters): string {
  if (filtersAreNeutral(f)) return "none";
  const v = f!;
  const parts: string[] = [];
  if (v.grayscale > 0) parts.push(`grayscale(${v.grayscale})`);
  if (v.sepia > 0) parts.push(`sepia(${v.sepia})`);
  if (Math.abs(v.brightness - 1) > 0.001) parts.push(`brightness(${v.brightness})`);
  if (Math.abs(v.contrast - 1) > 0.001) parts.push(`contrast(${v.contrast})`);
  if (v.blur > 0) parts.push(`blur(${v.blur}px)`);
  return parts.length ? parts.join(" ") : "none";
}

export interface SignatureItem extends ItemBase {
  type: "signature";
  assetId: string;
  rotation: number;
  opacity: number;
}

/** Code QR généré localement (aucune requête réseau). */
export interface QrItem extends ItemBase {
  type: "qr";
  /** Contenu encodé (URL, texte, Wi-Fi, contact…). */
  data: string;
  /** Couleur des modules sombres. */
  fg: string;
  /** Couleur de fond. */
  bg: string;
}

/** Icône vectorielle (registre src/lib/icon-paths.ts, tracés lucide ISC). */
export interface IconItem extends ItemBase {
  type: "icon";
  iconId: string;
  color: string;
}

export type Item =
  | HighlightItem
  | MarkItem
  | ShapeItem
  | LineItem
  | DrawItem
  | TextItem
  | NoteItem
  | ImageItem
  | SignatureItem
  | QrItem
  | IconItem;

// ---------------------------------------------------------------------------
// Blocs (modes Document et Formulaire)
// ---------------------------------------------------------------------------

export type Block =
  | { id: string; type: "title"; text: string }
  | { id: string; type: "subtitle"; text: string }
  | { id: string; type: "h1"; text: string }
  | { id: string; type: "h2"; text: string }
  | { id: string; type: "h3"; text: string }
  | { id: string; type: "paragraph"; html: string }
  | { id: string; type: "list"; ordered: boolean; html: string }
  | { id: string; type: "checklist"; entries: { id: string; text: string; done: boolean }[] }
  | { id: string; type: "quote"; html: string }
  | { id: string; type: "code"; html: string }
  | { id: string; type: "callout"; html: string; variant: "info" | "warning" | "success" }
  | { id: string; type: "divider" }
  | { id: string; type: "spacer"; h: number }
  | { id: string; type: "image"; assetId: string; widthPct: number; align: "left" | "center" | "right" }
  | {
      id: string;
      type: "table";
      header: boolean;
      rows: string[][];
    }
  | {
      id: string;
      type: "field";
      fieldType: "text" | "multiline" | "checkbox" | "date";
      label: string;
      required: boolean;
      placeholder?: string;
    };

export interface DocSettings {
  header: string;
  footer: string;
  pageNumbers: "none" | "bottom-center" | "bottom-right";
  showHeaderOnFirstPage: boolean;
  margin: number; // points
  /** Police de base du document (modes Document et Formulaire). */
  baseFont: string;
}

export const DEFAULT_DOC_SETTINGS: DocSettings = {
  header: "",
  footer: "",
  pageNumbers: "bottom-center",
  showHeaderOnFirstPage: true,
  margin: 64,
  baseFont: "Helvetica",
};

// ---------------------------------------------------------------------------
// Document AlteOS (enregistrement IndexedDB)
// ---------------------------------------------------------------------------

export interface AlteosDoc {
  id: string;
  name: string;
  kind: DocKind;
  createdAt: number;
  updatedAt: number;
  openedAt: number;
  favorite: boolean;
  deletedAt: number | null;
  /** Vignette (Blob PNG) affichée dans la bibliothèque. */
  thumb: Blob | null;
  /** PDF source (octets) — mode pdf uniquement. */
  pdfBytes: ArrayBuffer | null;
  pages: PageRef[]; // pdf
  designPages: DesignPage[]; // design
  items: Item[];
  blocks: Block[];
  formValues: Record<string, string | boolean>;
  settings: DocSettings;
  /** Dimensions du PDF source (par page src), en points, non pivoté. */
  srcPageSizes: { w: number; h: number }[];
  templateOf?: string;
}

export interface DocSummary {
  id: string;
  name: string;
  kind: DocKind;
  createdAt: number;
  updatedAt: number;
  openedAt: number;
  favorite: boolean;
  deletedAt: number | null;
  pageCount: number;
}

export interface AssetRecord {
  id: string;
  blob: Blob;
  mime: string;
  createdAt: number;
}

export interface SignatureRecord {
  id: string;
  blob: Blob;
  createdAt: number;
  label: string;
}

// ---------------------------------------------------------------------------
// Versions de documents (instantanés locaux, restauration)
// ---------------------------------------------------------------------------

/** Instantané du contenu éditorial d'un document (les assets restent partagés). */
export interface DocVersion {
  id: string;
  docId: string;
  createdAt: number;
  label: string;
  snapshot: {
    name: string;
    blocks: Block[];
    items: Item[];
    pages: PageRef[];
    designPages: DesignPage[];
    formValues: Record<string, string | boolean>;
    settings: DocSettings;
  };
}

// ---------------------------------------------------------------------------
// Outils éditeur
// ---------------------------------------------------------------------------

export type Tool =
  | "select"
  | "pan"
  | "highlight"
  | "underline"
  | "strike"
  | "rect"
  | "ellipse"
  | "line"
  | "arrow"
  | "draw"
  | "text"
  | "note"
  | "image"
  | "signature"
  | "qr"
  | "icon";

export const ANNOTATION_COLORS = [
  "#F5D90A", // jaune surligneur
  "#3FB950", // vert
  "#FF6B6B", // corail
  "#B197FC", // violet
  "#F7B32B", // ambre
  "#59636E", // gris encre
] as const;

export const INK_COLORS = [
  "#1C1B1A", // encre
  "#0E7C66", // jade AlteOS
  "#D64545", // rouge
  "#8B5E00", // brun
  "#33691E", // vert foncé
] as const;

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
