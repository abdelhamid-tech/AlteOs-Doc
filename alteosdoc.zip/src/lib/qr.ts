/**
 * AlteOS Docs — Génération de codes QR 100 % locale
 * ---------------------------------------------------
 * Encodage intégralement dans le navigateur (paquet « qrcode », MIT) :
 * aucune requête réseau, aucun service tiers, aucun coût.
 * Le résultat est un PNG (dataURL) utilisable à l'écran et à l'export PDF.
 */

import QRCode from "qrcode";

const cache = new Map<string, string>();

function key(data: string, fg: string, bg: string, px: number): string {
  return `${data}\u0000${fg}\u0000${bg}\u0000${px}`;
}

/**
 * Génère (ou relit du cache) un PNG de code QR.
 * @param px taille en pixels — les modules restent nets car le QR est vectoriel
 *           avant rastérisation ; 512 px couvre l'impression A5 confortablement.
 */
export async function qrDataUrl(data: string, fg = "#1C1B1A", bg = "#FFFFFF", px = 512): Promise<string> {
  const k = key(data, fg, bg, px);
  const hit = cache.get(k);
  if (hit) return hit;
  const url = await QRCode.toDataURL(data, {
    errorCorrectionLevel: "M",
    margin: 1,
    width: px,
    color: { dark: fg, light: bg },
  });
  if (cache.size > 120) cache.clear(); // borné : les QR partagent peu de variants
  cache.set(k, url);
  return url;
}

/** Blob PNG depuis un dataURL. */
export async function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  const res = await fetch(dataUrl);
  return res.blob();
}

/** Aperçu compact (rendu éditeur). */
export async function qrPreview(data: string, fg: string, bg: string): Promise<string> {
  return qrDataUrl(data, fg, bg, 256);
}
