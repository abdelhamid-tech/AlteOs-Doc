/**
 * AlteOS Docs — Rastérisation SVG → PNG (navigateur uniquement).
 * Utilisé par l'export PDF (icônes vectorielles) et la copie de page en image.
 * Aucune dépendance externe : Image + canvas 2D locaux.
 */

export async function rasterizeSvg(svgMarkup: string, pxWidth: number): Promise<Blob> {
  const svgBlob = new Blob([svgMarkup], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(svgBlob);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("SVG illisible"));
      el.src = url;
    });
    // Dimensions natives du SVG (largeur d'affichage) :
    // parse éventuel de width/height, sinon ratio via naturalWidth/Height.
    const ratio = img.naturalWidth && img.naturalHeight ? img.naturalHeight / img.naturalWidth : 1;
    const w = Math.max(1, Math.round(pxWidth));
    const h = Math.max(1, Math.round(pxWidth * (ratio || 1)));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(img, 0, 0, w, h);
    const out = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
    if (!out) throw new Error("La rastérisation a échoué.");
    return out;
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** SVG → octets PNG (prêt pour pdf-lib embedPng). */
export async function rasterizeSvgBytes(svgMarkup: string, pxWidth: number): Promise<Uint8Array> {
  const blob = await rasterizeSvg(svgMarkup, pxWidth);
  return new Uint8Array(await blob.arrayBuffer());
}
