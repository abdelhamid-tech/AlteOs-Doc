/**
 * AlteOS Docs — Stockage local IndexedDB
 * --------------------------------------
 * 100 % local : aucun fichier ne quitte l'appareil.
 * Magasins : documents, assets (images/signatures intégrées), signatures enregistrées, prefs.
 */

import type { AlteosDoc, AssetRecord, DocSummary, DocVersion, SignatureRecord } from "./types";

const DB_NAME = "alteos-docs";
const DB_VERSION = 2;

export const STORE_DOCS = "documents";
export const STORE_ASSETS = "assets";
export const STORE_SIGNATURES = "signatures";
export const STORE_PREFS = "prefs";
export const STORE_VERSIONS = "versions";

let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_DOCS)) {
        db.createObjectStore(STORE_DOCS, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(STORE_ASSETS)) {
        db.createObjectStore(STORE_ASSETS, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(STORE_SIGNATURES)) {
        db.createObjectStore(STORE_SIGNATURES, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(STORE_PREFS)) {
        db.createObjectStore(STORE_PREFS);
      }
      if (!db.objectStoreNames.contains(STORE_VERSIONS)) {
        const store = db.createObjectStore(STORE_VERSIONS, { keyPath: "id" });
        store.createIndex("docId", "docId", { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB indisponible"));
  });
  return dbPromise;
}

function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest): Promise<T> {
  return openDB().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(store, mode);
        const req = fn(t.objectStore(store));
        req.onsuccess = () => resolve(req.result as T);
        req.onerror = () => reject(req.error ?? new Error("Erreur IndexedDB"));
      })
  );
}

// ---------------------------------------------------------------------------
// Documents
// ---------------------------------------------------------------------------

export async function putDoc(doc: AlteosDoc): Promise<void> {
  await tx(STORE_DOCS, "readwrite", (s) => s.put(doc));
}

export async function getDoc(id: string): Promise<AlteosDoc | undefined> {
  return tx<AlteosDoc | undefined>(STORE_DOCS, "readonly", (s) => s.get(id));
}

export async function deleteDocForever(id: string): Promise<void> {
  const doc = await getDoc(id);
  await tx(STORE_DOCS, "readwrite", (s) => s.delete(id));
  if (doc) {
    // Nettoyage des assets orphelins
    for (const item of doc.items) {
      if ((item.type === "image" || item.type === "signature") && "assetId" in item) {
        await deleteAsset(item.assetId).catch(() => undefined);
      }
    }
    for (const b of doc.blocks) {
      if (b.type === "image") await deleteAsset(b.assetId).catch(() => undefined);
    }
  }
}

export async function getAllDocs(): Promise<AlteosDoc[]> {
  const docs = await tx<AlteosDoc[]>(STORE_DOCS, "readonly", (s) => s.getAll());
  return docs ?? [];
}

export async function listSummaries(): Promise<DocSummary[]> {
  const docs = await getAllDocs();
  return docs.map((d) => ({
    id: d.id,
    name: d.name,
    kind: d.kind,
    createdAt: d.createdAt,
    updatedAt: d.updatedAt,
    openedAt: d.openedAt,
    favorite: d.favorite,
    deletedAt: d.deletedAt ?? null,
    pageCount: d.kind === "pdf" ? d.pages.length : d.kind === "design" ? d.designPages.length : 1,
  }));
}

// ---------------------------------------------------------------------------
// Assets (images et signatures intégrées aux documents)
// ---------------------------------------------------------------------------

export async function putAsset(asset: AssetRecord): Promise<void> {
  await tx(STORE_ASSETS, "readwrite", (s) => s.put(asset));
}

export async function getAsset(id: string): Promise<AssetRecord | undefined> {
  return tx<AssetRecord | undefined>(STORE_ASSETS, "readonly", (s) => s.get(id));
}

/** Liste tous les assets (sauvegarde, duplication de documents). */
export async function listAssets(): Promise<AssetRecord[]> {
  const list = await tx<AssetRecord[]>(STORE_ASSETS, "readonly", (s) => s.getAll());
  return list ?? [];
}

export async function deleteAsset(id: string): Promise<void> {
  await tx(STORE_ASSETS, "readwrite", (s) => s.delete(id));
}

// ---------------------------------------------------------------------------
// Signatures enregistrées (réutilisables)
// ---------------------------------------------------------------------------

export async function putSignature(sig: SignatureRecord): Promise<void> {
  await tx(STORE_SIGNATURES, "readwrite", (s) => s.put(sig));
}

export async function getSignatures(): Promise<SignatureRecord[]> {
  const list = await tx<SignatureRecord[]>(STORE_SIGNATURES, "readonly", (s) => s.getAll());
  return (list ?? []).sort((a, b) => b.createdAt - a.createdAt);
}

export async function deleteSignature(id: string): Promise<void> {
  await tx(STORE_SIGNATURES, "readwrite", (s) => s.delete(id));
}

// ---------------------------------------------------------------------------
// Préférences (petites valeurs)
// ---------------------------------------------------------------------------

export async function getPref<T>(key: string): Promise<T | undefined> {
  return tx<T | undefined>(STORE_PREFS, "readonly", (s) => s.get(key));
}

export async function setPref<T>(key: string, value: T): Promise<void> {
  await tx(STORE_PREFS, "readwrite", (s) => s.put(value, key));
}

// ---------------------------------------------------------------------------
// Versions de documents (instantanés locaux, restauration)
// ---------------------------------------------------------------------------

const MAX_VERSIONS_PER_DOC = 20;

export async function putVersion(version: DocVersion): Promise<void> {
  await tx(STORE_VERSIONS, "readwrite", (s) => s.put(version));
  // Élagage : conserve au plus MAX_VERSIONS_PER_DOC instantanés par document.
  const all = await listVersions(version.docId);
  if (all.length > MAX_VERSIONS_PER_DOC) {
    for (const old of all.slice(MAX_VERSIONS_PER_DOC)) {
      await tx(STORE_VERSIONS, "readwrite", (s) => s.delete(old.id)).catch(() => undefined);
    }
  }
}

export async function listVersions(docId: string): Promise<DocVersion[]> {
  const all = await tx<DocVersion[]>(STORE_VERSIONS, "readonly", (s) => s.getAll());
  return (all ?? []).filter((v) => v.docId === docId).sort((a, b) => b.createdAt - a.createdAt);
}

export async function deleteVersion(id: string): Promise<void> {
  await tx(STORE_VERSIONS, "readwrite", (s) => s.delete(id));
}

// ---------------------------------------------------------------------------
// Estimation du stockage
// ---------------------------------------------------------------------------

export async function storageEstimate(): Promise<{ usage: number; quota: number } | null> {
  if (navigator.storage?.estimate) {
    const est = await navigator.storage.estimate();
    return { usage: est.usage ?? 0, quota: est.quota ?? 0 };
  }
  return null;
}
