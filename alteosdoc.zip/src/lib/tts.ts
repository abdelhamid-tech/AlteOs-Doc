/**
 * AlteOS Docs — Lecture à voix haute (text-to-speech)
 * -----------------------------------------------------
 * Utilise l'API SpeechSynthesis du navigateur : aucune requête réseau,
 * aucune dépendance, aucun coût. Les voix sont celles installées sur
 * l'appareil de l'utilisateur.
 */

export interface SpeakSegment {
  text: string;
  label: string;
}

export interface SpeakState {
  supported: boolean;
  playing: boolean;
  paused: boolean;
  segmentIndex: number;
  total: number;
}

type Listener = (s: SpeakState) => void;

class SpeakController {
  private segments: SpeakSegment[] = [];
  private index = 0;
  private listener: Listener | null = null;
  private voice: SpeechSynthesisVoice | null = null;
  private rate = 1;

  get supported(): boolean {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  }

  setListener(l: Listener): () => void {
    this.listener = l;
    this.emit();
    return () => {
      if (this.listener === l) this.listener = null;
    };
  }

  setVoice(v: SpeechSynthesisVoice | null): void {
    this.voice = v;
  }

  setRate(r: number): void {
    this.rate = Math.min(2, Math.max(0.5, r));
  }

  voices(): SpeechSynthesisVoice[] {
    if (!this.supported) return [];
    return window.speechSynthesis.getVoices().filter((v) => v.lang.toLowerCase().startsWith("fr") || true);
  }

  /** Voix françaises en priorité (l'app est francophone). */
  frenchVoices(): SpeechSynthesisVoice[] {
    return this.voices().sort((a, b) => {
      const aFr = a.lang.toLowerCase().startsWith("fr") ? 0 : 1;
      const bFr = b.lang.toLowerCase().startsWith("fr") ? 0 : 1;
      return aFr - bFr;
    });
  }

  start(segments: SpeakSegment[], from = 0): void {
    if (!this.supported || segments.length === 0) return;
    this.stopInternal();
    this.segments = segments;
    this.index = from;
    this.speakCurrent();
  }

  private speakCurrent(): void {
    if (!this.supported) return;
    const seg = this.segments[this.index];
    if (!seg) {
      this.emit({ playing: false, paused: false, segmentIndex: this.segments.length, total: this.segments.length });
      return;
    }
    const utter = new SpeechSynthesisUtterance(seg.text);
    if (this.voice) utter.voice = this.voice;
    utter.lang = this.voice?.lang ?? "fr-FR";
    utter.rate = this.rate;
    utter.onend = () => {
      this.index += 1;
      if (this.index < this.segments.length) this.speakCurrent();
      else this.emit({ playing: false, paused: false, segmentIndex: this.index, total: this.segments.length });
    };
    utter.onerror = () => {
      this.emit({ playing: false, paused: false, segmentIndex: this.index, total: this.segments.length });
    };
    window.speechSynthesis.speak(utter);
    this.emit({ playing: true, paused: false, segmentIndex: this.index, total: this.segments.length });
  }

  pause(): void {
    if (!this.supported) return;
    window.speechSynthesis.pause();
    this.emit({ playing: true, paused: true, segmentIndex: this.index, total: this.segments.length });
  }

  resume(): void {
    if (!this.supported) return;
    window.speechSynthesis.resume();
    this.emit({ playing: true, paused: false, segmentIndex: this.index, total: this.segments.length });
  }

  stop(): void {
    this.stopInternal();
    this.emit({ playing: false, paused: false, segmentIndex: 0, total: this.segments.length });
  }

  private stopInternal(): void {
    if (this.supported) window.speechSynthesis.cancel();
  }

  private emit(patch?: Partial<SpeakState>): void {
    this.listener?.({
      supported: this.supported,
      playing: patch?.playing ?? false,
      paused: patch?.paused ?? false,
      segmentIndex: patch?.segmentIndex ?? this.index,
      total: patch?.total ?? this.segments.length,
    });
  }
}

export const speak = new SpeakController();

/** Segments de lecture d'un document par blocs. */
export function blocksToSegments(blocks: { type: string; text?: string; html?: string; entries?: { text: string }[]; rows?: string[][] }[]): SpeakSegment[] {
  const segs: SpeakSegment[] = [];
  for (const b of blocks) {
    let text = "";
    if (typeof b.text === "string") text = b.text;
    else if (typeof b.html === "string") {
      if (typeof document === "undefined") text = b.html;
      else {
        const div = document.createElement("div");
        div.innerHTML = b.html;
        text = div.textContent ?? "";
      }
    } else if (Array.isArray(b.entries)) text = b.entries.map((e) => e.text).join(". ");
    else if (Array.isArray(b.rows)) text = b.rows.map((r) => r.join(", ")).join(". ");
    text = text.replace(/\s+/g, " ").trim();
    if (!text) continue;
    const label =
      b.type === "title" || b.type === "h1" || b.type === "h2" || b.type === "h3"
        ? text.slice(0, 40)
        : b.type === "checklist"
          ? "Liste de tâches"
          : `${text.slice(0, 40)}${text.length > 40 ? "…" : ""}`;
    segs.push({ text, label });
  }
  return segs;
}
