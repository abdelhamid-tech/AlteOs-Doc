/**
 * AlteOS Docs — Architecture des plans (freemium)
 * -----------------------------------------------
 * V1 : seul AlteOS Free est actif. Aucun paiement réel n'existe —
 * les plans payants sont affichés « Bientôt disponible ».
 * Toutes les limites et fonctionnalités sont centralisées ici :
 * aucune valeur n'est codée en dur ailleurs dans l'application.
 */

export type PlanId = "free" | "plus" | "pro" | "ultimate";

export interface FeatureFlag {
  key: string;
  label: string;
  enabled: boolean;
  planRequired: PlanId;
}

export interface PlanConfig {
  id: PlanId;
  name: string;
  tagline: string;
  /** Prix mensuel en USD — null signifie « à venir », aucun paiement configuré. */
  price: number | null;
  /** Plan réellement souscrit dans la V1 (toujours 'free'). */
  available: boolean;
  ai: {
    actionsPerMonth: number;
  };
  features: FeatureFlag[];
}

const COMMON_FEATURES: FeatureFlag[] = [
  { key: "docs.create", label: "Créer des documents, designs et formulaires", enabled: true, planRequired: "free" },
  { key: "pdf.import", label: "Ouvrir et lire des PDF", enabled: true, planRequired: "free" },
  { key: "pdf.annotate", label: "Annoter : surligner, dessiner, commenter", enabled: true, planRequired: "free" },
  { key: "pdf.edit", label: "Ajouter texte, images et formes", enabled: true, planRequired: "free" },
  { key: "pdf.pages", label: "Organiser, tourner et extraire les pages", enabled: true, planRequired: "free" },
  { key: "pdf.signature", label: "Signer des documents", enabled: true, planRequired: "free" },
  { key: "export.local", label: "Exporter en PDF et PNG (local)", enabled: true, planRequired: "free" },
  { key: "storage.local", label: "Stockage local sur cet appareil", enabled: true, planRequired: "free" },
  { key: "templates", label: "Bibliothèque de modèles", enabled: true, planRequired: "free" },
  { key: "ai.assist", label: "AlteOS Assist (IA)", enabled: false, planRequired: "plus" },
  { key: "cloud.sync", label: "AlteOS Cloud : sauvegarde et synchronisation", enabled: false, planRequired: "plus" },
  { key: "share.collaborate", label: "Inviter et collaborer en temps réel", enabled: false, planRequired: "pro" },
  { key: "history.versions", label: "Historique des versions", enabled: false, planRequired: "pro" },
  { key: "publish.web", label: "Publier sur le web", enabled: false, planRequired: "ultimate" },
];

export const PLANS: Record<PlanId, PlanConfig> = {
  free: {
    id: "free",
    name: "AlteOS Free",
    tagline: "L'essentiel, pour toujours. 0 $.",
    price: 0,
    available: true,
    ai: { actionsPerMonth: 20 },
    features: COMMON_FEATURES,
  },
  plus: {
    id: "plus",
    name: "AlteOS Plus",
    tagline: "Fonctions avancées et AlteOS Assist.",
    price: null,
    available: false,
    ai: { actionsPerMonth: 200 },
    features: COMMON_FEATURES,
  },
  pro: {
    id: "pro",
    name: "AlteOS Pro",
    tagline: "Pour un usage intensif et les équipes.",
    price: null,
    available: false,
    ai: { actionsPerMonth: 1000 },
    features: COMMON_FEATURES,
  },
  ultimate: {
    id: "ultimate",
    name: "AlteOS Ultimate",
    tagline: "Toutes les capacités AlteOS, sans plafond.",
    price: null,
    available: false,
    ai: { actionsPerMonth: 5000 },
    features: COMMON_FEATURES,
  },
};

/**
 * Plan actif. Dans la V1, il n'existe ni compte ni paiement :
 * la valeur est donc une constante locale, remplaçable plus tard
 * par la lecture d'un compte utilisateur.
 */
export const CURRENT_PLAN: PlanId = "free";

export function getPlan(id: PlanId = CURRENT_PLAN): PlanConfig {
  return PLANS[id];
}

export function isFeatureEnabled(key: string): boolean {
  const plan = getPlan();
  const f = plan.features.find((x) => x.key === key);
  return f ? f.enabled && plan.available : false;
}
