"use client";

import { AppShell } from "@/components/alteos/app-shell";

export default function Page() {
  return <AppShell />;
}
