import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/server/admin-auth";
import { prisma } from "@/lib/server/prisma";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Non autorisé." }, { status: 401 });
  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const [total, success, failures, recent] = await Promise.all([
    prisma.assistUsage.count({ where: { createdAt: { gte: since } } }),
    prisma.assistUsage.count({ where: { createdAt: { gte: since }, success: true } }),
    prisma.assistUsage.count({ where: { createdAt: { gte: since }, success: false } }),
    prisma.assistUsage.findMany({ where: { createdAt: { gte: since } }, orderBy: { createdAt: "desc" }, take: 20, select: { action: true, success: true, statusCode: true, createdAt: true, keyId: true, inputChars: true, outputChars: true } }),
  ]);
  return NextResponse.json({ total, success, failures, recent });
}
