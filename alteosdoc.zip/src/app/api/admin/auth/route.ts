import { NextResponse } from "next/server";
import { checkAdminPassword, makeSession, setAdminCookie } from "@/lib/server/admin-auth";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const password = typeof body.password === "string" ? body.password : "";
  if (!checkAdminPassword(password)) return NextResponse.json({ error: "Mot de passe incorrect." }, { status: 401 });
  await setAdminCookie(makeSession());
  return NextResponse.json({ ok: true });
}
