import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/server/admin-auth";
import { prisma } from "@/lib/server/prisma";
import { encryptApiKey, publicKeys } from "@/lib/server/key-vault";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Non autorisé." }, { status: 401 });
  return NextResponse.json({ keys: await publicKeys() });
}

export async function POST(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Non autorisé." }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const apiKey = typeof body.apiKey === "string" ? body.apiKey.trim() : "";
  const label = typeof body.label === "string" && body.label.trim() ? body.label.trim().slice(0, 80) : `Clé ${new Date().toLocaleDateString("fr-CA")}`;
  if (!apiKey) return NextResponse.json({ error: "Clé API manquante." }, { status: 400 });
  const encrypted = encryptApiKey(apiKey);
  const highest = await prisma.assistApiKey.aggregate({ _max: { priority: true } });
  const row = await prisma.assistApiKey.create({ data: { label, provider: "openai", ...encrypted, priority: (highest._max.priority ?? -1) + 1 } });
  return NextResponse.json({ id: row.id, keys: await publicKeys() }, { status: 201 });
}

export async function PATCH(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Non autorisé." }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  if (typeof body.id !== "string") return NextResponse.json({ error: "ID manquant." }, { status: 400 });
  const data: { enabled?: boolean; label?: string; priority?: number } = {};
  if (typeof body.enabled === "boolean") data.enabled = body.enabled;
  if (typeof body.label === "string") data.label = body.label.trim().slice(0, 80);
  if (typeof body.priority === "number" && Number.isFinite(body.priority)) data.priority = Math.trunc(body.priority);
  await prisma.assistApiKey.update({ where: { id: body.id }, data });
  return NextResponse.json({ keys: await publicKeys() });
}

export async function DELETE(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Non autorisé." }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  if (typeof body.id !== "string") return NextResponse.json({ error: "ID manquant." }, { status: 400 });
  await prisma.assistApiKey.delete({ where: { id: body.id } });
  return NextResponse.json({ keys: await publicKeys() });
}
