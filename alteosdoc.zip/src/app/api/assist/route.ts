import { NextResponse } from "next/server";
import { runAssist, type AssistActionId } from "@/lib/server/assist";

const WINDOW = 60_000;
const MAX_PER_IP = 20;
const buckets = new Map<string, { count: number; reset: number }>();

function clientIp(req: Request) {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
}

export async function POST(req: Request) {
  const ip = clientIp(req);
  const now = Date.now();
  const bucket = buckets.get(ip);
  if (!bucket || bucket.reset <= now) buckets.set(ip, { count: 1, reset: now + WINDOW });
  else if (++bucket.count > MAX_PER_IP) return NextResponse.json({ error: "Trop de requêtes. Réessayez dans un instant." }, { status: 429 });

  const body = await req.json().catch(() => ({}));
  const action = body.action as AssistActionId;
  const text = typeof body.text === "string" ? body.text.trim() : "";
  const targetLanguage = typeof body.targetLanguage === "string" ? body.targetLanguage.slice(0, 40) : undefined;
  if (!text) return NextResponse.json({ error: "Texte manquant." }, { status: 400 });
  if (text.length > 60_000) return NextResponse.json({ error: "Texte trop volumineux." }, { status: 413 });
  const allowed = new Set(["improve", "correct", "summarize", "rewrite", "translate", "shorten", "expand", "title", "outline", "explain"]);
  if (!allowed.has(action)) return NextResponse.json({ error: "Action invalide." }, { status: 400 });

  try {
    const result = await runAssist(action, text, targetLanguage);
    return NextResponse.json({ text: result });
  } catch (error) {
    const message = error instanceof Error ? error.message : "AlteOS Assist est temporairement indisponible.";
    const status = message === "NO_AI_KEY" ? 503 : 502;
    return NextResponse.json({ error: status === 503 ? "AlteOS Assist n'est pas configuré." : "AlteOS Assist est temporairement indisponible." }, { status });
  }
}
