"use client";

import { useEffect, useState } from "react";
import { KeyRound, LogOut, Plus, RefreshCw, ShieldCheck, Trash2, Power, BarChart3 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface KeyRow { id: string; label: string; enabled: boolean; priority: number; successCount: number; errorCount: number; lastUsedAt: string | null; lastError: string | null; createdAt: string; }
interface Stats { total: number; success: number; failures: number; }

export default function AdminAssistPage() {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [password, setPassword] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [label, setLabel] = useState("");
  const [keys, setKeys] = useState<KeyRow[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const [kr, sr] = await Promise.all([fetch("/api/admin/keys"), fetch("/api/admin/stats")]);
    if (kr.status === 401) { setAuthenticated(false); return; }
    setAuthenticated(true);
    const kd = await kr.json(); const sd = await sr.json();
    setKeys(kd.keys ?? []); setStats(sd);
  }
  useEffect(() => { load().catch(() => setAuthenticated(false)); }, []);

  async function login() {
    setBusy(true);
    const r = await fetch("/api/admin/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password }) });
    setBusy(false);
    if (!r.ok) return toast.error("Mot de passe incorrect.");
    setPassword(""); await load(); toast.success("Dashboard sécurisé ouvert.");
  }

  async function addKey() {
    if (!apiKey.trim()) return toast.error("Collez une clé API.");
    setBusy(true);
    const r = await fetch("/api/admin/keys", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ apiKey, label }) });
    const d = await r.json(); setBusy(false);
    if (!r.ok) return toast.error(d.error ?? "Impossible d’ajouter la clé.");
    setApiKey(""); setLabel(""); setKeys(d.keys); toast.success("Clé ajoutée et chiffrée côté serveur.");
  }

  async function toggle(k: KeyRow) {
    const r = await fetch("/api/admin/keys", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: k.id, enabled: !k.enabled }) });
    const d = await r.json(); if (r.ok) setKeys(d.keys); else toast.error(d.error ?? "Erreur");
  }

  async function remove(k: KeyRow) {
    if (!confirm(`Supprimer « ${k.label} » ?`)) return;
    const r = await fetch("/api/admin/keys", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: k.id }) });
    const d = await r.json(); if (r.ok) setKeys(d.keys); else toast.error(d.error ?? "Erreur");
  }

  async function logout() { await fetch("/api/admin/logout", { method: "POST" }); setAuthenticated(false); }

  if (authenticated === null) return <main className="min-h-screen grid place-items-center"><p className="text-muted-foreground">Vérification…</p></main>;
  if (!authenticated) return (
    <main className="min-h-screen bg-background grid place-items-center p-6">
      <Card className="w-full max-w-md">
        <CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="size-5" /> AlteOS Control Center</CardTitle><CardDescription>Zone privée d’administration d’AlteOS Assist.</CardDescription></CardHeader>
        <CardContent className="space-y-4"><Input type="password" placeholder="Mot de passe administrateur" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && login()} /><Button className="w-full" onClick={login} disabled={busy}>Ouvrir le dashboard</Button></CardContent>
      </Card>
    </main>
  );

  return (
    <main className="min-h-screen bg-background p-4 sm:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        <header className="flex items-center justify-between gap-4"><div><p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">AlteOS</p><h1 className="text-2xl font-semibold">Control Center · Assist</h1></div><div className="flex gap-2"><Button variant="outline" size="sm" onClick={() => load()}><RefreshCw className="size-4 mr-2" />Actualiser</Button><Button variant="ghost" size="sm" onClick={logout}><LogOut className="size-4 mr-2" />Quitter</Button></div></header>

        <div className="grid sm:grid-cols-3 gap-3">
          <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Requêtes · 30 jours</p><p className="text-2xl font-semibold mt-1">{stats?.total ?? 0}</p></CardContent></Card>
          <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Succès</p><p className="text-2xl font-semibold mt-1">{stats?.success ?? 0}</p></CardContent></Card>
          <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Échecs / fallback</p><p className="text-2xl font-semibold mt-1">{stats?.failures ?? 0}</p></CardContent></Card>
        </div>

        <Card><CardHeader><CardTitle className="flex items-center gap-2"><KeyRound className="size-5" /> Pool de clés OpenAI</CardTitle><CardDescription>Les clés complètes ne sont jamais affichées. Elles sont chiffrées avant d’être enregistrées.</CardDescription></CardHeader><CardContent className="space-y-4">
          <div className="grid sm:grid-cols-[1fr_2fr_auto] gap-2"><Input placeholder="Nom, ex. Production 1" value={label} onChange={(e) => setLabel(e.target.value)} /><Input type="password" placeholder="Collez la clé API ici" value={apiKey} onChange={(e) => setApiKey(e.target.value)} /><Button onClick={addKey} disabled={busy}><Plus className="size-4 mr-2" />Ajouter</Button></div>
          <div className="space-y-2">
            {keys.length === 0 && <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">Aucune clé. Ajoutez votre première clé pour activer AlteOS Assist.</div>}
            {keys.map((k) => <div key={k.id} className="rounded-xl border p-4 flex flex-col sm:flex-row sm:items-center gap-3"><div className="flex-1 min-w-0"><div className="flex items-center gap-2"><p className="font-medium truncate">{k.label}</p><Badge variant={k.enabled ? "default" : "secondary"}>{k.enabled ? "ACTIVE" : "DÉSACTIVÉE"}</Badge></div><p className="text-xs text-muted-foreground mt-1">Priorité {k.priority} · {k.successCount} succès · {k.errorCount} erreurs {k.lastError ? `· ${k.lastError.slice(0, 90)}` : ""}</p></div><div className="flex gap-2"><Button size="sm" variant="outline" onClick={() => toggle(k)}><Power className="size-4 mr-1" />{k.enabled ? "Désactiver" : "Activer"}</Button><Button size="sm" variant="ghost" onClick={() => remove(k)}><Trash2 className="size-4" /></Button></div></div>)}
          </div>
        </CardContent></Card>

        <Card><CardHeader><CardTitle className="flex items-center gap-2"><BarChart3 className="size-5" /> Fonctionnement</CardTitle></CardHeader><CardContent className="text-sm text-muted-foreground space-y-2"><p>AlteOS essaie les clés actives dans leur ordre de priorité. Si une clé rencontre une erreur récupérable, le serveur passe automatiquement à la suivante.</p><p>Le navigateur reçoit uniquement la réponse d’AlteOS Assist. Il ne reçoit jamais les clés, leur contenu, ni les données de chiffrement.</p></CardContent></Card>
      </div>
    </main>
  );
}
