// Génère un PDF d'exemple multi-pages (français) pour tester l'import dans AlteOS Docs.
// Exécuté avec bun. Sortie : public/exemple.pdf
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

const doc = await PDFDocument.create();
const font = await doc.embedFont(StandardFonts.Helvetica);
const bold = await doc.embedFont(StandardFonts.HelveticaBold);
const italic = await doc.embedFont(StandardFonts.HelveticaOblique);

const W = 595.28, H = 841.89; // A4

function page1() {
  const p = doc.addPage([W, H]);
  p.drawText("Rapport d'activité trimestriel", { x: 60, y: H - 90, size: 24, font: bold, color: rgb(0.06, 0.28, 0.24) });
  p.drawText("Exemple de document importé dans AlteOS Docs", { x: 60, y: H - 115, size: 12, font: italic, color: rgb(0.35, 0.35, 0.33) });
  p.drawLine({ start: { x: 60, y: H - 130 }, end: { x: W - 60, y: H - 130 }, thickness: 1.2, color: rgb(0.06, 0.28, 0.24) });

  const paras = [
    "Ce document sert d'exemple pour tester l'ouverture, l'annotation et l'édition de PDF",
    "dans AlteOS Docs. Il contient plusieurs pages, du texte sélectionnable, des images et",
    "des tableaux afin de couvrir les cas d'usage principaux du lecteur intégré.",
  ];
  let y = H - 170;
  for (const t of paras) {
    p.drawText(t, { x: 60, y, size: 11, font, color: rgb(0.15, 0.15, 0.14) });
    y -= 20;
  }
  y -= 10;
  const items = [
    "• Ouverture et lecture locales, sans envoi vers un serveur",
    "• Surlignage, soulignement et barré sur le texte sélectionnable",
    "• Ajout de texte, d'images et de formes",
    "• Signature manuscrite ou importée",
    "• Réorganisation, rotation et suppression de pages",
  ];
  for (const t of items) {
    p.drawText(t, { x: 70, y, size: 11, font, color: rgb(0.2, 0.2, 0.19) });
    y -= 18;
  }
  // Tableau simple
  y -= 16;
  const cols = [60, 240, 380, 500];
  const rows = [
    ["Trimestre", "Documents créés", "Annotations", "Exports"],
    ["T1", "142", "318", "97"],
    ["T2", "168", "402", "121"],
    ["T3", "205", "511", "156"],
  ];
  for (let r = 0; r < rows.length; r++) {
    const rw = rows[r];
    for (let c = 0; c < 4; c++) {
      p.drawText(rw[c], { x: cols[c] + 6, y: y - 14, size: 10, font: r === 0 ? bold : font, color: rgb(0.13, 0.13, 0.12) });
    }
    if (r === 0) p.drawRectangle({ x: 60, y: y - 20, width: W - 120, height: 24, color: rgb(0.93, 0.96, 0.95) });
    p.drawRectangle({ x: 60, y: y - 20, width: W - 120, height: 24, borderColor: rgb(0.78, 0.78, 0.76), borderWidth: 0.8 });
    y -= 26;
  }
  p.drawText("Page 1 — texte, liste et tableau", { x: 60, y: 50, size: 9, font: italic, color: rgb(0.5, 0.5, 0.48) });
}

function page2() {
  const p = doc.addPage([W, H]);
  p.drawText("Présentation visuelle", { x: 60, y: H - 90, size: 20, font: bold, color: rgb(0.06, 0.28, 0.24) });
  // Image vectorielle simulée (formes)
  p.drawRectangle({ x: 60, y: H - 380, width: 220, height: 160, color: rgb(0.90, 0.93, 0.92), borderColor: rgb(0.06, 0.28, 0.24), borderWidth: 1 });
  p.drawEllipse({ x: 170, y: H - 300, xScale: 60, yScale: 60, color: rgb(0.06, 0.28, 0.24) });
  p.drawEllipse({ x: 200, y: H - 280, xScale: 30, yScale: 30, color: rgb(0.55, 0.75, 0.7) });
  p.drawRectangle({ x: 320, y: H - 380, width: 215, height: 160, color: rgb(0.96, 0.95, 0.9), borderColor: rgb(0.85, 0.7, 0.2), borderWidth: 1 });
  p.drawText("Formes vectorielles", { x: 68, y: H - 400, size: 10, font });
  p.drawText("Blocs de couleur", { x: 328, y: H - 400, size: 10, font });
  const body = [
    "Cette deuxième page vérifie : navigation entre les pages, zoom, affichage des miniatures,",
    "ainsi que le recalcul de la mise en page lors de l'édition. Les paragraphes longs permettent",
    "de tester la sélection de texte sur plusieurs lignes, le surlignage et le copier-coller.",
    "",
    "Essayez : sélectionnez cette phrase, puis choisissez l'outil Surligner dans la barre d'outils.",
    "Le surlignage suit exactement le texte sélectionné, page après page, et reste modifiable.",
  ];
  let y = H - 440;
  for (const t of body) {
    p.drawText(t, { x: 60, y, size: 11, font, color: rgb(0.16, 0.16, 0.15) });
    y -= 18;
  }
  p.drawText("Page 2 — formes et texte long", { x: 60, y: 50, size: 9, font: italic, color: rgb(0.5, 0.5, 0.48) });
}

function page3() {
  const p = doc.addPage([W, H]);
  p.drawText("Champs et validation", { x: 60, y: H - 90, size: 20, font: bold, color: rgb(0.06, 0.28, 0.24) });
  let y = H - 150;
  const lines = [
    "Nom du responsable : ________________________",
    "Date d'approbation : ____ / ____ / ________",
    "Signature : zone réservée en bas de page.",
    "",
    "Cette page permet de tester le placement d'une signature, son redimensionnement",
    "et son intégration lors de l'export final du document.",
  ];
  for (const t of lines) {
    p.drawText(t, { x: 60, y, size: 12, font, color: rgb(0.16, 0.16, 0.15) });
    y -= 24;
  }
  p.drawRectangle({ x: 60, y: 120, width: 240, height: 90, borderColor: rgb(0.6, 0.6, 0.58), borderWidth: 1, borderDashArray: [4, 4] });
  p.drawText("Placer la signature ici", { x: 92, y: 160, size: 10, font: italic, color: rgb(0.55, 0.55, 0.53) });
  p.drawText("Page 3 — signature", { x: 60, y: 50, size: 9, font: italic, color: rgb(0.5, 0.5, 0.48) });
}

function page4() {
  // Page en paysage pour tester l'affichage multi-formats
  const p = doc.addPage([841.89, 595.28]);
  p.drawText("Annexe — Format paysage", { x: 60, y: 520, size: 20, font: bold, color: rgb(0.06, 0.28, 0.24) });
  const body = [
    "Cette page est au format paysage afin de vérifier que les dimensions de chaque page",
    "sont bien respectées à l'affichage, au zoom et lors de l'export.",
    "Testez la rotation de cette page depuis le panneau des pages : le contenu doit rester net.",
  ];
  let y = 480;
  for (const t of body) {
    p.drawText(t, { x: 60, y, size: 11, font, color: rgb(0.16, 0.16, 0.15) });
    y -= 20;
  }
  p.drawText("Page 4 — annexe", { x: 60, y: 40, size: 9, font: italic, color: rgb(0.5, 0.5, 0.48) });
}

function page5() {
  const p = doc.addPage([W, H]);
  p.drawText("Dernière page", { x: 60, y: H - 90, size: 20, font: bold, color: rgb(0.06, 0.28, 0.24) });
  p.drawText("Merci d'avoir testé AlteOS Docs — Créer sans limites. Modifier sans complexité. Garder le contrôle.", { x: 60, y: H - 130, size: 12, font: italic, color: rgb(0.3, 0.3, 0.28) });
  p.drawText("Page 5", { x: 60, y: 50, size: 9, font: italic, color: rgb(0.5, 0.5, 0.48) });
}

page1(); page2(); page3(); page4(); page5();

const bytes = await doc.save();
await Bun.write("public/exemple.pdf", bytes);
console.log("public/exemple.pdf généré :", bytes.length, "octets,", doc.getPageCount(), "pages");
