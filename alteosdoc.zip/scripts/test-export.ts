// Reproduit exportPdfDoc avec les mêmes types d'éléments pour diagnostiquer l'erreur de police.
import { PDFDocument, degrees, rgb } from "pdf-lib";

const bytes = await Bun.file("public/exemple.pdf").arrayBuffer();
const src = await PDFDocument.load(bytes, { ignoreEncryption: true });
const out = await PDFDocument.create();

const fonts = new Map();
const all = ["Helvetica","Helvetica-Bold","Helvetica-Oblique","Helvetica-BoldOblique","Times-Roman","Times-Bold","Times-Italic","Times-BoldItalic","Courier","Courier-Bold","Courier-Oblique","Courier-BoldOblique"];
for (const f of all) fonts.set(f, await out.embedFont(f));
console.log("clés:", [...fonts.keys()].join(","));

const copied = await out.copyPages(src, [0, 1, 2, 3]);
const page = copied[0];
page.setRotation(degrees(0));
out.addPage(page);

const Uh = 841.89;
// 1. highlight quads
for (const q of [{ x: 60, y: 160, w: 200, h: 12 }, { x: 60, y: 174, w: 180, h: 12 }]) {
  page.drawRectangle({ x: q.x, y: Uh - q.y - q.h, width: q.w, height: q.h, color: rgb(0.96, 0.85, 0.04), opacity: 0.32 });
}
// 2. rect
page.drawRectangle({ x: 100, y: 500, width: 130, height: 66, borderColor: rgb(0.11, 0.11, 0.1), borderWidth: 2 });
// 3. text — reproduit wrapText + drawText
const item = { text: "Texte ajouté par AlteOS", fontSize: 12, fontFamily: "Helvetica", bold: false, italic: false, underline: false, color: "#1C1B1A", align: "left", x: 120, y: 300, w: 220, h: 28 };
const name = "Helvetica";
const font = fonts.get(name);
console.log("font résolue:", font?.name);
const size = 12;
const asc = font.heightAtSize(size, { descender: false });
page.drawText(item.text, { x: item.x, y: Uh - item.y - asc, size, font, color: rgb(0.11, 0.11, 0.1) });

// 4. dessin libre (drawSvgPath)
page.drawSvgPath("M 100 700 L 150 720 L 200 690", { x: 0, y: Uh, borderColor: rgb(0.1, 0.3, 0.25), borderWidth: 2 });

const saved = await out.save({ useObjectStreams: true });
await Bun.write("scripts/out-export-test.pdf", saved);
console.log("OK —", saved.length, "octets");
