/**
 * Vérification du PDF exporté depuis le navigateur :
 *  - police Google (Caveat) réellement incorporée (FontFile2 + nom) ;
 *  - texte accentué présent (extraction des chaînes) ;
 *  - métadonnées AlteOS.
 */
import { PDFDocument } from "pdf-lib";

async function main() {
  const path = "/home/z/Downloads/Lettre typographique.pdf";
  const bytes = new Uint8Array(await Bun.file(path).arrayBuffer());
  const doc = await PDFDocument.load(bytes);

  // Les objets peuvent être compressés (object streams) : ré-enregistre à plat.
  const flat = Buffer.from(await doc.save({ useObjectStreams: false }));
  const raw = flat.toString("latin1");

  console.log("fichier:", path, bytes.length, "octets");
  console.log("FontFile2 présent :", raw.includes("FontFile2"));
  console.log("Caveat présent     :", raw.includes("Caveat"));

  console.log("pages:", doc.getPageCount());
  console.log("titre:", doc.getTitle());
  console.log("producteur:", doc.getProducer());

  const fontNames = [...raw.matchAll(/BaseFont\s*\/([A-Za-z0-9+\-]+)/g)].map((m) => m[1]);
  console.log("BaseFont trouvés  :", [...new Set(fontNames)].join(", "));

  const ok = raw.includes("FontFile2") && raw.includes("Garamond");
  console.log(ok ? "✔ POLICE EB GARAMOND INCORPORÉE AU PDF" : "✘ ÉCHEC d'incorporation");

  // Métadonnées en UTF-16 hex (comportement pdf-lib) : décodage et vérification
  const hexTitle = [...raw.matchAll(/\/Title\s*<FEFF([0-9A-Fa-f]+)>/g)]
    .map((m) => new TextDecoder("utf-16be").decode(Buffer.from(m[1], "hex")))
    .join(" | ");
  console.log("Titre (UTF-16 décodé):", hexTitle || "(non hex)");

  // Extraction du texte réel via pdf.js — prouve l'encodage des accents
  try {
    const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
    const data = new Uint8Array(flat.buffer.slice(flat.byteOffset, flat.byteOffset + flat.byteLength));
    const pdf = await pdfjs.getDocument({ data, useSystemFonts: false, isEvalSupported: false }).promise;
    const page = await pdf.getPage(1);
    const tc = await page.getTextContent();
    const text = tc.items.map((i: { str?: string }) => i.str ?? "").join("");
    console.log("Texte extrait:", JSON.stringify(text.slice(0, 80)));
    const accentsOk = text.includes("Élégance") && text.includes("œuvrée");
    console.log(accentsOk ? "✔ ACCENTS (É, œ) PRÉSERVÉS DANS LE PDF" : "✘ accents perdus");
  } catch (e) {
    console.log("extraction pdf.js non disponible:", (e as Error).message);
  }

  if (!ok) process.exit(1);
}

main();
