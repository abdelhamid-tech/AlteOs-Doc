// Vérification du PDF Document : blocs Code (police mono + fond) et Encadré (fond + bordure)
import { inflateSync } from "node:zlib";
import { PDFDocument } from "pdf-lib";

async function main() {
  const fs = await import("node:fs/promises");
  const raw = await fs.readFile("/home/z/Downloads/Document sans titre.pdf");
  const latin = raw.toString("latin1");
  const doc = await PDFDocument.load(new Uint8Array(raw));

  // 1. Polices incorporées
  const fontFiles = (latin.match(/FontFile2/g) || []).length;
  const baseFonts = [...new Set(latin.match(/\/BaseFont\s*\/([A-Za-z-]+)/g) || [])];
  // 2. Décompresse les flux de contenu
  let content = "";
  let pos = 0;
  for (;;) {
    const s = latin.indexOf("stream", pos);
    if (s === -1) break;
    const from = s + 6 + (latin[s + 6] === "\r" ? 2 : 1);
    const e = latin.indexOf("endstream", from);
    if (e === -1) break;
    try { content += inflateSync(raw.subarray(from, e)).toString("latin1") + "\n"; } catch {}
    pos = e + 9;
  }
  // Textes affichables (littéraux entre parenthèses, échappements basiques)
  const texts = (content.match(/\((?:\\.|[^\\()])*\)/g) || []).map(t => t.slice(1, -1).replace(/\\(\d{3}|.)/g, (m, g) => g.length === 3 ? String.fromCharCode(parseInt(g, 8)) : g));

  console.log("pages:", doc.getPageCount(), "| polices incorporées:", fontFiles);
  console.log("BaseFonts:", baseFonts.join(" "));
  const hasMono = baseFonts.some(f => /JetBrains|Courier/i.test(f));
  const codeText = texts.find(t => t.includes("conformite"));
  const calloutText = texts.find(t => t.includes("cart critique"));
  const toc1 = texts.find(t => t.includes("1. Contr"));
  const toc2 = texts.find(t => t.includes("2. Analyse"));
  console.log("police mono présente:", hasMono ? "✔ " + baseFonts.find(f => /JetBrains|Courier/i.test(f)) : "✘");
  console.log("texte du bloc Code:", codeText ? "✔ « " + codeText.slice(0, 40) + "… »" : "✘");
  console.log("texte de l'Encadré:", calloutText ? "✔ « " + calloutText.slice(0, 40) + "… »" : "✘");
  console.log("sommaire 1:", toc1 ? "✔" : "✘", "| sommaire 2:", toc2 ? "✔" : "✘");

  // Rectangles de fond : encadré = fond + bordure verticale ; code = fond gris
  const reCount = (content.match(/\bre\b/g) || []).length;
  const fillOps = (content.match(/\brg\b/g) || []).length;
  console.log("opérateurs 're':", reCount, "| remplissages 'rg':", fillOps);

  // Couleurs de fond spécifiques
  const hasCalloutBg = content.includes("0.9803921568627451 0.9529411764705882 0.8941176470588235") || /0\.98.*0\.95.*0\.89/.test(content); // #FBF3E4
  const hasCalloutBorder = /0\.71\d* 0\.47\d* 0\.12\d* rg/.test(content); // #B7791F
  const hasCodeBg = /0\.95\d* 0\.94\d* 0\.92\d* rg/.test(content); // #F4F2ED
  console.log("fond Encadré #FBF3E4:", hasCalloutBg ? "✔" : "✘", "| bordure #B7791F:", hasCalloutBorder ? "✔" : "✘", "| fond Code #F4F2ED:", hasCodeBg ? "✔" : "✘");
}
main().catch((e) => { console.error("ERREUR:", e.message); process.exit(1); });
// DEBUG (exécuté après main) — voir les opérateurs texte
