// Vérifie l'export PDF d'un document avec bloc Checklist :
// cases réellement dessinées + textes + barré des tâches faites.
import { inflateSync } from "node:zlib";
import { PDFDocument } from "pdf-lib";

async function main() {
  const fs = await import("node:fs/promises");
  const raw = await fs.readFile("/home/z/Downloads/Document sans titre (2).pdf");
  const latin = raw.toString("latin1");
  const doc = await PDFDocument.load(new Uint8Array(raw));

  let content = "";
  let pos = 0;
  for (;;) {
    const s = latin.indexOf("stream", pos);
    if (s === -1) break;
    const from = s + 6 + (latin[s + 6] === "\r" ? 2 : 1);
    const e = latin.indexOf("endstream", from);
    if (e === -1) break;
    try {
      content += inflateSync(raw.subarray(from, e)).toString("latin1") + "\n";
    } catch {
      content += latin.slice(from, e) + "\n";
    }
    pos = e + 9;
  }

  const texts: string[] = [];
  for (const m of content.matchAll(/<([0-9A-Fa-f]+)>\s*Tj/g)) texts.push(Buffer.from(m[1], "hex").toString("latin1"));
  for (const m of content.matchAll(/\(([^)]{1,80})\)\s*Tj/g)) texts.push(m[1]);

  const joined = texts.join(" ").replace(/\s+/g, " ");
  const checklistText = joined.includes("Vérifier les exports");
  const titleText = joined.includes("Document sans titre");
  // Cases à cocher : pdf-lib dessine un chemin fermé (m l l l h S) gris + croix jade
  const boxPaths = (content.match(/0\.42 0\.42 0\.4 RG[\s\S]{0,120}?h\nS/g) || []).length;
  const crossLines = (content.match(/0\.05 0\.49 0\.4 RG/g) || []).length;
  // Texte barré (tâche faite) : ligne gris clair 0.64 0.62 0.58
  const strikeLine = /0\.64 0\.62 0\.58 RG/.test(content);

  console.log("pages:", doc.getPageCount());
  console.log("titre présent:", titleText ? "✔" : "✘");
  console.log("texte checklist présent:", checklistText ? "✔" : "✘");
  console.log("cases dessinées (chemins fermés gris):", boxPaths);
  console.log("segments jade (croix cochée):", crossLines, crossLines >= 2 ? "✔ case cochée dessinée" : "✘");
  console.log("barré de la tâche faite:", strikeLine ? "✔" : "✘");
  const ok = titleText && checklistText && crossLines >= 2 && boxPaths >= 1;
  console.log(ok ? "=== CHECKLIST EXPORT PDF VALIDÉ ===" : "=== À CORRIGER ===");
  console.log("textes:", JSON.stringify(joined.slice(0, 120)));
}
main().catch((e) => {
  console.error("ERREUR:", e.message);
  process.exit(1);
});
