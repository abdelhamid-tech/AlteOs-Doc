// Test isolé : drawPageDecor équivalent sur une page vierge.
import { PDFDocument, StandardFonts, degrees, rgb } from "pdf-lib";

async function main() {
  const out = await PDFDocument.create();
  const font = await out.embedFont(StandardFonts.Helvetica);
  const page = out.addPage([595.28, 841.89]);

  const text = "CONFIDENTIEL";
  const size = 44;
  const tw = font.widthOfTextAtSize(text, size);
  const a = 45;
  const rad = (a * Math.PI) / 180;
  const cx = 595.28 / 2;
  const cy = 841.89 / 2;
  const x = cx - (tw / 2) * Math.cos(rad);
  const y = cy - (tw / 2) * Math.sin(rad) - size * 0.32;
  page.drawText(text, { x, y, size, font, color: rgb(0.54, 0.53, 0.51), opacity: 0.14, rotate: degrees(a) });
  page.drawText("Rapport de test AlteOS", { x: 200, y: 810, size: 8.5, font, color: rgb(0.45, 0.45, 0.43) });
  page.drawText("1", { x: 290, y: 16, size: 9, font, color: rgb(0.5, 0.5, 0.48) });

  const bytes = await out.save();
  const latin = Buffer.from(bytes).toString("latin1");
  const { inflateSync } = await import("node:zlib");
  let content = "";
  let pos = 0;
  for (;;) {
    const s = latin.indexOf("stream", pos);
    if (s === -1) break;
    const from = s + 6 + (latin[s + 6] === "\r" ? 2 : 1);
    const e = latin.indexOf("endstream", from);
    if (e === -1) break;
    try {
      content += inflateSync(Buffer.from(bytes).subarray(from, e)).toString("latin1") + "\n";
    } catch {
      content += latin.slice(from, e) + "\n";
    }
    pos = e + 9;
  }
  console.log("CONFIDENTIEL présent:", content.includes("CONFIDENTIEL") ? "✔" : "✘");
  console.log("en-tête présent:", content.includes("Rapport de test AlteOS") ? "✔" : "✘");
  const m = [...content.matchAll(/\(([^)]{2,40})\)\s*Tj/g)].map((x) => x[1]);
  console.log("chaînes Tj:", JSON.stringify(m));
  console.log("EXTRAIT BRUT:", JSON.stringify(content.slice(0, 400)));
}
main();
