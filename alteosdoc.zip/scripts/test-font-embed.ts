/**
 * Test rapide : incorporation d'une police Google (TTF gstatic) dans un PDF
 * via pdf-lib + @pdf-lib/fontkit, avec sous-ensemble.
 */
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";

const TTF_URL =
  "https://fonts.gstatic.com/s/playfairdisplay/v40/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvUDQZNTo_A.ttf";

async function main() {
  const res = await fetch(TTF_URL);
  console.log("fetch:", res.status, res.headers.get("content-type"));
  const buf = new Uint8Array(await res.arrayBuffer());
  console.log("octets:", buf.length, "signature:", buf[0], buf[1], buf[2], buf[3], "(0,1,0,0 = TTF)");

  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  let font;
  try {
    font = await pdf.embedFont(buf, { subset: true });
    console.log("embedFont(subset) OK —", font.name);
  } catch (e) {
    console.log("subset a échoué, tentative sans sous-ensemble:", (e as Error).message);
    font = await pdf.embedFont(buf, { subset: false });
    console.log("embedFont(plain) OK —", font.name);
  }

  const helv = await pdf.embedFont(StandardFonts.Helvetica);
  const page = pdf.addPage([595.28, 841.89]);

  const txt = "Élégance à la française — œuf, à côté,ça marche 42";
  const size = 24;
  const w = font.widthOfTextAtSize(txt, size);
  page.drawText(txt, { x: 40, y: 700, size, font, color: rgb(0.1, 0.1, 0.1) });
  page.drawText(`Playfair Display largeur=${w.toFixed(1)} (Helv=${helv.widthOfTextAtSize(txt, size).toFixed(1)})`, {
    x: 40, y: 660, size: 11, font: helv,
  });

  // hauteur ascender pour vérifier les métriques
  console.log("ascender@24:", font.heightAtSize(size, { descender: false }));

  const bytes = await pdf.save({ useObjectStreams: false });
  await Bun.write("/home/z/my-project/scripts/test-font-embed.pdf", bytes);

  const raw = Buffer.from(bytes).toString("latin1");
  console.log("FontFile2 présent:", raw.includes("FontFile2"));
  console.log("Playfair présent:", raw.includes("Playfair"));
  console.log("écrit: scripts/test-font-embed.pdf", bytes.length, "octets");
}

main().catch((e) => {
  console.error("ÉCHEC:", e);
  process.exit(1);
});
