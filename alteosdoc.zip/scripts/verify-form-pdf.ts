const b64 = (await Bun.file("scripts/form-export-b64.txt").text()).trim().replace(/^"|"$/g, "");
const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
await Bun.write("scripts/form-export.pdf", bytes);
const { PDFDocument } = await import("pdf-lib");
const doc = await PDFDocument.load(bytes);
console.log("Pages:", doc.getPageCount(), "| Titre:", doc.getTitle());
try {
  const form = doc.getForm();
  const fields = form.getFields();
  console.log("Champs AcroForm:", fields.length);
  for (const f of fields) {
    const type = f.constructor.name;
    let val = "";
    try { val = "value" in f ? String((f as any).getText?.() ?? (f as any).isChecked?.()) : ""; } catch {}
    console.log(`  - ${f.getName()} (${type})${val ? " = " + val : ""}`);
  }
} catch (e) {
  console.log("Pas d'AcroForm:", (e as Error).message.slice(0, 60));
}
