// Vérification de l'export Design vague 4 : filigrane, en-tête/pied, numéros, métadonnées, QR + icônes.
// pdf-lib encode les chaînes en hexadécimal (<...> Tj) — décodage complet des flux.
import { inflateSync } from "node:zlib";
import { PDFDocument } from "pdf-lib";

async function main() {
  const fs = await import("node:fs/promises");
  const raw = await fs.readFile("/home/z/Downloads/Design sans titre (2).pdf");
  const latin = raw.toString("latin1");
  const doc = await PDFDocument.load(new Uint8Array(raw));
  const page = doc.getPage(0);
  const { width, height } = page.getSize();

  let content = "";
  let pos = 0;
  for (;;) {
    const s = latin.indexOf("stream", pos);
    if (s === -1) break;
    const from = s + 6 + (latin[s + 6] === "\r" ? 2 : 1);
    const e = latin.indexOf("endstream", from);
    if (e === -1) break;
    const seg = raw.subarray(from, e);
    try {
      content += inflateSync(seg).toString("latin1") + "\n";
    } catch {
      content += latin.slice(from, e) + "\n";
    }
    pos = e + 9;
  }

  // Décode toutes les chaînes hex Tj en texte.
  const hexStrings: string[] = [];
  for (const m of content.matchAll(/<([0-9A-Fa-f]+)>\s*Tj/g)) {
    const b = Buffer.from(m[1], "hex");
    hexStrings.push(b.toString("latin1"));
  }
  const literalStrings: string[] = [];
  for (const m of content.matchAll(/\(([^)]{1,80})\)\s*Tj/g)) literalStrings.push(m[1]);
  const texts = [...hexStrings, ...literalStrings];
  const allText = texts.join("\n") + content;

  const wmFound = texts.some((t) => t.includes("CONFIDENTIEL"));
  const headerFound = texts.some((t) => t.includes("Rapport de test AlteOS"));
  const footerFound = texts.some((t) => t.includes("2026") && t.includes("d\u00e9monstration")) || texts.some((t) => t.includes("\u00a9 2026"));
  const pageNumberFound = texts.some((t) => t.trim() === "1");

  // Opacité du filigrane : /GS-xxx gs dans le flux + /ca 0.14 (flux d'objets décompressé).
  const extGState = /\/GS-\d+\s+gs/.test(content) && /\/ca\s+0\.14/.test(content);
  // Rotation 45° : matrice 0.7071 0.7071 -0.7071 0.7071 ... Tm
  const rotated = /0\.7071\d*\s+0\.7071\d*\s+-0\.7071\d*\s+0\.7071\d*\s+[\d.]+\s+[\d.]+\s+Tm/.test(content);

  const imageCount = (latin.match(/\/Subtype\s*\/Image/g) || []).length;
  const metaAuthor = doc.getAuthor();
  const metaSubject = doc.getSubject();

  console.log("page:", Math.round(width), "x", Math.round(height), "pt");
  console.log("auteur:", metaAuthor, "| sujet:", metaSubject);
  console.log("filigrane CONFIDENTIEL:", wmFound ? "✔ dessiné" : "✘ ABSENT");
  console.log("en-tête:", headerFound ? "✔ dessiné" : "✘ ABSENT");
  console.log("pied de page:", footerFound ? "✔ dessiné" : "✘ ABSENT");
  console.log("numéro de page « 1 »:", pageNumberFound ? "✔ dessiné" : "✘ ABSENT");
  console.log("opacité filigrane (ExtGState /ca 0.14):", extGState ? "✔" : "✘");
  console.log("rotation 45° (Tm 0.7071):", rotated ? "✔" : "✘");
  console.log("images incorporées (QR + icônes):", imageCount);
  console.log("chaînes texte décodées:", JSON.stringify(texts));

  const ok = wmFound && headerFound && footerFound && pageNumberFound && extGState && rotated && imageCount >= 5 && metaAuthor === "Camille Dupont";
  console.log(ok ? "\n=== EXPORT VAGUE 4 VALIDÉ (filigrane + décor + métadonnées + QR + icônes) ===" : "\n=== À CORRIGER ===");
}
main().catch((e) => {
  console.error("ERREUR:", e.message);
  process.exit(1);
});
