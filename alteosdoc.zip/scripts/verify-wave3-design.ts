// Décompresse tous les flux et compte les rectangles dessinés
import { inflateSync } from "node:zlib";
import { PDFDocument } from "pdf-lib";

async function main() {
  const fs = await import("node:fs/promises");
  const raw = await fs.readFile("/home/z/Downloads/Design sans titre.pdf");
  const latin = raw.toString("latin1");
  const doc = await PDFDocument.load(new Uint8Array(raw));
  const page = doc.getPage(0);
  const { width, height } = page.getSize();

  let content = "";
  let pos = 0;
  for (;;) {
    const s = latin.indexOf("stream", pos);
    if (s === -1) break;
    const from = s + 6 + (latin[s + 6] === "\r" ? 2 : 1);
    const e = latin.indexOf("endstream", from);
    if (e === -1) break;
    const seg = raw.subarray(from, e);
    try { content += inflateSync(seg).toString("latin1") + "\n"; } catch { /* pas un flux zippé */ }
    pos = e + 9;
  }

  const reCount = (content.match(/\bm\b/g) || []).length;
  const mRe = (content.match(/\bm\b/g) || []).length;
  const rgOps = (content.match(/ RG\b/g) || []).length;
  console.log("page:", Math.round(width), "x", Math.round(height), "pt | producer:", doc.getProducer());
  console.log("opérateurs re:", reCount, "| mouvements m:", mRe, "| traits RG:", rgOps);
  console.log("extrait contenu:", JSON.stringify(content.slice(0, 260)));
  console.log(reCount === 5 ? "✔ 5 rectangles — l'élément masqué est exclu de l'export" : `✘ attendu 5, trouvé ${reCount}`);
}
main().catch((e) => { console.error("ERREUR:", e.message); process.exit(1); });
