/**
 * AlteOS Docs — Générateur de la table des fichiers TTF Google Fonts.
 * -------------------------------------------------------------------------
 * Interroge l'API CSS2 de Google Fonts avec un User-Agent ancien (Android 2.2)
 * afin d'obtenir des URL TTF plein-jeu (tous glyphes, pas de sous-ensemble
 * unicode-range) directement servies par fonts.gstatic.com.
 *
 * Ces URL sont utilisées UNIQUEMENT au moment de l'export PDF : les octets
 * sont téléchargés dans le navigateur de l'utilisateur puis incorporés au
 * document via pdf-lib + fontkit (aucune donnée ne quitte l'appareil).
 *
 * Auto-correctif : pour chaque famille, essaie plusieurs combinaisons
 * d'axes (ital/gras) et enregistre celles qui réussissent.
 *
 * Sortie : src/lib/fonts-ttf.ts
 * Usage : bun scripts/gen-font-urls.ts
 */

import { GOOGLE_FONTS } from "../src/lib/fonts";

const UA =
  "Mozilla/5.0 (Linux; U; Android 2.2; en-us; Nexus One Build/FRF91) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1";

interface Files {
  r400?: string;
  r700?: string;
  i400?: string;
}

const enc = (family: string) => family.replace(/ /g, "+");

async function fetchCss(cssUrl: string): Promise<string | null> {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await fetch(cssUrl, { headers: { "User-Agent": UA } });
      if (res.ok) return await res.text();
      if (res.status === 400) return null; // combinaison d'axes invalide → pas une erreur réseau
      console.warn(`  HTTP ${res.status} sur ${cssUrl}`);
      return null;
    } catch (e) {
      if (attempt === 2) {
        console.warn(`  réseau: ${(e as Error).message}`);
        return null;
      }
      await Bun.sleep(400);
    }
  }
  return null;
}

interface Face {
  style: string;
  weight: number;
  url: string;
}

function parseFaces(css: string): Face[] {
  const faces: Face[] = [];
  const re = /font-style:\s*(\w+);\s*font-weight:\s*(\d+);[\s\S]*?src:\s*url\(([^)]+)\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(css))) {
    faces.push({ style: m[1], weight: Number(m[2]), url: m[3] });
  }
  return faces;
}

/** Vérifie qu'une URL sert bien un fichier de police (TTF/OTF) — téléchargement complet
 *  (les requêtes Range provoquent une erreur de décompression dans Bun). */
async function verifyFontUrl(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, { headers: { "User-Agent": UA } });
    if (!res.ok) return false;
    const buf = new Uint8Array(await res.arrayBuffer());
    if (buf.length < 1024) return false; // trop petit pour une police
    const isTtf = buf[0] === 0x00 && buf[1] === 0x01 && buf[2] === 0x00 && buf[3] === 0x00;
    const isOtf = buf[0] === 0x4f && buf[1] === 0x54 && buf[2] === 0x54 && buf[3] === 0x4f; // 'OTTO'
    return isTtf || isOtf;
  } catch {
    return false;
  }
}

async function resolveFamily(family: string): Promise<Files | null> {
  const combos = [
    `https://fonts.googleapis.com/css2?family=${enc(family)}:ital,wght@0,400;0,700;1,400&display=swap`,
    `https://fonts.googleapis.com/css2?family=${enc(family)}:ital,wght@0,400;1,400&display=swap`,
    `https://fonts.googleapis.com/css2?family=${enc(family)}:wght@400;700&display=swap`,
    `https://fonts.googleapis.com/css2?family=${enc(family)}:wght@400&display=swap`,
    `https://fonts.googleapis.com/css2?family=${enc(family)}&display=swap`,
  ];
  for (const url of combos) {
    const css = await fetchCss(url);
    if (!css) continue;
    const faces = parseFaces(css);
    if (faces.length === 0) continue;
    const files: Files = {};
    for (const f of faces) {
      if (f.style === "normal" && f.weight === 400) files.r400 = f.url;
      if (f.style === "normal" && f.weight === 700) files.r700 = f.url;
      if (f.style === "italic" && f.weight === 400) files.i400 = f.url;
    }
    if (!files.r400 && faces.length > 0) {
      // certaines familles n'exposent pas 400 en premier — prend le premier normal
      const anyNormal = faces.find((f) => f.style === "normal");
      if (anyNormal) files.r400 = anyNormal.url;
    }
    if (files.r400) return files;
  }
  return null;
}

async function main() {
  console.log(`Résolution de ${GOOGLE_FONTS.length} familles Google Fonts…`);
  const table: Record<string, Files> = {};
  const missing: string[] = [];
  const failedUrls: string[] = [];

  const queue = [...GOOGLE_FONTS];
  const worker = async () => {
    while (queue.length > 0) {
      const font = queue.shift()!;
      const files = await resolveFamily(font.id);
      if (!files) {
        missing.push(font.id);
        console.log(`✗ ${font.id} — indisponible`);
        continue;
      }
      // Vérifie chaque URL, retire celles qui ne servent pas de police valide
      const ok: Files = {};
      const checks: [keyof Files, string | undefined][] = [
        ["r400", files.r400],
        ["r700", files.r700],
        ["i400", files.i400],
      ];
      for (const [key, url] of checks) {
        if (!url) continue;
        if (await verifyFontUrl(url)) {
          ok[key] = url;
        } else {
          failedUrls.push(`${font.id}:${key}`);
        }
      }
      if (ok.r400 || ok.r700 || ok.i400) {
        table[font.id] = ok;
        const parts = [ok.r400 && "400", ok.r700 && "700", ok.i400 && "i"].filter(Boolean).join("·");
        console.log(`✓ ${font.id} (${parts})`);
      } else {
        missing.push(font.id);
        console.log(`✗ ${font.id} — aucune URL valide`);
      }
    }
  };

  await Promise.all(Array.from({ length: 6 }, worker));

  const withItalic = Object.values(table).filter((f) => f.i400).length;
  const withBold = Object.values(table).filter((f) => f.r700).length;
  console.log("\n———————————————————————————————————————");
  console.log(`Familles résolues : ${Object.keys(table).length}/${GOOGLE_FONTS.length}`);
  console.log(`Avec graisse 700  : ${withBold}`);
  console.log(`Avec italique     : ${withItalic}`);
  if (missing.length) console.log(`MANQUANTES        : ${missing.join(", ")}`);
  if (failedUrls.length) console.log(`URLs rejetées     : ${failedUrls.join(", ")}`);

  // Écriture du module
  const lines: string[] = [];
  lines.push(`/**`);
  lines.push(` * AlteOS Docs — Fichiers TTF Google Fonts (GÉNÉRÉ AUTOMATIQUEMENT)`);
  lines.push(` * Généré par scripts/gen-font-urls.ts le ${new Date().toISOString().slice(0, 10)}.`);
  lines.push(` * `);
  lines.push(` * URL TTF plein-jeu servies par fonts.gstatic.com. Utilisées uniquement`);
  lines.push(` * lors de l'export PDF : les octets sont téléchargés dans le navigateur`);
  lines.push(` * puis incorporés au document (pdf-lib + fontkit). Aucun envoi de données.`);
  lines.push(` * N'éditez pas ce fichier à la main — relancez le script.`);
  lines.push(` */`);
  lines.push(``);
  lines.push(`export interface GoogleFontFiles {`);
  lines.push(`  r400?: string;`);
  lines.push(`  r700?: string;`);
  lines.push(`  i400?: string;`);
  lines.push(`}`);
  lines.push(``);
  lines.push(`export const GOOGLE_TTF: Record<string, GoogleFontFiles> = {`);
  for (const font of GOOGLE_FONTS) {
    const files = table[font.id];
    if (!files) continue;
    const parts: string[] = [];
    if (files.r400) parts.push(`r400: "${files.r400}"`);
    if (files.r700) parts.push(`r700: "${files.r700}"`);
    if (files.i400) parts.push(`i400: "${files.i400}"`);
    lines.push(`  ${JSON.stringify(font.id)}: { ${parts.join(", ")} },`);
  }
  lines.push(`};`);
  lines.push(``);
  lines.push(`/** Familles Google annoncées mais introuvables via l'API — exclues du sélecteur. */`);
  lines.push(`export const MISSING_GOOGLE_FONTS: string[] = ${JSON.stringify(missing)};`);
  lines.push(``);
  const out = lines.join("\n");
  await Bun.write("src/lib/fonts-ttf.ts", out);
  console.log(`\nÉcrit : src/lib/fonts-ttf.ts (${(out.length / 1024).toFixed(1)} Ko)`);

  if (missing.length > 5) {
    console.error("TROP de familles manquantes — vérifier le réseau ou les noms.");
    process.exit(1);
  }
}

main();
