const b64 = (await Bun.file("scripts/design-export-b64.txt").text()).trim().replace(/^"|"$/g, "");
const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
await Bun.write("scripts/design-export.pdf", bytes);
const { PDFDocument } = await import("pdf-lib");
const doc = await PDFDocument.load(bytes);
console.log("Pages:", doc.getPageCount(), "| Titre:", doc.getTitle(), "| Format page:", doc.getPage(0).getWidth().toFixed(0) + "x" + doc.getPage(0).getHeight().toFixed(0));
