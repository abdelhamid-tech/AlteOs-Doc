import { PDFDocument } from "pdf-lib";
import { readdirSync } from "fs";
const files = readdirSync("/home/z/Downloads").filter((f) => f.endsWith(".pdf"));
const latest = files.sort()[files.length - 1];
const bytes = await Bun.file(`/home/z/Downloads/${latest}`).arrayBuffer();
const doc = await PDFDocument.load(bytes);
console.log("Fichier:", latest, "| Pages:", doc.getPageCount(), "| Titre:", doc.getTitle());
