import { PDFDocument } from "pdf-lib";
const bytes = await Bun.file("/home/z/Downloads/exemple.pdf").arrayBuffer();
const doc = await PDFDocument.load(bytes);
console.log("Pages:", doc.getPageCount());
doc.getPages().forEach((p, i) => {
  console.log(`  Page ${i + 1}: ${p.getWidth().toFixed(0)}x${p.getHeight().toFixed(0)} rotation=${p.getRotation().angle}°`);
});
console.log("Titre:", doc.getTitle(), "| Producteur:", doc.getProducer());
