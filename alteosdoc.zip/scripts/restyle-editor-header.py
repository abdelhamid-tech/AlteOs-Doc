#!/usr/bin/env python3
"""Remplace l'en-tête de l'éditeur AlteOS par la version Studio Ink (barre premium groupée)."""
import re
import pathlib

PATH = pathlib.Path("/home/z/my-project/src/components/alteos/editor/editor-root.tsx")
src = PATH.read_text(encoding="utf-8")

NEW_HEADER = '''      {/* Barre supérieure — chrome Studio Ink */}
      <header className="aos-topbar flex items-center gap-1.5 px-2 sm:px-3 shrink-0 h-12" data-editor-header>
        <Button variant="ghost" size="icon" className="size-8 shrink-0" onClick={handleClose} aria-label="Fermer l'éditeur et revenir aux documents">
          <ArrowLeft className="size-4" aria-hidden />
        </Button>
        <span className="hidden lg:grid place-items-center text-primary shrink-0" aria-hidden>
          <AlteosMark size={20} />
        </span>
        <Badge variant="outline" className="hidden sm:inline-flex text-[10px] px-1.5 h-auto py-0.5 font-medium shrink-0">
          {KIND_LABEL[doc.kind]}
        </Badge>
        <input
          value={doc.name}
          onChange={(e) => setName(e.target.value)}
          className="bg-transparent border-none outline-none focus:underline decoration-primary/50 underline-offset-4 text-sm font-medium min-w-0 flex-1 truncate rounded px-1 h-8 focus-visible:outline-2 focus-visible:outline-ring"
          aria-label="Nom du document"
          spellCheck={false}
        />
        <SaveState saving={saving} dirty={dirty} savedAt={savedAt} />

        <div className="flex items-center gap-1 shrink-0">
          <TooltipProvider delayDuration={200}>
            {/* Historique */}
            <div className="flex items-center gap-0.5" role="group" aria-label="Historique">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={undo} disabled={past.length === 0} aria-label="Annuler">
                    <Undo2 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Annuler (Ctrl+Z)</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={redo} disabled={future.length === 0} aria-label="Rétablir">
                    <Redo2 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Rétablir (Ctrl+Maj+Z)</TooltipContent>
              </Tooltip>
            </div>

            <span className="w-px h-5 bg-border mx-1 hidden sm:block" aria-hidden />

            {/* Affichage du document */}
            <div className="flex items-center gap-0.5" role="group" aria-label="Affichage du document">
              {(doc.kind === "pdf" || doc.kind === "design") && (
                <>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant={layersOpen ? "secondary" : "ghost"} size="icon" className="size-8" onClick={() => setLayersOpen(!layersOpen)} aria-label="Calques" aria-pressed={layersOpen}>
                        <Layers2 className="size-4" aria-hidden />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Calques</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="size-8" onClick={() => setReadingOpen(true)} aria-label="Mode lecture">
                        <Presentation className="size-4" aria-hidden />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Mode lecture</TooltipContent>
                  </Tooltip>
                </>
              )}
              {doc.kind === "pdf" && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => setTextDialogOpen(true)} aria-label="Texte du PDF">
                      <BookOpenText className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Texte du PDF</TooltipContent>
                </Tooltip>
              )}
              {(doc.kind === "document" || isForm) && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => setFindOpen(true)} aria-label="Rechercher et remplacer">
                      <BookOpenText className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Rechercher (Ctrl+F)</TooltipContent>
                </Tooltip>
              )}
              {(doc.kind === "pdf" || doc.kind === "design") && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8 hidden md:inline-flex" onClick={copyCurrentPageAsImage} aria-label="Copier la page en image">
                      <Copy className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Copier la page en image</TooltipContent>
                </Tooltip>
              )}
            </div>

            <span className="w-px h-5 bg-border mx-1 hidden md:block" aria-hidden />

            {/* Outils du document */}
            <div className="hidden md:flex items-center gap-0.5" role="group" aria-label="Outils du document">
              {isForm && (
                <Button
                  variant={fillMode ? "default" : "secondary"}
                  size="sm"
                  className="h-8 text-xs"
                  onClick={() => setFillMode((f) => !f)}
                  aria-pressed={fillMode}
                >
                  <PenLine className="size-3.5 mr-1.5" aria-hidden />
                  {fillMode ? "Remplir" : "Modifier"}
                </Button>
              )}
              {(doc.kind === "document" || isForm) && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => setSettingsOpen(true)} aria-label="Réglages du document (en-tête, pied de page)">
                      <PanelRight className="size-4" aria-hidden />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Réglages du document</TooltipContent>
                </Tooltip>
              )}
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => handleAssist("improve")} aria-label="AlteOS Assist">
                    <Sparkles className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>AlteOS Assist</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => setStatsOpen(true)} aria-label="Statistiques du document">
                    <BarChart3 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Statistiques</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => setVersionsOpen(true)} aria-label="Historique de versions">
                    <History className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Versions</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={openSpeak} aria-label="Lecture à voix haute">
                    <Volume2 className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Lecture à voix haute</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={() => setShortcutsOpen(true)} aria-label="Raccourcis clavier">
                    <Keyboard className="size-4" aria-hidden />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Raccourcis clavier</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8" onClick={toggleEditorFullscreen} aria-label="Plein écran">
                    {isFullscreen ? <Minimize className="size-4" aria-hidden /> : <Maximize className="size-4" aria-hidden />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{isFullscreen ? "Quitter le plein écran" : "Plein écran"}</TooltipContent>
              </Tooltip>
            </div>

            <span className="w-px h-5 bg-border mx-1 hidden md:block" aria-hidden />

            {/* Personnaliser + Exporter */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8"
                  onClick={() => setEditorCustomOpen(true)}
                  aria-label="Personnaliser l'éditeur"
                  data-personalize-editor
                >
                  <SlidersHorizontal className="size-4" aria-hidden />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Personnaliser l&apos;éditeur</TooltipContent>
            </Tooltip>
            <Button size="sm" className="h-8" onClick={() => setExportOpen(true)}>
              <FileDown className="size-4 mr-1.5" aria-hidden />
              Exporter
            </Button>
          </TooltipProvider>
        </div>
      </header>
'''

pattern = re.compile(r"      \{/\* Barre sup[ée]rieure \*/\}\n      <header className=\"flex items-center.*?</header>\n", re.DOTALL)
matches = pattern.findall(src)
if len(matches) != 1:
    raise SystemExit(f"ATTENDU 1 bloc header, trouvé {len(matches)} — abandon sans modification")

src = pattern.sub(NEW_HEADER, src, count=1)

# Import du monogramme de marque
if "AlteosMark" not in src.split("export default function")[0]:
    src = src.replace(
        'import { useAppStore } from "@/store/app-store";',
        'import { AlteosMark } from "@/components/alteos/logo";\nimport { useAppStore } from "@/store/app-store";',
        1,
    )

PATH.write_text(src, encoding="utf-8")
print("En-tête remplacé : OK")
