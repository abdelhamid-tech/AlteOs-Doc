/**
 * Génère src/lib/icon-paths.ts à partir des définitions officielles de
 * lucide-react (ISC) installées dans node_modules — tracés SVG exacts,
 * aucune invention. Chaque icône = liste d'éléments [tag, attrs].
 * Exécution : bun run scripts/gen-icon-paths.ts
 */
import { readdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";

// Icônes sélectionnées (nom de fichier dans dist/esm/icons/*.js, kebab-case).
const WANTED = [
  // Navigation & interface
  "arrow-left", "arrow-right", "arrow-up", "arrow-down", "house", "search", "settings", "menu", "x", "check", "plus", "minus",
  // Communication
  "mail", "phone", "link", "share-2", "message-circle", "send", "bell", "at-sign", "rss",
  // Documents & bureautique
  "file-text", "file", "files", "folder", "clipboard-list", "clipboard-check", "notebook-pen", "pen-line", "pencil", "eraser", "highlighter", "book-open", "bookmark", "paperclip", "printer", "stamp", "scale",
  // Médias
  "camera", "image", "film", "music", "mic", "headphones", "play", "circle-pause", "circle-stop", "volume-2",
  // Commerce
  "shopping-cart", "tag", "receipt", "credit-card", "wallet", "banknote", "coins", "package", "store", "percent", "gift",
  // Lieux & voyage
  "map-pin", "map", "compass", "globe", "navigation", "plane", "car", "bike", "train-front", "building", "building-2",
  // Tech
  "cpu", "database", "cloud", "wifi", "bluetooth", "battery-full", "plug", "lock", "key", "shield-check", "eye", "code", "terminal", "smartphone", "monitor", "laptop", "tablet",
  // Formes & symboles
  "star", "heart", "award", "trophy", "medal", "crown", "flag", "target", "zap", "flame", "sparkles", "sun", "moon", "cloud-sun", "umbrella",
  // Nature
  "leaf", "trees", "flower-2", "bird", "fish", "cat", "dog", "apple", "carrot",
  // Santé
  "heart-pulse", "activity", "stethoscope", "pill", "brain",
  // Divers utiles
  "calendar", "clock", "hourglass", "user", "users", "baby", "graduation-cap", "briefcase", "wrench", "hammer", "ruler", "scissors", "lightbulb", "bomb", "rocket", "anchor", "guitar",
];

const DIR = "node_modules/lucide-react/dist/esm/icons";

interface IconNode {
  tag: string;
  attrs: Record<string, string>;
}

function parseIconNode(source: string): IconNode[] | null {
  const marker = "const __iconNode = ";
  const i = source.indexOf(marker);
  if (i === -1) return null;
  const rest = source.slice(i + marker.length);
  // Trouve le crochet fermant de premier niveau.
  let depth = 0;
  let end = -1;
  let inStr: string | null = null;
  for (let k = 0; k < rest.length; k++) {
    const ch = rest[k];
    if (inStr) {
      if (ch === "\\") { k++; continue; }
      if (ch === inStr) inStr = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inStr = ch; continue; }
    if (ch === "[" || ch === "{") depth++;
    if (ch === "]" || ch === "}") {
      depth--;
      if (depth === 0) { end = k + 1; break; }
    }
  }
  if (end === -1) return null;
  let literal = rest.slice(0, end).replace(/,(\s*[\]}])/g, "$1");
  // Les littéraux lucide utilisent des clés non quotées (JS, pas JSON) :
  // on les quotte avant JSON.parse.
  literal = literal.replace(/([{,]\s*)([a-zA-Z_$][\w$]*)\s*:/g, '$1"$2":');
  try {
    const nodes = JSON.parse(literal) as [string, Record<string, string>][];
    return nodes.map(([tag, attrs]) => ({ tag, attrs }));
  } catch {
    return null;
  }
}

function nodesToSvgData(nodes: IconNode[]): string | null {
  // Reconstruit les attributs en syntaxe SVG (les clés lucide sont déjà camelCase
  // compatibles SVG sauf key, inutile ici).
  const parts: string[] = [];
  for (const { tag, attrs } of nodes) {
    const a = Object.entries(attrs)
      .filter(([k]) => k !== "key")
      .map(([k, v]) => `${k}="${v}"`)
      .join(" ");
    parts.push(`<${tag} ${a}/>`);
  }
  return parts.length ? parts.join("") : null;
}

async function main() {
  const files = await readdir(DIR);
  const fileSet = new Set(files.map((f) => f.replace(/\.js$/, "")));
  const wanted = [...new Set(WANTED.map((w) => w.trim()).filter(Boolean))].filter((w) => fileSet.has(w));
  const missing = WANTED.filter((w) => !fileSet.has(w));
  if (missing.length) console.log("Introuvables (ignorées) :", missing.join(", "));

  const entries: { id: string; label: string; svg: string }[] = [];
  const seen = new Set<string>();
  for (const id of wanted) {
    if (seen.has(id)) continue;
    seen.add(id);
    const src = await readFile(join(DIR, `${id}.js`), "utf8");
    const nodes = parseIconNode(src);
    if (!nodes) {
      console.log("Échec parsing :", id);
      continue;
    }
    const svg = nodesToSvgData(nodes);
    if (!svg) continue;
    const label = id
      .split("-")
      .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
      .join(" ");
    entries.push({ id, label, svg });
  }

  const out = `/**
 * AlteOS Docs — Registre d'icônes vectorielles (vagues 4)
 * --------------------------------------------------------
 * Généré depuis lucide v0.525 (licence ISC — libre d'utilisation)
 * par scripts/gen-icon-paths.ts. ${entries.length} icônes curatées.
 * Chaque entrée = fragments SVG (viewBox 0 0 24 24, trait 2, sans remplissage).
 * Utilisé pour le rendu éditeur (SVG inline) ET l'export PDF (drawSvgPath).
 */

export interface IconDef {
  id: string;
  label: string;
  /** Fragments SVG ("<path .../>...") dans le viewBox 24×24. */
  svg: string;
}

export const ICONS: IconDef[] = [
${entries.map((e) => `  ${JSON.stringify({ id: e.id, label: e.label, svg: e.svg })},`).join("\n")}
];

export const ICON_MAP: Map<string, IconDef> = new Map(ICONS.map((i) => [i.id, i]));

const SVG_NS = "http://www.w3.org/2000/svg";

/** SVG complet et autonome (réservé au rendu navigateur : éditeur, rastérisation export). */
export function iconFullSvg(id: string, color: string): string | null {
  const def = ICON_MAP.get(id);
  if (!def) return null;
  return (
    '<svg xmlns="' + SVG_NS + '" viewBox="0 0 24 24" fill="none" stroke="' + color +
    '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + def.svg + "</svg>"
  );
}
`;
  await writeFile("src/lib/icon-paths.ts", out, "utf8");
  console.log(`Généré src/lib/icon-paths.ts — ${entries.length} icônes.`);
}

main();
